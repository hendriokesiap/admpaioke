/**
 * Data Default & Struktur Rincian Minggu Efektif (RME)
 * Mata Pelajaran Pendidikan Agama Islam dan Budi Pekerti SD
 * Sesuai Standar Kurikulum Merdeka
 */

export interface PekanBulan {
  bulan: string;
  jmlMinggu: number;
  tidakEfektif: number;
  efektif: number;
  keterangan: string;
}

export interface RmeData {
  bebanJpPerMinggu: number;
  ganjil: PekanBulan[];
  genap: PekanBulan[];
  cadanganGanjil: number;
  cadanganGenap: number;
  catatanDistribusi: string;
}

export const DEFAULT_RME_DATA: RmeData = {
  bebanJpPerMinggu: 3,
  ganjil: [
    {
      bulan: "Juli",
      jmlMinggu: 4,
      tidakEfektif: 2,
      efektif: 2,
      keterangan: "Libur Akhir Tahun Ajaran & Masa Pengenalan Lingkungan Sekolah (MPLS)"
    },
    {
      bulan: "Agustus",
      jmlMinggu: 5,
      tidakEfektif: 1,
      efektif: 4,
      keterangan: "Peringatan HUT Kemerdekaan RI Ke-79 & Lomba Kemerdekaan"
    },
    {
      bulan: "September",
      jmlMinggu: 4,
      tidakEfektif: 1,
      efektif: 3,
      keterangan: "Asesmen Sumatif Tengah Semester (STS) Ganjil"
    },
    {
      bulan: "Oktober",
      jmlMinggu: 5,
      tidakEfektif: 0,
      efektif: 5,
      keterangan: "Efektif KBM PAI dan Budi Pekerti Penuh"
    },
    {
      bulan: "November",
      jmlMinggu: 4,
      tidakEfektif: 0,
      efektif: 4,
      keterangan: "Efektif KBM PAI dan Budi Pekerti Penuh"
    },
    {
      bulan: "Desember",
      jmlMinggu: 4,
      tidakEfektif: 4,
      efektif: 0,
      keterangan: "Asesmen Sumatif Akhir Semester (SAS), Pengolahan Rapor, dan Libur Semester Ganjil"
    }
  ],
  genap: [
    {
      bulan: "Januari",
      jmlMinggu: 5,
      tidakEfektif: 1,
      efektif: 4,
      keterangan: "Libur Awal Tahun Baru & Persiapan KBM Semester Genap"
    },
    {
      bulan: "Februari",
      jmlMinggu: 4,
      tidakEfektif: 1,
      efektif: 3,
      keterangan: "Peringatan Isra' Mi'raj & Pembiasaan Salat"
    },
    {
      bulan: "Maret",
      jmlMinggu: 4,
      tidakEfektif: 2,
      efektif: 2,
      keterangan: "Libur Awal Ramadan & Asesmen Sumatif Tengah Semester (STS) Genap"
    },
    {
      bulan: "April",
      jmlMinggu: 5,
      tidakEfektif: 2,
      efektif: 3,
      keterangan: "Libur Hari Raya Idul Fitri & Cuti Bersama Nasional"
    },
    {
      bulan: "Mei",
      jmlMinggu: 4,
      tidakEfektif: 1,
      efektif: 3,
      keterangan: "Asesmen Sumatif Akhir Tahun (SAT/SAS) & Asesmen Jenjang"
    },
    {
      bulan: "Juni",
      jmlMinggu: 4,
      tidakEfektif: 3,
      efektif: 1,
      keterangan: "Pengolahan Nilai Rapor, Pembagian Rapor, dan Libur Kenaikan Kelas"
    }
  ],
  cadanganGanjil: 6,
  cadanganGenap: 6,
  catatanDistribusi: "Alokasi jam pembelajaran didistribusikan secara proporsional sesuai keluasan lingkup materi Capaian Pembelajaran (CP) dan Alur Tujuan Pembelajaran (ATP) tiap bab."
};
