import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  Download,
  Printer,
  Calendar,
  Layers,
  Sparkles,
  ExternalLink,
  Copy,
  Clock,
  CheckCircle2,
  ListOrdered,
  FileText,
  ChevronRight,
  BookCheck,
  Award
} from 'lucide-react';

export interface TabMateriPembelajaranProps {
  modules: any[];
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  alokasiJpDefault?: 3 | 4;
  setAlokasiJpDefault?: (val: 3 | 4) => void;
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
  setActiveTab?: (tab: string) => void;
  setSelectedKelas?: (kls: string) => void;
  setSelectedSemester?: (sem: string) => void;
  setActiveModulId?: (id: string) => void;
}

export const TabMateriPembelajaran: React.FC<TabMateriPembelajaranProps> = ({
  modules,
  identitas,
  alokasiJpDefault = 3,
  setAlokasiJpDefault,
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat,
  setActiveTab,
  setSelectedKelas,
  setSelectedSemester,
  setActiveModulId
}) => {
  // State Filter
  const [filterKelas, setFilterKelas] = useState<string>("I");
  const [filterSemester, setFilterSemester] = useState<string>("I (Ganjil)");
  const [searchKeyword, setSearchKeyword] = useState<string>("");
  const [viewMode, setViewMode] = useState<"card" | "table">("card");

  // Helper judul Bab rapi
  const getBabTitle = (mod: any) => {
    if (mod.bab && !mod.bab.includes("undefined")) return mod.bab;
    return `Bab ${mod.nomor}: ${mod.elemen || "PAI & BP"}`;
  };

  // Helper materi pokok per pertemuan
  const getSubTopic = (pert: any, mod: any) => {
    if (!pert) return mod.tp || "Materi Pembelajaran";
    if (pert.judul) {
      const match = pert.judul.match(/^Pertemuan\s+Ke-\d+\s*\((.*)\)$/);
      if (match && match[1]) return match[1];
      return pert.judul;
    }
    return mod.tp || "Materi Pembelajaran";
  };

  // Data Terfilter
  const filteredModules = useMemo(() => {
    return modules.filter((m) => {
      const matchKelas = filterKelas === "Semua" || m.kelas === filterKelas;
      const matchSemester = filterSemester === "Semua" || m.semester === filterSemester;
      const babStr = getBabTitle(m).toLowerCase();
      const tpStr = (m.tp || "").toLowerCase();
      const elemenStr = (m.elemen || "").toLowerCase();
      const subsStr = (m.pertemuan || []).map((p: any) => p.judul || "").join(" ").toLowerCase();
      const q = searchKeyword.toLowerCase();
      const matchSearch = !searchKeyword || babStr.includes(q) || tpStr.includes(q) || elemenStr.includes(q) || subsStr.includes(q);
      return matchKelas && matchSemester && matchSearch;
    });
  }, [modules, filterKelas, filterSemester, searchKeyword]);

  // Statistik Ringkas
  const stats = useMemo(() => {
    const totalBab = filteredModules.length;
    const totalPertemuan = filteredModules.reduce((acc, cur) => acc + (cur.pertemuan?.length || 1), 0);
    const totalJp = totalPertemuan * alokasiJpDefault;
    return { totalBab, totalPertemuan, totalJp };
  }, [filteredModules, alokasiJpDefault]);

  const handleCopyMateriText = (mod: any) => {
    const babName = getBabTitle(mod);
    const pertList = (mod.pertemuan || []).map((p: any, idx: number) => {
      return `   • Pertemuan ${idx + 1}: ${getSubTopic(p, mod)}`;
    }).join("\n");

    const text = `*${babName} (Kelas ${mod.kelas} - ${mod.semester})*\n` +
      `Elemen: ${mod.elemen}\n` +
      `Alokasi: ${mod.pertemuan?.length || 1} x ${alokasiJpDefault} JP (${(mod.pertemuan?.length || 1) * alokasiJpDefault} JP)\n` +
      `Tujuan Pembelajaran: ${mod.tp}\n` +
      `Rincian Materi Pertemuan:\n${pertList}\n` +
      `Asesmen: ${mod.asesmen || "Formatif & Sumatif"}`;

    navigator.clipboard.writeText(text);
    showToast(`Materi ${babName} berhasil disalin ke clipboard!`);
  };

  return (
    <div className="space-y-6">
      {/* Toolbar Filter & Header Menu Materi */}
      <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-5 no-print text-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>Silabus &amp; Ruang Lingkup Materi Kurikulum Merdeka</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
              <BookOpen className="w-5 h-5 text-emerald-700" />
              <span>Daftar Materi Pokok, Bab &amp; Rincian Pertemuan PAI &amp; BP</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5 font-medium">
              Struktur lengkap Bab pembelajaran, alokasi pertemuan tatap muka, dan materi per pertemuan terintegrasi dengan 78 Modul Ajar dan PROMES.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Toggle 3 JP / 4 JP */}
            <div className="flex items-center gap-1 bg-emerald-50 border border-emerald-300 p-1 rounded-xl">
              <span className="text-[11px] font-bold text-emerald-950 px-1.5">Alokasi:</span>
              {([3, 4] as const).map((jp) => (
                <button
                  key={jp}
                  type="button"
                  onClick={() => setAlokasiJpDefault && setAlokasiJpDefault(jp)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                    alokasiJpDefault === jp
                      ? "bg-[#065f46] text-white shadow-xs"
                      : "text-emerald-900 hover:bg-emerald-200/60"
                  }`}
                >
                  {jp} JP
                </button>
              ))}
            </div>

            {/* Toggle Tampilan Kartu vs Tabel Dokumen */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-300">
              <button
                type="button"
                onClick={() => setViewMode("card")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewMode === "card"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Kartu Bab</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode("table")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewMode === "table"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Lembar Cetak A4</span>
              </button>
            </div>

            <button
              onClick={() =>
                handleDownloadWord(
                  "printable-materi-area",
                  `Materi_Pembelajaran_PAI_Kelas_${filterKelas}_Sem_${filterSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                  false
                )
              }
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Word (.doc)</span>
            </button>

            <button
              onClick={() =>
                handlePrintDocument(
                  "printable-materi-area",
                  `Materi_PAI_Kelas_${filterKelas}_Sem_${filterSemester.split(" ")[0]}`,
                  "portrait"
                )
              }
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Cetak / PDF (A4)</span>
            </button>
          </div>
        </div>

        {/* Filter Baris: Kelas, Semester, Pencarian, Ringkasan */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
          {/* Filter Kelas */}
          <div className="lg:col-span-4">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              Pilih Kelas:
            </label>
            <div className="grid grid-cols-7 gap-1">
              {["Semua", "I", "II", "III", "IV", "V", "VI"].map((kls) => (
                <button
                  key={kls}
                  onClick={() => setFilterKelas(kls)}
                  className={`py-2 px-1 text-center rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    filterKelas === kls
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                      : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                  }`}
                >
                  {kls}
                </button>
              ))}
            </div>
          </div>

          {/* Filter Semester */}
          <div className="lg:col-span-3">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              Semester:
            </label>
            <div className="grid grid-cols-3 gap-1">
              {["Semua", "I (Ganjil)", "II (Genap)"].map((sem) => (
                <button
                  key={sem}
                  onClick={() => setFilterSemester(sem)}
                  className={`py-2 px-1 text-center rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    filterSemester === sem
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                      : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                  }`}
                >
                  {sem === "Semua" ? "Semua" : sem.split(" ")[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Cari Bab / Materi */}
          <div className="lg:col-span-3">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              Cari Judul Bab / Materi:
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-emerald-700 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Cari materi / kata kunci..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-emerald-50/60 border border-emerald-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
              />
            </div>
          </div>

          {/* Ringkasan Statistik */}
          <div className="lg:col-span-2 grid grid-cols-2 gap-1.5">
            <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2 text-center shadow-xs">
              <span className="block text-[9px] text-emerald-900 uppercase font-extrabold">Total Bab</span>
              <span className="text-sm font-extrabold text-emerald-800">{stats.totalBab} Bab</span>
            </div>
            <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2 text-center shadow-xs">
              <span className="block text-[9px] text-teal-900 uppercase font-extrabold">Pertemuan</span>
              <span className="text-sm font-extrabold text-teal-800">{stats.totalPertemuan}x ({stats.totalJp} JP)</span>
            </div>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* TAMPILAN 1: KARTU INTERAKTIF BAB & RINCIAN PERTEMUAN     */}
      {/* ======================================================== */}
      {viewMode === "card" && (
        <div className="space-y-5 no-print">
          {filteredModules.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 text-center border-2 border-dashed border-emerald-300 text-slate-600">
              <BookOpen className="w-10 h-10 text-emerald-600 mx-auto mb-3" />
              <p className="text-sm font-bold text-slate-800">Tidak ada materi pembelajaran yang cocok dengan filter.</p>
              <p className="text-xs text-slate-500 mt-1">Coba ubah kata kunci pencarian atau pilihan tingkat kelas / semester.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredModules.map((mod: any) => {
                const babTitle = getBabTitle(mod);
                const pertList = mod.pertemuan || [];
                const jmlPert = pertList.length || 1;
                const totalJpModul = jmlPert * alokasiJpDefault;

                return (
                  <div
                    key={mod.id}
                    className="bg-white rounded-2xl border-2 border-emerald-300/80 hover:border-emerald-500 shadow-sm transition-all overflow-hidden flex flex-col justify-between"
                  >
                    {/* Header Kartu Bab */}
                    <div className="p-4 sm:p-5 border-b border-emerald-100 bg-[#f4fbf7]">
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2.5 py-0.5 rounded-lg text-xs font-extrabold bg-[#065f46] text-white">
                            Bab {mod.nomor}
                          </span>
                          <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-emerald-100 text-emerald-950 border border-emerald-300">
                            Kelas {mod.kelas} • {mod.semester}
                          </span>
                        </div>
                        <span className="text-[11px] font-extrabold text-emerald-900 bg-white border border-emerald-300 px-2 py-0.5 rounded-lg shadow-xs">
                          {jmlPert} Pertemuan ({totalJpModul} JP)
                        </span>
                      </div>

                      <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                        {babTitle}
                      </h3>
                      <p className="text-xs text-emerald-800 font-bold mt-0.5">
                        Elemen: {mod.elemen} • Fase {mod.fase}
                      </p>
                    </div>

                    {/* Badan Kartu: TP & Rincian Materi Tiap Pertemuan */}
                    <div className="p-4 sm:p-5 space-y-4 flex-1">
                      {/* Tujuan Pembelajaran */}
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                        <span className="text-[10px] font-extrabold text-slate-600 uppercase tracking-wider block mb-1">
                          Tujuan Pembelajaran (TP):
                        </span>
                        <p className="text-xs text-slate-800 leading-relaxed font-medium">
                          {mod.tp}
                        </p>
                      </div>

                      {/* Rincian Judul Materi Tiap Pertemuan */}
                      <div>
                        <span className="text-[10px] font-extrabold text-slate-600 uppercase tracking-wider block mb-2">
                          Rincian Judul Materi per Pertemuan ({jmlPert} Tatap Muka):
                        </span>
                        <div className="space-y-2">
                          {pertList.map((pert: any, pIdx: number) => {
                            const subTopic = getSubTopic(pert, mod);
                            return (
                              <div
                                key={pIdx}
                                className="p-2.5 rounded-xl bg-emerald-50/50 border border-emerald-200/80 hover:bg-emerald-50 transition-colors flex items-start gap-2.5"
                              >
                                <span className="w-6 h-6 rounded-lg bg-emerald-700 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                                  {pIdx + 1}
                                </span>
                                <div className="flex-1 min-w-0">
                                  <div className="text-xs font-bold text-slate-900 leading-snug">
                                    Pertemuan Ke-{pIdx + 1}: <span className="text-emerald-950 font-extrabold">{subTopic}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                                    Alokasi: {alokasiJpDefault} JP • Ice Breaking: {pert.iceBreaking || "Aktivitas pembiasaan Islami"}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Asesmen */}
                      <div className="text-[11px] text-slate-600 border-t border-slate-200 pt-3">
                        <span className="font-bold text-slate-800">Bentuk Asesmen: </span>
                        {mod.asesmen || "Formatif (Observasi & Lembar Kerja) serta Sumatif Lingkup Materi"}
                      </div>
                    </div>

                    {/* Tombol Aksi Bawah */}
                    <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => handleCopyMateriText(mod)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 transition-colors cursor-pointer"
                        title="Salin rincian materi bab ini"
                      >
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        <span>Salin Teks</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        {setActiveTab && (
                          <button
                            type="button"
                            onClick={() => {
                              if (setSelectedKelas) setSelectedKelas(mod.kelas);
                              if (setSelectedSemester) setSelectedSemester(mod.semester);
                              setActiveTab("jurnal-mengajar");
                              showToast(`Membuka Jurnal Mengajar Kelas ${mod.kelas}`);
                            }}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-900 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 transition-colors cursor-pointer"
                          >
                            <BookCheck className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Jurnal</span>
                          </button>
                        )}

                        {setActiveModulId && setActiveTab && (
                          <button
                            type="button"
                            onClick={() => {
                              if (setSelectedKelas) setSelectedKelas(mod.kelas);
                              if (setSelectedSemester) setSelectedSemester(mod.semester);
                              setActiveModulId(mod.id);
                              setActiveTab("modul");
                              showToast(`Membuka Modul Ajar ${mod.nomor} Kelas ${mod.kelas}`);
                            }}
                            className="inline-flex items-center gap-1 px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-[#065f46] hover:bg-emerald-800 shadow-xs transition-colors cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Buka Modul Ajar</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAMPILAN 2: DOKUMEN CETAK RESMI SILABUS & MATERI A4      */}
      {/* ======================================================== */}
      <div
        id="printable-materi-area"
        style={paperLightMode ? { padding: "1.5cm 2.0cm 2.0cm 2.5cm" } : undefined}
        className={`rounded-2xl border p-4 sm:p-8 transition-colors duration-300 ${docContainerClass} ${
          viewMode === "card" ? "hidden print:block" : "block"
        }`}
      >
        {/* Kop Surat Resmi */}
        {useKopSurat && kopSuratUrl && (
          <div className="kop-surat-header mb-4 text-center">
            <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-20 w-full object-contain mx-auto" />
            <div className="kop-surat-divider border-t-2 border-black mt-1.5 mb-3"></div>
          </div>
        )}

        {/* Header Judul Dokumen */}
        <div className="doc-header-box text-center border-b-2 pb-3 mb-4 border-black">
          <h2 className="doc-main-title text-base sm:text-[14pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            DAFTAR RUANG LINGKUP MATERI DAN RINCIAN PERTEMUAN PEMBELAJARAN
          </h2>
          <h3 className="doc-sub-title text-xs sm:text-[12pt] font-bold uppercase tracking-wider text-center text-black" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
          </h3>
          <p className="text-[11pt] font-bold text-center mt-1 uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            KURIKULUM MERDEKA • TAHUN AJARAN {identitas.tahunAjaran}
          </p>
        </div>

        {/* Identitas Dokumen */}
        <div className="identitas-block mb-4 space-y-0.5 text-xs sm:text-[11pt] max-w-2xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Satuan Pendidikan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold uppercase">{identitas.sekolah}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Tingkat Kelas / Fase</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {filterKelas === "Semua" ? "Kelas I s.d. VI" : `Kelas ${filterKelas}`} / Fase {filteredModules[0]?.fase || "A/B/C"}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Semester / Tahun Ajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {filterSemester === "Semua" ? "Semester I & II" : filterSemester} / {identitas.tahunAjaran}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Alokasi Jam Pelajaran (JP)</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {alokasiJpDefault} JP per Pertemuan (35 Menit/JP)
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Guru Mata Pelajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.guruPai} (NIP. {identitas.nipGuru})</span>
          </div>
        </div>

        {/* Tabel Silabus & Rincian Materi Lengkap */}
        <div className="overflow-x-auto print:overflow-visible">
          <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%' }}>
            <thead>
              <tr className={tableHeaderBgClass}>
                <th className={`border px-2 py-2 text-center font-bold w-[4%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  No
                </th>
                <th className={`border px-3 py-2 text-center font-bold w-[14%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Bab &amp; Elemen
                </th>
                <th className={`border px-3 py-2 text-center font-bold w-[22%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Tujuan Pembelajaran (TP)
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[8%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Alokasi Waktu
                </th>
                <th className={`border px-3 py-2 text-center font-bold w-[34%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Rincian Materi per Pertemuan (Sub-Topik)
                </th>
                <th className={`border px-2.5 py-2 text-center font-bold w-[18%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Bentuk Asesmen &amp; Evaluasi
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredModules.map((mod: any, idx: number) => {
                const babTitle = getBabTitle(mod);
                const pertList = mod.pertemuan || [];
                const jmlPert = pertList.length || 1;
                const totalJp = jmlPert * alokasiJpDefault;

                return (
                  <tr key={mod.id} className="text-[10pt] leading-normal" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                    <td className={`border px-2 py-2 text-center align-top font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'center' }}>
                      {idx + 1}
                    </td>
                    <td className={`border px-2.5 py-2 align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top' }}>
                      <div className="font-bold text-[10.5pt]">{babTitle}</div>
                      <div className="text-[9.5pt] font-semibold text-emerald-950 mt-1">Elemen: {mod.elemen}</div>
                      <div className="text-[9pt] text-slate-700 mt-0.5">Kelas {mod.kelas} • {mod.semester}</div>
                    </td>
                    <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                      <p style={{ margin: 0, padding: 0 }}>{mod.tp}</p>
                    </td>
                    <td className={`border px-2 py-2 text-center align-top font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'center' }}>
                      <div>{jmlPert} Pert.</div>
                      <div className="text-[9pt] font-normal text-slate-700">({jmlPert} x {alokasiJpDefault} JP)</div>
                      <div className="text-[9.5pt] font-bold text-emerald-950 mt-0.5">{totalJp} JP</div>
                    </td>
                    <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                      <div className="space-y-1.5">
                        {pertList.map((pert: any, pIdx: number) => {
                          const subTopic = getSubTopic(pert, mod);
                          return (
                            <div key={pIdx} className="border-b border-slate-200 pb-1 last:border-b-0 last:pb-0">
                              <span className="font-bold text-slate-900">Pertemuan {pIdx + 1} ({alokasiJpDefault} JP): </span>
                              <span className="font-semibold text-emerald-950">{subTopic}</span>
                              <div className="text-[8.5pt] text-slate-600 italic">
                                Aktivitas: {pert.kegiatan || pert.inti?.[0] || "Diskusi, membaca, dan pemahaman bermakna."}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </td>
                    <td className={`border px-2.5 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                      <p style={{ margin: 0, padding: 0 }}>
                        {mod.asesmen || "Asesmen Formatif (Observasi sikap, unjuk kerja membaca lafaz) & Sumatif Lingkup Materi."}
                      </p>
                    </td>
                  </tr>
                );
              })}

              {/* Baris Total / Rekapitulasi */}
              {filteredModules.length > 0 && (
                <tr className="bg-slate-50 font-bold" style={{ backgroundColor: '#f8fafc', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <td colSpan={3} className={`border px-3 py-2 text-right ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'right' }}>
                    Total Alokasi Pembelajaran:
                  </td>
                  <td className={`border px-2 py-2 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {stats.totalJp} JP
                  </td>
                  <td colSpan={2} className={`border px-3 py-2 text-left ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'left' }}>
                    Total {stats.totalBab} Bab Pokok • {stats.totalPertemuan} Pertemuan Tatap Muka
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Tanda Tangan Pengesahan Resmi (Tanpa Garis Kotak) */}
        <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <tbody>
            <tr style={{ border: 'none', background: 'transparent' }}>
              <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
              </td>
              <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru Mata Pelajaran PAI &amp; BP</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
