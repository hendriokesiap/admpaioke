import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  BookOpen,
  FileText,
  Compass,
  Settings,
  Filter,
  Search,
  Clock,
  Layers,
  FileCheck,
  Sparkles,
  Moon,
  Sun,
  Edit3, Save,
  Download,
  Printer,
  Calendar,
  CheckCircle2,
  School,
  BarChart3,
  ExternalLink,
  CalendarRange,
  CalendarDays,
  Award,
  Users,
  RefreshCw,
  TrendingUp,
  Plus,
  Trash2,
  LayoutDashboard,
  Copy,
  Check,
  UploadCloud,
  FileDown,
  RotateCcw,
  CheckSquare,
  Square,
  Share2,
  Database,
  Lock,
  LogOut,
  KeyRound,
  Wifi,
  WifiOff,
  DownloadCloud,
  AlertCircle,
  Eye,
  EyeOff,
  CalendarCheck,
  MoonStar,
  HeartHandshake,
  Menu,
  X,
  BookCheck,
  UserCheck,
  ShieldCheck,
  FileSpreadsheet
} from 'lucide-react';
import { useOnlineStatus } from './useOnlineStatus.ts';
import { usePWAInstall } from './usePWAInstall.ts';
import { DEFAULT_RME_DATA, RmeData, PekanBulan } from './dataMingguEfektif.ts';
import { DEFAULT_PROGRAM_KEAGAMAAN, ProgramKeagamaanData } from './dataProgramKeagamaan.ts';
import { TabMingguEfektif } from './TabMingguEfektif.tsx';
import { TabProgramKeagamaan } from './TabProgramKeagamaan.tsx';
import {
  TabJurnalMengajar,
  DEFAULT_DAFTAR_KELAS,
  DEFAULT_JADWAL_MENGAJAR,
  KelasRombelItem,
  JadwalMengajarItem
} from './TabJurnalMengajar.tsx';
import { TabMateriPembelajaran } from './TabMateriPembelajaran.tsx';
import { TabPenilaian } from './TabPenilaian.tsx';
import { TabAbsensiSiswa } from './TabAbsensiSiswa.tsx';
import { TabUploadSiswa } from './TabUploadSiswa.tsx';
import {
  TabHakAksesPengguna,
  UserAccount,
  DEFAULT_USER_ACCOUNTS,
  generateRandomPassword5,
  RegisteredSchool,
  DEFAULT_REGISTERED_SCHOOLS,
  getTodayPassword,
  isValidDailyPassword,
  isMatchedAdmin,
  findMatchedSchool,
  DEFAULT_MENU_PERMISSIONS,
  APP_MENU_DEFINITIONS
} from './TabHakAksesPengguna.tsx';

// ==========================================
// DATA STANDAR PENDAHULUAN & PENUTUP
// ==========================================
const makePendahuluan = (fokusMateri, iceBreaking = "tepuk semangat") => [
  "Murid menjawab salam pembuka dari guru dilanjutkan dengan pembukaan pembelajaran oleh guru. (mindful)",
  "Murid memimpin doa bersama yang dilanjutkan dengan membaca al-Qur’an secara bersama-sama (nama surat sesuai dengan program pembiasaan yang ditentukan sebelumnya). (mindful)",
  "Guru mengecek kehadiran murid dan menanyakan kabar. (mindful)",
  "Guru melakukan apersepsi dengan memberikan pertanyaan terkait materi yang akan dipelajari. (mindful)",
  `Murid melakukan ice breaking ${iceBreaking}. (joyful)`,
  `Guru menyampaikan tujuan pembelajaran dan cakupan materi serta penjelasan uraian kegiatan pembelajaran (${fokusMateri}). (mindful)`,
  "Guru memotivasi murid untuk berpartisipasi aktif agar terbangun sikap pembelajar mandiri. (mindful)"
];

const PENUTUP_STANDAR = [
  "Guru melakukan asesmen terhadap kompetensi dan materi yang telah disampaikan. (produk)",
  "Pada akhir pelajaran, guru dapat memandu aktivitas refleksi murid agar dapat mengemukakan pendapatnya terkait dengan materi pembelajaran yang telah dilaksanakan.",
  "Murid menerima penguatan materi pembelajaran yang disampaikan guru.",
  "Murid menerima informasi berkaitan dengan rencana pembelajaran pada pertemuan berikutnya.",
  "Murid bersama guru menutup pembelajaran dengan berdo’a."
];

// ==========================================
// DATA ALUR TUJUAN PEMBELAJARAN (ATP) FASE A, B, C
// ==========================================
const INITIAL_ATP_DATA = [
  {
    fase: "A",
    kelas: "Kelas I & II",
    elemen: [
      {
        nama: "Al-Qur’an-Hadis",
        cp: "Membaca dan membedakan huruf hijaiah berharakat, huruf hijaiah bersambung, menghafal Surah al-Fātiḥah, beberapa surah pendek Al-Qur’an, dan hadis tentang kebersihan.",
        atp: [
          "Menyebutkan, melafalkan, membaca dan membedakan huruf hijaiah dan harakatnya, huruf hijaiah bersambung.",
          "Menjelaskan dan menghafal Q.S. al-Fatihah, Q.S. al-Ikhlas, Q.S. an-Nas, Q.S. al-Falaq.",
          "Menjelaskan dan menghafal hadis tentang kebersihan."
        ]
      },
      {
        nama: "Akidah",
        cp: "Menjelaskan dan meyakini rukun iman, iman kepada Allah Swt., beberapa asmaulhusna, dan iman kepada malaikat.",
        atp: [
          "Menjelaskan dan meyakini rukun iman, iman kepada Allah Swt. dan iman kepada malaikat.",
          "Menjelaskan dan meyakini Asmaulhusna Ar-Rahman, Ar-Rahim, As-Salam, Al-Mu’min."
        ]
      },
      {
        nama: "Akhlak",
        cp: "Menerapkan akhlak terhadap Allah Swt. dengan menyucikan dan memuji-Nya dan akhlak terhadap diri sendiri.",
        atp: [
          "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan menyucikan dan memuji-Nya.",
          "Menjelaskan dan menerapkan akhlak terhadap diri sendiri (hidup bersih, hidup sehat, dan terbiasa berdoa)."
        ]
      },
      {
        nama: "Fikih",
        cp: "Menerapkan rukun Islam, syahadatain, tata cara bersuci, salat fardu, zikir, dan berdoa setelah salat.",
        atp: [
          "Menjelaskan dan menerapkan rukun Islam, syahadatain.",
          "Menjelaskan, mempraktikkan dan menerapkan tata cara bersuci (wudu, tayamum dan istinja), salat fardu, zikir dan berdoa setelah salat."
        ]
      },
      {
        nama: "Sejarah Peradaban Islam",
        cp: "Menceritakan kisah keteladanan beberapa nabi dan rasul.",
        atp: [
          "Menjelaskan dan menceritakan kisah keteladanan Nabi Adam a.s., Nabi Idris a.s., Nabi Nuh a.s., Nabi Ibrahim a.s."
        ]
      }
    ]
  },
  {
    fase: "B",
    kelas: "Kelas III & IV",
    elemen: [
      {
        nama: "Al-Qur’an-Hadis",
        cp: "Membaca, menulis, dan membedakan huruf hijaiah bersambung; menghafal dan menjelaskan beberapa surah pendek, hadis tentang kewajiban salat dan menjaga hubungan baik dengan sesama.",
        atp: [
          "Membaca, menulis, dan membedakan huruf hijaiah bersambung (praktik bacaan mad tabi'i, izhar halqi, idgam bigunnah, bilagunnah, iklab, dan ikhfa).",
          "Menghafal dan menjelaskan Q.S. al-Kausar; Q.S. An-Nasr.",
          "Menghafal dan menjelaskan hadis tentang kewajiban salat dan menjaga hubungan baik dengan sesama."
        ]
      },
      {
        nama: "Akidah",
        cp: "Menjelaskan dan meyakini sifat-sifat Allah Swt., beberapa asmaulhusna, iman kepada kitab-kitab Allah Swt. dan iman kepada rasul-rasul Allah Swt.",
        atp: [
          "Menjelaskan dan meyakini sifat wajib, mustahil dan jaiz bagi Allah.",
          "Menjelaskan dan meyakini asmaulhusna al-Gaffar, al-Wahhab, al-Fattah, al-Latif.",
          "Menjelaskan dan meyakini iman kepada kitab-kitab Allah dan rasul-Nya."
        ]
      },
      {
        nama: "Akhlak",
        cp: "Menerapkan akhlak terhadap Allah Swt. dengan berbaik sangka kepada-Nya, akhlak terhadap orang tua, keluarga, dan guru.",
        atp: [
          "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan berbaik sangka kepada-Nya.",
          "Menjelaskan dan menerapkan akhlak terhadap orang tua.",
          "Menjelaskan dan menerapkan akhlak terhadap keluarga.",
          "Menjelaskan dan menerapkan akhlak terhadap guru."
        ]
      },
      {
        nama: "Fikih",
        cp: "Menerapkan azan dan ikamah, salat jumat dan salat sunah, menjelaskan balig dan tanggung jawab yang menyertainya (taklīf).",
        atp: [
          "Menjelaskan dan menerapkan azan dan ikamah.",
          "Menjelaskan, mempraktikkan dan menerapkan salat Jum’at dan salat sunah Rawatib, Duha dan Tahajud.",
          "Menjelaskan dan menerapkan balig dan tanggung jawab yang menyertainya (taklīf)."
        ]
      },
      {
        nama: "Sejarah Peradaban Islam",
        cp: "Menceritakan dan menjelaskan kisah Nabi Muhammad saw. sebelum dan sesudah menjadi rasul periode Makkah.",
        atp: [
          "Menceritakan dan menjelaskan kelahiran, masa kanak-kanak, masa remaja, dan pernikahan Nabi Muhammad saw.",
          "Menceritakan dan menjelaskan kisah kerasulan, dakwah periode Makkah, dan hijrah Nabi Muhammad saw."
        ]
      }
    ]
  },
  {
    fase: "C",
    kelas: "Kelas V & VI",
    elemen: [
      {
        nama: "Al-Qur’an-Hadis",
        cp: "Membaca, menulis dan membedakan huruf hijaiah bersambung, menjelaskan beberapa surah pendek dan hadis tentang berbuat baik kepada orangtua, guru dan teman.",
        atp: [
          "Membaca, menulis dan membedakan huruf hijaiah bersambung (praktik bacaan mim sukun, qalqalah, gunnah, tafkhim dan tarkik).",
          "Menjelaskan dan menghafal Q.S. al-‘Asr, Q.S. al-Insyirah.",
          "Menjelaskan dan menerapkan hadis tentang berbuat baik kepada orangtua, guru dan teman."
        ]
      },
      {
        nama: "Akidah",
        cp: "Menjelaskan dan meyakini beberapa asmaulhusna, iman kepada hari akhir, qadāʾ dan qadar.",
        atp: [
          "Menjelaskan dan meyakini Asmaulhusna al-Halim, asy-Syakur, al-Hakim, al-Wadud, al-Waliy, al-Hamid, al-‘Adl, as-Sabur.",
          "Menjelaskan dan meyakini Iman kepada hari akhir, qadāʾ dan qadar."
        ]
      },
      {
        nama: "Akhlak",
        cp: "Menerapkan akhlak terhadap Allah Swt. dengan berdoa dan bertawakal kepada-Nya, akhlak terhadap teman, tetangga, non muslim, hewan, dan tumbuhan.",
        atp: [
          "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan berdoa dan bertawakal kepada-Nya.",
          "Menjelaskan dan menerapkan akhlak terhadap teman, tetangga, non muslim, hewan, dan tumbuhan."
        ]
      },
      {
        nama: "Fikih",
        cp: "Menerapkan puasa wajib dan sunah, makanan dan minuman yang halal dan haram, zakat, infak, sedekah, dan wakaf.",
        atp: [
          "Menjelaskan dan menerapkan puasa wajib dan sunnah, zakat, infak, sedekah dan wakaf.",
          "Menjelaskan dan menerapkan ketentuan makanan dan minuman yang halal dan haram."
        ]
      },
      {
        nama: "Sejarah Peradaban Islam",
        cp: "Menceritakan dan menjelaskan kisah Nabi Muhammad saw. periode Madinah dan khulafaurasyidin.",
        atp: [
          "Menceritakan dan menjelaskan kisah kepemimpinan Nabi Muhammad saw. di Madinah, Perjanjian Hudaibiah, Fathu Makkah, dan Haji Wada.",
          "Menceritakan dan menjelaskan kisah keteladanan al-khulafā al-rāsyidin (Abu Bakar as-Siddiq, Umar bin Khattab, Usman bin Affan, dan Ali bin Abi Talib)."
        ]
      }
    ]
  }
];

// ==========================================
// DATABASE LENGKAP 78 MODUL AJAR (KELAS I - VI, SEM 1 & 2)
// ==========================================
const buildInitialModules = () => {
  const rawConfigs = [
    // KELAS I - SEMESTER I (GANJIL)
    {
      kelas: "I", fase: "A", semester: "I (Ganjil)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Menyebutkan, melafalkan, membaca dan membedakan huruf hijaiah dan harakatnya.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Tes lisan membaca huruf hijaiah berharakat fathah, kasrah, dammah, dan unjuk kartu huruf.",
      subTopik: [
        "Mengenal dan melafalkan huruf hijaiah Alif sampai Ya",
        "Membaca huruf hijaiah berharakat fathah, kasrah, dan dammah",
        "Membedakan bunyi huruf hijaiah berharakat dengan tepat"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "I (Ganjil)", nomor: 2, elemen: "Akidah", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan meyakini enam Rukun Iman sebagai dasar keimanan seorang muslim.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kolaborasi.",
      asesmen: "Tes lisan menyebutkan 6 Rukun Iman secara berurutan dan mewarnai pohon Rukun Iman.",
      subTopik: [
        "Mengenal arti iman dan menyebutkan enam Rukun Iman",
        "Menunjukkan perilaku percaya kepada ciptaan Allah Swt. sebagai wujud rukun iman"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "I (Ganjil)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan menyucikan-Nya (membiasakan basmalah dan hamdalah).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian.",
      asesmen: "Observasi pembiasaan melafalkan Basmalah saat memulai kegiatan dan Hamdalah setelah selesai.",
      subTopik: [
        "Melafalkan kalimah tayibah Basmalah beserta artinya dalam kegiatan sehari-hari",
        "Melafalkan kalimah tayibah Hamdalah dan bersyukur atas nikmat Allah Swt."
      ]
    },
    {
      kelas: "I", fase: "A", semester: "I (Ganjil)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menerapkan lima Rukun Islam serta melafalkan dua kalimah syahadat (syahadatain) dengan benar.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kolaborasi.",
      asesmen: "Unjuk kerja melafalkan Syahadat Tauhid dan Syahadat Rasul beserta artinya.",
      subTopik: [
        "Mengenal dan menyebutkan lima Rukun Islam secara berurutan",
        "Melafalkan Syahadatain (Syahadat Tauhid dan Syahadat Rasul) dengan fasih",
        "Menjelaskan arti Syahadatain dan contoh pengamalannya"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "I (Ganjil)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menceritakan kisah keteladanan Nabi Adam a.s. sebagai manusia pertama.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kemandirian.",
      asesmen: "Bercerita kembali secara singkat kisah Nabi Adam a.s. dan membiasakan meminta maaf bila bersalah.",
      subTopik: [
        "Menceritakan kisah penciptaan Nabi Adam a.s. di surga",
        "Meneladani sikap Nabi Adam a.s. yang segera bertaubat dan meminta maaf saat berbuat salah"
      ]
    },

    // KELAS I - SEMESTER II (GENAP)
    {
      kelas: "I", fase: "A", semester: "II (Genap)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Membaca huruf hijaiah bersambung sederhana serta menjelaskan dan menghafal Q.S. al-Fatihah.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Unjuk kerja hafalan Q.S. al-Fatihah ayat 1–7 dengan makhraj yang benar.",
      subTopik: [
        "Mengenal bentuk huruf hijaiah di awal, tengah, dan akhir kata",
        "Melafalkan dan menghafal Q.S. al-Fatihah ayat 1 sampai 7 dengan tartil",
        "Menjelaskan pesan pokok Q.S. al-Fatihah sebagai induk Al-Qur’an"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "II (Genap)", nomor: 2, elemen: "Akidah", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan meyakini iman kepada Allah Swt. melalui pengamatan terhadap makhluk ciptaan-Nya.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis.",
      asesmen: "Mengelompokkan benda ciptaan Allah Swt. dan buatan manusia melalui lembar kerja.",
      subTopik: [
        "Mengenal Allah Swt. Maha Pencipta langit, bumi, dan seluruh isinya",
        "Cara mencintai Allah Swt. dengan merawat tubuh dan lingkungan"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "II (Genap)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan memuji-Nya (kalimah Subhanallah dan Masyaallah).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi.",
      asesmen: "Tes lisan dan observasi penggunaan kalimah Subhanallah dan Masyaallah.",
      subTopik: [
        "Melafalkan kalimah Subhanallah dan artinya saat melihat kebesaran Allah Swt.",
        "Membiasakan ucapan pujian kepada Allah Swt. dan santun dalam berbicara"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "II (Genap)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan, mempraktikkan, dan menerapkan tata cara bersuci (istinja, wudu, dan tayamum).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Kemandirian.",
      asesmen: "Praktik langsung urutan berwudu dan simulasi tayamum secara tertib.",
      subTopik: [
        "Mengenal arti taharah (bersuci) dan tata cara istinja yang bersih dan sehat",
        "Mempraktikkan urutan rukun dan sunah wudu dengan benar",
        "Mempraktikkan tata cara tayamum sebagai pengganti wudu ketika tidak ada air"
      ]
    },
    {
      kelas: "I", fase: "A", semester: "II (Genap)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menceritakan kisah keteladanan Nabi Idris a.s. yang cerdas dan rajin belajar.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kreativitas.",
      asesmen: "Tes lisan menceritakan keteladanan Nabi Idris a.s. dan penilaian kerapian menulis.",
      subTopik: [
        "Menceritakan kisah Nabi Idris a.s. yang pandai membaca, menulis, dan menjahit",
        "Meneladani semangat rajin belajar dan pantang menyerah dari Nabi Idris a.s."
      ]
    },

    // KELAS II - SEMESTER I (GANJIL)
    {
      kelas: "II", fase: "A", semester: "I (Ganjil)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menghafal Q.S. an-Nas dan Q.S. al-Falaq serta membaca huruf hijaiah bersambung.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Unjuk kerja hafalan Q.S. an-Nas dan Q.S. al-Falaq beserta pesan pokoknya.",
      subTopik: [
        "Membaca dan menghafal Q.S. an-Nas ayat 1–6 dengan tartil",
        "Membaca dan menghafal Q.S. al-Falaq ayat 1–5 dengan tartil",
        "Menjelaskan pesan pokok Q.S. an-Nas dan Q.S. al-Falaq tentang memohon perlindungan kepada Allah Swt."
      ]
    },
    {
      kelas: "II", fase: "A", semester: "I (Ganjil)", nomor: 2, elemen: "Akidah", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan meyakini Asmaulhusna ar-Rahman, ar-Rahim, as-Salam, dan al-Mu’min.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kolaborasi, Kreativitas.",
      asesmen: "Menjodohkan Asmaulhusna dengan artinya dan membuat karya kaligrafi warna.",
      subTopik: [
        "Mengenal arti dan bukti Asmaulhusna ar-Rahman dan ar-Rahim (Maha Pengasih dan Maha Penyayang)",
        "Mengenal arti Asmaulhusna as-Salam dan al-Mu’min serta meneladaninya dengan menebar kedamaian"
      ]
    },
    {
      kelas: "II", fase: "A", semester: "I (Ganjil)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak terhadap diri sendiri melalui perilaku hidup bersih dan hidup sehat.",
      dimensi: "Kesehatan, Kemandirian, Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa.",
      asesmen: "Observasi kerapian diri dan proyek jadwal menjaga kebersihan badan dan pakaian.",
      subTopik: [
        "Menerapkan adab menjaga kebersihan badan, pakaian, dan tempat belajar",
        "Membiasakan pola hidup sehat (makan bergizi, istirahat cukup, dan olahraga) sebagai syukur kepada Allah Swt."
      ]
    },
    {
      kelas: "II", fase: "A", semester: "I (Ganjil)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan, mempraktikkan, dan menerapkan ketentuan salat fardu lima waktu.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kesehatan.",
      asesmen: "Praktik gerakan dan bacaan salat fardu secara berurutan dan tuma'ninah.",
      subTopik: [
        "Mengenal nama-nama salat fardu lima waktu beserta jumlah rakaatnya",
        "Mempraktikkan gerakan salat fardu dari takbiratulihram hingga salam",
        "Melafalkan bacaan salat fardu dengan tertib dan tuma'ninah"
      ]
    },
    {
      kelas: "II", fase: "A", semester: "I (Ganjil)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menceritakan kisah keteladanan Nabi Nuh a.s. yang sabar dan pekerja keras.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kolaborasi.",
      asesmen: "Menceritakan kembali kisah pembuatan bahtera Nabi Nuh a.s. dan sikap sabar berdakwah.",
      subTopik: [
        "Menceritakan kisah dakwah Nabi Nuh a.s. dan pembuatan kapal besar (bahtera)",
        "Meneladani kesabaran, keteguhan iman, dan kerja keras Nabi Nuh a.s."
      ]
    },

    // KELAS II - SEMESTER II (GENAP)
    {
      kelas: "II", fase: "A", semester: "II (Genap)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menghafal Q.S. al-Ikhlas serta hadis tentang kebersihan.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Komunikasi.",
      asesmen: "Unjuk kerja hafalan Q.S. al-Ikhlas dan hadis kebersihan beserta artinya.",
      subTopik: [
        "Melafalkan dan menghafal Q.S. al-Ikhlas ayat 1–4 serta memahami keesaan Allah Swt.",
        "Membaca dan menghafal hadis tentang kebersihan sebagian dari iman",
        "Mempraktikkan pesan hadis kebersihan di kelas dan lingkungan sekolah"
      ]
    },
    {
      kelas: "II", fase: "A", semester: "II (Genap)", nomor: 2, elemen: "Akidah", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan meyakini iman kepada malaikat-malaikat Allah Swt. beserta tugasnya.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis.",
      asesmen: "Tes tertulis/lisan menyebutkan 10 malaikat Allah Swt. dan tugas-tugasnya.",
      subTopik: [
        "Mengenal pengertian malaikat dan menyebutkan 10 nama malaikat Allah Swt. beserta tugasnya",
        "Menunjukkan perilaku jujur dan taat karena yakin selalu diawasi malaikat Raqib dan Atid"
      ]
    },
    {
      kelas: "II", fase: "A", semester: "II (Genap)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak terhadap diri sendiri dengan terbiasa berdoa dalam setiap aktivitas.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian.",
      asesmen: "Praktik melafalkan doa sebelum dan sesudah belajar, makan, serta tidur.",
      subTopik: [
        "Mengenal adab berdoa yang baik dan waktu-waktu utama berdoa",
        "Melafalkan dan membiasakan doa harian (sebelum/sesudah belajar, makan, dan keluar rumah)"
      ]
    },
    {
      kelas: "II", fase: "A", semester: "II (Genap)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan, mempraktikkan, dan menerapkan bacaan zikir dan doa setelah salat fardu.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Unjuk kerja mempraktikkan zikir (istigfar, tasbih, tahmid, takbir) dan doa kedua orang tua setelah salat.",
      subTopik: [
        "Melafalkan bacaan zikir setelah salat (Istigfar, Subhanallah, Alhamdulillah, Allahu Akbar)",
        "Melafalkan doa setelah salat, khususnya doa memohon kebaikan untuk kedua orang tua",
        "Mempraktikkan zikir dan berdoa dengan tertib dan khusyuk seusai salat berjamaah"
      ]
    },
    {
      kelas: "II", fase: "A", semester: "II (Genap)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menceritakan kisah keteladanan Nabi Ibrahim a.s.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Komunikasi.",
      asesmen: "Menceritakan kembali kisah keteguhan iman Nabi Ibrahim a.s. mencari Tuhan dan membangun Ka'bah.",
      subTopik: [
        "Menceritakan kisah masa muda Nabi Ibrahim a.s. menggunakan akal pikiran mencari Tuhan Yang Maha Esa",
        "Meneladani ketaatan dan ketabahan Nabi Ibrahim a.s. dalam menjalankan perintah Allah Swt."
      ]
    },

    // KELAS III - SEMESTER I (GANJIL)
    {
      kelas: "III", fase: "B", semester: "I (Ganjil)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Membaca dan menulis huruf hijaiah bersambung (praktik bacaan mad tabi'i) serta menghafal dan menjelaskan Q.S. al-Kausar.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Unjuk kerja membaca & menghafal Q.S. al-Kausar serta mengidentifikasi bacaan mad tabi'i.",
      subTopik: [
        "Mengenal dan mempraktikkan hukum bacaan Mad Tabi'i dalam ayat Al-Qur’an",
        "Membaca, menulis, dan menghafal Q.S. al-Kausar ayat 1–3 dengan tartil",
        "Menjelaskan kandungan Q.S. al-Kausar tentang perintah salat dan berkurban sebagai wujud syukur"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "I (Ganjil)", nomor: 2, elemen: "Akidah", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan meyakini sifat wajib, sifat mustahil, dan sifat jaiz bagi Allah Swt.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kolaborasi.",
      asesmen: "Tes tertulis dan permainan kartu pasangan Sifat Wajib dan Sifat Mustahil bagi Allah Swt.",
      subTopik: [
        "Mengenal pengertian dan menyebutkan Sifat Wajib bagi Allah Swt. beserta artinya",
        "Mengenal Sifat Mustahil dan Sifat Jaiz bagi Allah Swt.",
        "Menunjukkan perilaku beriman kepada sifat-sifat Allah Swt. dalam kehidupan sehari-hari"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "I (Ganjil)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan berbaik sangka (husnuzan) kepada-Nya.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kesehatan.",
      asesmen: "Analisis studi kasus sederhana tentang sikap optimis, sabar, dan berbaik sangka kepada Allah Swt.",
      subTopik: [
        "Memahami pengertian berbaik sangka (husnuzan) kepada Allah Swt. dan hikmahnya",
        "Menerapkan sikap optimis, bersyukur saat mendapat nikmat, dan bersabar saat menghadapi ujian"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "I (Ganjil)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menerapkan ketentuan azan dan ikamah beserta doa setelah azan.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kemandirian.",
      asesmen: "Unjuk kerja melafalkan azan, ikamah, menjawab azan, dan membaca doa sesudah azan.",
      subTopik: [
        "Memahami pengertian, hukum, dan syarat muazin dalam mengumandangkan azan dan ikamah",
        "Mempraktikkan lafal azan dan ikamah dengan lagu dan makhraj yang baik",
        "Mempraktikkan cara menjawab seruan azan dan menghafal doa setelah azan"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "I (Ganjil)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah kelahiran dan masa kanak-kanak Nabi Muhammad saw.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Menceritakan kembali peristiwa Tahun Gajah, kelahiran, dan kemandirian masa kecil Nabi Muhammad saw.",
      subTopik: [
        "Menceritakan peristiwa kelahiran Nabi Muhammad saw. pada Tahun Gajah di kota Makkah",
        "Meneladani sifat jujur, mandiri, dan kasih sayang masa kanak-kanak Nabi Muhammad saw. dalam asuhan Halimah as-Sa'diyah, Abdul Muthalib, dan Abu Thalib"
      ]
    },

    // KELAS III - SEMESTER II (GENAP)
    {
      kelas: "III", fase: "B", semester: "II (Genap)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan izhar halqi serta menghafal dan menjelaskan hadis tentang kewajiban salat.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Tes lisan hafalan hadis kewajiban salat (Salat tiang agama) dan identifikasi hukum bacaan izhar halqi.",
      subTopik: [
        "Mengenal huruf-huruf halqi dan mempraktikkan bacaan Izhar Halqi dalam Al-Qur’an",
        "Membaca, menulis, dan menghafal hadis tentang salat sebagai tiang agama",
        "Menjelaskan kandungan hadis kewajiban salat dan membiasakan salat tepat waktu"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "II (Genap)", nomor: 2, elemen: "Akidah", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan meyakini iman kepada kitab-kitab Allah Swt. (Taurat, Zabur, Injil, dan Al-Qur’an).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kolaborasi.",
      asesmen: "Membuat bagan/infografis 4 kitab suci Allah Swt. beserta nabi penerimanya.",
      subTopik: [
        "Mengenal empat kitab suci Allah Swt. (Taurat, Zabur, Injil, Al-Qur’an) dan rasul penerimanya",
        "Cara mencintai dan mengamalkan Al-Qur’an sebagai kitab suci penyempurna"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "II (Genap)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak mulia terhadap kedua orang tua (birrul walidain).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kolaborasi.",
      asesmen: "Bermain peran (role playing) adab berbicara sopan, berpamitan, dan membantu orang tua di rumah.",
      subTopik: [
        "Memahami kewajiban menghormati, mematuhi, dan bertutur kata lembut kepada orang tua",
        "Mempraktikkan perilaku berbakti dan mendoakan kedua orang tua setiap hari"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "II (Genap)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan, mempraktikkan, dan menerapkan ketentuan ibadah salat Jum’at.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Kemandirian.",
      asesmen: "Tes pemahaman syarat wajib/sah salat Jum’at dan simulasi tata cara pelaksanaan salat Jum’at.",
      subTopik: [
        "Memahami pengertian, hukum, syarat wajib, dan syarat sah salat Jum’at",
        "Mengenal amalan-amalan sunah sebelum salat Jum’at dan adab mendengarkan khutbah",
        "Mempraktikkan tata cara pelaksanaan salat Jum’at berjamaah"
      ]
    },
    {
      kelas: "III", fase: "B", semester: "II (Genap)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah masa remaja dan pernikahan Nabi Muhammad saw.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Menceritakan kisah kejujuran Nabi Muhammad saw. berdagang ke Syam hingga diberi gelar Al-Amin.",
      subTopik: [
        "Menceritakan masa remaja Nabi Muhammad saw. yang giat bekerja, jujur berdagang, dan bergelar Al-Amin",
        "Menceritakan kisah pernikahan Nabi Muhammad saw. dengan Khadijah binti Khuwailid dan kebijaksanaan peletakan Hajar Aswad"
      ]
    },

    // KELAS IV - SEMESTER I (GANJIL)
    {
      kelas: "IV", fase: "B", semester: "I (Ganjil)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan idgam bigunnah dan bilagunnah serta menghafal dan menjelaskan Q.S. an-Nasr.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Unjuk kerja hafalan Q.S. an-Nasr, menulis kaligrafi ayat, dan identifikasi bacaan idgam.",
      subTopik: [
        "Memahami dan mempraktikkan hukum bacaan Idgam Bigunnah dan Idgam Bilagunnah",
        "Membaca, menulis, dan menghafal Q.S. an-Nasr ayat 1–3 dengan tartil",
        "Menjelaskan pesan pokok Q.S. an-Nasr tentang pertolongan Allah Swt., bertasbih, dan beristigfar"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "I (Ganjil)", nomor: 2, elemen: "Akidah", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan meyakini Asmaulhusna al-Gaffar, al-Wahhab, al-Fattah, dan al-Latif.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kreativitas, Kolaborasi.",
      asesmen: "Produk poster kaligrafi Asmaulhusna dan tes tertulis makna serta cara meneladaninya.",
      subTopik: [
        "Memahami makna Asmaulhusna al-Gaffar (Maha Pengampun) dan al-Wahhab (Maha Pemberi Karunia)",
        "Memahami makna Asmaulhusna al-Fattah (Maha Pembuka Rahmat) dan al-Latif (Maha Lembut)",
        "Meneladani sifat pemaaf, dermawan, dan lembut hati dalam pergaulan sehari-hari"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "I (Ganjil)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak mulia terhadap anggota keluarga (kakak, adik, dan kerabat).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kolaborasi, Komunikasi.",
      asesmen: "Proyek jurnal kebaikan di rumah dan refleksi sikap saling menyayangi antaranggota keluarga.",
      subTopik: [
        "Memahami adab menghormati yang lebih tua dan menyayangi yang lebih muda di dalam keluarga",
        "Menerapkan kerja sama, saling menolong, dan menjaga kerukunan di rumah"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "I (Ganjil)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan, mempraktikkan, dan menerapkan salat sunah Rawatib, salat Duha, dan salat Tahajud.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kesehatan.",
      asesmen: "Praktik pelaksanaan salat sunah Duha/Rawatib beserta doanya dan tes pemahaman ketentuan salat sunah.",
      subTopik: [
        "Memahami ketentuan dan keutamaan salat sunah Rawatib (Qabliyah dan Ba'diyah)",
        "Memahami ketentuan, waktu, dan mempraktikkan tata cara salat sunah Duha",
        "Memahami ketentuan dan keutamaan salat sunah Tahajud pada malam hari"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "I (Ganjil)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah kerasulan Nabi Muhammad saw. dan dakwah periode Makkah.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Komunikasi.",
      asesmen: "Presentasi peta kisah turunnya wahyu pertama di Gua Hira dan strategi dakwah sembunyi-sembunyi serta terang-terangan.",
      subTopik: [
        "Menceritakan peristiwa turunnya wahyu pertama (Q.S. al-‘Alaq 1–5) di Gua Hira dan pengangkatan menjadi Rasul",
        "Menjelaskan ketabahan Nabi Muhammad saw. dan para sahabat (Assabiqunal Awwalun) dalam berdakwah di Makkah"
      ]
    },

    // KELAS IV - SEMESTER II (GENAP)
    {
      kelas: "IV", fase: "B", semester: "II (Genap)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan iklab dan ikhfa serta menghafal dan menjelaskan hadis tentang menjaga hubungan baik dengan sesama.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Komunikasi.",
      asesmen: "Unjuk kerja hafalan hadis silaturahmi/persaudaraan dan tes identifikasi bacaan iklab serta ikhfa.",
      subTopik: [
        "Memahami dan mempraktikkan hukum bacaan Iklab dan Ikhfa Haqiqi dalam Al-Qur’an",
        "Membaca, menulis, dan menghafal hadis tentang menjaga hubungan baik (silaturahmi) dengan sesama",
        "Menerapkan isi kandungan hadis dengan menjauhi sikap saling membenci dan memutus persaudaraan"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "II (Genap)", nomor: 2, elemen: "Akidah", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan meyakini iman kepada rasul-rasul Allah Swt. beserta sifat wajib, mustahil, dan jaiz rasul.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kemandirian.",
      asesmen: "Tes tertulis 25 Nabi dan Rasul, Rasul Ulul Azmi, serta 4 sifat wajib rasul (Siddiq, Amanah, Tablig, Fatanah).",
      subTopik: [
        "Mengenal tugas rasul Allah Swt., 25 Nabi dan Rasul, serta gelar Rasul Ulul Azmi",
        "Menjelaskan dan meneladani sifat Siddiq, Amanah, Tablig, dan Fatanah dalam kehidupan sehari-hari"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "II (Genap)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak mulia terhadap guru di sekolah maupun di lingkungan masyarakat.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kolaborasi.",
      asesmen: "Observasi sikap santun kepada guru, bermain peran adab bertanya, dan membuat kartu ucapan terima kasih guru.",
      subTopik: [
        "Memahami kedudukan mulia guru sebagai pewaris ilmu dan orang tua kedua di sekolah",
        "Mempraktikkan adab memberi salam, mendengarkan penjelasan dengan saksama, dan mematuhi nasihat guru"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "II (Genap)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan tanda-tanda usia balig menurut ilmu fikih dan biologi serta tanggung jawab yang menyertainya (taklīf).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Kemandirian.",
      asesmen: "Penyusunan buklet/peta konsep tanda-tanda balig, tata cara mandi wajib, dan kewajiban anak mukallaf.",
      subTopik: [
        "Mengidentifikasi tanda-tanda usia balig bagi laki-laki dan perempuan menurut ilmu fikih dan ilmu biologi",
        "Memahami tata cara bersuci dari hadas besar (mandi wajib/janabah)",
        "Menjelaskan kewajiban dan tanggung jawab (taklīf) sebagai seorang mukallaf dalam beribadah dan menjaga aurat"
      ]
    },
    {
      kelas: "IV", fase: "B", semester: "II (Genap)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah perjalanan hijrah Nabi Muhammad saw. ke Madinah.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kolaborasi, Penalaran Kritis.",
      asesmen: "Menceritakan sebab-sebab, rute perjalanan, dan hikmah peristiwa hijrah Nabi Muhammad saw. ke Yatsrib (Madinah).",
      subTopik: [
        "Menjelaskan sebab-sebab dan persiapan hijrah Nabi Muhammad saw. bersama Abu Bakar as-Siddiq",
        "Meneladani pengorbanan, tawakal, dan semangat perubahan menuju kebaikan dari peristiwa hijrah"
      ]
    },

    // KELAS V - SEMESTER I (GANJIL)
    {
      kelas: "V", fase: "C", semester: "I (Ganjil)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan mim sukun (ikhfa syafawi, idgam mimi, izhar syafawi) serta menjelaskan dan menghafal Q.S. al-‘Asr.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Penalaran Kritis.",
      asesmen: "Unjuk kerja hafalan Q.S. al-‘Asr, analisis hukum bacaan mim sukun, dan proyek jadwal disiplin waktu.",
      subTopik: [
        "Memahami dan mempraktikkan hukum bacaan Mim Sukun (Ikhfa Syafawi, Idgam Mimi, dan Izhar Syafawi)",
        "Membaca, menulis, dan menghafal Q.S. al-‘Asr ayat 1–3 dengan tartil",
        "Menjelaskan pesan pokok Q.S. al-‘Asr tentang menghargai waktu, beramal saleh, serta saling menasihati dalam kebenaran dan kesabaran"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "I (Ganjil)", nomor: 2, elemen: "Akidah", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan meyakini Asmaulhusna al-Halim, asy-Syakur, al-Hakim, dan al-Wadud.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kolaborasi, Kreativitas.",
      asesmen: "Tes tertulis makna Asmaulhusna dan karya kaligrafi/peta konsep perilaku meneladani ke-4 Asmaulhusna.",
      subTopik: [
        "Memahami makna dan bukti Asmaulhusna al-Halim (Maha Penyantun) dan asy-Syakur (Maha Menghargai/Mensyukuri)",
        "Memahami makna dan bukti Asmaulhusna al-Hakim (Maha Bijaksana) dan al-Wadud (Maha Mencintai)",
        "Mengimplementasikan akhlak santun, pandai bersyukur, bijaksana, dan penuh kasih sayang"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "I (Ganjil)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak terhadap Allah Swt. dengan berdoa dan bertawakal kepada-Nya.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Penalaran Kritis.",
      asesmen: "Penilaian studi kasus tentang keseimbangan antara ikhtiar (usaha maksimal), berdoa, dan bertawakal.",
      subTopik: [
        "Memahami hakikat ikhtiar, berdoa, dan bertawakal kepada Allah Swt.",
        "Menunjukkan perilaku gigih belajar, rajin berdoa, dan menyerahkan hasil terbaik kepada Allah Swt."
      ]
    },
    {
      kelas: "V", fase: "C", semester: "I (Ganjil)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menerapkan ketentuan ibadah puasa wajib (Ramadan) dan puasa sunah.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Kemandirian.",
      asesmen: "Tes tertulis syarat/rukun puasa, hal yang membatalkan puasa, macam-macam puasa sunah, serta hikmahnya.",
      subTopik: [
        "Memahami pengertian, syarat wajib, syarat sah, dan rukun puasa wajib di bulan Ramadan",
        "Mengidentifikasi hal-hal yang membatalkan puasa, sunah-sunah puasa, dan orang yang diberi keringanan (rukhsah)",
        "Mengenal macam-macam puasa sunah (Senin-Kamis, Syawal, Arafah, Asyura) beserta hikmah puasa bagi kesehatan dan takwa"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "I (Ganjil)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah kepemimpinan Nabi Muhammad saw. dalam membangun masyarakat Madinah.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Kolaborasi.",
      asesmen: "Presentasi kelompok tentang langkah Nabi Muhammad saw. membangun Masjid Nabawi, mempersaudarakan Muhajirin-Ansar, dan Piagam Madinah.",
      subTopik: [
        "Menjelaskan usaha Nabi Muhammad saw. membangun masjid dan mempersaudarakan kaum Muhajirin dengan kaum Ansar",
        "Meneladani prinsip toleransi, keadilan, dan perdamaian dalam kesepakatan Piagam Madinah"
      ]
    },

    // KELAS V - SEMESTER II (GENAP)
    {
      kelas: "V", fase: "C", semester: "II (Genap)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan qalqalah (sugra dan kubra) serta menjelaskan dan menerapkan hadis tentang berbuat baik kepada orang tua dan guru.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kolaborasi.",
      asesmen: "Praktik membaca ayat berhukum qalqalah dan unjuk kerja hafalan serta pengamalan hadis berbakti kepada orang tua & guru.",
      subTopik: [
        "Mengenal huruf-huruf Qalqalah (Ba, Jim, Dal, Ta, Qaf) dan membedakan Qalqalah Sugra serta Qalqalah Kubra",
        "Membaca dan menghafal hadis tentang rida Allah terletak pada rida orang tua dan memuliakan guru",
        "Menyusun rencana aksi nyata berbuat baik kepada orang tua di rumah dan guru di sekolah"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "II (Genap)", nomor: 2, elemen: "Akidah", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan meyakini iman kepada Hari Akhir (Kiamat) beserta hikmahnya.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kemandirian.",
      asesmen: "Membuat peta konsep tahapan peristiwa Hari Akhir (Yaumul Barzakh, Ba'ats, Mahsyar, Hisab, Mizan, Jaza') dan tes tertulis.",
      subTopik: [
        "Memahami pengertian Hari Akhir serta perbedaan Kiamat Sugra dan Kiamat Kubra",
        "Menjelaskan tahapan perjalanan manusia setelah kematian (Alam Barzakh, Yaumul Ba'ats, Mahsyar, Hisab, dan Mizan)",
        "Menunjukkan perilaku mawas diri, jujur, dan gemar beramal saleh sebagai hikmah beriman kepada Hari Akhir"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "II (Genap)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak mulia terhadap teman dalam kehidupan sehari-hari.",
      dimensi: "Kolaborasi, Komunikasi, Kewargaan.",
      asesmen: "Observasi sikap berteman tanpa membeda-bedakan, anti-perundungan (bullying), dan bermain peran saling menolong.",
      subTopik: [
        "Memahami adab bergaul dengan teman sebaya (saling menghargai, menolong, dan memaafkan)",
        "Menghindari perilaku mengejek, merundung (bullying), dan memaksakan kehendak kepada teman"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "II (Genap)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menerapkan ketentuan makanan dan minuman yang halal dan haram.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Penalaran Kritis.",
      asesmen: "Investigasi label halal kemasan produk pangan dan tes analisis kriteria halal-haram dari segi zat maupun cara memperolehnya.",
      subTopik: [
        "Memahami pengertian dan dasar hukum makanan serta minuman yang halal dan tayib (baik/sehat)",
        "Mengidentifikasi jenis-jenis makanan dan minuman yang haram (karena zatnya maupun cara memperolehnya)",
        "Membiasakan mengonsumsi makanan halal-bergizi dan menjauhi makanan haram dalam kehidupan sehari-hari"
      ]
    },
    {
      kelas: "V", fase: "C", semester: "II (Genap)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah Perjanjian Hudaibiah, Fathu Makkah, dan Haji Wada.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Penalaran Kritis.",
      asesmen: "Tes tertulis dan presentasi nilai perdamaian dalam Perjanjian Hudaibiah, sifat pemaaf saat Fathu Makkah, dan pesan Haji Wada.",
      subTopik: [
        "Menceritakan kronologi dan hikmah diplomasi damai Perjanjian Hudaibiah serta peristiwa Fathu Makkah tanpa pertumpahan darah",
        "Menjelaskan pesan-pesan luhur Nabi Muhammad saw. pada khutbah Haji Wada (Haji Perpisahan)"
      ]
    },

    // KELAS VI - SEMESTER I (GANJIL)
    {
      kelas: "VI", fase: "C", semester: "I (Ganjil)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan gunnah serta menjelaskan dan menghafal Q.S. al-Insyirah.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi.",
      asesmen: "Unjuk kerja hafalan dan tulis Q.S. al-Insyirah ayat 1–8 serta praktik membaca hukum bacaan gunnah (nun/mim bertasydid).",
      subTopik: [
        "Memahami dan mempraktikkan hukum bacaan Gunnah Musyaddadah (Nun dan Mim bertasydid)",
        "Membaca, menulis, dan menghafal Q.S. al-Insyirah ayat 1–8 dengan tartil",
        "Menjelaskan kandungan Q.S. al-Insyirah tentang sikap optimis bahwa bersama kesulitan pasti ada kemudahan"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "I (Ganjil)", nomor: 2, elemen: "Akidah", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan meyakini Asmaulhusna al-Waliy, al-Hamid, al-‘Adl, dan as-Sabur.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Kreativitas.",
      asesmen: "Karya poster kaligrafi dan tes pemahaman pengamalan Asmaulhusna al-Waliy, al-Hamid, al-‘Adl, dan as-Sabur.",
      subTopik: [
        "Memahami makna Asmaulhusna al-Waliy (Maha Melindungi) dan al-Hamid (Maha Terpuji)",
        "Memahami makna Asmaulhusna al-‘Adl (Maha Adil) dan as-Sabur (Maha Sabar)",
        "Meneladani sikap adil, sabar, dan senantiasa memohon perlindungan hanya kepada Allah Swt."
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "I (Ganjil)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak mulia terhadap tetangga dan saudara non-muslim dalam kehidupan bermasyarakat.",
      dimensi: "Kewargaan, Kolaborasi, Komunikasi.",
      asesmen: "Analisis studi kasus toleransi beragama dan proyek aksi peduli tetangga di lingkungan rumah.",
      subTopik: [
        "Memahami hak dan adab berbuat baik kepada tetangga dekat maupun jauh",
        "Menerapkan sikap toleransi (tasamuh), saling menghormati, dan bekerja sama dalam urusan sosial dengan sesama warga termasuk non-muslim"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "I (Ganjil)", nomor: 4, elemen: "Fikih", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan menerapkan ketentuan zakat, infak, dan sedekah sebagai wujud kepedulian sosial.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Penalaran Kritis.",
      asesmen: "Simulasi perhitungan serta penyerahan zakat fitrah, identifikasi 8 asnaf mustahik zakat, dan pembiasaan infak/sedekah.",
      subTopik: [
        "Memahami perbedaan pengertian dan hukum antara Zakat, Infak, dan Sedekah",
        "Menjelaskan ketentuan Zakat Fitrah, Zakat Mal, serta 8 golongan penerima zakat (mustahik)",
        "Mempraktikkan simulasi amil zakat dan membiasakan gemar berinfak serta bersedekah"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "I (Ganjil)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah keteladanan Khalifah Abu Bakar as-Siddiq dan Umar bin Khattab.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Komunikasi.",
      asesmen: "Presentasi biografi, perjuangan, dan keteladanan kepemimpinan Abu Bakar as-Siddiq serta Umar bin Khattab.",
      subTopik: [
        "Menceritakan kesetiaan, kedermawanan, dan kepemimpinan Khalifah Abu Bakar as-Siddiq",
        "Menceritakan keberanian, ketegasan, keadilan, dan kesederhanaan Khalifah Umar bin Khattab"
      ]
    },

    // KELAS VI - SEMESTER II (GENAP)
    {
      kelas: "VI", fase: "C", semester: "II (Genap)", nomor: 1, elemen: "Al-Qur’an-Hadis", alokasi: "3 x 3 JP",
      tp: "Mempraktikkan bacaan tafkhim dan tarkik (lam jalalah dan ra) serta menjelaskan dan menerapkan hadis tentang berbuat baik kepada teman.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Komunikasi, Kolaborasi.",
      asesmen: "Praktik membaca ayat yang mengandung hukum Tafkhim dan Tarkik serta unjuk kerja hafalan hadis persahabatan.",
      subTopik: [
        "Memahami dan mempraktikkan bacaan Tafkhim (tebal) dan Tarkik (tipis) pada huruf Lam Jalalah dan Ra",
        "Membaca, menghafal, dan memahami kandungan hadis tentang sebaik-baik sahabat di sisi Allah Swt.",
        "Mengamalkan perilaku sahabat sejati yang mengajak pada kebaikan dan saling mendukung"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "II (Genap)", nomor: 2, elemen: "Akidah", alokasi: "3 x 3 JP",
      tp: "Menjelaskan dan meyakini iman kepada Qadāʾ dan Qadar (takdir mubram dan takdir muallaq).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kemandirian.",
      asesmen: "Membuat tabel klasifikasi contoh Takdir Mubram dan Takdir Muallaq beserta refleksi cita-cita masa depan.",
      subTopik: [
        "Memahami pengertian Qadāʾ dan Qadar sebagai rukun iman keenam",
        "Membedakan antara Takdir Mubram (ketetapan mutlak) dan Takdir Muallaq (ketetapan yang berkaitan dengan ikhtiar manusia)",
        "Menunjukkan sikap optimis, pantang menyerah, rendah hati, dan tawakal sebagai buah iman kepada Qadāʾ dan Qadar"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "II (Genap)", nomor: 3, elemen: "Akhlak", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan akhlak mulia terhadap hewan dan tumbuhan (pelestarian alam).",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Kolaborasi.",
      asesmen: "Proyek aksi merawat tanaman di sekolah/rumah dan kampanye poster menyayangi hewan serta lingkungan.",
      subTopik: [
        "Memahami ajaran Islam tentang kasih sayang terhadap hewan dan larangan menyiksa makhluk hidup",
        "Mempraktikkan cara merawat tumbuhan dan menjaga kelestarian alam sebagai khalifah di bumi"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "II (Genap)", nomor: 4, elemen: "Fikih", alokasi: "2 x 3 JP",
      tp: "Menjelaskan dan menerapkan ketentuan wakaf sebagai amal jariah yang berkelanjutan.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Kolaborasi.",
      asesmen: "Tes tertulis syarat/rukun wakaf dan proyek aksi wakaf buku/tanaman untuk sekolah.",
      subTopik: [
        "Memahami pengertian, dasar hukum, rukun, dan syarat harta benda yang diwakafkan (mauquf)",
        "Menjelaskan hikmah dan manfaat wakaf sebagai sedekah jariah bagi kesejahteraan umat"
      ]
    },
    {
      kelas: "VI", fase: "C", semester: "II (Genap)", nomor: 5, elemen: "Sejarah Peradaban Islam", alokasi: "2 x 3 JP",
      tp: "Menceritakan dan menjelaskan kisah keteladanan Khalifah Usman bin Affan dan Ali bin Abi Talib.",
      dimensi: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kemandirian.",
      asesmen: "Presentasi jasa kodifikasi mushaf Al-Qur’an oleh Usman bin Affan dan kecerdasan ilmu Ali bin Abi Talib.",
      subTopik: [
        "Menceritakan kesantunan, kedermawanan (wakaf sumur Raumah), dan jasa pembukuan Al-Qur’an masa Khalifah Usman bin Affan",
        "Menceritakan keberanian, kezuhudan, dan kecintaan terhadap ilmu pengetahuan dari Khalifah Ali bin Abi Talib"
      ]
    }
  ];

  return rawConfigs.map((cfg) => {
    const semCode = cfg.semester.startsWith("I ") ? "s1" : "s2";
    const id = `k${cfg.kelas.toLowerCase()}-${semCode}-m${cfg.nomor}`;
    const pertemuan = cfg.subTopik.map((sub, idx) => ({
      judul: `Pertemuan Ke-${idx + 1} (${sub})`,
      iceBreaking: idx % 2 === 0 ? "tepuk semangat dan lagu islami" : "permainan konsentrasi ceria",
      inti: [
        `Murid mengamati tayangan visual, peragaan, atau membaca kisah pemantik terkait materi "${sub}". (mindful)`,
        `Guru bersama murid melakukan tanya jawab interaktif untuk menggali pemahaman konsep "${sub}" dan mengaitkannya dengan pengalaman sehari-hari. (meaningful)`,
        `Murid dibagi ke dalam beberapa kelompok belajar untuk berdiskusi, berlatih, atau menyelesaikan lembar aktivitas kolaboratif tentang "${sub}". (asy-syura, joyful)`,
        `Setiap kelompok atau perwakilan murid mendemonstrasikan hasil kerja/praktik di depan kelas dan saling memberikan apresiasi. (produk, al-qudwah)`,
        `Guru memberikan umpan balik dan penguatan nilai karakter islami dari materi "${sub}". (meaningful)`
      ]
    }));

    return {
      id,
      kelas: cfg.kelas,
      fase: cfg.fase,
      semester: cfg.semester,
      nomor: cfg.nomor,
      elemen: cfg.elemen,
      alokasi: cfg.alokasi,
      tp: cfg.tp,
      dimensi: cfg.dimensi,
      asesmen: cfg.asesmen,
      pertemuan
    };
  });
};

const INITIAL_MODULES = buildInitialModules();

// ==========================================
// DATABASE LENGKAP 12 MODUL PROJEK KOKURIKULER (KELAS I - VI, SEM 1 & 2)
// ==========================================
const INITIAL_KOKURIKULER_DATA = [
  {
    id: "ko-k1-s1",
    kelas: "I",
    fase: "A",
    semester: "I (Ganjil)",
    nomor: 1,
    tema: "Kearifan Lokal & Literasi Al-Qur’an",
    judulProjek: "Festival Ceria Huruf Hijaiah & Syukurku pada Ilahi",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Huruf Hijaiah & Harakat, Rukun Iman, Menyucikan Allah Swt., Rukun Islam, Syahadatain, Kisah Nabi Adam a.s.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kreativitas, Kolaborasi, Komunikasi.",
    nilaiPpra: "Berkeadaban (Ta’addub), Keteladanan (Qudwah), Musyawarah (Syura).",
    lintasDisiplin: "Seni Rupa (membuat kartu flashcard warna-warni), Bahasa Indonesia (melafalkan vokal dan huruf), Pendidikan Pancasila (kerja sama tim).",
    tujuanProjek: "Membangun kecintaan murid terhadap huruf-huruf Al-Qur’an serta membiasakan ucapan kalimah tayibah dan rasa syukur melalui karya pohon syukur dan kartu hijaiah kreatif.",
    produkAkhir: "Kartu Flashcard Hijaiah Berharakat Hias & Pohon Syukur Kelas I.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mengamati berbagai bentuk kaligrafi huruf hijaiah dan menyimak kisah penciptaan alam semesta serta Nabi Adam a.s. sebagai wujud kebesaran Allah Swt. (mindful)",
          "Tanya jawab interaktif mengenai pentingnya mengenal huruf Al-Qur’an dan menyebutkan lima Rukun Islam serta enam Rukun Iman. (meaningful)",
          "Menyanyikan lagu Huruf Hijaiah, Tepuk Rukun Islam, dan Tepuk Rukun Iman secara berkelompok. (joyful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Hubungkan dengan Keseharian)",
        kegiatan: [
          "Murid mengidentifikasi benda-benda ciptaan Allah Swt. di lingkungan sekolah yang patut disyukuri dengan mengucap Alhamdulillah dan Subhanallah. (meaningful)",
          "Murid mengelompokkan bentuk huruf hijaiah dan tanda baca harakat (fathah, kasrah, dammah) melalui permainan mencari pasangan kartu. (joyful)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Setiap kelompok mewarnai dan menghias Kartu Flashcard Huruf Hijaiah Berharakat menggunakan kertas karton dan pewarna yang aman. (joyful, produk)",
          "Murid menulis atau menempelkan gambar nikmat Allah Swt. pada 'Pohon Syukur dan Rukun Iman' di sudut kelas. (meaningful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut (Bagikan & Biasakan)",
        kegiatan: [
          "Gelar Karya Mini: Setiap kelompok mendemonstrasikan pembacaan Kartu Hijaiah karya mereka dan melafalkan Syahadatain beserta artinya di depan kelas. (produk)",
          "Refleksi bersama tentang kebiasaan meminta maaf ketika berbuat salah (meneladani Nabi Adam a.s.) dan selalu menjaga kesucian diri."
        ]
      }
    ],
    asesmenProjek: "Observasi sikap kolaborasi dan kemandirian, penilaian produk Kartu Flashcard Hijaiah & Pohon Syukur, serta unjuk kerja pelafalan."
  },
  {
    id: "ko-k1-s2",
    kelas: "I",
    fase: "A",
    semester: "II (Genap)",
    nomor: 2,
    tema: "Bangunlah Jiwa dan Raganya",
    judulProjek: "Duta Kecil Bersih, Sehat, dan Tertib Berwudu",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Q.S. Al-Fatihah, Iman kepada Allah Swt., Memuji Allah Swt., Tata Cara Wudu, Tayamum, Istinja, Kisah Nabi Idris a.s.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Kemandirian, Penalaran Kritis.",
    nilaiPpra: "Keteladanan (Qudwah), Berkeadaban (Ta’addub), Dinamis dan Inovatif (Tathawwur wa Ibtikar).",
    lintasDisiplin: "PJOK (kebersihan badan), Bahasa Indonesia (urutan prosedur), Seni Rupa (poster urutan wudu).",
    tujuanProjek: "Menumbuhkan kesadaran dan keterampilan praktik bersuci (istinja, wudu, tayamum) secara tertib dan hemat air, serta meneladani semangat belajar Nabi Idris a.s.",
    produkAkhir: "Poster Urutan Wudu Bergambar, Stiker Hemat Air di Tempat Wudu, & Kartu Komitmen Anak Bersih.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid menyimak demonstrasi pentingnya bersuci sebelum beribadah dan membaca Q.S. Al-Fatihah dengan tartil. (mindful)",
          "Mengamati perbedaan air suci menyucikan dan debu suci untuk tayamum serta adab buang air (istinja). (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Observasi Lingkungan)",
        kegiatan: [
          "Kunjungan ke tempat wudu dan toilet sekolah untuk mengamati cara menggunakan keran air secara bijak (tidak boros air). (meaningful)",
          "Diskusi kelompok tentang kisah keteladanan Nabi Idris a.s. yang rajin belajar dan menjaga kerapian pakaian. (asy-syura)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Praktik & Karya)",
        kegiatan: [
          "Murid menyusun dan menempel gambar urutan rukun dan sunah wudu menjadi Poster Urutan Wudu yang menarik. (joyful, produk)",
          "Praktik langsung berwudu dengan tertib, membaca doa sebelum dan sesudah wudu, serta simulasi tayamum secara bergiliran. (meaningful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Kampanye Duta Kecil Bersuci: Menempelkan stiker pengingat hemat air dan doa masuk/keluar kamar mandi di area sekolah.",
          "Refleksi harian melalui Kartu Komitmen Anak Bersih dan Rajin Belajar selama satu minggu bersama orang tua."
        ]
      }
    ],
    asesmenProjek: "Rubrik unjuk kerja praktik wudu & tayamum, penilaian produk Poster Urutan Wudu, dan jurnal pembiasaan harian."
  },
  {
    id: "ko-k2-s1",
    kelas: "II",
    fase: "A",
    semester: "I (Ganjil)",
    nomor: 1,
    tema: "Bangunlah Jiwa dan Raganya & Kreativitas Islami",
    judulProjek: "Anak Saleh Disiplin Salat, Hidup Sehat & Galeri Kaligrafi Asmaulhusna",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Q.S. An-Nas & Al-Falaq, Asmaulhusna (ar-Rahman, ar-Rahim, as-Salam, al-Mu’min), Hidup Bersih & Sehat, Salat Fardu, Kisah Nabi Nuh a.s.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kreativitas, Kemandirian, Kesehatan.",
    nilaiPpra: "Keseimbangan (Tawazun), Lurus dan Tegas (I’tidal), Keteladanan (Qudwah).",
    lintasDisiplin: "Seni Rupa (mewarnai kaligrafi), Matematika (mengenal bilangan rakaat dan waktu salat), PJOK (gerakan salat menyehatkan tubuh).",
    tujuanProjek: "Membentuk kedisiplinan melaksanakan salat fardu lima waktu, membiasakan pola hidup bersih dan sehat, serta mengekspresikan keindahan Asmaulhusna melalui karya seni.",
    produkAkhir: "Kaligrafi Warna-warni Asmaulhusna, Jam Pengingat Waktu Salat & Jurnal Salat 5 Waktu.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid melafalkan Q.S. An-Nas dan Q.S. Al-Falaq sebagai doa perlindungan diri kepada Allah Swt. (mindful)",
          "Mengenal makna kasih sayang dan keselamatan dari Asmaulhusna ar-Rahman, ar-Rahim, as-Salam, dan al-Mu’min. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Hubungkan dengan Keseharian)",
        kegiatan: [
          "Berdiskusi tentang hubungan gerakan salat yang tertib dan pola hidup bersih-sehat terhadap kebugaran tubuh. (meaningful)",
          "Menyimak keteladanan kesabaran dan kerja keras Nabi Nuh a.s. dalam menyelesaikan pembuatan bahtera. (al-i’tidal)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Membuat karya Kaligrafi Asmaulhusna (ar-Rahman, ar-Rahim, as-Salam, al-Mu’min) dan kerajinan 'Jam Pengingat 5 Waktu Salat' dari kardus bekas. (joyful, produk)",
          "Praktik salat fardu berjamaah di musala sekolah dengan gerakan dan bacaan yang tuma'ninah. (meaningful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Pameran Galeri Kaligrafi Kelas II dan presentasi cara merawat kesehatan tubuh sebagai rasa syukur kepada Allah Swt.",
          "Evaluasi pengisian Jurnal Salat 5 Waktu yang ditandatangani bersama orang tua di rumah."
        ]
      }
    ],
    asesmenProjek: "Penilaian produk Kaligrafi dan Jam Waktu Salat, rubrik praktik gerakan & bacaan salat fardu, serta pemantauan jurnal salat."
  },
  {
    id: "ko-k2-s2",
    kelas: "II",
    fase: "A",
    semester: "II (Genap)",
    nomor: 2,
    tema: "Gaya Hidup Berkelanjutan & Pembiasaan Ibadah",
    judulProjek: "Gerakan Sekolah Bersih Beriman & Taman Doa Anak Hebat",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Q.S. Al-Ikhlas, Hadis tentang Kebersihan, Iman kepada Malaikat, Terbiasa Berdoa, Zikir & Doa Setelah Salat, Kisah Nabi Ibrahim a.s.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kolaborasi, Kemandirian, Kesehatan.",
    nilaiPpra: "Berkeadaban (Ta’addub), Kesetaraan (Musawah), Musyawarah (Syura).",
    lintasDisiplin: "Bahasa Indonesia (membaca dan menulis teks doa/hadis), Seni Kerajinan (membuat gantungan doa harian), Pendidikan Pancasila (gotong royong).",
    tujuanProjek: "Mengamalkan hadis tentang kebersihan melalui aksi nyata peduli lingkungan sekolah serta membiasakan zikir dan doa setelah salat dalam kehidupan sehari-hari.",
    produkAkhir: "Buku Saku Zikir & Doa Harian Hias, Poster Hadis Kebersihan, & Aksi Jumat Bersih.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid membaca dan menghafalkan Q.S. Al-Ikhlas serta Hadis tentang Kebersihan ('At-tuhuru syatrul iman'). (mindful)",
          "Mengenal 10 Malaikat Allah beserta tugasnya yang selalu mencatat amal baik anak yang menjaga kebersihan dan rajin berdoa. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Telusuri Lingkungan)",
        kegiatan: [
          "Observasi kebersihan kelas dan halaman sekolah, lalu mendiskusikan mengapa kebersihan menjadi bagian dari iman. (asy-syura)",
          "Meneladani keberanian dan ketaatan Nabi Ibrahim a.s. dalam beribadah dan berdoa kepada Allah Swt. (al-qudwah)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Melaksanakan Aksi 'Jumat Bersih Beriman': Memilah sampah dan menata sudut kelas secara bergotong royong. (joyful, proses)",
          "Membuat 'Buku Saku & Gantungan Pintu Zikir dan Doa Setelah Salat' yang dihias secara kreatif oleh masing-masing murid. (produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Praktik bersama melafalkan zikir (istigfar, tasbih, tahmid, takbir) dan doa untuk kedua orang tua setelah salat.",
          "Refleksi perasaan setelah menjaga kebersihan kelas dan komitmen membiasakan berdoa sebelum dan sesudah beraktivitas."
        ]
      }
    ],
    asesmenProjek: "Penilaian produk Buku Saku Zikir & Doa, observasi partisipasi aksi kebersihan, dan tes lisan hafalan hadis kebersihan & doa."
  },
  {
    id: "ko-k3-s1",
    kelas: "III",
    fase: "B",
    semester: "I (Ganjil)",
    nomor: 1,
    tema: "Suara Demokrasi & Keteladanan Ibadah",
    judulProjek: "Pekan Muazin Cilik, Syukur Nikmat (Al-Kausar) & Pohon Husnuzan",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Mad Tabi’i, Q.S. Al-Kausar, Sifat Wajib/Mustahil/Jaiz Allah, Berbaik Sangka (Husnuzan), Azan & Ikamah, Masa Kanak-kanak Nabi Muhammad saw.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Komunikasi, Penalaran Kritis.",
    nilaiPpra: "Keteladanan (Qudwah), Berkeadaban (Ta’addub), Toleransi (Tasamuh).",
    lintasDisiplin: "Seni Musik/Suara (irama pelafalan azan dan tajwid mad tabi'i), Bahasa Indonesia (kosakata sifat wajib Allah dan cerita teladan).",
    tujuanProjek: "Melatih keberanian dan kefasihan mengumandangkan azan/ikamah serta menumbuhkan sikap bersyukur (Q.S. Al-Kausar) dan selalu berbaik sangka (husnuzan) kepada Allah Swt.",
    produkAkhir: "Festival Muazin & Doa Setelah Azan, Pohon Husnuzan (Pikiran Positif), & Kartu Sifat-Sifat Allah.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid menyimak kandungan Q.S. Al-Kausar tentang nikmat Allah yang melimpah serta mengenal sifat Wajib, Mustahil, dan Jaiz bagi Allah Swt. (mindful)",
          "Menyimak video tata cara dan adab mengumandangkan azan serta ikamah dengan makhraj dan panjang-pendek (mad tabi'i) yang tepat. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Hubungkan dengan Keseharian)",
        kegiatan: [
          "Diskusi studi kasus sederhana tentang perbedaan sikap anak yang berbaik sangka (husnuzan) dan pantang menyerah seperti masa kecil Nabi Muhammad saw. (asy-syura)",
          "Berlatih menjawab lafal azan dan membaca doa sesudah azan secara berpasangan. (joyful)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Membuat karya 'Pohon Husnuzan & Syukur' berisi kalimat-kalimat positif dan wujud syukur atas nikmat Allah Swt. (produk)",
          "Penyelenggaraan 'Festival Muazin Cilik & Jawaban Azan' di musala sekolah (murid laki-laki praktik azan/ikamah, murid perempuan praktik menjawab azan dan doa setelah azan). (joyful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Apresiasi penampilan seluruh peserta dan penyusunan jadwal muazin cilik harian untuk salat Zuhur berjamaah di sekolah.",
          "Refleksi pembiasaan sikap optimis dan berbaik sangka kepada Allah Swt. saat menghadapi kesulitan belajar."
        ]
      }
    ],
    asesmenProjek: "Rubrik unjuk kerja praktik Azan/Ikamah & Doa Setelah Azan, penilaian produk Pohon Husnuzan, dan kuis kartu Sifat Allah."
  },
  {
    id: "ko-k3-s2",
    kelas: "III",
    fase: "B",
    semester: "II (Genap)",
    nomor: 2,
    tema: "Bhinneka Tunggal Ika & Bakti Keluarga",
    judulProjek: "Panggung Drama Bakti Orang Tua (Birrul Walidain) & Pojok Literasi Kitab Suci",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Izhar Halqi, Hadis Kewajiban Salat, Iman kepada Kitab-Kitab Allah, Akhlak terhadap Orang Tua, Salat Jum’at, Masa Remaja Nabi Muhammad saw. (Al-Amin).",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kolaborasi, Komunikasi, Kreativitas.",
    nilaiPpra: "Berkeadaban (Ta’addub), Keteladanan (Qudwah), Musyawarah (Syura).",
    lintasDisiplin: "Seni Teater (bermain peran/role playing bakti orang tua), Bahasa Indonesia (menulis surat cinta untuk ayah ibu), Pendidikan Pancasila (kewajiban anak di rumah).",
    tujuanProjek: "Menanamkan sikap hormat, santun, dan berbakti kepada orang tua serta kecintaan membaca Al-Qur’an dan melaksanakan kewajiban salat tepat waktu.",
    produkAkhir: "Pentas Role Playing 'Anak Berbakti & Jujur (Al-Amin)', Surat Cinta & Kupon Bantuan untuk Orang Tua, serta Infografis 4 Kitab Allah.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mengkaji Hadis tentang Kewajiban Salat sebagai tiang agama dan mengenal 4 Kitab Suci Allah Swt. (Taurat, Zabur, Injil, Al-Qur’an). (mindful)",
          "Menyimak kisah kejujuran masa remaja Nabi Muhammad saw. hingga mendapat gelar Al-Amin serta adab mulia terhadap orang tua. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Refleksi Pengalaman)",
        kegiatan: [
          "Murid berbagi cerita dalam kelompok tentang jasa dan perjuangan orang tua di rumah serta adab persiapan mengikuti ibadah Salat Jum’at. (asy-syura)",
          "Merancang naskah singkat bermain peran (role playing) tentang perilaku santun kepada orang tua dan kejujuran. (proses)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Membuat 'Surat Cinta & 5 Kupon Bantuan di Rumah' untuk diberikan kepada orang tua serta membuat poster mini 4 Kitab Allah. (joyful, produk)",
          "Pementasan Role Playing kelompok di depan kelas tentang adab berbicara sopan, membantu orang tua, dan mengingatkan waktu salat. (produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Murid mengumpulkan tanggapan tertulis dari orang tua atas Surat Cinta dan pelaksanaan Kupon Bantuan di rumah.",
          "Komitmen bersama menjaga salat lima waktu dan membaca Al-Qur’an setiap hari dengan tajwid (izhar halqi) yang benar."
        ]
      }
    ],
    asesmenProjek: "Rubrik penampilan Role Playing, penilaian produk Surat Cinta & Infografis Kitab Allah, serta lembar testimoni orang tua."
  },
  {
    id: "ko-k4-s1",
    kelas: "IV",
    fase: "B",
    semester: "I (Ganjil)",
    nomor: 1,
    tema: "Kearifan Lokal & Harmoni Keluarga",
    judulProjek: "Pameran Kaligrafi Asmaulhusna & Gerakan Keluarga Harmonis Gemar Salat Sunah",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Idgam Bigunnah & Bilagunnah, Q.S. An-Nasr, Asmaulhusna (al-Gaffar, al-Wahhab, al-Fattah, al-Latif), Akhlak terhadap Keluarga, Salat Sunah (Rawatib, Duha, Tahajud), Dakwah Periode Makkah.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kreativitas, Kolaborasi, Kemandirian.",
    nilaiPpra: "Moderat (Tawassuth), Keteladanan (Qudwah), Berkeadaban (Ta’addub).",
    lintasDisiplin: "Seni Rupa (lukisan/kaligrafi media campuran), Bahasa Indonesia (presentasi karya), Pendidikan Pancasila (kerukunan di dalam keluarga).",
    tujuanProjek: "Menginternalisasi sifat pemaaf, dermawan, dan lembut hati dari Asmaulhusna dalam kehidupan keluarga serta membiasakan ibadah salat sunah Duha dan Rawatib.",
    produkAkhir: "Karya Bingkai Kaligrafi Asmaulhusna, Pohon Silsilah & Kasih Sayang Keluarga, serta Jurnal Pembiasaan Salat Duha & Rawatib.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mempelajari pesan Q.S. An-Nasr dan mendalami makna Asmaulhusna al-Gaffar, al-Wahhab, al-Fattah, dan al-Latif. (mindful)",
          "Memahami keutamaan dan tata cara salat sunah Rawatib, Duha, dan Tahajud sebagai penyempurna salat fardu. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Hubungkan dengan Keseharian)",
        kegiatan: [
          "Diskusi kelompok tentang cara mewujudkan akhlak mulia terhadap kakak, adik, dan anggota keluarga di rumah (saling memaafkan seperti sifat al-Gaffar dan berbagi seperti al-Wahhab). (asy-syura)",
          "Meneladani ketabahan dakwah Nabi Muhammad saw. periode Makkah bersama keluarga dan sahabat terdekat. (al-qudwah)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Praktik bersama Salat Sunah Duha di musala sekolah dilanjutkan doa Duha dengan khusyuk. (meaningful, proses)",
          "Membuat karya Kaligrafi Asmaulhusna (al-Gaffar, al-Wahhab, al-Fattah, al-Latif) berbingkai kreatif dan Bagan Komitmen Kasih Sayang Keluarga. (joyful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Gallery Walk (Pameran Kelas): Setiap kelompok memajang kaligrafi dan mempresentasikan cara mengamalkan Asmaulhusna tersebut di rumah.",
          "Refleksi pelaksanaan jurnal Salat Sunah Duha dan Rawatib selama dua pekan."
        ]
      }
    ],
    asesmenProjek: "Penilaian produk Kaligrafi Berbingkai, rubrik praktik Salat Sunah Duha/Rawatib, dan observasi presentasi Gallery Walk."
  },
  {
    id: "ko-k4-s2",
    kelas: "IV",
    fase: "B",
    semester: "II (Genap)",
    nomor: 2,
    tema: "Bangunlah Jiwa dan Raganya (Edukasi Pubertas Islami)",
    judulProjek: "Kampanye Siap Balig (Mukallaf Tangguh), Hormat Guru & Persaudaraan Sejati",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Iklab & Ikhfa, Hadis Menjaga Hubungan Baik, Iman kepada Rasul-Rasul Allah, Akhlak terhadap Guru, Konsep Balig & Taklif, Kisah Hijrah Nabi Muhammad saw.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Penalaran Kritis, Kemandirian, Kesehatan, Komunikasi.",
    nilaiPpra: "Lurus dan Tegas (I’tidal), Berkeadaban (Ta’addub), Dinamis dan Inovatif (Tathawwur wa Ibtikar).",
    lintasDisiplin: "IPAS (perubahan biologis masa pubertas dan kesehatan reproduksi), Bahasa Indonesia (wawancara dan poster edukasi), Seni Rupa (desain buklet).",
    tujuanProjek: "Membekali murid dengan pemahaman ilmiah dan fikih tentang tanda-tanda balig, cara bersuci dari hadas besar, tanggung jawab taklif, serta memuliakan guru dan sesama.",
    produkAkhir: "Buklet Saku 'Aku Siap Memasuki Usia Balig', Poster 4 Sifat Wajib Rasul (Siddiq, Amanah, Tablig, Fatanah), & Aksi Apresiasi Guru.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mengkaji tanda-tanda balig menurut ilmu fikih dan ilmu biologi (IPAS) serta kewajiban mandi wajib dan menutup aurat. (mindful, meaningful)",
          "Mempelajari Hadis tentang menjaga hubungan baik (silaturahmi) dan 4 sifat wajib Rasul Allah sebagai teladan remaja muslim. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Diskusi & Wawancara)",
        kegiatan: [
          "Diskusi terarah tentang perubahan tanggung jawab (taklif) ketika seorang anak telah balig (mukallaf) dalam ibadah, akidah, dan akhlak. (asy-syura)",
          "Melakukan wawancara santun kepada bapak/ibu guru di sekolah mengenai nasihat menjadi murid yang beradab dan sukses belajar (mempraktikkan akhlak terhadap guru). (joyful)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Menyusun 'Buklet Saku Aku Siap Balig & Mandiri Beribadah' serta Poster Ajakan Meneladani Sifat Siddiq, Amanah, Tablig, Fatanah. (produk)",
          "Menyerahkan Kartu Apresiasi dan Doa Terbaik untuk Bapak/Ibu Guru di sekolah sebagai wujud ta’dzim dan terima kasih. (meaningful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Presentasi kelompok mengenai hikmah semangat perubahan (hijrah) menuju pribadi yang lebih bertanggung jawab seperti kisah Hijrah Nabi Muhammad saw.",
          "Refleksi kesiapan diri menjaga kebersihan badan, tata krama pergaulan, dan ketaatan beribadah."
        ]
      }
    ],
    asesmenProjek: "Penilaian produk Buklet Siap Balig & Poster Sifat Rasul, observasi adab wawancara kepada guru, serta tes pemahaman ketentuan taklif."
  },
  {
    id: "ko-k5-s1",
    kelas: "V",
    fase: "C",
    semester: "I (Ganjil)",
    nomor: 1,
    tema: "Kewirausahaan Sosial & Manajemen Waktu Islami",
    judulProjek: "Manajemen Waktu Produktif (Al-‘Asr), Doa-Tawakal & Semarak Amaliah Puasa",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Hukum Mim Sukun, Q.S. Al-‘Asr, Asmaulhusna (al-Halim, asy-Syakur, al-Hakim, al-Wadud), Akhlak Berdoa & Bertawakal, Puasa Wajib & Sunah, Kepemimpinan Nabi di Madinah.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kolaborasi, Penalaran Kritis.",
    nilaiPpra: "Keseimbangan (Tawazun), Musyawarah (Syura), Keteladanan (Qudwah).",
    lintasDisiplin: "Bahasa Indonesia (menyusun jadwal dan jurnal), IPS (kepemimpinan sosial dan piagam kesepakatan), Seni Rupa (desain kalender amaliah).",
    tujuanProjek: "Membentuk pribadi murid yang disiplin menghargai waktu sesuai pesan Q.S. Al-‘Asr, gigih berusaha disertai doa dan tawakal, serta menghayati hikmah ibadah puasa.",
    produkAkhir: "Planner Mingguan 'Produktif Tanpa Rugi (Q.S. Al-‘Asr)', Piagam Kerukunan Kelas (Inspirasi Piagam Madinah), & Panduan Amaliah Puasa.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mentadabburi kandungan Q.S. Al-‘Asr tentang kerugian manusia yang menyia-nyiakan waktu dan mempelajari hukum bacaan mim sukun. (mindful)",
          "Mengkaji konsep ikhtiar maksimal, berdoa, dan bertawakal kepada Allah Swt. serta hikmah puasa wajib dan puasa sunah. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Analisis Masalah)",
        kegiatan: [
          "Audit waktu harian: Murid menganalisis kebiasaan sehari-hari (waktu belajar, ibadah, membantu orang tua, vs waktu bermain gawai). (penalaran kritis)",
          "Mengkaji keteladanan kepemimpinan Nabi Muhammad saw. di Madinah yang mempersaudarakan kaum Muhajirin dan Ansar. (asy-syura)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Merancang 'Planner Manajemen Waktu & Ibadahku' serta membuat Kaligrafi Asmaulhusna al-Halim, asy-Syakur, al-Hakim, al-Wadud. (joyful, produk)",
          "Merumuskan bersama 'Piagam Persaudaraan Kelas V' untuk menciptakan lingkungan belajar yang damai, adil, dan saling menasihati dalam kebenaran dan kesabaran. (produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Presentasi hasil penerapan Planner Waktu selama 1 minggu dan simulasi edukasi keutamaan puasa wajib dan sunah.",
          "Penandatanganan Piagam Persaudaraan Kelas V oleh seluruh murid dan guru."
        ]
      }
    ],
    asesmenProjek: "Penilaian produk Planner Manajemen Waktu & Piagam Kelas, rubrik presentasi tadabbur Q.S. Al-‘Asr, dan observasi sikap disiplin."
  },
  {
    id: "ko-k5-s2",
    kelas: "V",
    fase: "C",
    semester: "II (Genap)",
    nomor: 2,
    tema: "Gaya Hidup Berkelanjutan & Konsumsi Halalan Tayyiban",
    judulProjek: "Detektif Pangan Halal-Thayyib & Duta Persahabatan Damai",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Qalqalah, Hadis Berbuat Baik kepada Orang Tua & Guru, Iman kepada Hari Akhir, Akhlak terhadap Teman, Makanan & Minuman Halal-Haram, Hudaibiah, Fathu Makkah & Haji Wada.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kesehatan, Penalaran Kritis, Kewargaan, Kolaborasi.",
    nilaiPpra: "Lurus dan Tegas (I’tidal), Toleransi (Tasamuh), Anti Kekerasan (La ‘Unf).",
    lintasDisiplin: "IPAS (komposisi zat makanan dan kesehatan pencernaan), Bahasa Indonesia (teks eksplanasi label kemasan), Pendidikan Pancasila (anti-perundungan/bullying).",
    tujuanProjek: "Melatih ketelitian memilih makanan/minuman yang halal dan baik bagi kesehatan (halalan tayyiban) serta membangun persahabatan anti-perundungan dengan kesadaran pertanggungjawaban di Hari Akhir.",
    produkAkhir: "Katalog/Poster Investigasi Kemasan Halal-Thayyib, Peta Konsep Hikmah Hari Akhir, & Deklarasi Sahabat Sejati Anti-Bullying.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mempelajari ketentuan makanan dan minuman yang halal dan haram (dari segi zat, cara memperoleh, dan proses pengolahan). (mindful)",
          "Mengkaji makna Iman kepada Hari Akhir bahwa setiap perbuatan baik maupun buruk kepada orang tua, guru, dan teman akan dipertanggungjawabkan. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Investigasi Lapangan)",
        kegiatan: [
          "Detektif Halal: Murid membawa berbagai bungkus kemasan makanan/minuman ringan untuk meneliti logo Halal resmi, komposisi bahan, dan tanggal kedaluwarsa. (joyful, proses)",
          "Meneladani semangat perdamaian dan sifat pemaaf Nabi Muhammad saw. pada peristiwa Perjanjian Hudaibiah dan Fathu Makkah dalam pertemanan di sekolah. (tasamuh)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Membuat 'Papan Informasi & Katalog Cerdas Memilih Jajanan Halal dan Sehat' serta Peta Konsep Hikmah Beriman kepada Hari Akhir. (produk)",
          "Kampanye dan Role Playing 'Sahabat Sejati: Saling Menolong, Memaafkan, dan Menolak Perundungan (Bullying)'. (meaningful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Presentasi hasil investigasi Detektif Pangan Halal di depan kelas dan sosialisasi ke adik kelas.",
          "Refleksi diri tentang komitmen menjaga lisan dan perbuatan terhadap orang tua, guru, dan teman sebaya."
        ]
      }
    ],
    asesmenProjek: "Penilaian produk Katalog Investigasi Halal & Peta Konsep Hari Akhir, rubrik role playing persahabatan, serta kuis analisis studi kasus halal-haram."
  },
  {
    id: "ko-k6-s1",
    kelas: "VI",
    fase: "C",
    semester: "I (Ganjil)",
    nomor: 1,
    tema: "Bhinneka Tunggal Ika & Filantropi Islam",
    judulProjek: "Gerakan Filantropi Cilik (ZIS) & Harmoni Bertetangga Lintas Iman",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Gunnah, Q.S. Al-Insyirah, Asmaulhusna (al-Waliy, al-Hamid, al-‘Adl, as-Sabur), Akhlak terhadap Tetangga & Non-Muslim, Zakat, Infak & Sedekah, Kisah Abu Bakar & Umar bin Khattab.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kewargaan, Kolaborasi, Penalaran Kritis, Komunikasi.",
    nilaiPpra: "Toleransi (Tasamuh), Kewarganegaraan dan Kebangsaan (Muwathanah), Kesetaraan (Musawah), Moderat (Tawassuth).",
    lintasDisiplin: "Matematika (menghitung takaran zakat fitrah dan persentase zakat mal), IPS & Pendidikan Pancasila (kerukunan sosial masyarakat majemuk).",
    tujuanProjek: "Menumbuhkan jiwa kedermawanan sosial melalui praktik Zakat, Infak, dan Sedekah (meneladani Abu Bakar & Umar) serta memperkokoh sikap toleransi dan adab bertetangga.",
    produkAkhir: "Kotak & Program 'Kencleng Sedekah Subuh/Jumat Berkah', Simulasi Amil Zakat Fitrah, & Komik Strip/Poster Toleransi Bertetangga.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mentadabburi Q.S. Al-Insyirah tentang optimisme dan kepedulian sosial, serta mempelajari perbedaan Zakat, Infak, dan Sedekah beserta 8 golongan mustahik. (mindful)",
          "Mengkaji prinsip akhlak mulia terhadap tetangga dan saudara non-muslim dalam bingkai ukhuwah wathaniyah (persaudaraan sebangsa) dan basyariyah (kemanusiaan). (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Studi Kasus & Teladan Sejarah)",
        kegiatan: [
          "Meneladani kedermawanan Khalifah Abu Bakar as-Siddiq dan keadilan serta kepedulian Khalifah Umar bin Khattab terhadap rakyat yang membutuhkan. (al-qudwah)",
          "Berlatih menghitung kewajiban zakat fitrah (2,5 kg atau 3,5 liter beras per jiwa) dan merancang kegiatan berbagi di lingkungan sekitar sekolah. (asy-syura)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Praktik Simulasi Panitia Amil Zakat Fitrah (prosesi ijab kabul penyerahan zakat, doa menerima zakat, dan pendistribusian kepada mustahik) serta menghias Celengan Infak. (joyful, produk)",
          "Membuat Poster/Komik Strip bertema 'Indahnya Rukun Bertetangga dan Toleransi Antarumat Beragama' yang mencerminkan Asmaulhusna al-‘Adl dan as-Sabur. (produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Penyaluran hasil pengumpulan infak/sedekah sukarela murid untuk kegiatan sosial kemanusiaan.",
          "Refleksi bersama tentang kebahagiaan berbagi dan pentingnya menjaga kerukunan hidup di tengah keberagaman masyarakat Indonesia."
        ]
      }
    ],
    asesmenProjek: "Rubrik simulasi praktik Amil & Muzakki Zakat, penilaian produk Poster Toleransi & Celengan Infak, serta evaluasi perhitungan zakat."
  },
  {
    id: "ko-k6-s2",
    kelas: "VI",
    fase: "C",
    semester: "II (Genap)",
    nomor: 2,
    tema: "Gaya Hidup Berkelanjutan (Ekoteologi Islam & Amal Jariah)",
    judulProjek: "Ekoteologi Cilik: Wakaf Pohon/Buku & Aksi Sayang Hewan-Tumbuhan",
    alokasi: "18 JP (6 Pertemuan x 3 JP)",
    materiTerkait: "Bacaan Tafkhim & Tarkik, Hadis Berbuat Baik kepada Teman, Iman kepada Qada & Qadar, Akhlak terhadap Hewan & Tumbuhan, Ketentuan Wakaf, Kisah Usman bin Affan & Ali bin Abi Talib.",
    dimensiProfil: "Keimanan dan ketakwaan terhadap Tuhan Yang Maha Esa, Kemandirian, Kolaborasi, Kreativitas, Penalaran Kritis.",
    nilaiPpra: "Dinamis dan Inovatif (Tathawwur wa Ibtikar), Keteladanan (Qudwah), Berkeadaban (Ta’addub), Keseimbangan (Tawazun).",
    lintasDisiplin: "IPAS (ekosistem, pelestarian tumbuhan dan hewan), Bahasa Indonesia (karya tulis refleksi kelulusan dan pojok baca), Prakarya (labelisasi tanaman).",
    tujuanProjek: "Mewujudkan akhlak kasih sayang terhadap hewan dan tumbuhan serta meninggalkan jejak amal jariah (wakaf buku/tanaman) bagi sekolah sebelum lulus Kelas VI dengan keyakinan penuh pada Qada dan Qadar Allah.",
    produkAkhir: "Program 'Wakaf Buku Literasi & Wakaf Tanaman Hijau Kelas VI', Peta Konsep Takdir & Ikhtiar Cita-Citaku, serta Kampanye Sayang Hewan-Tumbuhan.",
    tahapan: [
      {
        tahap: "1. Tahap Pengenalan (Temukan & Kenali)",
        kegiatan: [
          "Murid mempelajari makna Iman kepada Qada dan Qadar (takdir mubram dan muallaq) bahwa kesuksesan masa depan diraih dengan ikhtiar sungguh-sungguh dan doa. (mindful)",
          "Mengkaji konsep Wakaf sebagai amal jariah yang pahalanya terus mengalir (meneladani wakaf sumur Raumah oleh Khalifah Usman bin Affan dan kecintaan ilmu Khalifah Ali bin Abi Talib) serta adab menyayangi hewan dan tumbuhan. (meaningful)"
        ]
      },
      {
        tahap: "2. Tahap Kontekstualisasi (Observasi & Perencanaan)",
        kegiatan: [
          "Observasi taman sekolah dan pojok baca perpustakaan untuk merencanakan kontribusi nyata murid Kelas VI yang bermanfaat berkelanjutan bagi adik-adik kelas. (asy-syura)",
          "Mengkaji Hadis berbuat baik kepada sahabat/teman sebagai bekal menjaga ukhuwah menjelang kelulusan sekolah dasar. (tasamuh)"
        ]
      },
      {
        tahap: "3. Tahap Aksi Nyata (Lakukan & Berkarya)",
        kegiatan: [
          "Aksi Nyata 'Jejak Jariah Kelas VI': Menanam dan merawat tanaman berlabel nama ilmiah & pesan pelestarian alam di taman sekolah, serta menghibahkan/mewakafkan buku bacaan bermanfaat untuk Pojok Literasi PAI. (joyful, produk)",
          "Membuat karya 'Peta Konsep Ikhtiar & Takdir Cita-Citaku' beserta pesan persahabatan untuk teman sekelas. (meaningful, produk)"
        ]
      },
      {
        tahap: "4. Tahap Refleksi & Tindak Lanjut",
        kegiatan: [
          "Serah terima simbolis Pojok Buku & Taman Hijau Jariah Kelas VI kepada Kepala Sekolah dan perwakilan adik kelas.",
          "Refleksi akhir jenjang SD: Bersyukur atas ketetapan Allah Swt., bertekad menjaga akhlak terhadap sesama dan alam semesta di jenjang pendidikan berikutnya."
        ]
      }
    ],
    asesmenProjek: "Penilaian partisipasi aksi Wakaf Tanaman/Buku, penilaian produk Peta Konsep Qada-Qadar & Poster Ekoteologi, serta refleksi diri."
  }
];

// ==========================================
// HELPER GENERATOR DETAIL VERSI 3 (PEMBELAJARAN MENDALAM)
// ==========================================
function getDeepLearningDetails(modul) {
  if (!modul) return {};

  const faseData = INITIAL_ATP_DATA.find((f) => f.fase === modul.fase);
  const elData = faseData?.elemen.find((e) => e.nama === modul.elemen);
  const cpText =
    elData?.cp ||
    `Murid memiliki kemampuan memahami dan menerapkan materi ${modul.elemen} sesuai capaian pembelajaran Fase ${modul.fase}.`;

  let lintasDisiplin = "Bahasa Indonesia (keterkaitan kemampuan membaca, memahami, dan menyimpulkan informasi)";
  if (modul.elemen === "Akhlak") {
    lintasDisiplin = "Pendidikan Pancasila (penerapan adab, budi pekerti luhur, dan norma sosial dalam kehidupan sehari-hari)";
  } else if (modul.elemen === "Fikih") {
    lintasDisiplin = "IPAS & PJOK (keterkaitan menjaga kebersihan, kesehatan jasmani, dan ketertiban pelaksanaan ibadah)";
  } else if (modul.elemen === "Sejarah Peradaban Islam") {
    lintasDisiplin = "Bahasa Indonesia & IPS (kemampuan literasi bercerita kembali dan memahami keteladanan tokoh sejarah)";
  }

  return {
    pesertaDidik: `Kondisi peserta didik terbagi dalam dua kelompok: (1) Sebagian besar sudah memiliki pengetahuan awal yang baik terkait materi "${modul.tp}" namun perlu penguatan ketepatan praktik/pemahaman, dan (2) Sebagian kecil masih memerlukan bimbingan intensif dari guru.`,
    materiPelajaran: `Materi "${modul.tp}" mencakup pengetahuan faktual, konseptual, prosedural, dan metakognitif. Materi ini berkaitan erat dengan penguasaan pengetahuan, keterampilan praktik, dan implementasi akhlak mulia dalam kehidupan sehari-hari.`,
    cp: cpText,
    topik: `“Senangnya Belajar: ${modul.tp}”`,
    lintasDisiplin,
    pedagogis: "Pembelajaran langsung (Direct Instruction), pembelajaran kolaboratif (diskusi kelompok & berpasangan), serta permainan edukatif aktif.",
    kemitraan: "Peserta didik, rekan sejawat, dan orang tua sebagai mitra belajar dalam pembiasaan di rumah.",
    lingkungan: "Menggunakan ruang kelas, musala sekolah, dan lingkungan sekitar sebagai ruang belajar yang aman dan menyenangkan.",
    digital: "Penggunaan tayangan audio visual berupa video pembelajaran interaktif, slide presentasi, dan media gambar.",
    asesmenAwal: `Mengecek kesiapan belajar peserta didik dengan pertanyaan pemantik singkat terkait pengetahuan awal tentang ${modul.tp.toLowerCase()}.`,
    asesmenProses: "Mengetahui perkembangan peserta didik dan memberikan umpan balik langsung melalui tanya jawab, observasi diskusi kelompok, dan presentasi unjuk keterampilan."
  };
}

// ==========================================
// KOMPONEN UTAMA APLIKASI
// ==========================================
const DEFAULT_IDENTITAS = {
  sekolah: "SD Negeri Ciketing Udik 2",
  tahunAjaran: "2026/2027",
  kota: "Bekasi",
  tanggal: "13 Juli 2026",
  kepalaSekolah: "SAKRI, S.Ag, MM",
  nipKepsek: "197009202007011010",
  guruPai: "SUHENDRI, S.Pd.I",
  nipGuru: "198001122024211002",
  sapaanSiswa: "Murid", // 'Murid' atau 'Peserta didik'
  kopSurat: "",
  logoSekolah: ""
};

const DEFAULT_JURNAL = [
  {
    id: 1,
    nama: "Ahmad Fauzan",
    modulNomor: 1,
    nilaiAwal: "55",
    indikatorBelumTuntas: "Membedakan bunyi huruf hijaiah berharakat kasrah dan dammah",
    bentukLayanan: "Remedial (Bimbingan Khusus & Tutor Sebaya)",
    nilaiAkhir: "80",
    keterangan: "Tuntas mencapai KKTP"
  },
  {
    id: 2,
    nama: "Siti Aisyah Humaira",
    modulNomor: 1,
    nilaiAwal: "95",
    indikatorBelumTuntas: "Seluruh indikator terlampaui dengan sangat mahir",
    bentukLayanan: "Pengayaan (Menjadi Tutor Sebaya & Praktik Huruf Sambung)",
    nilaiAkhir: "98",
    keterangan: "Pengayaan Terlaksana (Mahir)"
  }
];

const getTodayFormattedDate = () => {
  const now = new Date();
  return now.toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
};

// Helper format tanggal ke bahasa Indonesia resmi (contoh: "13 Juli 2026")
const formatTanggalIndo = (dateInput?: string | Date): string => {
  if (!dateInput) return "";
  if (typeof dateInput === "string") {
    const parts = dateInput.split("-");
    if (parts.length === 3 && parts[0].length === 4) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const months = [
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
      ];
      if (month >= 0 && month < 12 && day > 0 && day <= 31) {
        return `${day} ${months[month]} ${year}`;
      }
    }
    const d = new Date(dateInput);
    if (!isNaN(d.getTime())) {
      const months = [
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
      ];
      return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
    }
    return dateInput;
  }
  const months = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  return `${dateInput.getDate()} ${months[dateInput.getMonth()]} ${dateInput.getFullYear()}`;
};

export default function App() {
  // Status Offline & PWA
  const isOnline = useOnlineStatus();
  const { isInstallable, install } = usePWAInstall();

  // Daftar Sekolah Terdaftar (Hanya sekolah yang didaftarkan yang diizinkan login)
  const [registeredSchools, setRegisteredSchools] = useState<RegisteredSchool[]>(() => {
    try {
      const saved = localStorage.getItem("perangkat_registered_schools");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_REGISTERED_SCHOOLS;
  });

  // Sinkronisasi otomatis registeredSchools ke localStorage
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_registered_schools", JSON.stringify(registeredSchools));
    } catch {}
  }, [registeredSchools]);

  // Kontrol Hak Akses Fitur Menu (Diatur oleh Admin dengan tanda centang [✓] untuk guru / share)
  const [menuPermissions, setMenuPermissions] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem("perangkat_menu_permissions");
      if (saved) return { ...DEFAULT_MENU_PERMISSIONS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_MENU_PERMISSIONS;
  });

  // Sinkronisasi otomatis menuPermissions ke localStorage
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_menu_permissions", JSON.stringify(menuPermissions));
    } catch {}
  }, [menuPermissions]);

  // Daftar Akun Pengguna Terdaftar (Persisten di localStorage)
  const [userAccounts, setUserAccounts] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem("perangkat_user_accounts");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_USER_ACCOUNTS;
  });

  // Current User yang sedang login di sesi aktif
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    try {
      const saved = sessionStorage.getItem("admin_auth_user");
      if (saved) return JSON.parse(saved);
    } catch {}
    return null;
  });

  // Status Autentikasi Sesi (Wajib Login Setiap Membuka Link / Tab Baru)
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    try {
      return sessionStorage.getItem("admin_auth_session") === "true";
    } catch {
      return false;
    }
  });

  const [loginGuru, setLoginGuru] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_identitas");
      return saved ? JSON.parse(saved).guruPai || "" : "SUHENDRI, S.Pd.I";
    } catch {
      return "SUHENDRI, S.Pd.I";
    }
  });

  const [loginSekolah, setLoginSekolah] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_identitas");
      return saved ? JSON.parse(saved).sekolah || "" : "SD NEGERI CIKETING UDIK 2";
    } catch {
      return "SD NEGERI CIKETING UDIK 2";
    }
  });

  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [showPasswordHint, setShowPasswordHint] = useState(false);
  const [showPasswordText, setShowPasswordText] = useState(false);

  // Deteksi apakah pengguna yang sedang login adalah Admin
  const isAdmin = currentUser?.role === "admin";

  // State Navigasi Utama
  // State Kop Surat Resmi Sekolah
  const [kopSuratUrl, setKopSuratUrl] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("perangkat_kop_surat");
      if (saved) return saved;
      const identitasSaved = localStorage.getItem("perangkat_identitas");
      if (identitasSaved) {
        const parsed = JSON.parse(identitasSaved);
        if (parsed.kopSurat) return parsed.kopSurat;
      }
      return "";
    } catch {
      return "";
    }
  });

  const [useKopSurat, setUseKopSurat] = useState<boolean>(() => {
    try {
      return localStorage.getItem("perangkat_use_kop_surat") !== "false";
    } catch {
      return true;
    }
  });

  // State Notice Sebelum Simpan/Cetak PDF: "Pakai Kop Surat / Tidak" & "Layout Portrait / Landscape"
  const [printNoticeModal, setPrintNoticeModal] = useState<{
    show: boolean;
    elemId: string;
    docTitle: string;
    withKop: boolean;
    orientation: "portrait" | "landscape";
  }>({
    show: false,
    elemId: "printable-area",
    docTitle: "",
    withKop: true,
    orientation: "portrait"
  });

  // State Modal Khusus Penentuan Tanggal Cetak ke Semua Dokumen
  const [showDateModal, setShowDateModal] = useState(false);
  const [tempTanggal, setTempTanggal] = useState("");
  const [tempKota, setTempKota] = useState("");

  const kopFileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadKopSurat = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      showToast("Ukuran berkas terlalu besar. Maksimal ukuran gambar 5 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = ev.target?.result as string;
      setKopSuratUrl(base64);
      try {
        localStorage.setItem("perangkat_kop_surat", base64);
        setIdentitas((prev: any) => ({ ...prev, kopSurat: base64 }));
      } catch (err) {
        console.warn("Storage quota exceeded or error:", err);
      }
      showToast("Kop surat resmi sekolah berhasil diunggah!");
    };
    reader.readAsDataURL(file);
    if (e.target) e.target.value = "";
  };

  const handleRemoveKopSurat = () => {
    setKopSuratUrl("");
    try {
      localStorage.removeItem("perangkat_kop_surat");
      setIdentitas((prev: any) => ({ ...prev, kopSurat: "" }));
    } catch {}
    showToast("Kop surat resmi berhasil dihapus.");
  };

  // State Logo Sekolah Resmi (Digunakan untuk Cover dan Ikon Header di sebelah kiri judul)
  const [logoSekolahUrl, setLogoSekolahUrl] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("perangkat_logo_sekolah");
      if (saved) return saved;
      const identitasSaved = localStorage.getItem("perangkat_identitas");
      if (identitasSaved) {
        const parsed = JSON.parse(identitasSaved);
        if (parsed.logoSekolah) return parsed.logoSekolah;
      }
      return "";
    } catch {
      return "";
    }
  });

  const logoFileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadLogoSekolah = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      showToast("Ukuran berkas logo terlalu besar. Maksimal 5 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = ev.target?.result as string;
      setLogoSekolahUrl(base64);
      try {
        localStorage.setItem("perangkat_logo_sekolah", base64);
        setIdentitas((prev: any) => ({ ...prev, logoSekolah: base64 }));
      } catch (err) {
        console.warn("Storage error:", err);
      }
      showToast("Logo sekolah resmi berhasil diunggah dan disimpan!");
    };
    reader.readAsDataURL(file);
    if (e.target) e.target.value = "";
  };

  const handleRemoveLogoSekolah = () => {
    setLogoSekolahUrl("");
    try {
      localStorage.removeItem("perangkat_logo_sekolah");
      setIdentitas((prev: any) => ({ ...prev, logoSekolah: "" }));
    } catch {}
    showToast("Logo sekolah resmi berhasil dihapus.");
  };

  const [activeTab, setActiveTab] = useState("beranda"); // 'beranda' | 'identitas' | 'cover' | 'modul' | 'kokurikuler' | 'analisis-cp' | 'atp' | 'minggu-efektif' | 'prota' | 'promes' | 'kktp' | 'remedial-pengayaan' | 'program-keagamaan'
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Helper cek apakah suatu tab menu diizinkan untuk diakses
  const isTabEnabled = (tabId: string): boolean => {
    if (isAdmin) return true;
    if (tabId === "beranda") return true;
    if (tabId === "hak-akses") return false;
    return menuPermissions[tabId] !== false;
  };

  // Navigasi aman yang memblokir perpindahan ke menu yang dinonaktifkan
  const safeSetActiveTab = (tabId: string) => {
    if (!isTabEnabled(tabId)) {
      showToast("Menu ini sedang dinonaktifkan oleh Administrator.");
      return;
    }
    setActiveTab(tabId);
    setMobileSidebarOpen(false);
  };

  // Perlindungan Hak Akses Menu: Guru Non-Admin dialihkan ke Beranda jika mengakses menu yang dinonaktifkan oleh Admin
  useEffect(() => {
    if (!isAdmin && activeTab !== "beranda") {
      if (!isTabEnabled(activeTab)) {
        setActiveTab("beranda");
      }
    }
  }, [isAdmin, activeTab, menuPermissions]);
  const [paperLightMode, setPaperLightMode] = useState(true); // Opsi melihat kertas dokumen dalam mode terang/gelap
  const [lineSpacing, setLineSpacing] = useState("1.15"); // Standar spasi baris dokumen resmi: '1.15' atau '1.5'
  const [previewOfficialLayout, setPreviewOfficialLayout] = useState(true); // Pratinjau tata letak A4 Times New Roman langsung di layar
  const fileInputRef = useRef(null);

  // State Identitas Sekolah & Guru (Tersimpan otomatis di LocalStorage)
  const [identitas, setIdentitas] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_identitas");
      return saved ? JSON.parse(saved) : DEFAULT_IDENTITAS;
    } catch {
      return DEFAULT_IDENTITAS;
    }
  });

  // Sinkronisasi otomatis identitas ke LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_identitas", JSON.stringify(identitas));
    } catch {}
  }, [identitas]);

  // State Daftar Kelas (Rombel) & Jadwal Mengajar Mingguan Guru PAI
  const [daftarKelas, setDaftarKelas] = useState<KelasRombelItem[]>(() => {
    try {
      const saved = localStorage.getItem("perangkat_daftar_kelas");
      return saved ? JSON.parse(saved) : DEFAULT_DAFTAR_KELAS;
    } catch {
      return DEFAULT_DAFTAR_KELAS;
    }
  });

  const [jadwalMengajar, setJadwalMengajar] = useState<JadwalMengajarItem[]>(() => {
    try {
      const saved = localStorage.getItem("perangkat_jadwal_mengajar");
      return saved ? JSON.parse(saved) : DEFAULT_JADWAL_MENGAJAR;
    } catch {
      return DEFAULT_JADWAL_MENGAJAR;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_daftar_kelas", JSON.stringify(daftarKelas));
    } catch {}
  }, [daftarKelas]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_jadwal_mengajar", JSON.stringify(jadwalMengajar));
    } catch {}
  }, [jadwalMengajar]);

  // State Pilihan Alokasi Jam Pelajaran (JP): 3 JP atau 4 JP per minggu
  const [alokasiJpDefault, setAlokasiJpDefault] = useState<3 | 4>(() => {
    try {
      const saved = localStorage.getItem("perangkat_alokasi_jp");
      if (saved === "4") return 4;
    } catch {}
    return 3;
  });

  const handleSetAlokasiJp = (val: 3 | 4) => {
    setAlokasiJpDefault(val);
    try {
      localStorage.setItem("perangkat_alokasi_jp", String(val));
    } catch {}
    showToast(`Alokasi waktu pembelajaran diatur ke ${val} JP per minggu/pertemuan`);
  };

  // State Modul Ajar & Filter
  const [modules, setModules] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_modules");
      return saved ? JSON.parse(saved) : INITIAL_MODULES;
    } catch {
      return INITIAL_MODULES;
    }
  });
  const [selectedKelas, setSelectedKelas] = useState("I");
  const [selectedSemester, setSelectedSemester] = useState("I (Ganjil)");
  const [selectedElemen, setSelectedElemen] = useState("Semua");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeModulId, setActiveModulId] = useState("k1-s1-m1");
  const [versiTemplate, setVersiTemplate] = useState(2); // 1 = Versi 1, 2 = Versi 2, 3 = Versi 3 (Lengkap PM)
  const [isEditingModul, setIsEditingModul] = useState(false);

  // State Edit & Simpan untuk Setiap Dokumen Administrasi
  const [isEditingAnalisis, setIsEditingAnalisis] = useState(false);
  const [isEditingAtp, setIsEditingAtp] = useState(false);
  const [isEditingProta, setIsEditingProta] = useState(false);
  const [isEditingPromes, setIsEditingPromes] = useState(false);
  const [isEditingKktp, setIsEditingKktp] = useState(false);
  const [isEditingRemedial, setIsEditingRemedial] = useState(false);
  const [isEditingRme, setIsEditingRme] = useState(false);
  const [isEditingKeagamaan, setIsEditingKeagamaan] = useState(false);

  // State Filter RME (Rincian Minggu Efektif)
  const [rmeKelas, setRmeKelas] = useState("I");
  const [rmeSemester, setRmeSemester] = useState("Semua"); // 'Semua' | 'I (Ganjil)' | 'II (Genap)'

  // State Data RME
  const [rmeData, setRmeData] = useState<RmeData>(() => {
    try {
      const saved = localStorage.getItem("perangkat_rme_data");
      return saved ? JSON.parse(saved) : DEFAULT_RME_DATA;
    } catch {
      return DEFAULT_RME_DATA;
    }
  });

  // State Data Program Keagamaan Islam
  const [programKeagamaan, setProgramKeagamaan] = useState<ProgramKeagamaanData>(() => {
    try {
      const saved = localStorage.getItem("perangkat_program_keagamaan");
      return saved ? JSON.parse(saved) : DEFAULT_PROGRAM_KEAGAMAAN;
    } catch {
      return DEFAULT_PROGRAM_KEAGAMAAN;
    }
  });

  // State ATP Terstruktur & Persisten
  const [atpList, setAtpList] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_atp_data");
      return saved ? JSON.parse(saved) : INITIAL_ATP_DATA;
    } catch {
      return INITIAL_ATP_DATA;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_atp_data", JSON.stringify(atpList));
    } catch {}
  }, [atpList]);

  // State Interval KKTP Kustom
  const [kktpIntervals, setKktpIntervals] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_kktp_intervals");
      return saved ? JSON.parse(saved) : {
        perluBimbingan: "0 - 65",
        cukup: "66 - 75",
        baik: "76 - 85",
        sangatBaik: "86 - 100",
        tindakLanjut: "Intervensi remedial individual untuk nilai < 66; Pengayaan penguatan kontekstual untuk nilai >= 86."
      };
    } catch {
      return {
        perluBimbingan: "0 - 65",
        cukup: "66 - 75",
        baik: "76 - 85",
        sangatBaik: "86 - 100",
        tindakLanjut: "Intervensi remedial individual untuk nilai < 66; Pengayaan penguatan kontekstual untuk nilai >= 86."
      };
    }
  });

  // State Catatan Remedial & Pengayaan
  const [remNotes, setRemNotes] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_rem_notes");
      return saved ? JSON.parse(saved) : {
        strategiRemedial: "Bimbingan perorangan, penyederhanaan materi/LKPD, dan tutor sebaya dengan tes formatif ulang.",
        strategiPengayaan: "Pemberian tugas eksplorasi materi kontekstual, studi kasus Islami, dan peran sebagai tutor sebaya."
      };
    } catch {
      return {
        strategiRemedial: "Bimbingan perorangan, penyederhanaan materi/LKPD, dan tutor sebaya dengan tes formatif ulang.",
        strategiPengayaan: "Pemberian tugas eksplorasi materi kontekstual, studi kasus Islami, dan peran sebagai tutor sebaya."
      };
    }
  });

  // Helper Simpan Dokumen dengan Notifikasi Sukses
  const handleSaveModul = () => {
    try {
      localStorage.setItem("perangkat_modules", JSON.stringify(modules));
    } catch {}
    setIsEditingModul(false);
    showToast("Perubahan Modul Ajar berhasil disimpan!");
  };

  const handleSaveKokurikuler = () => {
    try {
      localStorage.setItem("perangkat_kokurikuler", JSON.stringify(kokurikulerList));
    } catch {}
    setIsEditingKo(false);
    showToast("Perubahan Modul Kokurikuler berhasil disimpan!");
  };

  const handleSaveAnalisis = () => {
    try {
      localStorage.setItem("perangkat_modules", JSON.stringify(modules));
      localStorage.setItem("perangkat_atp_data", JSON.stringify(atpList));
    } catch {}
    setIsEditingAnalisis(false);
    showToast("Perubahan Dokumen Analisis CP berhasil disimpan!");
  };

  const handleSaveAtp = () => {
    try {
      localStorage.setItem("perangkat_atp_data", JSON.stringify(atpList));
    } catch {}
    setIsEditingAtp(false);
    showToast("Perubahan Alur Tujuan Pembelajaran (ATP) berhasil disimpan!");
  };

  const handleSaveProta = () => {
    try {
      localStorage.setItem("perangkat_modules", JSON.stringify(modules));
    } catch {}
    setIsEditingProta(false);
    showToast("Perubahan Program Tahunan (PROTA) berhasil disimpan!");
  };

  const handleSavePromes = () => {
    try {
      localStorage.setItem("perangkat_modules", JSON.stringify(modules));
    } catch {}
    setIsEditingPromes(false);
    showToast("Perubahan Program Semester (PROMES) berhasil disimpan!");
  };

  const handleSaveKktp = () => {
    try {
      localStorage.setItem("perangkat_kktp_intervals", JSON.stringify(kktpIntervals));
      localStorage.setItem("perangkat_modules", JSON.stringify(modules));
    } catch {}
    setIsEditingKktp(false);
    showToast("Perubahan Dokumen KKTP berhasil disimpan!");
  };

  const handleSaveRemedial = () => {
    try {
      localStorage.setItem("perangkat_rem_notes", JSON.stringify(remNotes));
      localStorage.setItem("perangkat_jurnal_remedial", JSON.stringify(jurnalRemedialList));
    } catch {}
    setIsEditingRemedial(false);
    showToast("Perubahan Program Remedial & Pengayaan berhasil disimpan!");
  };

  const handleSaveRme = () => {
    try {
      localStorage.setItem("perangkat_rme_data", JSON.stringify(rmeData));
    } catch {}
    setIsEditingRme(false);
    showToast("Perubahan Rincian Minggu Efektif (RME) berhasil disimpan!");
  };

  const handleSaveKeagamaan = () => {
    try {
      localStorage.setItem("perangkat_program_keagamaan", JSON.stringify(programKeagamaan));
    } catch {}
    setIsEditingKeagamaan(false);
    showToast("Perubahan Program Keagamaan Islam berhasil disimpan!");
  };

  const handleUpdateModulFieldById = (id, field, val) => {
    setModules(prev => prev.map(m => m.id === id ? { ...m, [field]: val } : m));
  };

  // State Filter ATP
  const [selectedFaseAtp, setSelectedFaseAtp] = useState("Semua");

  // State Filter Analisis CP per Kelas & Semester
  const [analisisKelas, setAnalisisKelas] = useState("I");
  const [analisisSemester, setAnalisisSemester] = useState("Semua");
  const [analisisElemen, setAnalisisElemen] = useState("Semua");

  // State Filter PROTA, PROMES & KKTP
  const [protaKelas, setProtaKelas] = useState("I");
  const [protaMergeSemester, setProtaMergeSemester] = useState(false);
  const [promesKelas, setPromesKelas] = useState("I");
  const [promesSemester, setPromesSemester] = useState("I (Ganjil)");
  const [kktpKelas, setKktpKelas] = useState("I");
  const [kktpSemester, setKktpSemester] = useState("I (Ganjil)");
  const [kktpModel, setKktpModel] = useState("interval"); // 'interval' | 'rubrik' | 'deskripsi'

  // State Filter & Data Program Remedial & Pengayaan
  const [remKelas, setRemKelas] = useState("I");
  const [remSemester, setRemSemester] = useState("I (Ganjil)");
  const [remSubTab, setRemSubTab] = useState("program"); // 'program' | 'jurnal'
  const [jurnalRemedialList, setJurnalRemedialList] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_jurnal_remedial");
      return saved ? JSON.parse(saved) : DEFAULT_JURNAL;
    } catch {
      return DEFAULT_JURNAL;
    }
  });

  // State Modul Kokurikuler (Kelas I - VI, 2 Semester)
  const [kokurikulerList, setKokurikulerList] = useState(() => {
    try {
      const saved = localStorage.getItem("perangkat_kokurikuler");
      return saved ? JSON.parse(saved) : INITIAL_KOKURIKULER_DATA;
    } catch {
      return INITIAL_KOKURIKULER_DATA;
    }
  });
  const [koKelas, setKoKelas] = useState("Semua");
  const [koSemester, setKoSemester] = useState("Semua");
  const [activeKoId, setActiveKoId] = useState("ko-k1-s1");
  const [isEditingKo, setIsEditingKo] = useState(false);

  // Checklist Administrasi Guru
  const [checklist, setChecklist] = useState({
    atp: true,
    prota: true,
    promes: true,
    kktp: true,
    modul: true,
    kokurikuler: true,
    analisis: true,
    remedial: true
  });

  // State Notifikasi Toast
  const [toastMsg, setToastMsg] = useState(null);

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3200);
  };

  // Filter daftar modul berdasarkan kelas, semester, elemen, dan kata kunci
  const filteredModules = useMemo(() => {
    return modules.filter((m) => {
      const matchKelas = selectedKelas === "Semua" || m.kelas === selectedKelas;
      const matchSem = selectedSemester === "Semua" || m.semester === selectedSemester;
      const matchElemen = selectedElemen === "Semua" || m.elemen === selectedElemen;
      const matchSearch =
        !searchQuery.trim() ||
        m.tp.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.elemen.toLowerCase().includes(searchQuery.toLowerCase()) ||
        `modul ajar ${m.nomor}`.includes(searchQuery.toLowerCase());
      return matchKelas && matchSem && matchElemen && matchSearch;
    });
  }, [modules, selectedKelas, selectedSemester, selectedElemen, searchQuery]);

  // Modul yang sedang aktif dilihat
  const activeModul = useMemo(() => {
    return modules.find((m) => m.id === activeModulId) || filteredModules[0] || modules[0];
  }, [modules, activeModulId, filteredModules]);

  // Filter daftar Modul Kokurikuler berdasarkan kelas dan semester
  const filteredKokurikuler = useMemo(() => {
    return kokurikulerList.filter((item) => {
      const matchKelas = koKelas === "Semua" || item.kelas === koKelas;
      const matchSem = koSemester === "Semua" || item.semester === koSemester;
      return matchKelas && matchSem;
    });
  }, [kokurikulerList, koKelas, koSemester]);

  const activeKokurikuler = useMemo(() => {
    return (
      kokurikulerList.find((item) => item.id === activeKoId) ||
      filteredKokurikuler[0] ||
      kokurikulerList[0]
    );
  }, [kokurikulerList, activeKoId, filteredKokurikuler]);

  const handleUpdateActiveKokurikuler = (field, value) => {
    setKokurikulerList((prev) =>
      prev.map((item) => (item.id === activeKokurikuler.id ? { ...item, [field]: value } : item))
    );
  };

  // Helper menghitung angka JP dari teks alokasi waktu (contoh: "3 x 3 JP" -> 9 JP)
  const parseTotalJP = (alokasiStr) => {
    if (!alokasiStr) return 0;
    const match = alokasiStr.match(/(\d+)\s*x\s*(\d+)/i);
    if (match) {
      return parseInt(match[1], 10) * parseInt(match[2], 10);
    }
    const single = alokasiStr.match(/(\d+)/);
    return single ? parseInt(single[1], 10) : 0;
  };

  const parseJumlahPertemuan = (alokasiStr, fallbackLength = 1) => {
    if (!alokasiStr) return fallbackLength;
    const match = alokasiStr.match(/(\d+)\s*x\s*(\d+)/i);
    return match ? parseInt(match[1], 10) : fallbackLength;
  };

  // Data Terstruktur Analisis CP per Kelas & per Semester
  const analisisCpData = useMemo(() => {
    const kelasOrder = ["I", "II", "III", "IV", "V", "VI"];
    const semesterOrder = ["I (Ganjil)", "II (Genap)"];

    const targetKelasList = analisisKelas === "Semua" ? kelasOrder : [analisisKelas];
    const targetSemList = analisisSemester === "Semua" ? semesterOrder : [analisisSemester];

    const groups = [];

    targetKelasList.forEach((kls) => {
      targetSemList.forEach((sem) => {
        const mods = modules.filter(
          (m) =>
            m.kelas === kls &&
            m.semester === sem &&
            (analisisElemen === "Semua" || m.elemen === analisisElemen)
        );

        if (mods.length > 0) {
          const fase = mods[0].fase;
          const faseObj = INITIAL_ATP_DATA.find((f) => f.fase === fase);

          const items = mods.map((m) => {
            const elObj = faseObj?.elemen.find((e) => e.nama === m.elemen);
            const jmlPertemuan = parseJumlahPertemuan(m.alokasi, m.pertemuan?.length || 1);
            const jp = jmlPertemuan * alokasiJpDefault;
            return {
              ...m,
              cp: elObj?.cp || "-",
              atpList: elObj?.atp || [],
              totalJp: jp,
              jmlPertemuan
            };
          });

          const totalJpSemester = items.reduce((acc, cur) => acc + cur.totalJp, 0);
          const totalPertemuanSemester = items.reduce((acc, cur) => acc + cur.jmlPertemuan, 0);

          groups.push({
            kelas: kls,
            fase,
            semester: sem,
            items,
            totalJpSemester,
            totalPertemuanSemester
          });
        }
      });
    });

    return groups;
  }, [modules, analisisKelas, analisisSemester, analisisElemen, alokasiJpDefault]);

  // Ringkasan Statistik Analisis CP yang sedang difilter
  const analisisSummary = useMemo(() => {
    const totalModul = analisisCpData.reduce((acc, g) => acc + g.items.length, 0);
    const totalJp = analisisCpData.reduce((acc, g) => acc + g.totalJpSemester, 0);
    const totalPertemuan = analisisCpData.reduce((acc, g) => acc + g.totalPertemuanSemester, 0);
    return { totalModul, totalJp, totalPertemuan };
  }, [analisisCpData]);

  // ==========================================
  // DATA GENERATOR: PROGRAM TAHUNAN (PROTA)
  // ==========================================
  const protaData = useMemo(() => {
    const kelasOrder = ["I", "II", "III", "IV", "V", "VI"];
    const targetKelasList = protaKelas === "Semua" ? kelasOrder : [protaKelas];

    return targetKelasList.map((kls) => {
      const sem1Mods = modules
        .filter((m) => m.kelas === kls && m.semester === "I (Ganjil)")
        .map((m) => {
          const jmlPertemuan = parseJumlahPertemuan(m.alokasi, m.pertemuan?.length || 1);
          return {
            ...m,
            jmlPertemuan,
            totalJp: jmlPertemuan * alokasiJpDefault
          };
        });

      const sem2Mods = modules
        .filter((m) => m.kelas === kls && m.semester === "II (Genap)")
        .map((m) => {
          const jmlPertemuan = parseJumlahPertemuan(m.alokasi, m.pertemuan?.length || 1);
          return {
            ...m,
            jmlPertemuan,
            totalJp: jmlPertemuan * alokasiJpDefault
          };
        });

      const totalJpSem1 = sem1Mods.reduce((acc, cur) => acc + cur.totalJp, 0);
      const totalPertSem1 = sem1Mods.reduce((acc, cur) => acc + cur.jmlPertemuan, 0);
      const totalJpSem2 = sem2Mods.reduce((acc, cur) => acc + cur.totalJp, 0);
      const totalPertSem2 = sem2Mods.reduce((acc, cur) => acc + cur.jmlPertemuan, 0);

      return {
        kelas: kls,
        fase: sem1Mods[0]?.fase || sem2Mods[0]?.fase || "A",
        sem1Mods,
        sem2Mods,
        totalJpSem1,
        totalPertSem1,
        totalJpSem2,
        totalPertSem2,
        totalJpTahun: totalJpSem1 + totalJpSem2,
        totalPertTahun: totalPertSem1 + totalPertSem2
      };
    });
  }, [modules, protaKelas, alokasiJpDefault]);

  // ==========================================
  // DATA GENERATOR: PROGRAM SEMESTER (PROMES)
  // ==========================================
  const promesData = useMemo(() => {
    const isGanjil = promesSemester === "I (Ganjil)";
    const bulanList = isGanjil
      ? ["Juli", "Agustus", "September", "Oktober", "November", "Desember"]
      : ["Januari", "Februari", "Maret", "April", "Mei", "Juni"];

    const mods = modules
      .filter((m) => m.kelas === promesKelas && m.semester === promesSemester)
      .map((m) => {
        const jmlPertemuan = parseJumlahPertemuan(m.alokasi, m.pertemuan?.length || 1);
        return {
          ...m,
          jmlPertemuan,
          totalJp: jmlPertemuan * alokasiJpDefault
        };
      });

    // Total 24 slot minggu (6 bulan x 4 minggu). Minggu efektif dimulai dari minggu ke-2 bulan pertama
    let currentWeekCursor = 2; // Minggu ke-1 Juli/Januari umumnya Masa Pengenalan / Awal Semester

    const rows = [];
    mods.forEach((m) => {
      const pertList = m.pertemuan.map((p, idx) => {
        // Hindari minggu tidak efektif tertentu (misal minggu ke-11 STS/PTS, minggu ke-23/24 SAS/PAS)
        if (currentWeekCursor === 11) currentWeekCursor = 12;
        if (currentWeekCursor > 22) currentWeekCursor = 22;

        const weekIndex = currentWeekCursor;
        currentWeekCursor += 1;

        return {
          ...p,
          pertKe: idx + 1,
          jp: alokasiJpDefault,
          weekIndex // 1 s.d. 24
        };
      });

      rows.push({
        ...m,
        pertemuanScheduled: pertList
      });
    });

    const totalJp = mods.reduce((acc, cur) => acc + cur.totalJp, 0);
    const totalPertemuan = mods.reduce((acc, cur) => acc + cur.jmlPertemuan, 0);

    return {
      kelas: promesKelas,
      fase: mods[0]?.fase || "A",
      semester: promesSemester,
      bulanList,
      rows,
      totalJp,
      totalPertemuan
    };
  }, [modules, promesKelas, promesSemester, alokasiJpDefault]);

  // ==========================================
  // DATA GENERATOR: KKTP (KRITERIA KETERCAPAIAN TP)
  // ==========================================
  const kktpData = useMemo(() => {
    const mods = modules.filter(
      (m) =>
        m.kelas === kktpKelas &&
        (kktpSemester === "Semua" || m.semester === kktpSemester)
    );

    const items = mods.map((m) => {
      const indikatorList = m.pertemuan.map((p) => {
        // Ambil deskripsi indikator dari dalam tanda kurung judul pertemuan bila ada
        const match = p.judul.match(/\(([^)]+)\)/);
        const cleanIndikator = match ? match[1] : p.judul;
        return `Mampu ${cleanIndikator.charAt(0).toLowerCase() + cleanIndikator.slice(1)} dengan baik dan benar.`;
      });

      return {
        ...m,
        totalJp: parseTotalJP(m.alokasi),
        indikatorList,
        rubrik: {
          baruBerkembang: `Belum mampu ${m.tp.toLowerCase()} secara mandiri dan masih memerlukan bimbingan penuh dari guru.`,
          layak: `Mampu memahami dan mempraktikkan sebagian indikator ${m.tp.toLowerCase()} dengan bimbingan sesekali.`,
          cakap: `Mampu ${m.tp.toLowerCase()} secara mandiri, tepat, dan sesuai seluruh indikator ketercapaian.`,
          mahir: `Mampu ${m.tp.toLowerCase()} secara sangat lancar, konsisten, serta dapat membimbing atau menjadi teladan bagi teman sebaya.`
        }
      };
    });

    return {
      kelas: kktpKelas,
      fase: items[0]?.fase || "A",
      semester: kktpSemester,
      items
    };
  }, [modules, kktpKelas, kktpSemester]);

  // ==========================================
  // DATA GENERATOR: PROGRAM REMEDIAL & PENGAYAAN
  // ==========================================
  const remedialPengayaanData = useMemo(() => {
    const mods = modules.filter(
      (m) =>
        m.kelas === remKelas &&
        (remSemester === "Semua" || m.semester === remSemester)
    );

    const items = mods.map((m) => {
      const indikatorUtama = m.pertemuan.map((p) => {
        const match = p.judul.match(/\(([^)]+)\)/);
        return match ? match[1] : p.judul;
      });

      // Menyesuaikan strategi berdasarkan elemen PAI
      let strategiRemedial = "Pembimbingan individu/kelompok kecil, penyederhanaan materi dengan media visual, dan latihan bertahap.";
      let strategiPengayaan = "Eksplorasi materi lanjutan, penugasan proyek mini, dan peran sebagai tutor sebaya.";

      if (m.elemen === "Al-Qur’an-Hadis") {
        strategiRemedial = "Bimbingan khusus talaqqi/drill pelafalan makhraj dan tajwid menggunakan kartu flashcard/audio murattal serta pendampingan tutor sebaya.";
        strategiPengayaan = "Menjadi tutor sebaya dalam menyimak bacaan/hafalan teman, menulis kaligrafi ayat/hadis, dan mentadabburi kandungan ayat lebih mendalam.";
      } else if (m.elemen === "Akidah") {
        strategiRemedial = "Penjelasan ulang konsep keimanan menggunakan peta konsep bergambar, tanya jawab terarah, dan lembar kerja menjodohkan.";
        strategiPengayaan = "Membuat poster/infografis reflektif bukti keimanan dalam kehidupan sehari-hari dan mempresentasikannya di depan kelas.";
      } else if (m.elemen === "Akhlak") {
        strategiRemedial = "Pendampingan refleksi perilaku melalui cerita bergambar/video keteladanan dan bimbingan pembiasaan adab harian.";
        strategiPengayaan = "Menganalisis studi kasus keteladanan akhlak, memimpin kampanye adab mulia di kelas, dan menyusun jurnal kebaikan.";
      } else if (m.elemen === "Fikih") {
        strategiRemedial = "Demonstrasi ulang dan praktik terbimbing langkah demi langkah (scaffolding) tata cara ibadah hingga tertib dan benar.";
        strategiPengayaan = "Praktik simulasi ibadah sebagai imam/pemandu kelompok dan mempelajari hikmah serta amalan sunah pelengkap ibadah terkait.";
      } else if (m.elemen === "Sejarah Peradaban Islam") {
        strategiRemedial = "Menyimak kembali alur kisah keteladanan melalui bagan alur cerita (timeline) sederhana dan tanya jawab terbimbing.";
        strategiPengayaan = "Menceritakan kembali (storytelling) kisah teladan dengan bahasa sendiri dan merumuskan nilai kepemimpinan tokoh dalam kehidupan modern.";
      }

      return {
        ...m,
        indikatorUtama,
        strategiRemedial,
        bentukAsesmenRemedial: `Asesmen ulang terfokus pada indikator yang belum tuntas (${m.asesmen.toLowerCase()})`,
        strategiPengayaan,
        tagihanPengayaan: "Portofolio karya reflektif / unjuk kerja tutor sebaya / ringkasan eksplorasi materi."
      };
    });

    return {
      kelas: remKelas,
      fase: items[0]?.fase || "A",
      semester: remSemester,
      items
    };
  }, [modules, remKelas, remSemester]);

  const handleAddJurnalRow = () => {
    setJurnalRemedialList((prev) => [
      ...prev,
      {
        id: Date.now(),
        nama: "Nama Murid Baru",
        modulNomor: 1,
        nilaiAwal: "60",
        indikatorBelumTuntas: "Indikator yang memerlukan bimbingan...",
        bentukLayanan: "Remedial (Bimbingan Khusus)",
        nilaiAkhir: "78",
        keterangan: "Tuntas mencapai KKTP"
      }
    ]);
  };

  const handleUpdateJurnalRow = (id, field, value) => {
    setJurnalRemedialList((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: value } : row))
    );
  };

  const handleDeleteJurnalRow = (id) => {
    setJurnalRemedialList((prev) => prev.filter((row) => row.id !== id));
  };

  // Fungsi mengganti sapaan "Murid" <-> "Peserta didik" sesuai pengaturan
  const formatTextSapaan = (text) => {
    if (!text) return "";
    if (identitas.sapaanSiswa === "Peserta didik") {
      return text
        .replace(/\bMurid\b/g, "Peserta didik")
        .replace(/\bmurid\b/g, "peserta didik");
    }
    return text
      .replace(/\bPeserta didik\b/g, "Murid")
      .replace(/\bpeserta didik\b/g, "murid");
  };

  // Fungsi Update Modul Aktif saat mode edit
  const handleUpdateActiveModul = (field, value) => {
    setModules((prev) =>
      prev.map((m) => (m.id === activeModul.id ? { ...m, [field]: value } : m))
    );
  };

  // Handler Login Sesi: Akses Sekolah Terdaftar, Nama Guru Bebas, Password Dinamis Harian, Admin Otomatis
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    const name = loginGuru.trim();
    const school = loginSekolah.trim();
    const pass = loginPassword.trim();

    if (!name) {
      setLoginError("Nama Pengguna / Guru Lengkap wajib diisi.");
      return;
    }

    if (!school) {
      setLoginError("Nama Sekolah / Satuan Pendidikan wajib diisi.");
      return;
    }

    if (!pass) {
      setLoginError(`Password dinamis harian format tanggalbulantahun (${getTodayPassword()}) wajib diisi.`);
      return;
    }

    // 1. Validasi Sekolah Terdaftar (HANYA SEKOLAH YANG TELAH DIDAFTARKAN YANG BISA AKSES)
    const matchedSchool = findMatchedSchool(school, registeredSchools);
    if (!matchedSchool) {
      setLoginError(
        `Akses Ditolak: Sekolah "${school}" belum terdaftar! Hanya guru dari sekolah yang telah didaftarkan oleh Administrator yang dapat mengakses aplikasi. Silakan hubungi Administrator (085780255805) untuk mendaftarkan nama sekolah Anda.`
      );
      return;
    }

    if (matchedSchool.status === "nonaktif") {
      setLoginError(
        `Akses Sekolah Dikunci: Status akses untuk "${matchedSchool.nama}" saat ini sedang dinonaktifkan oleh Administrator (085780255805).`
      );
      return;
    }

    // 2. Validasi Password Dinamis Harian: Format TanggalBulanTahun (ddmmyy, contoh: 081126)
    const isPassValid = isValidDailyPassword(pass);
    if (!isPassValid) {
      setLoginError(
        `Password salah! Masukkan password dinamis harian dengan format tanggalbulantahun (${getTodayPassword()}). Berlaku untuk seluruh guru dan administrator.`
      );
      return;
    }

    // 3. Deteksi Peran Otomatis: Admin jika Guru = "SUHENDRI,S.Pd.I" dan Sekolah = "SD NEGERI CIKETING UDIK 2"
    const isAdminUser = isMatchedAdmin(name, school);

    const authUser: UserAccount = {
      id: isAdminUser ? "admin-suhendri" : `usr-${Date.now().toString(36)}`,
      namaLengkap: name,
      namaSekolah: matchedSchool.nama,
      password: pass,
      role: isAdminUser ? "admin" : "guru",
      status: "aktif",
      createdAt: new Date().toLocaleDateString("id-ID"),
      lastLogin: new Date().toLocaleDateString("id-ID"),
      keterangan: isAdminUser
        ? "Administrator Sistem Utama (Guru PAI & BP SD Negeri Ciketing Udik 2)"
        : "Guru PAI & BP Terdaftar"
    };

    // Update userAccounts di localStorage
    setUserAccounts((prev) => {
      const idx = prev.findIndex(
        (u) =>
          u.namaLengkap.toLowerCase() === name.toLowerCase() &&
          u.namaSekolah.toLowerCase() === matchedSchool.nama.toLowerCase()
      );
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          lastLogin: "Hari Ini",
          role: isAdminUser ? "admin" : "guru",
          password: `Dinamis (${getTodayPassword()})`
        };
        return updated;
      }
      return [...prev, authUser];
    });

    setCurrentUser(authUser);
    setIdentitas((prev) => ({
      ...prev,
      guruPai: name,
      sekolah: matchedSchool.nama
    }));

    try {
      sessionStorage.setItem("admin_auth_session", "true");
      sessionStorage.setItem("admin_auth_user", JSON.stringify(authUser));
      localStorage.setItem("perangkat_identitas", JSON.stringify({
        ...identitas,
        guruPai: name,
        sekolah: matchedSchool.nama
      }));
    } catch {}

    setIsAuthenticated(true);
    setActiveTab("beranda");
    if (isAdminUser) {
      showToast(`Selamat datang, Administrator SUHENDRI, S.Pd.I! Mode Administrator aktif dengan hak akses penuh.`);
    } else {
      showToast(`Selamat datang, ${name}! Sesi administrasi aktif untuk ${matchedSchool.nama}.`);
    }
  };

  const handleLogout = () => {
    try {
      sessionStorage.removeItem("admin_auth_session");
      sessionStorage.removeItem("admin_auth_user");
    } catch {}
    setIsAuthenticated(false);
    setCurrentUser(null);
    setLoginPassword("");
    setActiveTab("beranda");
    showToast("Sesi telah keluar. Silakan login kembali.");
  };

  // State untuk Modal Opsi Simpan PDF (100% Berfungsi di Seluruh Perangkat & Iframe)
  const [pdfHelperData, setPdfHelperData] = useState<{
    show: boolean;
    title: string;
    blobUrl: string;
    isLandscape: boolean;
  }>({ show: false, title: "", blobUrl: "", isLandscape: false });

  // Fungsi Simpan PDF / Cetak (100% Berfungsi di Browser & Iframe dengan Isolasi Kertas A4 Resmi)
  const handlePrint = (customTargetId?: any, docTitle?: string, withKop?: boolean, customOrientation?: "portrait" | "landscape") => {
    const targetElemId = typeof customTargetId === "string" && customTargetId ? customTargetId : "printable-area";
    const defaultOrientation: "portrait" | "landscape" =
      customOrientation || (activeTab === "promes" || activeTab === "analisis-cp" || activeTab === "jurnal-mengajar" || activeTab === "penilaian" || activeTab === "absensi" || activeTab === "hak-akses" || targetElemId === "printable-jadwal-area" || targetElemId === "printable-penilaian-area" || targetElemId === "printable-absensi-area" || targetElemId === "printable-hak-akses-area" ? "landscape" : "portrait");

    // Jika belum ada pilihan kop surat eksplisit (withKop bukan boolean), buka dialog notice konfirmasi format cetak/PDF
    if (typeof withKop !== "boolean") {
      setPrintNoticeModal({
        show: true,
        elemId: targetElemId,
        docTitle: typeof docTitle === "string" ? docTitle : "",
        withKop: useKopSurat,
        orientation: defaultOrientation
      });
      return;
    }

    // 1. Dapatkan elemen dokumen resmi target cetak
    const targetId = targetElemId;
    let elem = document.getElementById(targetId);

    // Fallback pencarian: jika ID spesifik tidak ditemukan, cari wadah resmi dokumen
    if (!elem) {
      elem = (document.querySelector(".official-doc-typography") ||
              document.querySelector("[data-printable='true']") ||
              document.getElementById("printable-area")) as HTMLElement;
    }

    if (!elem) {
      showToast("Silakan buka salah satu tab berkas (Modul, PROTA, PROMES, KKTP, RME, atau Program Keagamaan) untuk menyimpan PDF.");
      return;
    }

    // Pastikan elemen aktif memiliki id 'printable-area' agar aturan CSS @media print bekerja optimal
    if (elem.id !== "printable-area") {
      document.querySelectorAll("#printable-area").forEach((el) => {
        if (el !== elem) el.removeAttribute("id");
      });
      elem.id = "printable-area";
    }

    // 2. Tentukan orientasi halaman (User dapat menentukan dan merubah Portrait atau Landscape secara bebas)
    const isLandscape = (customOrientation || defaultOrientation) === "landscape";
    const orientation = isLandscape ? "landscape" : "portrait";
    const pageSize = isLandscape ? "A4 landscape" : "A4 portrait";

    let calculatedTitle = docTitle;
    if (!calculatedTitle) {
      if (activeTab === "modul" && activeModul) {
        calculatedTitle = `Modul_Ajar_PAI_Kelas_${activeModul.kelas}_Sem_${activeModul.semester.split(" ")[0]}_Modul_${activeModul.nomor}`;
      } else if (activeTab === "prota") {
        calculatedTitle = `PROTA_PAI_Kelas_${activeModul?.kelas || 'SD'}_${identitas.tahunAjaran.replace(/\//g, '-')}`;
      } else if (activeTab === "promes") {
        calculatedTitle = `PROMES_PAI_Kelas_${activeModul?.kelas || 'SD'}_${identitas.tahunAjaran.replace(/\//g, '-')}`;
      } else if (activeTab === "jurnal-mengajar") {
        calculatedTitle = `Jurnal_Mengajar_PAI_${identitas.sekolah.replace(/\s+/g, '_')}_${identitas.tahunAjaran.replace(/\//g, '-')}`;
      } else if (activeTab === "atp") {
        calculatedTitle = `ATP_PAI_BP_Fase_${selectedFaseAtp}_${identitas.sekolah.replace(/\s+/g, '_')}`;
      } else if (activeTab === "kktp") {
        calculatedTitle = `KKTP_PAI_Kelas_${activeModul?.kelas || 'SD'}_${identitas.tahunAjaran.replace(/\//g, '-')}`;
      } else if (activeTab === "rme") {
        calculatedTitle = `Rincian_Minggu_Efektif_Kelas_${rmeKelas}_PAI_${identitas.tahunAjaran.replace(/\//g, '-')}`;
      } else if (activeTab === "keagamaan") {
        calculatedTitle = `Program_Keagamaan_Islam_${identitas.sekolah.replace(/\s+/g, '_')}_${identitas.tahunAjaran.replace(/\//g, '-')}`;
      } else {
        calculatedTitle = `Berkas_Administrasi_PAI_${identitas.sekolah.replace(/\s+/g, '_')}`;
      }
    }

    // 3. Pasang aturan @page dinamis sesuai tab aktif (Margin: Atas 1.5 cm, Kiri 2.5 cm, Kanan 2.0 cm, Bawah 2.0 cm)
    let dynamicStyle = document.getElementById("a4-print-dynamic-rule") as HTMLStyleElement;
    if (!dynamicStyle) {
      dynamicStyle = document.createElement("style");
      dynamicStyle.id = "a4-print-dynamic-rule";
      document.head.appendChild(dynamicStyle);
    }
    dynamicStyle.innerHTML = `
      @page {
        size: ${pageSize} !important;
        margin-top: 1.5cm !important;
        margin-left: 2.5cm !important;
        margin-right: 2.0cm !important;
        margin-bottom: 2.0cm !important;
      }
      @media print {
        html, body {
          width: 100% !important;
          height: auto !important;
          min-height: 100% !important;
          background: #ffffff !important;
          color: #000000 !important;
          overflow: visible !important;
        }
        #root, #root > div, main, .overflow-x-hidden {
          overflow: visible !important;
          overflow-x: visible !important;
          overflow-y: visible !important;
          height: auto !important;
          max-height: none !important;
          position: static !important;
          transform: none !important;
        }
        body * {
          visibility: hidden !important;
        }
        #printable-area, #printable-area * {
          visibility: visible !important;
        }
        #printable-area {
          position: absolute !important;
          left: 0 !important;
          top: 0 !important;
          width: 100% !important;
          max-width: none !important;
          margin: 0 !important;
          padding: 0 !important;
          border: none !important;
          box-shadow: none !important;
          background: #ffffff !important;
          color: #000000 !important;
          overflow: visible !important;
          display: block !important;
        }
        .ttd-container, .ttd-wrapper {
          width: 100% !important;
          margin-top: 20pt !important;
          page-break-inside: avoid !important;
          break-inside: avoid !important;
          border: none !important;
          background: transparent !important;
          display: block !important;
          clear: both !important;
        }
        .ttd-row {
          display: flex !important;
          display: -webkit-flex !important;
          flex-direction: row !important;
          justify-content: space-between !important;
          width: 100% !important;
          border: none !important;
        }
        .ttd-col-left {
          width: 45% !important;
          display: inline-block !important;
          float: left !important;
          text-align: left !important;
          box-sizing: border-box !important;
        }
        .ttd-col-right {
          width: 45% !important;
          display: inline-block !important;
          float: right !important;
          text-align: left !important;
          box-sizing: border-box !important;
        }
        .ttd-row::after {
          content: "" !important;
          display: table !important;
          clear: both !important;
        }
        /* Hilangkan tabel / garis pada bagian tanda tangan tanpa merubah format */
        table.ttd-table,
        table.ttd-table tr,
        table.ttd-table td,
        .ttd-table,
        .ttd-table tr,
        .ttd-table td,
        table.no-border,
        table.no-border tr,
        table.no-border td,
        .ttd-left,
        .ttd-right {
          border: none !important;
          border-width: 0 !important;
          border-style: none !important;
          outline: none !important;
          box-shadow: none !important;
          background: transparent !important;
        }
        .no-print {
          display: none !important;
        }
      }
    `;

    // 4. Siapkan dokumen bersih mandiri via Blob URL untuk Tab Baru Siap PDF
    const clone = elem.cloneNode(true) as HTMLElement;
    clone.querySelectorAll(".no-print").forEach((el) => el.remove());
    // Normalisasi overflow agar tabel tidak terpotong garisnya di cetak PDF
    clone.querySelectorAll(".overflow-x-auto, .overflow-y-auto").forEach((el) => {
      el.classList.remove("overflow-x-auto", "overflow-y-auto");
      (el as HTMLElement).style.overflow = "visible";
    });

    const shouldIncludeKop = withKop !== undefined ? withKop : useKopSurat;
    const existingKop = clone.querySelector(".kop-surat-header");

    if (shouldIncludeKop && kopSuratUrl) {
      if (!existingKop) {
        const kopDiv = document.createElement("div");
        kopDiv.className = "kop-surat-header mb-4 text-center";
        kopDiv.innerHTML = `
          <img src="${kopSuratUrl}" alt="Kop Surat Resmi" class="kop-surat-img" style="max-height: 120px; max-width: 100%; object-fit: contain; margin: 0 auto; display: block;" />
          <div class="kop-surat-divider" style="border-top: 2px solid #000000; margin-top: 6pt; margin-bottom: 12pt; width: 100%;"></div>
        `;
        clone.insertBefore(kopDiv, clone.firstChild);
      }
    } else {
      if (existingKop) {
        existingKop.remove();
      }
    }

    const standaloneHtml = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>${calculatedTitle}</title>
  <style>
    @page {
      size: ${pageSize};
      margin-top: 1.5cm;
      margin-left: 2.5cm;
      margin-right: 2.0cm;
      margin-bottom: 2.0cm;
    }
    * {
      box-sizing: border-box;
    }
    html, body {
      font-family: "Times New Roman", Times, serif;
      font-size: 11pt;
      line-height: ${lineSpacing};
      color: #000000;
      background-color: #ffffff;
      margin: 0;
      padding: 0;
      text-align: justify;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }

    /* KOP SURAT RESMI */
    .kop-surat-header {
      text-align: center !important;
      margin-bottom: 10pt !important;
      width: 100% !important;
      display: block !important;
    }
    .kop-surat-img {
      max-width: 100% !important;
      max-height: 120px !important;
      height: auto !important;
      object-fit: contain !important;
      margin: 0 auto !important;
      display: block !important;
    }
    .kop-surat-divider {
      border: none !important;
      border-top: 2px solid #000000 !important;
      margin-top: 6pt !important;
      margin-bottom: 12pt !important;
      width: 100% !important;
    }

    /* JUDUL DOKUMEN - RAPAT TANPA JARAK SPASI BERLEBIH, RATA TENGAH */
    .doc-header-box,
    .text-center.border-b-2 {
      text-align: center !important;
      border-bottom: 2px solid #000000 !important;
      padding-bottom: 6pt !important;
      margin-bottom: 12pt !important;
      display: block !important;
      width: 100% !important;
    }
    h2.doc-main-title,
    .doc-main-title {
      font-family: "Times New Roman", Times, serif !important;
      font-size: 14pt !important;
      font-weight: bold !important;
      text-transform: uppercase !important;
      text-align: center !important;
      margin: 0 !important;
      padding: 0 !important;
      line-height: 1.15 !important;
      display: block !important;
    }
    h3.doc-sub-title,
    .doc-sub-title {
      font-family: "Times New Roman", Times, serif !important;
      font-size: 13pt !important;
      font-weight: bold !important;
      text-transform: uppercase !important;
      text-align: center !important;
      margin: 0 !important;
      margin-top: 2pt !important;
      padding: 0 !important;
      line-height: 1.15 !important;
      display: block !important;
    }

    /* IDENTITAS DOKUMEN - RATA KIRI, TANPA TABEL, TITIK DUA RAPI SEJAJAR */
    .identitas-block,
    .space-y-0\\.5 {
      text-align: left !important;
      margin-top: 6pt !important;
      margin-bottom: 14pt !important;
      border: none !important;
      background: transparent !important;
      display: block !important;
      max-width: 650px !important;
    }
    .identitas-row,
    .flex.items-baseline {
      display: flex !important;
      display: -webkit-flex !important;
      flex-direction: row !important;
      align-items: baseline !important;
      margin-bottom: 2.5pt !important;
      line-height: 1.35 !important;
      font-size: 11pt !important;
      text-align: left !important;
    }
    .identitas-label,
    .w-44, .w-36 {
      width: 175px !important;
      min-width: 175px !important;
      max-width: 175px !important;
      font-weight: bold !important;
      text-align: left !important;
      flex-shrink: 0 !important;
      display: inline-block !important;
    }
    .identitas-colon,
    .w-4 {
      width: 16px !important;
      min-width: 16px !important;
      font-weight: bold !important;
      text-align: center !important;
      flex-shrink: 0 !important;
      display: inline-block !important;
    }
    .identitas-val,
    .flex.items-baseline > span:last-child {
      flex: 1 1 auto !important;
      text-align: left !important;
      display: inline-block !important;
    }
    .font-bold { font-weight: bold !important; }
    .uppercase { text-transform: uppercase !important; }
    .text-center { text-align: center !important; }
    .text-left { text-align: left !important; }

    /* TANDA TANGAN RESMI KEPALA SEKOLAH & GURU - HORIZONTAL KIRI & KANAN (ANTI-VERTIKAL) */
    .ttd-container,
    .ttd-wrapper {
      width: 100% !important;
      margin-top: 20pt !important;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
      border: none !important;
      background: transparent !important;
      display: block !important;
      clear: both !important;
    }
    .ttd-row,
    .keep-together .flex.justify-between,
    .flex.justify-between {
      display: flex !important;
      display: -webkit-flex !important;
      flex-direction: row !important;
      -webkit-flex-direction: row !important;
      justify-content: space-between !important;
      -webkit-justify-content: space-between !important;
      align-items: flex-start !important;
      width: 100% !important;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
      border: none !important;
    }
    .ttd-col-left,
    .ttd-col-right,
    .ttd-col,
    .keep-together .flex.justify-between > div,
    .flex.justify-between > div {
      width: 45% !important;
      min-width: 40% !important;
      max-width: 48% !important;
      display: inline-block !important;
      text-align: left !important;
      vertical-align: top !important;
      border: none !important;
      background: transparent !important;
      box-sizing: border-box !important;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .ttd-col-left,
    .keep-together .flex.justify-between > div:first-child {
      float: left !important;
    }
    .ttd-col-right,
    .keep-together .flex.justify-between > div:last-child {
      float: right !important;
    }
    .ttd-row::after,
    .keep-together .flex.justify-between::after,
    .flex.justify-between::after {
      content: "" !important;
      display: table !important;
      clear: both !important;
    }
    .ttd-space {
      height: 80px !important;
      min-height: 80px !important;
      display: block !important;
    }
    .print-header-bar {
      background: #0f172a;
      color: #ffffff;
      padding: 12px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 3px solid #10b981;
      font-family: system-ui, -apple-system, sans-serif;
      position: sticky;
      top: 0;
      z-index: 99999;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    .btn-pdf {
      background: #059669;
      color: #ffffff;
      border: none;
      padding: 9px 18px;
      font-weight: 700;
      font-size: 13px;
      border-radius: 8px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .btn-pdf:hover { background: #047857; }
    .btn-close {
      background: #334155;
      color: #cbd5e1;
      border: none;
      padding: 9px 14px;
      font-weight: 600;
      font-size: 13px;
      border-radius: 8px;
      cursor: pointer;
      margin-left: 8px;
    }
    .btn-close:hover { background: #475569; color: #fff; }
    .doc-wrapper {
      padding: 1.5cm 2.0cm 2.0cm 2.5cm;
      max-width: ${isLandscape ? "29.7cm" : "21.0cm"};
      margin: 0 auto;
      box-sizing: border-box;
      background: #fff;
    }
    table {
      width: 100% !important;
      border-collapse: collapse !important;
      border-spacing: 0 !important;
      page-break-inside: auto !important;
      break-inside: auto !important;
      margin-top: 6pt;
      margin-bottom: 12pt;
    }
    thead {
      display: table-header-group !important;
    }
    tfoot {
      display: table-footer-group !important;
    }
    tbody {
      display: table-row-group !important;
    }
    tr, .keep-together {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    th, td {
      border: 1px solid #000000 !important;
      padding: 5pt 6pt !important;
      font-size: 11pt;
      line-height: ${lineSpacing};
      box-sizing: border-box !important;
    }
    th {
      background-color: #f1f5f9 !important;
      font-weight: bold !important;
      text-align: center !important;
      vertical-align: middle !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    td {
      vertical-align: top;
    }
    .overflow-x-auto, .overflow-y-auto, .overflow-hidden {
      overflow: visible !important;
      max-width: 100% !important;
      height: auto !important;
    }
    /* HILANGKAN TABEL / GARIS PADA TANDA TANGAN TANPA MERUBAH FORMAT */
    table.ttd-table,
    table.ttd-table tr,
    table.ttd-table td,
    .ttd-table,
    .ttd-table tr,
    .ttd-table td,
    table.no-border,
    table.no-border tr,
    table.no-border td,
    .ttd-left,
    .ttd-right,
    .ttd-container table,
    .ttd-container td,
    .ttd-wrapper table,
    .ttd-wrapper td {
      border: none !important;
      border-width: 0 !important;
      border-style: none !important;
      border-color: transparent !important;
      outline: none !important;
      box-shadow: none !important;
      background: transparent !important;
      background-color: transparent !important;
    }
    @media print {
      .print-header-bar { display: none !important; }
      .doc-wrapper { padding: 0 !important; max-width: none !important; width: 100% !important; margin: 0 !important; }
      body { margin: 0 !important; padding: 0 !important; }
    }
  </style>
</head>
<body>
  <div class="print-header-bar no-print">
    <div>
      <span style="font-weight: 700; font-size: 14px;">📄 Pratinjau Dokumen Siap Simpan PDF</span>
      <span style="margin-left: 12px; font-size: 12px; color: #94a3b8;">Ukuran A4 (${isLandscape ? 'Landscape' : 'Portrait'}) • Margin: 1.5 - 2.5 - 2.0 - 2.0 cm</span>
    </div>
    <div>
      <button class="btn-pdf" onclick="window.print()">📥 Simpan sebagai PDF (Ctrl + P)</button>
      <button class="btn-close" onclick="window.close()">Tutup Halaman</button>
    </div>
  </div>
  <div class="doc-wrapper">
    ${clone.innerHTML}
  </div>
  <script>
    window.addEventListener('load', function() {
      setTimeout(function() {
        try {
          window.focus();
          window.print();
        } catch(e) {}
      }, 350);
    });
  <\/script>
</body>
</html>`;

    const blob = new Blob([standaloneHtml], { type: "text/html;charset=utf-8" });
    const blobUrl = URL.createObjectURL(blob);

    // Buka modal bantuan opsi simpan PDF
    setPdfHelperData({
      show: true,
      title: calculatedTitle,
      blobUrl: blobUrl,
      isLandscape: isLandscape
    });

    // 5. Beri panduan toast yang jelas
    showToast("Membuka dialog Simpan PDF... Pada opsi Tujuan (Destination), pilih 'Simpan sebagai PDF' (Save as PDF).");

    // 6. Cetak via hidden iframe dengan standaloneHtml murni (anti blank putih & anti terpotong)
    let printIframe = document.getElementById("clean-print-frame") as HTMLIFrameElement;
    if (printIframe) {
      try { printIframe.remove(); } catch {}
    }

    try {
      printIframe = document.createElement("iframe");
      printIframe.id = "clean-print-frame";
      printIframe.style.position = "fixed";
      printIframe.style.right = "0";
      printIframe.style.bottom = "0";
      printIframe.style.width = "0px";
      printIframe.style.height = "0px";
      printIframe.style.border = "0";
      printIframe.style.visibility = "hidden";
      document.body.appendChild(printIframe);

      const frameDoc = printIframe.contentWindow?.document || printIframe.contentDocument;
      if (frameDoc) {
        frameDoc.open();
        frameDoc.write(standaloneHtml);
        frameDoc.close();

        setTimeout(() => {
          try {
            printIframe.contentWindow?.focus();
            printIframe.contentWindow?.print();
          } catch (err) {
            console.warn("Iframe print gagal, fallback ke window.print:", err);
            window.focus();
            window.print();
          }
        }, 250);
      } else {
        setTimeout(() => {
          try {
            window.focus();
            window.print();
          } catch (err) {
            console.warn("Gagal membuka window.print langsung:", err);
          }
        }, 150);
      }
    } catch {
      setTimeout(() => {
        try {
          window.focus();
          window.print();
        } catch (err) {
          console.warn("Gagal membuka window.print langsung:", err);
        }
      }, 150);
    }
  };

  const handlePrintDocument = (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => {
    const defaultOrientation: "portrait" | "landscape" =
      preferredOrientation || (activeTab === "promes" || activeTab === "analisis-cp" || activeTab === "jurnal-mengajar" || activeTab === "penilaian" || activeTab === "absensi" || activeTab === "hak-akses" || elemId === "printable-jadwal-area" || elemId === "printable-penilaian-area" || elemId === "printable-absensi-area" || elemId === "printable-hak-akses-area" ? "landscape" : "portrait");

    // Tampilkan Notice sebelum Simpan/Cetak PDF: pilihan "Pakai Kop Surat / Tidak" & penentuan "Layout Portrait / Landscape"
    setPrintNoticeModal({
      show: true,
      elemId: elemId || "printable-area",
      docTitle: docTitle || "",
      withKop: useKopSurat,
      orientation: defaultOrientation
    });
  };

  // Fungsi Export ke Microsoft Word dengan Standar Dokumen Resmi Pendidikan Indonesia (A4, Margin 4-3-3-3, Times New Roman 12pt, Justify)
  const handleDownloadWord = (elementId, filename, isLandscape = false) => {
    const content = document.getElementById(elementId);
    if (!content) return;

    // Kloning elemen dan bersihkan elemen non-cetak (no-print) agar file Word murni dan rapi
    const clone = content.cloneNode(true) as HTMLElement;
    clone.querySelectorAll('.no-print').forEach((el) => el.remove());

    const pageSize = isLandscape ? '29.7cm 21.0cm' : '21.0cm 29.7cm';
    const pageOrientation = isLandscape ? 'landscape' : 'portrait';
    const lineHeightPercent = lineSpacing === "1.5" ? "150%" : "115%";

    const htmlHeader = `
      <html xmlns:v="urn:schemas-microsoft-com:vml"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:w="urn:schemas-microsoft-com:office:word"
            xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
            xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8">
        <title>${filename}</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <style>
          /* A. Pengaturan Halaman Resmi: Kertas A4 & Margin Atas 1.5cm, Kiri 2.5cm, Kanan 2.0cm, Bawah 2.0cm */
          @page WordSection1 {
            size: ${pageSize};
            mso-page-orientation: ${pageOrientation};
            margin: 1.5cm 2.0cm 2.0cm 2.5cm;
            mso-header-margin: 1.0cm;
            mso-footer-margin: 1.0cm;
            mso-footer: f1;
          }
          div.WordSection1 {
            page: WordSection1;
          }

          /* B. Pengaturan Teks & Paragraf: Times New Roman 11pt, Justify, Spasi Konsisten */
          body {
            font-family: "Times New Roman", Times, serif;
            font-size: 11pt;
            color: #000000;
            line-height: ${lineHeightPercent};
            text-align: justify;
          }
          p {
            margin-top: 0pt;
            margin-bottom: 6pt;
            text-align: justify;
            line-height: ${lineHeightPercent};
            font-family: "Times New Roman", Times, serif;
            font-size: 11pt;
          }
          .indent-first {
            text-indent: 1.25cm;
          }

          /* Judul Utama (14pt, Tebal, Rata Tengah) & Subjudul (12pt, Tebal, Keep with Next) */
          h1, h2.doc-main-title {
            font-family: "Times New Roman", Times, serif;
            font-size: 14pt;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
            margin-top: 0pt;
            margin-bottom: 1pt;
            line-height: 115%;
            page-break-after: avoid;
            mso-pagination: lines-together;
          }
          h3.doc-sub-title {
            font-family: "Times New Roman", Times, serif;
            font-size: 13pt;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
            margin-top: 0pt;
            margin-bottom: 10pt;
            line-height: 115%;
            page-break-after: avoid;
          }
          .flex.justify-between {
            display: table !important;
            width: 100% !important;
          }
          .flex.justify-between > div {
            display: table-cell !important;
            vertical-align: top !important;
            border: none !important;
            mso-border-alt: none !important;
          }
          h4.doc-section-heading {
            font-family: "Times New Roman", Times, serif;
            font-size: 11pt;
            font-weight: bold;
            text-transform: uppercase;
            margin-top: 12pt;
            margin-bottom: 6pt;
            page-break-after: avoid;
            mso-pagination: keep-with-next;
          }
          h5.doc-sub-heading {
            font-family: "Times New Roman", Times, serif;
            font-size: 11pt;
            font-weight: bold;
            margin-top: 8pt;
            margin-bottom: 4pt;
            page-break-after: avoid;
            mso-pagination: keep-with-next;
          }

          /* C. Pengaturan Tabel: Garis 1pt Solid, Header Berulang, Anti-Terpotong */
          table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 6pt;
            margin-bottom: 12pt;
            font-family: "Times New Roman", Times, serif;
            font-size: 11pt;
          }
          thead {
            display: table-header-group;
          }
          tr {
            page-break-inside: avoid;
            mso-row-margin-left: 0pt;
          }
          th {
            border: 1pt solid #000000;
            padding: 6pt 8pt;
            font-weight: bold;
            text-align: center;
            vertical-align: middle;
            background-color: #f2f2f2;
            color: #000000;
          }
          td {
            border: 1pt solid #000000;
            padding: 5pt 8pt;
            vertical-align: top;
            text-align: justify;
            color: #000000;
            line-height: ${lineHeightPercent};
          }
          td.label-col {
            font-weight: bold;
            text-align: left;
            width: 32%;
          }

          /* Tabel Tanda Tangan Tanpa Garis */
          table.no-border, table.no-border td, table.no-border tr {
            border: none !important;
            text-align: left;
            page-break-inside: avoid;
          }

          /* D. Penomoran & Daftar Berpoin Seragam */
          ol, ul {
            margin-top: 3pt;
            margin-bottom: 6pt;
            padding-left: 1.0cm;
            text-align: justify;
          }
          li {
            margin-bottom: 3pt;
            text-align: justify;
            line-height: ${lineHeightPercent};
          }

          /* Footer Nomor Halaman Pojok Kanan Bawah */
          p.MsoFooter, li.MsoFooter, div.MsoFooter {
            margin: 0cm;
            margin-bottom: 0.0001pt;
            mso-pagination: widow-orphan;
            font-size: 11pt;
            font-family: "Times New Roman", Times, serif;
            text-align: right;
          }
        </style>
      </head>
      <body>
        <div class="WordSection1">
          ${clone.innerHTML}
          <div style="mso-element:footer" id="f1">
            <p class="MsoFooter" align="right" style="text-align:right">
              <!--[if supportFields]><span class="MsoPageNumber"><span style="mso-element:field-begin"></span><span style="mso-spacerun:yes"> </span>PAGE <span style="mso-element:field-separator"></span></span><![endif]-->
              <!--[if supportFields]><span class="MsoPageNumber"><span style="mso-element:field-end"></span></span><![endif]-->
            </p>
          </div>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', htmlHeader], {
      type: 'application/msword;charset=utf-8'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`Berhasil mengunduh dokumen resmi: ${filename}.doc (A4, Margin Atas 1,5cm, Kiri 2,5cm, Kanan 2cm, Bawah 2cm, Times New Roman 11pt)`);
  };

  // Auto-save data ke localStorage setiap kali ada perubahan
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_identitas", JSON.stringify(identitas));
    } catch {}
  }, [identitas]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_modules", JSON.stringify(modules));
    } catch {}
  }, [modules]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_kokurikuler", JSON.stringify(kokurikulerList));
    } catch {}
  }, [kokurikulerList]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_jurnal_remedial", JSON.stringify(jurnalRemedialList));
    } catch {}
  }, [jurnalRemedialList]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_rme_data", JSON.stringify(rmeData));
    } catch {}
  }, [rmeData]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_program_keagamaan", JSON.stringify(programKeagamaan));
    } catch {}
  }, [programKeagamaan]);

  // Cadangkan semua data ke file JSON
  const handleExportBackup = () => {
    const backupData = {
      app: "Sistem Administrasi Guru & Perangkat Ajar Modern PAI SD",
      version: "2.0",
      timestamp: new Date().toISOString(),
      identitas,
      modules,
      kokurikulerList,
      jurnalRemedialList,
      rmeData,
      programKeagamaan
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Backup_Administrasi_PAI_${identitas.sekolah.replace(/\s+/g, '_')}_${identitas.tahunAjaran.replace(/\//g, '-')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast("Seluruh berkas administrasi berhasil dicadangkan ke file JSON!");
  };

  // Pulihkan data dari file JSON cadangan
  const handleImportBackup = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const data = JSON.parse(text);
        if (data.identitas) {
          const lockedSchool = identitas.sekolah;
          setIdentitas({
            ...data.identitas,
            sekolah: isAuthenticated && lockedSchool ? lockedSchool : data.identitas.sekolah
          });
          if (data.identitas.logoSekolah) {
            setLogoSekolahUrl(data.identitas.logoSekolah);
            try { localStorage.setItem("perangkat_logo_sekolah", data.identitas.logoSekolah); } catch {}
          }
          if (data.identitas.kopSurat) {
            setKopSuratUrl(data.identitas.kopSurat);
            try { localStorage.setItem("perangkat_kop_surat", data.identitas.kopSurat); } catch {}
          }
        }
        if (data.modules && Array.isArray(data.modules)) setModules(data.modules);
        if (data.kokurikulerList && Array.isArray(data.kokurikulerList)) setKokurikulerList(data.kokurikulerList);
        if (data.jurnalRemedialList && Array.isArray(data.jurnalRemedialList)) setJurnalRemedialList(data.jurnalRemedialList);
        if (data.rmeData) setRmeData(data.rmeData);
        if (data.programKeagamaan) setProgramKeagamaan(data.programKeagamaan);
        showToast("Data administrasi berhasil dipulihkan dari cadangan!");
      } catch {
        showToast("Gagal membaca file cadangan. Format JSON tidak valid.");
      }
    };
    reader.readAsText(file);
    if (event.target) event.target.value = "";
  };

  // Reset ke data awal pabrik
  const handleResetToDefaults = () => {
    if (window.confirm("Apakah Anda yakin ingin mengembalikan seluruh data administrasi ke pengaturan awal standar? Seluruh perubahan kustom akan disetel ulang.")) {
      localStorage.removeItem("perangkat_identitas");
      localStorage.removeItem("perangkat_modules");
      localStorage.removeItem("perangkat_kokurikuler");
      localStorage.removeItem("perangkat_jurnal_remedial");
      localStorage.removeItem("perangkat_rme_data");
      localStorage.removeItem("perangkat_program_keagamaan");
      setIdentitas(DEFAULT_IDENTITAS);
      setModules(INITIAL_MODULES);
      setKokurikulerList(INITIAL_KOKURIKULER_DATA);
      setJurnalRemedialList(DEFAULT_JURNAL);
      setRmeData(DEFAULT_RME_DATA);
      setProgramKeagamaan(DEFAULT_PROGRAM_KEAGAMAAN);
      showToast("Data berhasil dikembalikan ke standar awal Kurikulum Merdeka!");
    }
  };

  // Salin ringkasan Modul Ajar untuk WA / Portal Guru
  const handleCopyModulSummary = (modul) => {
    if (!modul) return;
    const summaryText = `*ADMINISTRASI MODUL AJAR PAI & BP*
🏫 *Satuan Pendidikan:* ${identitas.sekolah}
📚 *Fase / Kelas / Semester:* Fase ${modul.fase} / Kelas ${modul.kelas} / Semester ${modul.semester}
📖 *Elemen:* ${modul.elemen} (Modul Ajar ${modul.nomor})
⏱️ *Alokasi Waktu:* ${modul.alokasi}
🎯 *Tujuan Pembelajaran:*
${modul.tp}

👥 *Profil Lulusan:*
${modul.dimensi}

📝 *Rincian Pertemuan:*
${modul.pertemuan.map((p, i) => `${i + 1}. ${p.judul}`).join("\n")}

📊 *Asesmen Sumatif:*
${modul.asesmen}

_Disusun oleh: ${identitas.guruPai} (NIP. ${identitas.nipGuru})_`;

    navigator.clipboard.writeText(summaryText).then(() => {
      showToast("Ringkasan modul ajar berhasil disalin ke clipboard!");
    }).catch(() => {
      showToast("Gagal menyalin ringkasan.");
    });
  };

  // Warna badge elemen (Dark Mode Elegan)
  const getElemenBadge = (elemen) => {
    switch (elemen) {
      case "Al-Qur’an-Hadis":
        return "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
      case "Akidah":
        return "bg-sky-500/15 text-sky-300 border-sky-500/30";
      case "Akhlak":
        return "bg-amber-500/15 text-amber-300 border-amber-500/30";
      case "Fikih":
        return "bg-purple-500/15 text-purple-300 border-purple-500/30";
      case "Sejarah Peradaban Islam":
        return "bg-rose-500/15 text-rose-300 border-rose-500/30";
      default:
        return "bg-slate-800 text-slate-300 border-slate-700";
    }
  };

  // Highlight tag (mindful, joyful, meaningful, al-i'tidal, dll.)
  const renderHighlightedActivity = (text) => {
    const formatted = formatTextSapaan(text);
    const parts = formatted.split(/(\([^)]+\))/g);
    return parts.map((part, idx) => {
      if (part.startsWith("(") && part.endsWith(")")) {
        const lower = part.toLowerCase();
        if (
          lower.includes("mindful") ||
          lower.includes("meaningful") ||
          lower.includes("joyful") ||
          lower.includes("al-") ||
          lower.includes("asy-syura") ||
          lower.includes("tasamuh") ||
          lower.includes("tawassut") ||
          lower.includes("produk") ||
          lower.includes("proses")
        ) {
          return (
            <span
              key={idx}
              className={`inline-block ml-1.5 px-2.5 py-0.5 text-[11px] font-semibold rounded-full border transition-colors print:bg-transparent print:text-black print:border-none print:px-0 print:italic print:text-[12pt] print:font-normal ${
                paperLightMode
                  ? "bg-emerald-50 text-emerald-800 border-emerald-200"
                  : "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"
              }`}
            >
              {part}
            </span>
          );
        }
      }
      return <span key={idx}>{part}</span>;
    });
  };

  const deepDetails = useMemo(() => getDeepLearningDetails(activeModul), [activeModul]);

  // Pratinjau Dokumen: Selalu Mode Terang Permanen (Kertas Putih Standar Resmi A4)
  const docContainerClass = "bg-white text-black border-slate-300 shadow-2xl";
  const tableBorderClass = "border-black";
  const tableHeaderBgClass = "bg-slate-100 text-black";
  const tableLabelBgClass = "bg-slate-50/70 text-black";
  const sectionBannerClass = "border-b border-black text-black pb-1";

  return (
    <div className="min-h-screen bg-[#ecfdf5] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.18),rgba(255,255,255,0))] text-slate-800 flex flex-col font-sans selection:bg-emerald-600 selection:text-white">
      {/* Style khusus Cetak Resmi Standar Pendidikan Indonesia (A4, Margin Atas 1,5cm, Kiri 2,5cm, Kanan 2cm, Bawah 2cm, Times New Roman 12pt, thead Berulang) */}
      <style>{`
        @page {
          size: A4 portrait;
          margin-top: 1.5cm;
          margin-left: 2.5cm;
          margin-right: 2.0cm;
          margin-bottom: 2.0cm;
          @bottom-right {
            content: counter(page);
            font-family: 'Times New Roman', Times, serif;
            font-size: 11pt;
          }
        }
        @media print {
          html, body {
            background: #ffffff !important;
            color: #000000 !important;
            font-family: 'Times New Roman', Times, serif !important;
            font-size: 11pt !important;
            line-height: ${lineSpacing} !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
          }
          #root, #root > div, main, .overflow-x-hidden {
            overflow: visible !important;
            overflow-x: visible !important;
            overflow-y: visible !important;
            height: auto !important;
            max-height: none !important;
            position: static !important;
            transform: none !important;
          }
          body * {
            visibility: hidden;
          }
          #printable-area, #printable-area * {
            visibility: visible;
            color: #000000 !important;
            background-color: transparent !important;
            font-family: 'Times New Roman', Times, serif !important;
          }
          #printable-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100% !important;
            max-width: none !important;
            box-shadow: none !important;
            border: none !important;
            padding: 0 !important;
            margin: 0 !important;
            text-align: justify !important;
            font-size: 11pt !important;
            line-height: ${lineSpacing} !important;
            overflow: visible !important;
          }
          #printable-area section,
          #printable-area .overflow-x-auto,
          #printable-area .overflow-y-auto {
            overflow: visible !important;
            max-height: none !important;
            height: auto !important;
          }

          /* Tanda Tangan Resmi Kepala Sekolah & Guru - Wajib Horizontal Kiri & Kanan (Anti-Vertikal) */
          .ttd-container,
          .ttd-wrapper,
          #printable-area .ttd-container,
          #printable-area .ttd-wrapper {
            width: 100% !important;
            margin-top: 20pt !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            border: none !important;
            background: transparent !important;
            display: block !important;
            clear: both !important;
          }
          .ttd-row,
          #printable-area .ttd-row,
          .keep-together .flex.justify-between {
            display: flex !important;
            display: -webkit-flex !important;
            flex-direction: row !important;
            -webkit-flex-direction: row !important;
            justify-content: space-between !important;
            -webkit-justify-content: space-between !important;
            align-items: flex-start !important;
            width: 100% !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            border: none !important;
          }
          .ttd-col-left,
          .ttd-col-right,
          .ttd-col,
          #printable-area .ttd-col-left,
          #printable-area .ttd-col-right,
          .keep-together .flex.justify-between > div {
            width: 45% !important;
            min-width: 40% !important;
            max-width: 48% !important;
            display: inline-block !important;
            text-align: left !important;
            vertical-align: top !important;
            border: none !important;
            background: transparent !important;
            box-sizing: border-box !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }
          .ttd-col-left,
          #printable-area .ttd-col-left,
          .keep-together .flex.justify-between > div:first-child {
            float: left !important;
          }
          .ttd-col-right,
          #printable-area .ttd-col-right,
          .keep-together .flex.justify-between > div:last-child {
            float: right !important;
          }
          .ttd-row::after,
          #printable-area .ttd-row::after,
          .keep-together .flex.justify-between::after {
            content: "" !important;
            display: table !important;
            clear: both !important;
          }
          #printable-area h2.doc-main-title {
            font-size: 14pt !important;
            font-weight: bold !important;
            text-align: center !important;
            margin-bottom: 4pt !important;
            page-break-after: avoid !important;
            break-after: avoid !important;
          }
          #printable-area h3.doc-sub-title {
            font-size: 13pt !important;
            font-weight: bold !important;
            text-align: center !important;
            margin-bottom: 12pt !important;
            page-break-after: avoid !important;
            break-after: avoid !important;
          }
          #printable-area h4.doc-section-heading,
          #printable-area h5.doc-sub-heading {
            font-size: 11pt !important;
            font-weight: bold !important;
            page-break-after: avoid !important;
            break-after: avoid !important;
            border-left: none !important;
            padding-left: 0 !important;
          }
          #printable-area p, #printable-area li, #printable-area td {
            font-size: 11pt !important;
            line-height: ${lineSpacing} !important;
            text-align: justify !important;
          }
          #printable-area table {
            width: 100% !important;
            border-collapse: collapse !important;
            page-break-inside: auto !important;
            break-inside: auto !important;
            margin-top: 6pt !important;
            margin-bottom: 12pt !important;
          }
          #printable-area thead {
            display: table-header-group !important;
          }
          #printable-area tfoot {
            display: table-footer-group !important;
          }
          #printable-area tbody {
            display: table-row-group !important;
          }
          #printable-area tr, #printable-area .keep-together {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            page-break-after: auto !important;
            break-after: auto !important;
          }
          #printable-area th, #printable-area td {
            border: 1px solid #000000 !important;
            padding: 5pt 7pt !important;
            vertical-align: top !important;
            box-sizing: border-box !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }
          #printable-area th {
            text-align: center !important;
            font-weight: bold !important;
            vertical-align: middle !important;
            background-color: #f3f4f6 !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          /* Hilangkan tabel / border pada tanda tangan */
          #printable-area table.no-border,
          #printable-area table.no-border tr,
          #printable-area table.no-border td,
          #printable-area table.ttd-table,
          #printable-area table.ttd-table tr,
          #printable-area table.ttd-table td,
          #printable-area .ttd-table,
          #printable-area .ttd-table tr,
          #printable-area .ttd-table td,
          #printable-area .ttd-left,
          #printable-area .ttd-right,
          #printable-area .ttd-container table,
          #printable-area .ttd-container td,
          #printable-area .ttd-wrapper table,
          #printable-area .ttd-wrapper td {
            border: none !important;
            border-width: 0 !important;
            border-style: none !important;
            border-color: transparent !important;
            outline: none !important;
            box-shadow: none !important;
            background: transparent !important;
            background-color: transparent !important;
          }
          .no-print {
            display: none !important;
          }
        }
        /* Gaya Tampilan Resmi Times New Roman di Layar */
        .official-doc-typography {
          font-family: 'Times New Roman', Times, serif;
          font-size: 11pt;
          line-height: ${lineSpacing};
          text-align: justify;
        }
        /* Custom Fresh Mint Scrollbar */
        ::-webkit-scrollbar { width: 7px; height: 7px; }
        ::-webkit-scrollbar-track { background: #d1fae5; }
        ::-webkit-scrollbar-thumb { background: #34d399; border-radius: 9999px; }
        ::-webkit-scrollbar-thumb:hover { background: #059669; }
      `}</style>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-white text-emerald-950 px-5 py-3.5 rounded-2xl shadow-xl shadow-emerald-950/20 border-2 border-emerald-400 backdrop-blur-md animate-bounce no-print">
          <CheckCircle2 className="w-5 h-5 text-emerald-700" />
          <span className="text-sm font-bold tracking-wide text-slate-900">{toastMsg}</span>
        </div>
      )}

      {/* Modal Notice Pilihan Cetak / PDF: Pakai Kop Surat atau Tidak */}
      {printNoticeModal.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/50 backdrop-blur-md no-print animate-in fade-in duration-200">
          <div className="bg-white border-2 border-emerald-400 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 text-slate-900">
            <div className="flex items-start justify-between gap-3 border-b border-emerald-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800 border border-emerald-300">
                  <Printer className="w-6 h-6 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Konfirmasi Format Cetak / Simpan PDF</h3>
                  <p className="text-xs text-slate-600 font-medium">Pilih format dokumen resmi sebelum dicetak atau disimpan:</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPrintNoticeModal((prev) => ({ ...prev, show: false }))}
                className="text-slate-400 hover:text-slate-800 p-1 rounded-lg hover:bg-slate-100 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Bagian 1: Pilihan Penggunaan Kop Surat */}
              <div className="space-y-2.5">
                <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wider block">
                  1. Penggunaan Kop Surat Resmi:
                </label>

                {/* Opsi 1: Pakai Kop Surat Resmi */}
                <div
                  onClick={() => {
                    setPrintNoticeModal((prev) => ({ ...prev, withKop: true }));
                    setUseKopSurat(true);
                    try { localStorage.setItem("perangkat_use_kop_surat", "true"); } catch {}
                  }}
                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3.5 ${
                    printNoticeModal.withKop
                      ? "bg-[#e6f7ef] border-emerald-600 shadow-md"
                      : "bg-slate-50 border-slate-200 hover:border-emerald-300"
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 shrink-0 ${
                    printNoticeModal.withKop ? "border-emerald-700 bg-[#065f46]" : "border-slate-400"
                  }`}>
                    {printNoticeModal.withKop && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="font-extrabold text-xs sm:text-sm text-slate-900">Pakai Kop Surat Resmi</span>
                      {kopSuratUrl ? (
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                          Kop Terpasang
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                          Belum Diunggah
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                      Menyertakan gambar Kop Surat resmi sekolah di bagian paling atas berkas sebelum judul dokumen.
                    </p>
                    {kopSuratUrl ? (
                      <div className="mt-1.5 p-1.5 bg-white rounded-lg border border-slate-200 inline-block max-w-full">
                        <img src={kopSuratUrl} alt="Kop Surat" className="max-h-10 object-contain" />
                      </div>
                    ) : (
                      <p className="text-[10px] text-amber-700 italic font-medium">
                        * Belum ada gambar kop surat. Anda dapat mengunggahnya di tab Pengaturan Identitas.
                      </p>
                    )}
                  </div>
                </div>

                {/* Opsi 2: Tanpa Kop Surat */}
                <div
                  onClick={() => {
                    setPrintNoticeModal((prev) => ({ ...prev, withKop: false }));
                    setUseKopSurat(false);
                    try { localStorage.setItem("perangkat_use_kop_surat", "false"); } catch {}
                  }}
                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3.5 ${
                    !printNoticeModal.withKop
                      ? "bg-[#e6f7ef] border-emerald-600 shadow-md"
                      : "bg-slate-50 border-slate-200 hover:border-emerald-300"
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 shrink-0 ${
                    !printNoticeModal.withKop ? "border-emerald-700 bg-[#065f46]" : "border-slate-400"
                  }`}>
                    {!printNoticeModal.withKop && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-extrabold text-xs sm:text-sm text-slate-900">Tanpa Kop Surat (Hanya Judul Polos)</span>
                      <span className="text-[10px] font-bold text-slate-700 bg-slate-200 px-2 py-0.5 rounded-full">
                        Standar
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                      Dokumen dicetak langsung dengan judul utama dan identitas tanpa gambar kepala surat.
                    </p>
                  </div>
                </div>
              </div>

              {/* Bagian 2: Pilihan Tata Letak Halaman (Layout Portrait vs Landscape) */}
              <div className="space-y-2.5 pt-3 border-t border-emerald-200">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wider block">
                    2. Tata Letak Kertas (Layout A4):
                  </label>
                  <span className="text-[11px] font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                    {printNoticeModal.orientation === "landscape" ? "Landscape (Mendatar)" : "Portrait (Tegak)"}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Pilihan Portrait */}
                  <div
                    onClick={() => setPrintNoticeModal((prev) => ({ ...prev, orientation: "portrait" }))}
                    className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-center gap-3 ${
                      printNoticeModal.orientation === "portrait"
                        ? "bg-[#e6f7ef] border-emerald-600 shadow-md"
                        : "bg-slate-50 border-slate-200 hover:border-emerald-300"
                    }`}
                  >
                    <div className={`w-9 h-11 rounded-lg border-2 flex items-center justify-center shrink-0 ${
                      printNoticeModal.orientation === "portrait"
                        ? "border-emerald-700 bg-emerald-100 text-emerald-800"
                        : "border-slate-300 bg-white text-slate-400"
                    }`}>
                      <div className="w-4 h-6 border-2 border-current rounded-sm flex flex-col justify-between p-0.5">
                        <div className="w-full h-0.5 bg-current opacity-70" />
                        <div className="w-full h-0.5 bg-current opacity-70" />
                      </div>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-xs sm:text-sm text-slate-900">Portrait (Tegak)</span>
                        {printNoticeModal.orientation === "portrait" && (
                          <Check className="w-3.5 h-3.5 text-emerald-700" />
                        )}
                      </div>
                      <p className="text-[10px] sm:text-[11px] text-slate-600 font-medium mt-0.5">
                        21,0 × 29,7 cm • Modul Ajar, ATP, PROTA, KKTP, RME
                      </p>
                    </div>
                  </div>

                  {/* Pilihan Landscape */}
                  <div
                    onClick={() => setPrintNoticeModal((prev) => ({ ...prev, orientation: "landscape" }))}
                    className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-center gap-3 ${
                      printNoticeModal.orientation === "landscape"
                        ? "bg-[#e6f7ef] border-emerald-600 shadow-md"
                        : "bg-slate-50 border-slate-200 hover:border-emerald-300"
                    }`}
                  >
                    <div className={`w-11 h-9 rounded-lg border-2 flex items-center justify-center shrink-0 ${
                      printNoticeModal.orientation === "landscape"
                        ? "border-emerald-700 bg-emerald-100 text-emerald-800"
                        : "border-slate-300 bg-white text-slate-400"
                    }`}>
                      <div className="w-6 h-4 border-2 border-current rounded-sm flex flex-col justify-between p-0.5">
                        <div className="w-full h-0.5 bg-current opacity-70" />
                        <div className="w-full h-0.5 bg-current opacity-70" />
                      </div>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-xs sm:text-sm text-slate-900">Landscape (Mendatar)</span>
                        {printNoticeModal.orientation === "landscape" && (
                          <Check className="w-3.5 h-3.5 text-emerald-700" />
                        )}
                      </div>
                      <p className="text-[10px] sm:text-[11px] text-slate-600 font-medium mt-0.5">
                        29,7 × 21,0 cm • PROMES, Analisis CP, Tabel Berkolom Banyak
                      </p>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-emerald-200">
              <button
                type="button"
                onClick={() => setPrintNoticeModal((prev) => ({ ...prev, show: false }))}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  const targetChoice = printNoticeModal.withKop;
                  const targetOrientation = printNoticeModal.orientation;
                  setPrintNoticeModal((prev) => ({ ...prev, show: false }));
                  handlePrint(printNoticeModal.elemId, printNoticeModal.docTitle, targetChoice, targetOrientation);
                }}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md flex items-center gap-2 transition-all cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Simpan PDF / Cetak Sekarang ({printNoticeModal.orientation === "landscape" ? "Landscape" : "Portrait"})</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Sederhana Tanggal Cetak & Titimangsa Seluruh Dokumen */}
      {showDateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/50 backdrop-blur-md no-print animate-in fade-in duration-200">
          <div className="bg-white border-2 border-emerald-400 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-5 text-slate-900">
            <div className="flex items-start justify-between gap-3 border-b border-emerald-200 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800 border border-emerald-300">
                  <Calendar className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Atur Tanggal Cetak Dokumen</h3>
                  <p className="text-xs text-slate-600 font-medium">Diterapkan otomatis ke seluruh berkas administrasi</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowDateModal(false)}
                className="text-slate-400 hover:text-slate-800 p-1 rounded-lg hover:bg-slate-100 text-xs transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Form Input Sederhana Kota & Tanggal */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Kota Titimangsa
                  </label>
                  <input
                    type="text"
                    value={tempKota}
                    onChange={(e) => setTempKota(e.target.value)}
                    placeholder="Contoh: Bekasi"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Tanggal Pengesahan
                  </label>
                  <input
                    type="text"
                    value={tempTanggal}
                    onChange={(e) => setTempTanggal(e.target.value)}
                    placeholder="Contoh: 13 Juli 2026"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-semibold text-emerald-950"
                  />
                </div>
              </div>

              {/* Pemilih Kalender Langsung */}
              <div className="bg-[#e6f7ef] p-3 rounded-2xl border border-emerald-300 flex items-center justify-between gap-3">
                <span className="text-xs text-slate-800 font-bold flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Pilih dari Kalender:</span>
                </span>
                <input
                  type="date"
                  onChange={(e) => {
                    if (e.target.value) {
                      setTempTanggal(formatTanggalIndo(e.target.value));
                    }
                  }}
                  className="px-3 py-1.5 text-xs bg-white text-emerald-900 font-bold border border-emerald-400 rounded-lg cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Pilihan Cepat Sederhana */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                  Pilihan Cepat Tanggal:
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const tgl = formatTanggalIndo(new Date());
                      setTempTanggal(tgl);
                    }}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-900 border border-emerald-300 transition-all cursor-pointer"
                  >
                    Hari Ini ({formatTanggalIndo(new Date())})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTempTanggal("13 Juli 2026")}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-slate-800 border border-emerald-300 transition-all cursor-pointer"
                  >
                    13 Juli 2026 (Sem 1)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTempTanggal("5 Januari 2027")}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-slate-800 border border-emerald-300 transition-all cursor-pointer"
                  >
                    5 Januari 2027 (Sem 2)
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-emerald-200">
              <button
                type="button"
                onClick={() => setShowDateModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  const newTgl = tempTanggal.trim() || identitas.tanggal;
                  const newKota = tempKota.trim() || identitas.kota;
                  setIdentitas((prev) => {
                    const updated = { ...prev, tanggal: newTgl, kota: newKota };
                    try {
                      localStorage.setItem("perangkat_identitas", JSON.stringify(updated));
                    } catch {}
                    return updated;
                  });
                  setShowDateModal(false);
                  showToast(`Tanggal cetak disimpan: ${newKota}, ${newTgl}`);
                }}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md flex items-center gap-2 transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Simpan Tanggal</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Bar / Modal Bantuan Simpan PDF (100% Berfungsi di Browser & Iframe) */}
      {pdfHelperData.show && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 max-w-lg w-full px-4 no-print animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="bg-white/98 backdrop-blur-2xl border-2 border-emerald-500 rounded-3xl p-5 shadow-2xl space-y-3 text-slate-900">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800 border border-emerald-300">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900">Simpan Berkas sebagai PDF (A4 Standar)</h4>
                  <p className="text-xs text-slate-600 font-medium">
                    Pada kotak dialog cetak, pilih Tujuan: <strong>"Simpan sebagai PDF"</strong> (Save as PDF)
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPdfHelperData((prev) => ({ ...prev, show: false }))}
                className="text-slate-400 hover:text-slate-800 p-1 rounded-lg hover:bg-slate-100 transition-all text-xs"
                title="Tutup panel bantuan"
              >
                ✕
              </button>
            </div>

            <div className="bg-[#e6f7ef] rounded-2xl p-3 border border-emerald-300 text-[11px] text-slate-700 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="flex items-center gap-1.5 text-emerald-950 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                  <span>Ukuran: A4 ({pdfHelperData.isLandscape ? "Landscape / Mendatar" : "Portrait / Tegak"}) • Margin 1.5 - 2.5 - 2.0 - 2.0 cm</span>
                </p>
                <button
                  type="button"
                  onClick={() => {
                    const newOrientation = pdfHelperData.isLandscape ? "portrait" : "landscape";
                    handlePrint("printable-area", pdfHelperData.title, useKopSurat, newOrientation);
                  }}
                  className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-400 flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                  title="Ganti orientasi kertas dokumen ini"
                >
                  <RefreshCw className="w-3 h-3 text-emerald-700" />
                  <span>Ganti ke {pdfHelperData.isLandscape ? "Portrait (Tegak)" : "Landscape (Mendatar)"}</span>
                </button>
              </div>
              <p className="font-medium">Jika dialog cetak peramban tidak otomatis muncul di dalam tampilan ini, gunakan tombol di bawah:</p>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  if (pdfHelperData.blobUrl) {
                    window.open(pdfHelperData.blobUrl, "_blank");
                  }
                }}
                className="flex-1 py-2 px-3 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Buka di Tab Baru (100% Siap Simpan PDF)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  try {
                    window.focus();
                    window.print();
                  } catch (e) {
                    if (pdfHelperData.blobUrl) window.open(pdfHelperData.blobUrl, "_blank");
                  }
                }}
                className="py-2 px-3 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-emerald-700" />
                <span>Ulangi Dialog</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* JIKA BELUM LOGIN: TAMPILKAN MENU LOGIN WAJIB */}
      {!isAuthenticated ? (
        <div className="flex-1 flex flex-col justify-center items-center p-4 sm:p-8 no-print my-auto">
          <div className="max-w-md w-full bg-white/95 backdrop-blur-2xl border-2 border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-emerald-950/10 space-y-6 text-slate-800">
            {/* Header Login */}
            <div className="text-center space-y-3">
              <div className="w-16 h-16 mx-auto p-4 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-2xl border border-emerald-400/40 shadow-lg shadow-emerald-900/20 flex items-center justify-center text-white">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900">
                  Portal Administrasi Guru
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  Pendidikan Agama Islam &amp; Budi Pekerti SD (Kurikulum Merdeka)
                </p>
              <div className="pt-1.5 flex items-center justify-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300 tracking-wide">
                  Login Sistem Administrasi
                </span>
              </div>
              </div>

              {/* Status Online & Tanggal */}
              <div className="flex items-center justify-center gap-2 flex-wrap pt-1">
                <span
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
                    isOnline
                      ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                      : "bg-amber-50 text-amber-800 border-amber-300"
                  }`}
                >
                  {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-600" /> : <WifiOff className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{isOnline ? "Online & PWA Siap" : "Mode Offline Aktif"}</span>
                </span>
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
                  <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{getTodayFormattedDate()}</span>
                </span>
              </div>
            </div>

            {/* INFO KEAMANAN AKSES */}
            <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-950 space-y-1">
              <div className="flex items-center gap-2 font-bold text-emerald-900">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Akses Sekolah Terdaftar &amp; Password Dinamis</span>
              </div>
              <p className="text-[11.5px] text-slate-700 leading-relaxed">
                Hanya guru dari sekolah yang telah didaftarkan yang dapat masuk. Masukkan nama Anda, pilih nama sekolah terdaftar, dan masukkan password dinamis harian (<strong>{getTodayPassword()}</strong>).
              </p>
            </div>

            {/* FORM LOGIN TUNGGAL UNTUK GURU & ADMINISTRATOR */}
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Nama Guru Mata Pelajaran</span>
                </label>
                <input
                  type="text"
                  required
                  value={loginGuru}
                  onChange={(e) => setLoginGuru(e.target.value)}
                  placeholder="Contoh: SUHENDRI, S.Pd.I atau Nama Lengkap Anda"
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none placeholder:text-slate-400 font-semibold"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Nama guru disesuaikan dengan yang menginputkan.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <School className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Nama Sekolah / Satuan Pendidikan</span>
                  </span>
                  <span className="text-[10.5px] font-bold text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                    Wajib Terdaftar
                  </span>
                </label>
                <input
                  type="text"
                  list="registered-schools-datalist"
                  required
                  value={loginSekolah}
                  onChange={(e) => setLoginSekolah(e.target.value)}
                  placeholder="Pilih atau ketik nama sekolah terdaftar..."
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none placeholder:text-slate-400 font-semibold"
                />
                <datalist id="registered-schools-datalist">
                  {registeredSchools.map((sch) => (
                    <option key={sch.id} value={sch.nama}>
                      {sch.nama} {sch.status === "nonaktif" ? "(Nonaktif)" : "(Terdaftar)"}
                    </option>
                  ))}
                </datalist>
                <p className="text-[11px] text-slate-500 mt-1">
                  Hanya nama sekolah yang telah didaftarkan oleh Administrator yang dapat mengakses.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Password Dinamis Harian (ddmmyy)</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPasswordHint(!showPasswordHint)}
                    className="text-[11px] text-emerald-700 hover:text-emerald-900 hover:underline font-bold cursor-pointer"
                  >
                    {showPasswordHint ? "Tutup Bantuan" : "Format Password"}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPasswordText ? "text" : "password"}
                    required
                    maxLength={10}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder={`Format: ddmmyy (Contoh hari ini: ${getTodayPassword()})`}
                    className="w-full pl-4 pr-11 py-2.5 text-sm bg-slate-50 border-2 border-emerald-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none placeholder:text-slate-400 font-mono tracking-widest font-extrabold"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswordText(!showPasswordText)}
                    className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-700 cursor-pointer"
                    title={showPasswordText ? "Sembunyikan Password" : "Lihat Password"}
                  >
                    {showPasswordText ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {showPasswordHint && (
                  <div className="mt-2 p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-950 space-y-1 animate-fadeIn">
                    <p className="font-bold flex items-center gap-1.5 text-emerald-800">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Aturan Password Dinamis:</span>
                    </p>
                    <p className="text-slate-700 leading-relaxed">
                      Format password: <strong>tanggalbulantahun (ddmmyy)</strong>. Misalnya tanggal 8 November 2026 menjadi <strong>081126</strong>. Password berubah otomatis setiap hari dan berlaku sama untuk seluruh guru maupun administrator.
                    </p>
                  </div>
                )}

                {/* Tombol Cepat Bantuan Login */}
                <div className="mt-2.5 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginPassword(getTodayPassword());
                      showToast(`Password hari ini (${getTodayPassword()}) terisi otomatis.`);
                    }}
                    className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 underline cursor-pointer flex items-center gap-1"
                  >
                    <Calendar className="w-3 h-3 text-emerald-600" />
                    <span>⚡ Isi Password Hari Ini ({getTodayPassword()})</span>
                  </button>
                </div>
              </div>

              {loginError && (
                <div className="flex items-start gap-2.5 text-rose-900 bg-rose-50 border-2 border-rose-300 p-3 rounded-xl text-xs font-semibold leading-relaxed">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-600 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl text-sm font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-lg shadow-emerald-900/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4 text-emerald-200" />
                <span>Masuk Sistem Administrasi</span>
              </button>
            </form>

            {/* Offline PWA Info */}
            <div className="pt-4 border-t border-slate-200 text-center space-y-2.5">
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Aplikasi ini mendukung <strong>Mode Offline Penuh (PWA)</strong>. Seluruh 78 Modul Ajar, ATP, PROTA, PROMES, dan KKTP tersimpan di memori perangkat lokal Anda.
              </p>
              <p className="text-xs text-slate-700 font-semibold tracking-wider pt-1">created by hendrie_cikud2</p>
              {isInstallable && (
                <button
                  type="button"
                  onClick={install}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 transition-all"
                >
                  <DownloadCloud className="w-3.5 h-3.5" />
                  <span>Pasang Aplikasi di Layar Utama / Desktop</span>
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* HEADER NAVIGASI DENGAN JUDUL & TAGLINE YANG DI-FREEZE (STICKY TOP) */}
          <header className="bg-white/95 backdrop-blur-xl border-b-2 border-emerald-400/50 text-slate-900 sticky top-0 z-40 no-print shadow-md">
            <div className="w-full max-w-full px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div className="flex items-center gap-3">
                {/* Tombol Hamburger di HP/Tablet */}
                <button
                  type="button"
                  onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
                  className="md:hidden p-2 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-300 cursor-pointer"
                  title="Buka / Tutup Menu"
                >
                  {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>

                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 border-2 border-emerald-400/40 text-white shadow-md shadow-emerald-900/20 flex items-center justify-center p-1 shrink-0 overflow-hidden">
                  {logoSekolahUrl ? (
                    <img
                      src={logoSekolahUrl}
                      alt="Logo Sekolah"
                      className="w-full h-full object-contain bg-white rounded-xl p-1"
                    />
                  ) : (
                    <BookOpen className="w-6 h-6 sm:w-7 sm:h-7" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h1 className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900">
                      Sistem Perangkat Ajar PAI &amp; BP SD
                    </h1>
                    <span className="hidden sm:inline-flex items-center gap-1 text-[11px] bg-emerald-100 text-emerald-900 border border-emerald-400 font-bold px-2.5 py-0.5 rounded-full">
                      <Sparkles className="w-3 h-3 text-emerald-700" />
                      Kurikulum Merdeka &amp; PM
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    <span className="text-emerald-800 font-bold">{identitas.sekolah}</span> • Guru: <span className="text-slate-800 font-bold">{identitas.guruPai}</span> • Tahun Ajaran {identitas.tahunAjaran}
                  </p>
                </div>
              </div>

              {/* Action Badges & Logout */}
              <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
                {/* Tombol Cepat Menu Tanggal Cetak Dokumen */}
                <button
                  type="button"
                  onClick={() => {
                    setTempTanggal(identitas.tanggal);
                    setTempKota(identitas.kota);
                    setShowDateModal(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-400 transition-all shadow-sm cursor-pointer"
                  title="Menu Atur Tanggal Cetak untuk Seluruh Dokumen"
                >
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Tgl Cetak: <strong className="text-emerald-950 font-bold">{identitas.tanggal || '13 Juli 2026'}</strong></span>
                </button>

                <div
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                    isOnline
                      ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                      : "bg-amber-50 text-amber-800 border-amber-300"
                  }`}
                  title={isOnline ? "Aplikasi terhubung online & data tersimpan lokal" : "Aplikasi bekerja penuh secara offline tanpa internet"}
                >
                  {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-600" /> : <WifiOff className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{isOnline ? "Online" : "Mode Offline"}</span>
                </div>

                {isAdmin ? (
                  <button
                    type="button"
                    onClick={() => setActiveTab("hak-akses")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold bg-amber-400 hover:bg-amber-500 text-slate-950 border border-amber-500 shadow-sm cursor-pointer"
                    title="Buka menu Hak Akses Pengguna"
                  >
                    <ShieldCheck className="w-4 h-4 text-slate-950" />
                    <span>Mode Administrator</span>
                  </button>
                ) : (
                  <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-100 text-emerald-950 border border-emerald-300">
                    <Users className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{currentUser?.namaLengkap || identitas.guruPai}</span>
                  </div>
                )}

                {isInstallable && (
                  <button
                    onClick={install}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                    title="Pasang aplikasi ke layar laptop / smartphone"
                  >
                    <DownloadCloud className="w-3.5 h-3.5" />
                    <span>Pasang PWA</span>
                  </button>
                )}

                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 hover:border-rose-400 transition-all shadow-sm cursor-pointer"
                  title="Kunci sesi administrasi"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Keluar</span>
                </button>
              </div>
            </div>

            {/* Tagline Regulasi Resmi di Bawah Judul (Posisi Difreeze Bersama Header) */}
            <div className="w-full bg-[#dcfce7] border-t border-emerald-300 px-4 sm:px-6 py-2 no-print">
              <div className="max-w-full flex items-center gap-2.5 text-xs text-emerald-950 font-medium">
                <span className="font-extrabold text-white uppercase tracking-wider bg-emerald-800 border border-emerald-900 px-2 py-0.5 rounded-md text-[10px] shrink-0">
                  Regulasi Resmi
                </span>
                <p className="leading-snug">
                  berdasarkan Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026 pembaruan Capaian Pembelajaran (CP) dan Alur Tujuan Pembelajaran (ATP) khusus untuk mata pelajaran Pendidikan Agama dan Budi Pekerti (PAI)
                </p>
              </div>
            </div>
          </header>

          {/* CONTAINER UTAMA DENGAN BILAH MENU KIRI (SIDEBAR) & KONTEN */}
          <div className="flex-1 flex w-full min-h-[calc(100vh-106px)]">
            {/* Mobile Drawer Backdrop */}
            {mobileSidebarOpen && (
              <div
                className="fixed inset-0 z-40 bg-emerald-950/60 backdrop-blur-sm md:hidden no-print"
                onClick={() => setMobileSidebarOpen(false)}
              />
            )}

            {/* BILAH MENU KIRI (LEFT SIDEBAR) SESUAI DESAIN GAMBAR HIJAU */}
            <aside
              className={`fixed md:sticky top-0 md:top-[106px] left-0 z-50 md:z-20 w-72 lg:w-76 shrink-0 bg-[#e6f7ef] border-r-2 border-emerald-400/40 p-3 sm:p-4 flex flex-col justify-between h-full md:h-[calc(100vh-106px)] overflow-y-auto no-print transition-transform duration-300 shadow-xl md:shadow-none ${
                mobileSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
              }`}
            >
              <div className="space-y-4">
                {/* Header drawer mobile */}
                <div className="flex items-center justify-between md:hidden border-b border-emerald-200 pb-3">
                  <span className="text-xs font-bold text-emerald-950 uppercase tracking-wider flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-emerald-700" />
                    <span>Menu Administrasi</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setMobileSidebarOpen(false)}
                    className="p-1 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-emerald-100"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Profil Singkat Guru di Sidebar Sesuai Gambar Referensi */}
                <div className="p-3 bg-white rounded-2xl border-2 border-emerald-300 shadow-sm flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-extrabold text-slate-900 truncate">{identitas.guruPai}</p>
                    <p className="text-[11px] text-emerald-800 font-semibold">
                      Guru PAI
                      {isTabEnabled("identitas") && (
                        <> • <button onClick={() => setActiveTab("identitas")} className="underline hover:text-emerald-950 font-bold cursor-pointer">Ganti</button></>
                      )}
                    </p>
                  </div>
                  {isTabEnabled("identitas") && (
                    <button onClick={() => setActiveTab("identitas")} className="p-1 text-slate-400 hover:text-emerald-700 cursor-pointer" title="Pengaturan Identitas">
                      <Settings className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Daftar Menu Bernomor Sesuai Hak Akses (Admin mengontrol tanda centang untuk guru & share) */}
                <nav className="space-y-1.5">
                  {(() => {
                    const rawList = [
                      { id: "beranda", label: "Dashboard", icon: LayoutDashboard },
                      { id: "identitas", label: "Profil Guru", icon: School },
                      { id: "modul", label: `Modul Ajar (${modules.length})`, icon: FileText },
                      { id: "materi-bab", label: "Materi & Bab", icon: BookOpen, badge: "Lengkap" },
                      { id: "kokurikuler", label: `Modul Kokurikuler (${kokurikulerList.length})`, icon: Users },
                      { id: "analisis-cp", label: "Analisis CP", icon: BarChart3 },
                      { id: "atp", label: "ATP Fase A-B-C", icon: Compass },
                      { id: "minggu-efektif", label: "Minggu Efektif", icon: CalendarCheck },
                      { id: "prota", label: "PROTA", icon: CalendarRange },
                      { id: "promes", label: "PROMES", icon: CalendarDays },
                      { id: "jurnal-mengajar", label: "Jurnal & Jadwal Mengajar", icon: BookCheck, badge: "Terintegrasi" },
                      { id: "absensi", label: "Absensi & Presensi Siswa", icon: UserCheck, badge: "Mingguan" },
                      { id: "penilaian", label: "Buku Nilai & Penilaian", icon: Award, badge: "Rapor" },
                      { id: "upload-siswa", label: "Upload Data Siswa", icon: FileSpreadsheet, badge: "Excel" },
                      { id: "kktp", label: "KKTP", icon: Award },
                      { id: "remedial-pengayaan", label: "Remedial & Pengayaan", icon: RefreshCw },
                      { id: "program-keagamaan", label: "Program Keagamaan", icon: MoonStar }
                    ];

                    // Non-admin (guru / link share) hanya melihat menu yang dicentang oleh Administrator
                    const accessibleList = isAdmin
                      ? rawList
                      : rawList.filter((m) => menuPermissions[m.id] !== false);

                    // Penomoran berurutan dinamis
                    const numberedList = accessibleList.map((item, idx) => ({
                      ...item,
                      num: `${idx + 1}.`
                    }));

                    // Menu Khusus Administrator (#18 Hak Akses Pengguna & Sekolah)
                    if (isAdmin) {
                      numberedList.push({
                        id: "hak-akses",
                        num: `${numberedList.length + 1}.`,
                        label: "Hak Akses Pengguna",
                        icon: ShieldCheck,
                        badge: "Admin"
                      });
                    }

                    return numberedList;
                  })().map((item: { id: string; num: string; label: string; icon: any; badge?: string }) => {
                    const isActive = activeTab === item.id;
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileSidebarOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm transition-all duration-200 cursor-pointer text-left ${
                          isActive
                            ? "bg-[#065f46] text-white font-bold shadow-md shadow-emerald-950/20"
                            : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100/80 font-medium"
                        }`}
                      >
                        <span className={`text-xs font-mono font-bold w-5 shrink-0 ${isActive ? "text-emerald-200" : "text-emerald-800"}`}>
                          {item.num}
                        </span>
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-white" : "text-emerald-700"}`} />
                        <span className="truncate flex-1">{item.label}</span>
                        {item.badge && (
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                            isActive ? "bg-white/20 text-white" : "bg-emerald-200 text-emerald-900 border border-emerald-300"
                          }`}>
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Widget Bawah Sidebar: Shortcut Tanggal Cetak & Identitas */}
              <div className="pt-3 border-t border-emerald-300/80 space-y-2 mt-4">
                <button
                  type="button"
                  onClick={() => {
                    setTempTanggal(identitas.tanggal);
                    setTempKota(identitas.kota);
                    setShowDateModal(true);
                    setMobileSidebarOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-950 border border-emerald-300 transition-all cursor-pointer shadow-sm"
                  title="Atur tanggal cetak untuk seluruh dokumen"
                >
                  <span className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                    <span>Tanggal Cetak</span>
                  </span>
                  <span className="text-[11px] font-extrabold text-emerald-800 truncate max-w-[110px]">{identitas.tanggal}</span>
                </button>

                <div className="p-2.5 bg-white rounded-xl border border-emerald-200 text-[11px] text-slate-600 shadow-sm">
                  <p className="font-bold text-slate-900 truncate">{identitas.sekolah}</p>
                  <p className="text-[10px] text-emerald-800 font-semibold">Guru: {identitas.guruPai}</p>
                </div>
              </div>
            </aside>

            {/* KONTEN UTAMA */}
            <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 bg-[#ecfdf5] overflow-x-hidden">
              {/* ========================================== */}
              {/* TAB 0: DASHBOARD / BERANDA UTAMA           */}
              {/* ========================================== */}
              {activeTab === "beranda" && (
                <div className="space-y-8 no-print">
                  {/* Hero Welcome Banner Sesuai Gambar Referensi */}
                  <div className="relative overflow-hidden rounded-3xl bg-white border-2 border-emerald-400/60 p-6 sm:p-10 shadow-lg shadow-emerald-950/5 text-slate-800">
                    <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                      <div className="space-y-3 max-w-3xl">
                        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-950 border border-emerald-400">
                          <span>SIM PERANGKAT PEMBELAJARAN PAI &amp; BP SD • TAHUN {identitas.tahunAjaran}</span>
                        </div>
                        <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
                          Selamat Datang, {identitas.guruPai}
                        </h1>
                        <p className="text-slate-600 text-sm sm:text-base leading-relaxed font-medium">
                          Sistem perangkat Kurikulum Merdeka PAI SD yang akurat, terukur, dan bermakna. Kelola perencanaan CP &amp; TP, modul ajar pembelajaran mendalam, pembiasaan karakter keagamaan, hingga pencetakan dokumen resmi.
                        </p>
                        <div className="flex flex-wrap items-center gap-3 pt-2">
                          {isTabEnabled("modul") && (
                            <button
                              onClick={() => setActiveTab("modul")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-[#065f46] hover:bg-[#047857] text-white shadow-md transition-all flex items-center gap-2 cursor-pointer"
                            >
                              <FileText className="w-4 h-4 text-emerald-200" />
                              <span>78 Modul Ajar</span>
                            </button>
                          )}
                          {isTabEnabled("materi-bab") && (
                            <button
                              onClick={() => setActiveTab("materi-bab")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-[#047857] hover:bg-[#065f46] text-white shadow-md transition-all flex items-center gap-2 cursor-pointer"
                            >
                              <BookOpen className="w-4 h-4 text-emerald-200" />
                              <span>Materi &amp; Bab</span>
                            </button>
                          )}
                          {isTabEnabled("penilaian") && (
                            <button
                              onClick={() => setActiveTab("penilaian")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-[#f59e0b] hover:bg-[#d97706] text-slate-950 shadow-md transition-all flex items-center gap-2 cursor-pointer"
                            >
                              <Award className="w-4 h-4" />
                              <span>Buku Nilai &amp; Rapor</span>
                            </button>
                          )}
                          {isTabEnabled("absensi") && (
                            <button
                              onClick={() => setActiveTab("absensi")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-[#047857] hover:bg-[#065f46] text-white shadow-md transition-all flex items-center gap-2 cursor-pointer"
                            >
                              <UserCheck className="w-4 h-4 text-emerald-200" />
                              <span>Absensi Siswa</span>
                            </button>
                          )}
                          {isTabEnabled("jurnal-mengajar") && (
                            <button
                              onClick={() => setActiveTab("jurnal-mengajar")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-white hover:bg-emerald-50 text-emerald-900 border-2 border-emerald-400 transition-all flex items-center gap-2 cursor-pointer shadow-sm"
                            >
                              <BookCheck className="w-4 h-4 text-emerald-700" />
                              <span>Jurnal Mengajar</span>
                            </button>
                          )}
                          {isTabEnabled("upload-siswa") && (
                            <button
                              onClick={() => setActiveTab("upload-siswa")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-white hover:bg-emerald-50 text-emerald-950 border-2 border-emerald-400 transition-all flex items-center gap-2 cursor-pointer shadow-sm"
                            >
                              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                              <span>Upload Siswa (Excel)</span>
                            </button>
                          )}
                          {isAdmin && (
                            <button
                              onClick={() => setActiveTab("hak-akses")}
                              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-amber-400 hover:bg-amber-500 text-slate-950 shadow-md transition-all flex items-center gap-2 cursor-pointer"
                            >
                              <ShieldCheck className="w-4 h-4 text-slate-950" />
                              <span>Hak Akses Pengguna</span>
                            </button>
                          )}
                          <button
                            onClick={handleExportBackup}
                            className="px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-white hover:bg-slate-50 text-slate-700 border-2 border-slate-300 transition-all flex items-center gap-2 cursor-pointer shadow-xs"
                            title="Simpan cadangan berkas ke komputer"
                          >
                            <FileDown className="w-4 h-4 text-slate-600" />
                            <span>Cadangkan Data</span>
                          </button>
                        </div>
                      </div>

                      <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-2xl p-5 min-w-[260px] space-y-3 shadow-sm">
                        <div className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-2">
                          <School className="w-4 h-4 text-emerald-700" />
                          <span>Identitas Satuan Pendidikan</span>
                        </div>
                        <div>
                          <h3 className="text-base font-extrabold text-slate-900">{identitas.sekolah}</h3>
                          <p className="text-xs text-emerald-800 font-semibold">Tahun Ajaran {identitas.tahunAjaran}</p>
                        </div>
                        <div className="pt-2 border-t border-emerald-200 text-xs space-y-1">
                          <div className="text-slate-700">Guru PAI: <span className="text-slate-900 font-bold">{identitas.guruPai}</span></div>
                          <div className="text-slate-700">Kepsek: <span className="text-slate-900 font-bold">{identitas.kepalaSekolah}</span></div>
                        </div>
                        {isTabEnabled("identitas") && (
                          <button
                            onClick={() => safeSetActiveTab("identitas")}
                            className="w-full text-center py-2 px-3 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                          >
                            <Settings className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Ubah Profil Sekolah</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

            {/* Statistik Utama Sesuai Gambar Referensi Hijau */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white border-2 border-emerald-300 rounded-2xl p-5 space-y-2 shadow-sm">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-slate-800">Modul Ajar</span>
                  <div className="p-2 bg-emerald-100 rounded-xl text-emerald-700 border border-emerald-300">
                    <FileText className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-slate-900">{modules.length} <span className="text-base font-bold text-slate-600">Modul</span></div>
                <p className="text-xs text-slate-600 font-medium">Kelas I – VI • Semester 1 &amp; 2 Lengkap</p>
              </div>

              <div className="bg-white border-2 border-emerald-300 rounded-2xl p-5 space-y-2 shadow-sm">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-slate-800">Kokurikuler</span>
                  <div className="p-2 bg-emerald-100 rounded-xl text-emerald-700 border border-emerald-300">
                    <Users className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-slate-900">{kokurikulerList.length} <span className="text-base font-bold text-slate-600">Projek</span></div>
                <p className="text-xs text-slate-600 font-medium">P5 &amp; PPRA Pembelajaran Mendalam</p>
              </div>

              <div className="bg-white border-2 border-emerald-300 rounded-2xl p-5 space-y-2 shadow-sm">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-slate-800">Alokasi Waktu</span>
                  <div className="p-2 bg-amber-100 rounded-xl text-amber-700 border border-amber-300">
                    <Clock className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-slate-900">108 <span className="text-base font-bold text-slate-600">JP / Thn</span></div>
                <p className="text-xs text-slate-600 font-medium">3 JP / Minggu Tatap Muka per Kelas</p>
              </div>

              <div className="bg-white border-2 border-emerald-300 rounded-2xl p-5 space-y-2 shadow-sm">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-slate-800">Standar Dokumen</span>
                  <div className="p-2 bg-emerald-100 rounded-xl text-emerald-700 border border-emerald-300">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-emerald-800">Format Resmi</div>
                <p className="text-xs text-slate-600 font-medium">A4 • Margin 4-3-3-3 • TNR 11pt</p>
              </div>
            </div>

            {/* Akses Cepat Perangkat Ajar per Tingkat Kelas (I s/d VI) */}
            <div className="bg-white border-2 border-emerald-300 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm text-slate-800">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-200 pb-4">
                <div>
                  <h2 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
                    <Compass className="w-5 h-5 text-emerald-700" />
                    <span>Akses Cepat Administrasi Pembelajaran per Kelas</span>
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 mt-0.5 font-medium">
                    Pilih tingkat kelas untuk langsung membuka Modul Ajar, PROTA, PROMES, KKTP, atau Remedial secara terintegrasi.
                  </p>
                </div>
                <span className="text-xs font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1.5 rounded-full self-start sm:self-auto">
                  6 Tingkat Kelas • 3 Fase
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {[
                  { kls: "I", fase: "A", range: "Kelas I & II", color: "from-emerald-50 to-teal-50", border: "border-emerald-300", text: "text-emerald-800" },
                  { kls: "II", fase: "A", range: "Kelas I & II", color: "from-teal-50 to-emerald-50", border: "border-teal-300", text: "text-teal-800" },
                  { kls: "III", fase: "B", range: "Kelas III & IV", color: "from-emerald-50 to-teal-50", border: "border-emerald-300", text: "text-emerald-800" },
                  { kls: "IV", fase: "B", range: "Kelas III & IV", color: "from-teal-50 to-emerald-50", border: "border-teal-300", text: "text-teal-800" },
                  { kls: "V", fase: "C", range: "Kelas V & VI", color: "from-emerald-50 to-amber-50", border: "border-emerald-300", text: "text-emerald-800" },
                  { kls: "VI", fase: "C", range: "Kelas V & VI", color: "from-emerald-50 to-teal-50", border: "border-emerald-300", text: "text-emerald-800" }
                ].map((item) => (
                  <div
                    key={item.kls}
                    className={`rounded-2xl p-5 border-2 ${item.border} bg-gradient-to-br ${item.color} space-y-4 hover:border-emerald-500 transition-all shadow-sm`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#065f46] text-white flex items-center justify-center font-black text-base shadow-sm">
                          {item.kls}
                        </div>
                        <div>
                          <h3 className="font-extrabold text-slate-900 text-base">Kelas {item.kls} SD</h3>
                          <p className="text-xs text-slate-600 font-semibold">Fase {item.fase} ({item.range})</p>
                        </div>
                      </div>
                      <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-white border ${item.border} ${item.text}`}>
                        Fase {item.fase}
                      </span>
                    </div>

                    <div className="text-xs text-slate-700 font-medium">
                      Terdiri dari <strong>10 Modul Ajar</strong> (5 Sem 1 &amp; 5 Sem 2) serta <strong>2 Modul Kokurikuler</strong> P5-PPRA.
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      {isTabEnabled("modul") && (
                        <button
                          onClick={() => {
                            setSelectedKelas(item.kls);
                            setActiveTab("modul");
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-bold bg-white hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer"
                        >
                          Modul Ajar
                        </button>
                      )}
                      {isTabEnabled("kokurikuler") && (
                        <button
                          onClick={() => {
                            setKoKelas(item.kls);
                            setActiveTab("kokurikuler");
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-bold bg-white hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer"
                        >
                          Kokurikuler
                        </button>
                      )}
                      {isTabEnabled("prota") && (
                        <button
                          onClick={() => {
                            setProtaKelas(item.kls);
                            setActiveTab("prota");
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-bold bg-white hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer"
                        >
                          PROTA
                        </button>
                      )}
                      {isTabEnabled("promes") && (
                        <button
                          onClick={() => {
                            setPromesKelas(item.kls);
                            setActiveTab("promes");
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-bold bg-white hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer"
                        >
                          PROMES
                        </button>
                      )}
                      {isTabEnabled("kktp") && (
                        <button
                          onClick={() => {
                            setKktpKelas(item.kls);
                            setActiveTab("kktp");
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-bold bg-white hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer"
                        >
                          KKTP
                        </button>
                      )}
                      {isTabEnabled("remedial-pengayaan") && (
                        <button
                          onClick={() => {
                            setRemKelas(item.kls);
                            setActiveTab("remedial-pengayaan");
                          }}
                          className="py-1.5 px-2.5 rounded-lg text-xs font-bold bg-white hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer"
                        >
                          Remedial
                        </button>
                      )}
                      {isTabEnabled("jurnal-mengajar") && (
                        <button
                          onClick={() => {
                            setSelectedKelas(item.kls);
                            setActiveTab("jurnal-mengajar");
                          }}
                          className="col-span-2 py-1.5 px-2.5 rounded-lg text-xs font-bold bg-emerald-50 hover:bg-emerald-700 hover:text-white text-emerald-950 border border-emerald-300 transition-all text-center shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <BookCheck className="w-3.5 h-3.5 text-emerald-700 group-hover:text-white" />
                          <span>Jurnal Mengajar Kelas {item.kls}</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Checklist Administrasi & Standar Resmi */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Checklist Administrasi Guru */}
              <div className="bg-white border-2 border-emerald-300 rounded-3xl p-6 space-y-4 shadow-sm text-slate-800">
                <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
                  <div className="flex items-center gap-2">
                    <CheckSquare className="w-5 h-5 text-emerald-700" />
                    <h3 className="font-extrabold text-slate-900 text-base">Checklist Kelengkapan Administrasi</h3>
                  </div>
                  <span className="text-xs font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-full">
                    11 Dokumen Siap
                  </span>
                </div>

                <p className="text-xs text-slate-600 font-medium">
                  Berikut kelengkapan berkas portofolio pembelajaran guru yang telah disiapkan secara otomatis oleh aplikasi:
                </p>

                <div className="space-y-2.5">
                  {[
                    { key: "atp", label: "Alur Tujuan Pembelajaran (ATP Fase A, B, C)", tab: "atp" },
                    { key: "minggu-efektif", label: "Rincian Minggu Efektif (RME / Alokasi Waktu Belajar)", tab: "minggu-efektif" },
                    { key: "prota", label: "Program Tahunan (PROTA) Kelas I–VI Lengkap", tab: "prota" },
                    { key: "promes", label: "Program Semester (PROMES Ganjil & Genap)", tab: "promes" },
                    { key: "jurnal-mengajar", label: "Jurnal Mengajar Harian (Terintegrasi Modul & PROMES)", tab: "jurnal-mengajar" },
                    { key: "kktp", label: "Kriteria Ketercapaian TP (Interval & Rubrik)", tab: "kktp" },
                    { key: "modul", label: "78 Modul Ajar Pembelajaran Mendalam (Deep Learning)", tab: "modul" },
                    { key: "kokurikuler", label: "12 Modul Projek Kokurikuler (P5-PPRA)", tab: "kokurikuler" },
                    { key: "analisis", label: "Analisis Capaian Pembelajaran & Pemetaan JP", tab: "analisis-cp" },
                    { key: "remedial", label: "Program & Jurnal Remedial / Pengayaan", tab: "remedial-pengayaan" },
                    { key: "program-keagamaan", label: "Program Keagamaan Islam (PHBI & Pembiasaan Jumat)", tab: "program-keagamaan" }
                  ]
                    .filter((item) => isAdmin || menuPermissions[item.tab] !== false)
                    .map((item) => (
                    <div
                      key={item.key}
                      onClick={() => setActiveTab(item.tab)}
                      className="flex items-center justify-between p-3 rounded-xl bg-[#e6f7ef] border border-emerald-300 hover:border-emerald-500 cursor-pointer transition-all shadow-xs"
                    >
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 flex-shrink-0" />
                        <span className="text-xs sm:text-sm font-bold text-slate-800">{item.label}</span>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-emerald-700 hover:text-emerald-900" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Panduan Cetak Standar Pendidikan Indonesia */}
              <div className="bg-white border-2 border-emerald-300 rounded-3xl p-6 space-y-4 shadow-sm text-slate-800">
                <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
                  <div className="flex items-center gap-2">
                    <FileCheck className="w-5 h-5 text-emerald-700" />
                    <h3 className="font-extrabold text-slate-900 text-base">Standar Format Resmi Dokumen</h3>
                  </div>
                  <span className="text-xs font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded-full">
                    A4 Margin 1.5 - 2.5 - 2.0 - 2.0
                  </span>
                </div>

                <div className="space-y-3 text-xs sm:text-sm text-slate-700 leading-relaxed">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-bold">1. Pengaturan Ukuran Kertas &amp; Margin:</strong>
                    <p className="text-slate-600 font-medium">
                      Kertas berukuran <strong>A4 (21,0 × 29,7 cm)</strong> dengan margin: <strong>Atas 1,5 cm, Kiri 2,5 cm, Kanan 2,0 cm, dan Bawah 2,0 cm</strong>.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-bold">2. Tipografi, Paragraf &amp; Tabel Multi-Halaman:</strong>
                    <p className="text-slate-600 font-medium">
                      Jenis huruf standar <strong>Times New Roman 12 pt</strong> untuk naskah isi (Judul 14 pt bold), rata kiri-kanan (<em>justify</em>). Tabel multi-halaman tidak terpotong garisnya dan baris judul (<em>thead</em>) otomatis diulang di halaman selanjutnya.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <strong className="text-slate-900 block font-bold">3. Kompatibilitas Microsoft Word (.doc):</strong>
                    <p className="text-slate-600 font-medium">
                      Seluruh dokumen dapat diunduh langsung menjadi file Word resmi dengan header tabel berulang otomatis (<em>table-header-group</em>), tanda tangan anti-terpotong (<em>keep-together</em>), dan nomor halaman.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* TAB 1: GENERATOR & VIEWER MODUL AJAR       */}
        {/* ========================================== */}
        {activeTab === "modul" && isTabEnabled("modul") && (
          <div className="flex flex-col lg:flex-row gap-6">
            
            {/* SIDEBAR KIRI: FILTER & DAFTAR MODUL */}
            <aside className="w-full lg:w-80 xl:w-96 flex-shrink-0 flex flex-col gap-5 no-print">
              
              {/* Panel Filter */}
              <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 text-slate-800">
                <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
                  <div className="flex items-center gap-2 font-extrabold text-slate-900 text-sm">
                    <Filter className="w-4 h-4 text-emerald-700" />
                    <span>Filter Perangkat Ajar</span>
                  </div>
                  <span className="text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 px-2.5 py-0.5 rounded-full">
                    {filteredModules.length} Modul
                  </span>
                </div>

                {/* Pilih Kelas 1 - 6 */}
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">Pilih Kelas</label>
                  <div className="grid grid-cols-7 gap-1.5">
                    {["Semua", "I", "II", "III", "IV", "V", "VI"].map((kls) => (
                      <button
                        key={kls}
                        onClick={() => {
                          setSelectedKelas(kls);
                          const firstMatch = modules.find(
                            (m) =>
                              (kls === "Semua" || m.kelas === kls) &&
                              (selectedSemester === "Semua" || m.semester === selectedSemester)
                          );
                          if (firstMatch) setActiveModulId(firstMatch.id);
                        }}
                        className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all duration-150 cursor-pointer ${
                          selectedKelas === kls
                            ? "bg-[#065f46] text-white border-emerald-700 shadow-sm"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {kls === "Semua" ? "All" : kls}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Pilih Semester */}
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">Semester</label>
                  <div className="grid grid-cols-3 gap-2">
                    {["Semua", "I (Ganjil)", "II (Genap)"].map((sem) => (
                      <button
                        key={sem}
                        onClick={() => {
                          setSelectedSemester(sem);
                          const firstMatch = modules.find(
                            (m) =>
                              (selectedKelas === "Semua" || m.kelas === selectedKelas) &&
                              (sem === "Semua" || m.semester === sem)
                          );
                          if (firstMatch) setActiveModulId(firstMatch.id);
                        }}
                        className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all duration-150 cursor-pointer ${
                          selectedSemester === sem
                            ? "bg-[#065f46] text-white border-emerald-700 shadow-sm"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {sem === "Semua" ? "Semua" : sem.split(" ")[0] + " " + sem.split(" ")[1]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Pilih Elemen */}
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">Elemen PAI</label>
                  <select
                    value={selectedElemen}
                    onChange={(e) => setSelectedElemen(e.target.value)}
                    className="w-full text-xs sm:text-sm rounded-xl border border-emerald-300 bg-emerald-50/60 text-slate-900 font-medium px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Semua">Semua Elemen (5 Elemen)</option>
                    <option value="Al-Qur’an-Hadis">Al-Qur’an-Hadis</option>
                    <option value="Akidah">Akidah</option>
                    <option value="Akhlak">Akhlak</option>
                    <option value="Fikih">Fikih</option>
                    <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam</option>
                  </select>
                </div>

                {/* Pencarian */}
                <div className="relative">
                  <Search className="w-4 h-4 text-emerald-700 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder="Cari materi / tujuan pembelajaran..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 text-xs sm:text-sm bg-emerald-50/60 border border-emerald-300 text-slate-900 placeholder-slate-400 font-medium rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Daftar Modul Ajar */}
              <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 overflow-hidden flex flex-col max-h-[540px]">
                <div className="px-5 py-3 bg-[#dcfce7] border-b border-emerald-200 text-[11px] font-extrabold text-emerald-950 uppercase tracking-widest flex items-center justify-between">
                  <span>Daftar Modul Ajar</span>
                  <span className="text-emerald-800 font-bold">Pilih Modul</span>
                </div>
                <div className="divide-y divide-emerald-100 overflow-y-auto flex-1 p-2.5 space-y-1.5">
                  {filteredModules.length === 0 ? (
                    <div className="p-8 text-center text-slate-500 text-sm font-medium">
                      Tidak ada modul yang sesuai dengan filter.
                    </div>
                  ) : (
                    filteredModules.map((m) => {
                      const isSelected = activeModul?.id === m.id;
                      return (
                        <button
                          key={m.id}
                          onClick={() => {
                            setActiveModulId(m.id);
                            setIsEditingModul(false);
                          }}
                          className={`w-full text-left p-3.5 rounded-xl transition-all duration-150 flex items-start gap-3.5 cursor-pointer ${
                            isSelected
                              ? "bg-[#e6f7ef] border-2 border-emerald-500 shadow-sm"
                              : "hover:bg-emerald-50/80 border border-transparent"
                          }`}
                        >
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 transition-transform ${
                            isSelected
                              ? "bg-[#065f46] text-white shadow-sm scale-105"
                              : "bg-emerald-100 text-emerald-900 border border-emerald-300"
                          }`}>
                            {m.nomor}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                              <span className="text-[11px] font-bold text-slate-700">
                                Kls {m.kelas} • Sem {m.semester.split(" ")[0]}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                                {m.elemen}
                              </span>
                            </div>
                            <p className={`text-xs sm:text-sm font-bold line-clamp-2 leading-snug ${
                              isSelected ? "text-emerald-950 font-extrabold" : "text-slate-800"
                            }`}>
                              {m.tp}
                            </p>
                            <p className="text-[11px] text-slate-500 mt-1.5 flex items-center gap-1.5 font-medium">
                              <Clock className="w-3 h-3 text-emerald-700" />
                              <span>{m.alokasi} • {m.pertemuan.length} Pertemuan</span>
                            </p>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            </aside>

            {/* AREA KANAN: TOOLBAR VERSI & DOKUMEN MODUL AJAR */}
            <section className="flex-1 flex flex-col gap-5 min-w-0">
              
              {/* Toolbar Pilihan Versi Template & Export */}
              <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-4 sm:p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-4 no-print text-slate-800">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-extrabold text-slate-700 uppercase tracking-wider mr-1 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-emerald-700" />
                    <span>Format Template:</span>
                  </span>
                  {[
                    { v: 1, label: "Versi 1 (Ringkas)" },
                    { v: 2, label: "Versi 2 (+Profil Lulusan)" },
                    { v: 3, label: "Versi 3 (Lengkap PM)" }
                  ].map((item) => (
                    <button
                      key={item.v}
                      onClick={() => setVersiTemplate(item.v)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all duration-150 cursor-pointer ${
                        versiTemplate === item.v
                          ? "bg-[#065f46] text-white border-emerald-700 shadow-sm"
                          : "bg-emerald-50 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>

                {/* Tombol Aksi & Pengaturan Tata Letak Cetak */}
                <div className="flex flex-wrap items-center gap-2 self-start xl:self-center">
                  {/* Pilihan Alokasi JP (3 JP atau 4 JP) */}
                  <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-1 text-xs">
                    <span className="px-2 text-slate-400 font-medium">Alokasi:</span>
                    {([3, 4] as const).map((jp) => (
                      <button
                        key={jp}
                        type="button"
                        onClick={() => handleSetAlokasiJp(jp)}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          alokasiJpDefault === jp
                            ? "bg-emerald-600 text-white shadow"
                            : "text-slate-300 hover:text-white"
                        }`}
                      >
                        {jp} JP
                      </button>
                    ))}
                  </div>

                  {/* Pilihan Spasi Baris Resmi (1,15 atau 1,5) */}
                  <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-1 text-xs">
                    <span className="px-2 text-slate-400 font-medium">Spasi:</span>
                    {["1.15", "1.5"].map((sp) => (
                      <button
                        key={sp}
                        onClick={() => setLineSpacing(sp)}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                          lineSpacing === sp
                            ? "bg-emerald-600 text-white shadow"
                            : "text-slate-300 hover:text-white"
                        }`}
                      >
                        {sp.replace(".", ",")}
                      </button>
                    ))}
                  </div>

                  {/* Toggle Font Times New Roman 12pt di Layar */}
                  <button
                    onClick={() => setPreviewOfficialLayout(!previewOfficialLayout)}
                    title="Aktifkan huruf Times New Roman 11pt & Rata Kiri-Kanan (Justify)"
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                      previewOfficialLayout
                        ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-300"
                        : "border-slate-700 bg-slate-800/80 text-slate-300 hover:text-white"
                    }`}
                  >
                    <FileCheck className="w-4 h-4" />
                    <span>Format Resmi A4</span>
                  </button>

                  

                  <button
                    onClick={() => setIsEditingModul(!isEditingModul)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      isEditingModul
                        ? "bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-lg shadow-amber-950/50"
                        : "bg-slate-800/80 text-slate-200 border-slate-700 hover:bg-slate-800"
                    }`}
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>{isEditingModul ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSaveModul}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-950/50 transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() => handleCopyModulSummary(activeModul)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800/80 hover:bg-slate-800 text-emerald-300 border border-slate-700 hover:border-emerald-500/40 transition-all"
                    title="Salin ringkasan modul ajar ke clipboard untuk WA atau LMS"
                  >
                    <Share2 className="w-4 h-4 text-emerald-400" />
                    <span>Salin Ringkasan</span>
                  </button>

                  <button
                    onClick={() => handleDownloadWord("printable-area", `Modul_Ajar_PAI_Kelas_${activeModul.kelas}_Sem_${activeModul.semester.split(" ")[0]}_Modul_${activeModul.nomor}_V${versiTemplate}`, false)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white shadow-lg shadow-blue-950/50 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Unduh Word (.doc)</span>
                  </button>

                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-950/50 transition-all"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Info Standar Tata Letak Naskah Pendidikan Indonesia */}
              <div className="bg-white border-2 border-emerald-300 rounded-2xl px-5 py-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-800 shadow-sm no-print">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 flex-shrink-0" />
                  <span>
                    <strong>Standar Cetak &amp; Word Aktif:</strong> Kertas A4 (21×29,7 cm) • Margin Kiri 4 cm, Kanan/Atas/Bawah 3 cm • Times New Roman 12 pt (Judul 14 pt) • Rata Kiri–Kanan (Justify) • Spasi {lineSpacing.replace(".", ",")}.
                  </span>
                </div>
              </div>

              {/* Panel Editor Cepat (Jika Mode Edit Aktif) */}
              {isEditingModul && activeModul && (
                <div className="bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shadow-md no-print text-slate-800">
                  <div className="flex items-center justify-between border-b border-amber-200 pb-3">
                    <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2">
                      <Edit3 className="w-4 h-4 text-amber-600" />
                      <span>Mode Kustomisasi Cepat Modul Ajar (Perubahan langsung tampil di dokumen bawah)</span>
                    </h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Tujuan Pembelajaran</label>
                      <input
                        type="text"
                        value={activeModul.tp}
                        onChange={(e) => handleUpdateActiveModul("tp", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Alokasi Waktu</label>
                      <input
                        type="text"
                        value={activeModul.alokasi}
                        onChange={(e) => handleUpdateActiveModul("alokasi", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                      />
                    </div>
                    <div className="md:col-span-3">
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Dimensi Profil Lulusan</label>
                      <input
                        type="text"
                        value={activeModul.dimensi}
                        onChange={(e) => handleUpdateActiveModul("dimensi", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                      />
                    </div>
                    <div className="md:col-span-3">
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">Asesmen Sumatif</label>
                      <textarea
                        rows={2}
                        value={activeModul.asesmen}
                        onChange={(e) => handleUpdateActiveModul("asesmen", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* LEMBAR DOKUMEN MODUL AJAR (SIAP CETAK / WORD STANDAR RESMI A4) */}
              {activeModul && (
                <div
                  id="printable-area"
                  style={
                    paperLightMode
                      ? { padding: "2.5cm 2.5cm 2.5cm 3.2cm" }
                      : undefined
                  }
                  className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 ${docContainerClass} ${
                    previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
                  }`}
                >
                  {/* KOP SURAT RESMI */}
                  {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

                  {/* Judul Header Modul (14pt, Tebal, Rata Tengah) */}
                  <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-sans font-bold uppercase tracking-widest mb-2 no-print bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      <span>Template Versi {versiTemplate}</span>
                      <span>•</span>
                      <span>Kelas {activeModul.kelas} Semester {activeModul.semester}</span>
                    </div>
                    <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                      MODUL AJAR {activeModul.nomor}
                    </h2>
                    <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                      PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                    </h3>
                  </div>

                  {/* Tabel Informasi Umum */}
                  <table className={`w-full border-collapse border mb-6 ${tableBorderClass}`}>
                    <tbody>
                      <tr>
                        <td className={`label-col border px-4 py-2 font-bold w-1/3 ${tableBorderClass} ${tableLabelBgClass}`}>Sekolah</td>
                        <td className={`border px-4 py-2 ${tableBorderClass}`}>{identitas.sekolah}</td>
                      </tr>
                      <tr>
                        <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Fase / Kelas / Semester</td>
                        <td className={`border px-4 py-2 ${tableBorderClass}`}>
                          Fase {activeModul.fase} / Kelas {activeModul.kelas} / Semester {activeModul.semester}
                        </td>
                      </tr>
                      <tr>
                        <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Alokasi Waktu</td>
                        <td className={`border px-4 py-2 ${tableBorderClass}`}>
                          {activeModul.pertemuan?.length || 1} x {alokasiJpDefault} JP ({(activeModul.pertemuan?.length || 1) * alokasiJpDefault} JP)
                        </td>
                      </tr>
                      <tr>
                        <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Tahun Ajaran</td>
                        <td className={`border px-4 py-2 ${tableBorderClass}`}>{identitas.tahunAjaran}</td>
                      </tr>
                      <tr>
                        <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Elemen</td>
                        <td className={`border px-4 py-2 font-bold ${tableBorderClass} text-black`}>
                          {activeModul.elemen}
                        </td>
                      </tr>
                      {versiTemplate === 2 && (
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Dimensi Profil Lulusan</td>
                          <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{activeModul.dimensi}</td>
                        </tr>
                      )}
                    </tbody>
                  </table>

                  {/* ======================================= */}
                  {/* KOMPONEN TAMBAHAN KHUSUS VERSI 3 (PM)   */}
                  {/* ======================================= */}
                  {versiTemplate === 3 && (
                    <div className="mb-6 space-y-5">
                      <div>
                        <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                          A. Identifikasi (Opsional)
                        </h4>
                        <table className={`w-full border-collapse border ${tableBorderClass}`}>
                          <tbody>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold w-1/3 ${tableBorderClass} ${tableLabelBgClass}`}>Peserta Didik</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{formatTextSapaan(deepDetails.pesertaDidik)}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Materi Pelajaran</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{deepDetails.materiPelajaran}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Dimensi Profil Lulusan</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{activeModul.dimensi}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      <div>
                        <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                          B. Desain Pembelajaran
                        </h4>
                        <table className={`w-full border-collapse border ${tableBorderClass}`}>
                          <tbody>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold w-1/3 ${tableBorderClass} ${tableLabelBgClass}`}>Capaian Pembelajaran</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{formatTextSapaan(deepDetails.cp)}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Tujuan Pembelajaran</td>
                              <td className={`border px-4 py-2 font-bold text-justify ${tableBorderClass} text-black`}>
                                {activeModul.tp}
                              </td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Topik Pembelajaran</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{deepDetails.topik}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Lintas Disiplin Ilmu</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{deepDetails.lintasDisiplin}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Praktik Pedagogis</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{deepDetails.pedagogis}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Kemitraan Pembelajaran</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{formatTextSapaan(deepDetails.kemitraan)}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Lingkungan Pembelajaran</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{deepDetails.lingkungan}</td>
                            </tr>
                            <tr>
                              <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Pemanfaatan Digital</td>
                              <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{deepDetails.digital}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* TUJUAN PEMBELAJARAN (Untuk Versi 1 dan 2) */}
                  {versiTemplate !== 3 && (
                    <div className="mb-6">
                      <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2 ${sectionBannerClass}`}>
                        A. Tujuan Pembelajaran
                      </h4>
                      <p className={`font-semibold text-justify px-4 py-3 rounded-xl border ${
                        paperLightMode
                          ? "bg-white border-black text-black"
                          : "bg-slate-800/50 border-slate-700/80 text-white"
                      }`}>
                        {activeModul.tp}
                      </p>
                    </div>
                  )}

                  {/* LANGKAH-LANGKAH / KEGIATAN PEMBELAJARAN */}
                  <div className="mb-6">
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-3 ${sectionBannerClass}`}>
                      {versiTemplate === 3 ? "C. Pengalaman Belajar — " : "B. "}
                      Langkah-langkah / Kegiatan Pembelajaran
                      {versiTemplate >= 2 && (
                        <span className={`block text-xs font-normal normal-case mt-0.5 ${paperLightMode ? "text-black" : "text-slate-400"}`}>
                          (Termasuk di dalamnya ada pengalaman belajar yang terdiri dari memahami, mengaplikasi, dan merefleksi)
                        </span>
                      )}
                    </h4>

                    <div className="space-y-6">
                      {activeModul.pertemuan.map((pert, idx) => {
                        const pendahuluanList = makePendahuluan(activeModul.tp, pert.iceBreaking);
                        return (
                          <div
                            key={idx}
                            className={`border rounded-xl overflow-hidden ${
                              paperLightMode ? "border-black rounded-none" : "border-slate-700/80 bg-slate-950/30"
                            }`}
                          >
                            <h5 className={`doc-sub-heading px-4 py-2.5 border-b font-bold flex items-center gap-2 ${
                              paperLightMode
                                ? "bg-slate-100 border-black text-black"
                                : "bg-slate-800/90 border-slate-700/80 text-emerald-300"
                            }`}>
                              <Calendar className="w-4 h-4 no-print opacity-80" />
                              <span>{pert.judul}</span>
                            </h5>
                            <div className="p-4 sm:p-5 space-y-4">
                              {/* Kegiatan Pendahuluan */}
                              <div>
                                <h5 className={`doc-sub-heading font-bold mb-1.5 underline decoration-emerald-500/60 underline-offset-4 ${
                                  paperLightMode ? "text-black decoration-black" : "text-slate-200"
                                }`}>
                                  1. Kegiatan Pendahuluan:
                                </h5>
                                <ol className="list-decimal pl-6 space-y-1.5 text-justify">
                                  {pendahuluanList.map((item, i) => (
                                    <li key={i} className="text-justify">{renderHighlightedActivity(item)}</li>
                                  ))}
                                </ol>
                              </div>

                              {/* Kegiatan Inti */}
                              <div>
                                <h5 className={`doc-sub-heading font-bold mb-1.5 underline decoration-emerald-500/60 underline-offset-4 ${
                                  paperLightMode ? "text-black decoration-black" : "text-slate-200"
                                }`}>
                                  2. Kegiatan Inti:
                                </h5>
                                <ol className="list-decimal pl-6 space-y-1.5 text-justify">
                                  {pert.inti.map((item, i) => (
                                    <li key={i} className="text-justify">{renderHighlightedActivity(item)}</li>
                                  ))}
                                </ol>
                              </div>

                              {/* Kegiatan Penutup */}
                              <div>
                                <h5 className={`doc-sub-heading font-bold mb-1.5 underline decoration-emerald-500/60 underline-offset-4 ${
                                  paperLightMode ? "text-black decoration-black" : "text-slate-200"
                                }`}>
                                  3. Kegiatan Penutup:
                                </h5>
                                <ol className="list-decimal pl-6 space-y-1.5 text-justify">
                                  {PENUTUP_STANDAR.map((item, i) => (
                                    <li key={i} className="text-justify">{renderHighlightedActivity(item)}</li>
                                  ))}
                                </ol>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* ASESMEN */}
                  <div className="mb-8 keep-together">
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2 ${sectionBannerClass}`}>
                      {versiTemplate === 3 ? "D. Asesmen Pembelajaran" : "C. Asesmen"}
                    </h4>
                    {versiTemplate === 3 ? (
                      <ol className="list-decimal pl-6 space-y-1.5 text-justify">
                        <li className="text-justify">
                          <strong>Asesmen Awal (Opsional):</strong> {formatTextSapaan(deepDetails.asesmenAwal)}
                        </li>
                        <li className="text-justify">
                          <strong>Asesmen Proses (Opsional):</strong> {formatTextSapaan(deepDetails.asesmenProses)}
                        </li>
                        <li className="text-justify">
                          <strong>Asesmen Sumatif:</strong> {formatTextSapaan(activeModul.asesmen)}
                        </li>
                      </ol>
                    ) : (
                      <p className="text-justify px-1">{formatTextSapaan(activeModul.asesmen)}</p>
                    )}
                  </div>

                  {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>

                </div>
              )}
            </section>
          </div>
        )}

        {/* ======================================================= */}
        {/* TAB 4: MATERI PEMBELAJARAN (BAB & RINCIAN PERTEMUAN)     */}
        {/* ======================================================= */}
        {activeTab === "materi-bab" && isTabEnabled("materi-bab") && (
          <TabMateriPembelajaran
            modules={modules}
            identitas={identitas}
            alokasiJpDefault={alokasiJpDefault}
            setAlokasiJpDefault={handleSetAlokasiJp}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
            setActiveTab={safeSetActiveTab}
            setSelectedKelas={setSelectedKelas}
            setSelectedSemester={setSelectedSemester}
            setActiveModulId={setActiveModulId}
          />
        )}

        {/* ======================================================= */}
        {/* TAB BARU: MODUL PROJEK KOKURIKULER (KELAS I-VI, 2 SEM)  */}
        {/* ======================================================= */}
        {activeTab === "kokurikuler" && isTabEnabled("kokurikuler") && (
          <div className="flex flex-col lg:flex-row gap-6">
            {/* SIDEBAR KIRI: FILTER & DAFTAR 12 MODUL KOKURIKULER */}
            <aside className="w-full lg:w-80 xl:w-96 flex-shrink-0 flex flex-col gap-5 no-print">
              <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 text-slate-800">
                <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
                  <div className="flex items-center gap-2 font-extrabold text-slate-900 text-sm">
                    <Users className="w-4 h-4 text-emerald-700" />
                    <span>Filter Modul Kokurikuler</span>
                  </div>
                  <span className="text-xs font-bold bg-emerald-100 text-emerald-950 border border-emerald-300 px-2.5 py-0.5 rounded-full">
                    {filteredKokurikuler.length} Projek
                  </span>
                </div>

                {/* Pilih Kelas 1 - 6 */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Pilih Kelas
                  </label>
                  <div className="grid grid-cols-7 gap-1.5">
                    {["Semua", "I", "II", "III", "IV", "V", "VI"].map((kls) => (
                      <button
                        key={kls}
                        onClick={() => {
                          setKoKelas(kls);
                          const firstMatch = kokurikulerList.find(
                            (m) =>
                              (kls === "Semua" || m.kelas === kls) &&
                              (koSemester === "Semua" || m.semester === koSemester)
                          );
                          if (firstMatch) setActiveKoId(firstMatch.id);
                        }}
                        className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all duration-150 cursor-pointer ${
                          koKelas === kls
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {kls === "Semua" ? "All" : kls}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Pilih Semester */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Semester
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {["Semua", "I (Ganjil)", "II (Genap)"].map((sem) => (
                      <button
                        key={sem}
                        onClick={() => {
                          setKoSemester(sem);
                          const firstMatch = kokurikulerList.find(
                            (m) =>
                              (koKelas === "Semua" || m.kelas === koKelas) &&
                              (sem === "Semua" || m.semester === sem)
                          );
                          if (firstMatch) setActiveKoId(firstMatch.id);
                        }}
                        className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all duration-150 cursor-pointer ${
                          koSemester === sem
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {sem === "Semua" ? "Semua" : sem.split(" ")[0] + " " + sem.split(" ")[1]}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Daftar Projek Kokurikuler */}
              <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 overflow-hidden flex flex-col max-h-[560px]">
                <div className="px-5 py-3.5 bg-[#dcfce7] border-b border-emerald-300 text-[11px] font-bold text-emerald-950 uppercase tracking-widest flex items-center justify-between">
                  <span>Daftar Projek Kelas I–VI</span>
                  <span className="text-emerald-800 font-extrabold">12 Semester</span>
                </div>
                <div className="divide-y divide-emerald-100 overflow-y-auto flex-1 p-2.5 space-y-1.5">
                  {filteredKokurikuler.map((ko) => {
                    const isSelected = activeKokurikuler?.id === ko.id;
                    return (
                      <button
                        key={ko.id}
                        onClick={() => {
                          setActiveKoId(ko.id);
                          setIsEditingKo(false);
                        }}
                        className={`w-full text-left p-3.5 rounded-xl transition-all duration-150 flex items-start gap-3.5 cursor-pointer ${
                          isSelected
                            ? "bg-[#e6f7ef] border-2 border-emerald-500 shadow-sm"
                            : "hover:bg-emerald-50/70 border border-transparent"
                        }`}
                      >
                        <div
                          className={`w-9 h-9 rounded-xl flex flex-col items-center justify-center font-bold text-[10px] flex-shrink-0 mt-0.5 ${
                            isSelected
                              ? "bg-[#065f46] text-white shadow-sm"
                              : "bg-emerald-100 text-emerald-900 border border-emerald-300"
                          }`}
                        >
                          <span>Kls {ko.kelas}</span>
                          <span className="text-[9px] opacity-90">S.{ko.nomor}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap mb-1">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                              Sem {ko.semester}
                            </span>
                            <span className="text-[10px] text-slate-500 truncate font-medium">
                              {ko.tema}
                            </span>
                          </div>
                          <p
                            className={`text-xs sm:text-sm font-bold line-clamp-2 leading-snug ${
                              isSelected ? "text-slate-900" : "text-slate-700"
                            }`}
                          >
                            {ko.judulProjek}
                          </p>
                          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5 font-medium">
                            <Clock className="w-3 h-3 text-emerald-600" />
                            <span>{ko.alokasi}</span>
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </aside>

            {/* AREA KANAN: TOOLBAR & DOKUMEN MODUL KOKURIKULER */}
            <section className="flex-1 flex flex-col gap-5 min-w-0">
              {/* Toolbar Aksi */}
              <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-4 sm:p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-4 no-print text-slate-800">
                <div>
                  <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-700" />
                    <span>Modul Projek Kokurikuler PAI &amp; Budi Pekerti (P5-PPRA &amp; Pembelajaran Mendalam)</span>
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Terintegrasi langsung dengan materi intrakurikuler PAI Kelas {activeKokurikuler?.kelas} Semester {activeKokurikuler?.semester}.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsEditingKo(!isEditingKo)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isEditingKo
                        ? "bg-amber-400 text-slate-950 border-amber-500"
                        : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>{isEditingKo ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSaveKokurikuler}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `Modul_Kokurikuler_PAI_Kelas_${activeKokurikuler.kelas}_Sem_${activeKokurikuler.semester.split(" ")[0]}`,
                        false
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh Word (.doc)</span>
                  </button>

                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-950" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Editor Cepat Kokurikuler */}
              {isEditingKo && activeKokurikuler && (
                <div className="bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shadow-md no-print text-slate-800">
                  <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2 border-b border-amber-200 pb-2.5">
                    <Edit3 className="w-4 h-4 text-amber-600" />
                    <span>Kustomisasi Modul Kokurikuler Kelas {activeKokurikuler.kelas}</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Judul Projek Kokurikuler</label>
                      <input
                        type="text"
                        value={activeKokurikuler.judulProjek}
                        onChange={(e) => handleUpdateActiveKokurikuler("judulProjek", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Alokasi Waktu</label>
                      <input
                        type="text"
                        value={activeKokurikuler.alokasi}
                        onChange={(e) => handleUpdateActiveKokurikuler("alokasi", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl font-medium"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">Tujuan Projek Kokurikuler</label>
                      <textarea
                        rows={2}
                        value={activeKokurikuler.tujuanProjek}
                        onChange={(e) => handleUpdateActiveKokurikuler("tujuanProjek", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl font-medium"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">Produk / Karya Akhir</label>
                      <input
                        type="text"
                        value={activeKokurikuler.produkAkhir}
                        onChange={(e) => handleUpdateActiveKokurikuler("produkAkhir", e.target.value)}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 text-slate-900 rounded-xl font-medium"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* LEMBAR DOKUMEN MODUL KOKURIKULER SIAP CETAK */}
              {activeKokurikuler && (
                <div
                  id="printable-area"
                  style={paperLightMode ? { padding: "2.5cm 2.5cm 2.5cm 3.2cm" } : undefined}
                  className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 ${docContainerClass} ${
                    previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
                  }`}
                >
                  {/* KOP SURAT RESMI */}
                  {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

                  {/* Header Dokumen */}
                  <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-sans font-bold uppercase tracking-widest mb-2 no-print bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      <span>Kokurikuler P5-PPRA & Pembelajaran Mendalam</span>
                      <span>•</span>
                      <span>Kelas {activeKokurikuler.kelas} Semester {activeKokurikuler.semester}</span>
                    </div>
                    <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                      MODUL PROJEK KOKURIKULER {activeKokurikuler.nomor}
                    </h2>
                    <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                      PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                    </h3>
                  </div>

                  {/* A. Identitas & Informasi Umum Kokurikuler */}
                  <div className="mb-6">
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                      A. Identitas dan Informasi Umum Projek
                    </h4>
                    <table className={`w-full border-collapse border ${tableBorderClass}`}>
                      <tbody>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold w-1/3 ${tableBorderClass} ${tableLabelBgClass}`}>Satuan Pendidikan</td>
                          <td className={`border px-4 py-2 ${tableBorderClass}`}>{identitas.sekolah}</td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Fase / Kelas / Semester</td>
                          <td className={`border px-4 py-2 font-bold ${tableBorderClass}`}>
                            Fase {activeKokurikuler.fase} / Kelas {activeKokurikuler.kelas} / Semester {activeKokurikuler.semester}
                          </td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Tema Kokurikuler</td>
                          <td className={`border px-4 py-2 ${tableBorderClass}`}>{activeKokurikuler.tema}</td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Judul Projek</td>
                          <td className={`border px-4 py-2 font-bold ${tableBorderClass} text-black`}>
                            “{activeKokurikuler.judulProjek}”
                          </td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Alokasi Waktu & Tahun Ajaran</td>
                          <td className={`border px-4 py-2 ${tableBorderClass}`}>
                            {activeKokurikuler.alokasi} • Tahun Ajaran {identitas.tahunAjaran}
                          </td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Materi PAI Terintegrasi</td>
                          <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{activeKokurikuler.materiTerkait}</td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Dimensi Profil Lulusan (8 Dimensi)</td>
                          <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{activeKokurikuler.dimensiProfil}</td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Nilai Rahmatan Lil ‘Alamin / Moderasi</td>
                          <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{activeKokurikuler.nilaiPpra}</td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Kolaborasi Lintas Disiplin Ilmu</td>
                          <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>{activeKokurikuler.lintasDisiplin}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* B. Tujuan Projek & Produk Akhir */}
                  <div className="mb-6">
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                      B. Tujuan Kokurikuler & Produk Karya Akhir
                    </h4>
                    <table className={`w-full border-collapse border ${tableBorderClass}`}>
                      <tbody>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold w-1/3 ${tableBorderClass} ${tableLabelBgClass}`}>Tujuan Projek Kokurikuler</td>
                          <td className={`border px-4 py-2 text-justify ${tableBorderClass}`}>
                            {formatTextSapaan(activeKokurikuler.tujuanProjek)}
                          </td>
                        </tr>
                        <tr>
                          <td className={`label-col border px-4 py-2 font-bold ${tableBorderClass} ${tableLabelBgClass}`}>Target Produk / Unjuk Karya</td>
                          <td className={`border px-4 py-2 font-bold text-justify ${tableBorderClass}`}>
                            {activeKokurikuler.produkAkhir}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* C. Alur Aktivitas Tahapan Projek Kokurikuler */}
                  <div className="mb-6">
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-3 ${sectionBannerClass}`}>
                      C. Alur Kegiatan Pelaksanaan Projek Kokurikuler (Memahami, Mengaplikasi, Merefleksi)
                    </h4>
                    <div className="space-y-4">
                      {activeKokurikuler.tahapan.map((thp, idx) => (
                        <div
                          key={idx}
                          className={`border rounded-xl overflow-hidden ${
                            paperLightMode ? "border-black rounded-none" : "border-slate-700/80 bg-slate-950/30"
                          }`}
                        >
                          <h5
                            className={`doc-sub-heading px-4 py-2 border-b font-bold ${
                              paperLightMode
                                ? "bg-slate-100 border-black text-black"
                                : "bg-slate-800/90 border-slate-700/80 text-emerald-300"
                            }`}
                          >
                            {thp.tahap}
                          </h5>
                          <div className="p-4">
                            <ol className="list-decimal pl-6 space-y-1.5 text-justify">
                              {thp.kegiatan.map((keg, kIdx) => (
                                <li key={kIdx} className="text-justify">
                                  {renderHighlightedActivity(keg)}
                                </li>
                              ))}
                            </ol>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* D. Rubrik & Asesmen Ketercapaian Kokurikuler */}
                  <div className="mb-8 keep-together">
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                      D. Asesmen dan Rubrik Ketercapaian Projek Kokurikuler
                    </h4>
                    <p className="mb-3 text-justify">
                      <strong>Metode Penilaian:</strong> {formatTextSapaan(activeKokurikuler.asesmenProjek)}
                    </p>
                    <table className={`w-full border-collapse border ${tableBorderClass}`}>
                      <thead>
                        <tr className={tableHeaderBgClass}>
                          <th className={`border px-3 py-2 text-center font-bold w-1/4 ${tableBorderClass}`}>Mulai Berkembang (MB)</th>
                          <th className={`border px-3 py-2 text-center font-bold w-1/4 ${tableBorderClass}`}>Sedang Berkembang (SB)</th>
                          <th className={`border px-3 py-2 text-center font-bold w-1/4 ${tableBorderClass}`}>Berkembang Sesuai Harapan (BSH)</th>
                          <th className={`border px-3 py-2 text-center font-bold w-1/4 ${tableBorderClass}`}>Sangat Berkembang (SAB)</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className={`border px-3 py-2 text-justify ${tableBorderClass}`}>
                            {identitas.sapaanSiswa} mulai mengenal konsep materi terkait projek namun masih membutuhkan bimbingan intensif dalam berkolaborasi dan menyelesaikan karya ({activeKokurikuler.produkAkhir}).
                          </td>
                          <td className={`border px-3 py-2 text-justify ${tableBorderClass}`}>
                            {identitas.sapaanSiswa} mampu memahami materi dan berpartisipasi aktif dalam kegiatan kelompok serta menyelesaikan sebagian besar tahapan pembuatan produk dengan arahan guru.
                          </td>
                          <td className={`border px-3 py-2 text-justify font-semibold ${tableBorderClass}`}>
                            {identitas.sapaanSiswa} mampu mengaitkan nilai-nilai PAI ke dalam aksi nyata secara mandiri, bekerja sama dengan kompak, dan menghasilkan karya {activeKokurikuler.produkAkhir} dengan baik dan tepat waktu.
                          </td>
                          <td className={`border px-3 py-2 text-justify font-semibold ${tableBorderClass}`}>
                            {identitas.sapaanSiswa} menunjukkan inisiatif tinggi, kreativitas luar biasa, serta menjadi teladan (qudwah) bagi teman sebaya dalam mempresentasikan dan membiasakan nilai projek dalam keseharian.
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
                </div>
              )}
            </section>
          </div>
        )}

        {/* ======================================================= */}
        {/* TAB BARU: ANALISIS CAPAIAN PEMBELAJARAN (CP) PER KELAS  */}
        {/* ======================================================= */}
        {activeTab === "analisis-cp" && isTabEnabled("analisis-cp") && (
          <div className="space-y-6">
            {/* Panel Filter & Ekspor Analisis CP */}
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-5 no-print text-slate-800">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
                    <BarChart3 className="w-5 h-5 text-emerald-700" />
                    <span>Analisis Pemetaan Capaian Pembelajaran (CP), TP &amp; Modul Ajar</span>
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Pemetaan terintegrasi Capaian Pembelajaran (Fase A, B, C) ke Tujuan Pembelajaran, Materi Pokok Pertemuan, Profil Lulusan, Asesmen, dan Alokasi Waktu per Kelas &amp; Semester.
                  </p>
                </div>

                {/* Tombol Aksi Unduh & Cetak */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsEditingAnalisis(!isEditingAnalisis)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isEditingAnalisis
                        ? "bg-amber-400 text-slate-950 border-amber-500"
                        : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>{isEditingAnalisis ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSaveAnalisis}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `Analisis_CP_PAI_Kelas_${analisisKelas}_Sem_${analisisSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                        true
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh Word Landscape (.doc)</span>
                  </button>
                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `Analisis_CP_PAI_Portrait_Kelas_${analisisKelas}_Sem_${analisisSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                        false
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh Word Portrait (.doc)</span>
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-950" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Baris Filter Kelas, Semester, Elemen & Kartu Ringkasan */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
                {/* Pilih Kelas */}
                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Filter Kelas
                  </label>
                  <div className="grid grid-cols-7 gap-1.5">
                    {["Semua", "I", "II", "III", "IV", "V", "VI"].map((kls) => (
                      <button
                        key={kls}
                        onClick={() => setAnalisisKelas(kls)}
                        className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          analisisKelas === kls
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {kls === "Semua" ? "Semua" : kls}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Pilih Semester */}
                <div className="lg:col-span-3">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Filter Semester
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {["Semua", "I (Ganjil)", "II (Genap)"].map((sem) => (
                      <button
                        key={sem}
                        onClick={() => setAnalisisSemester(sem)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          analisisSemester === sem
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {sem === "Semua" ? "Semua" : sem.split(" ")[0] + " " + sem.split(" ")[1]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Pilih Elemen */}
                <div className="lg:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Elemen PAI
                  </label>
                  <select
                    value={analisisElemen}
                    onChange={(e) => setAnalisisElemen(e.target.value)}
                    className="w-full text-xs font-bold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value="Semua">Semua Elemen</option>
                    <option value="Al-Qur’an-Hadis">Al-Qur’an-Hadis</option>
                    <option value="Akidah">Akidah</option>
                    <option value="Akhlak">Akhlak</option>
                    <option value="Fikih">Fikih</option>
                    <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam</option>
                  </select>
                </div>

                {/* Statistik Ringkas */}
                <div className="lg:col-span-3 grid grid-cols-3 gap-2">
                  <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2.5 text-center">
                    <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Total Modul</span>
                    <span className="text-base font-extrabold text-emerald-800">{analisisSummary.totalModul}</span>
                  </div>
                  <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2.5 text-center">
                    <span className="block text-[10px] text-teal-900 uppercase font-extrabold">Pertemuan</span>
                    <span className="text-base font-extrabold text-teal-800">{analisisSummary.totalPertemuan}x</span>
                  </div>
                  <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2.5 text-center">
                    <span className="block text-[10px] text-amber-900 uppercase font-extrabold">Alokasi JP</span>
                    <span className="text-base font-extrabold text-amber-800">{analisisSummary.totalJp} JP</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Panel Editor Analisis CP */}
            {isEditingAnalisis && (
              <div className="bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shadow-md no-print text-slate-800">
                <div className="flex items-center justify-between border-b border-amber-200 pb-3">
                  <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2">
                    <Edit3 className="w-4 h-4 text-amber-600" />
                    <span>Editor Cepat Analisis Capaian Pembelajaran (Kelas {analisisKelas} - {analisisSemester})</span>
                  </h3>
                  <button
                    onClick={handleSaveAnalisis}
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Simpan Perubahan Analisis CP</span>
                  </button>
                </div>
                <div className="space-y-3">
                  <p className="text-xs text-slate-600 font-medium">
                    Silakan sesuaikan Materi Pokok dan Alokasi Waktu (JP) untuk modul pada kelas dan semester aktif:
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-2">
                    {modules
                      .filter(m => (analisisKelas === "Semua" || m.kelas === analisisKelas) && (analisisSemester === "Semua" || m.semester === analisisSemester))
                      .map(mod => (
                        <div key={mod.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-emerald-800">{mod.bab}: {mod.judul}</span>
                            <span className="text-[10px] text-slate-500 font-semibold">Kelas {mod.kelas}</span>
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-600 font-semibold block mb-0.5">Materi Pokok:</label>
                            <input
                              type="text"
                              value={mod.materi}
                              onChange={(e) => handleUpdateModulFieldById(mod.id, 'materi', e.target.value)}
                              className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 focus:ring-1 focus:ring-emerald-500"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-600 font-semibold block mb-0.5">Alokasi Waktu:</label>
                            <input
                              type="text"
                              value={mod.alokasi}
                              onChange={(e) => handleUpdateModulFieldById(mod.id, 'alokasi', e.target.value)}
                              className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 focus:ring-1 focus:ring-emerald-500"
                            />
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            )}

            {/* LEMBAR DOKUMEN ANALISIS CP PER KELAS & SEMESTER */}
            <div
              id="printable-area"
              style={
                paperLightMode
                  ? { padding: "2.5cm 2.5cm 2.5cm 3.2cm" }
                  : undefined
              }
              className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 ${docContainerClass} ${
                previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
              }`}
            >
              {/* KOP SURAT RESMI */}
              {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

              {/* Judul Utama Dokumen Analisis CP */}
              <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  ANALISIS CAPAIAN PEMBELAJARAN (CP) DAN PEMETAAN MODUL AJAR
                </h2>
                <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                </h3>
              </div>

              {/* Identitas Dokumen */}
              {/* Identitas Dokumen (Tanpa Tabel / Kotak, Susun Rapi Tanpa Spasi Berlebih) */}
              <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">{identitas.sekolah}</span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Kelas / Semester</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">
                    {analisisKelas === "Semua" ? "Kelas I – VI (Semua Kelas)" : `Kelas ${analisisKelas}`} /{" "}
                    {analisisSemester === "Semua" ? "Semester I (Ganjil) & II (Genap)" : `Semester ${analisisSemester}`}
                  </span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">{identitas.tahunAjaran}</span>
                </div>
              </div>

              {/* Daftar Tabel Analisis per Kelas & Semester */}
              <div className="space-y-8">
                {analisisCpData.map((group) => (
                  <div key={`${group.kelas}-${group.semester}`} className="space-y-3">
                    <div
                      className={`px-4 py-2.5 rounded-xl flex flex-wrap items-center justify-between gap-2 ${
                        paperLightMode
                          ? "bg-slate-100 border border-black text-black rounded-none"
                          : "bg-gradient-to-r from-emerald-900/90 via-teal-900/80 to-slate-900 text-white border border-emerald-500/30"
                      }`}
                    >
                      <h4 className="doc-section-heading font-bold uppercase m-0">
                        KELAS {group.kelas} (FASE {group.fase}) — SEMESTER {group.semester.toUpperCase()}
                      </h4>
                      <span className="text-xs font-bold">
                        Total: {group.items.length} Modul Ajar • {group.totalPertemuanSemester} Pertemuan ({group.totalJpSemester} JP)
                      </span>
                    </div>

                    <div className="overflow-x-auto print:overflow-visible">
                      <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%' }}>
                        <thead>
                          <tr className={tableHeaderBgClass}>
                            <th className={`border px-2 py-2 text-center font-bold w-[5%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>No</th>
                            <th className={`border px-2.5 py-2 text-center font-bold w-[13%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>Elemen</th>
                            <th className={`border px-3 py-2 text-center font-bold w-[20%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                              Capaian Pembelajaran (CP Fase {group.fase})
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold w-[18%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                              Tujuan Pembelajaran (TP Modul)
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold w-[21%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                              Rincian Materi Pokok / Kegiatan Pertemuan
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold w-[15%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                              Dimensi Profil Lulusan & Asesmen
                            </th>
                            <th className={`border px-2 py-2 text-center font-bold w-[8%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                              Alokasi Waktu
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {group.items.map((item, idx) => (
                            <tr key={item.id} className="keep-together">
                              <td className={`border px-2 py-2 text-center font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'center' }}>
                                {idx + 1}
                              </td>
                              <td className={`border px-2.5 py-2 align-top font-bold text-left ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'left' }}>
                                <div>{item.elemen}</div>
                                <div className="text-[11px] font-normal mt-1 opacity-80">
                                  Modul Ajar {item.nomor}
                                </div>
                                {isTabEnabled("modul") && (
                                  <button
                                    onClick={() => {
                                      setSelectedKelas(item.kelas);
                                      setSelectedSemester(item.semester);
                                      setActiveModulId(item.id);
                                      safeSetActiveTab("modul");
                                      showToast(`Membuka Modul Ajar ${item.nomor} Kelas ${item.kelas} Semester ${item.semester}`);
                                    }}
                                    className="mt-2 inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-sans font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500 hover:text-slate-950 transition-all no-print cursor-pointer"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                    <span>Buka Modul</span>
                                  </button>
                                )}
                              </td>
                              <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                                {formatTextSapaan(item.cp)}
                              </td>
                              <td className={`border px-3 py-2 align-top font-semibold text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                                {formatTextSapaan(item.tp)}
                              </td>
                              <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                                <ol className="list-decimal pl-4 space-y-1 text-justify">
                                  {item.pertemuan.map((p, pIdx) => (
                                    <li key={pIdx} className="text-justify">
                                      <span className="font-semibold">{p.judul}</span>
                                    </li>
                                  ))}
                                </ol>
                              </td>
                              <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                                <div className="mb-2">
                                  <span className="font-bold block underline">Profil Lulusan:</span>
                                  <span>{item.dimensi}</span>
                                </div>
                                <div>
                                  <span className="font-bold block underline">Asesmen:</span>
                                  <span>{formatTextSapaan(item.asesmen)}</span>
                                </div>
                              </td>
                              <td className={`border px-2 py-2 align-top text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'center' }}>
                                <div>{item.alokasi}</div>
                                <div className="text-xs font-normal mt-1">
                                  ({item.totalJp} JP)
                                </div>
                              </td>
                            </tr>
                          ))}
                          {/* Baris Total JP per Semester */}
                          <tr className={tableLabelBgClass}>
                            <td
                              colSpan={6}
                              className={`border px-4 py-2 text-right font-bold ${tableBorderClass}`}
                              style={{ textAlign: "right", border: '1px solid #000000' }}
                            >
                              Jumlah Alokasi Waktu Kelas {group.kelas} Semester {group.semester}
                            </td>
                            <td
                              className={`border px-2.5 py-2 text-center font-bold ${tableBorderClass}`}
                              style={{ textAlign: "center", border: '1px solid #000000' }}
                            >
                              {group.totalPertemuanSemester} Pertemuan ({group.totalJpSemester} JP)
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>

              {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* TAB 2: ALUR TUJUAN PEMBELAJARAN (ATP)      */}
        {/* ========================================== */}
        {activeTab === "atp" && isTabEnabled("atp") && (
          <div className="space-y-6">
            {/* Toolbar ATP */}
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print text-slate-800">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider mr-2">Pilih Fase:</span>
                {["Semua", "A", "B", "C"].map((f) => (
                  <button
                    key={f}
                    onClick={() => setSelectedFaseAtp(f)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      selectedFaseAtp === f
                        ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                        : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                    }`}
                  >
                    {f === "Semua" ? "Semua Fase (A, B, C)" : `Fase ${f}`}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  onClick={() => setIsEditingAtp(!isEditingAtp)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    isEditingAtp
                      ? "bg-amber-400 text-slate-950 border-amber-500 font-bold"
                      : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                  }`}
                >
                  <Edit3 className="w-4 h-4 text-amber-700" />
                  <span>{isEditingAtp ? "Tutup Editor" : "Edit Dokumen"}</span>
                </button>

                <button
                  onClick={handleSaveAtp}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Perubahan</span>
                </button>

                <button
                  onClick={() => handleDownloadWord("printable-area", `ATP_PAI_BP_Fase_${selectedFaseAtp}_${identitas.sekolah.replace(/\s+/g, "_")}`, false)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-700" />
                  <span>Unduh ATP Portrait (.doc)</span>
                </button>
                <button
                  onClick={() => handleDownloadWord("printable-area", `ATP_PAI_BP_Landscape_Fase_${selectedFaseAtp}_${identitas.sekolah.replace(/\s+/g, "_")}`, true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-700" />
                  <span>Unduh ATP Landscape (.doc)</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-slate-950" />
                  <span>Simpan PDF (A4)</span>
                </button>
              </div>
            </div>

            {/* Dokumen ATP */}
            <div
              id="printable-area"
              style={
                paperLightMode
                  ? { padding: "2.5cm 2.5cm 2.5cm 3.2cm" }
                  : undefined
              }
              className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 ${docContainerClass} ${
                previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
              }`}
            >
              {/* KOP SURAT RESMI */}
              {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

              <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  ALUR TUJUAN PEMBELAJARAN (ATP)
                </h2>
                <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                </h3>
              </div>

              {/* Identitas Dokumen (Tanpa Tabel / Kotak, Susun Rapi Tanpa Spasi Berlebih) */}
              <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-md keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Sekolah</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">{identitas.sekolah}</span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">{identitas.tahunAjaran}</span>
                </div>
              </div>

              <div className="space-y-8">
                {atpList.filter((d) => selectedFaseAtp === "Semua" || d.fase === selectedFaseAtp).map((faseData) => (
                  <div key={faseData.fase} className="space-y-3">
                    <h4 className={`doc-section-heading font-bold px-4 py-2 rounded-xl flex items-center justify-between ${
                      paperLightMode
                        ? "bg-slate-100 border border-black text-black rounded-none"
                        : "bg-gradient-to-r from-emerald-800 to-teal-900 text-white border border-emerald-600/30"
                    }`}>
                      <span>FASE {faseData.fase} ({faseData.kelas})</span>
                      <span className="text-xs font-normal no-print opacity-80">Kurikulum Merdeka</span>
                    </h4>

                    <table className={`w-full border-collapse border ${tableBorderClass}`}>
                      <thead>
                        <tr className={tableHeaderBgClass}>
                          <th className={`border px-4 py-2.5 text-center font-bold w-1/5 ${tableBorderClass}`}>Elemen</th>
                          <th className={`border px-4 py-2.5 text-center font-bold w-2/5 ${tableBorderClass}`}>Capaian Pembelajaran (CP)</th>
                          <th className={`border px-4 py-2.5 text-center font-bold w-2/5 ${tableBorderClass}`}>Alur Tujuan Pembelajaran (ATP)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {faseData.elemen.map((el, idx) => (
                          <tr key={idx}>
                            <td className={`border px-4 py-2.5 font-bold align-top text-left ${tableBorderClass} text-black`}>
                              {el.nama}
                            </td>
                            <td className={`border px-4 py-2.5 align-top text-justify ${tableBorderClass}`}>
                              {el.cp}
                            </td>
                            <td className={`border px-4 py-2.5 align-top text-justify ${tableBorderClass}`}>
                              <ol className="list-decimal pl-5 space-y-1.5 text-justify">
                                {el.atp.map((item, i) => (
                                  <li key={i} className="text-justify">{item}</li>
                                ))}
                              </ol>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ))}
              </div>

              {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================= */}
        {/* TAB 4: PROGRAM TAHUNAN (PROTA)                          */}
        {/* ======================================================= */}
        {activeTab === "prota" && isTabEnabled("prota") && (
          <div className="space-y-6">
            {/* Toolbar Filter & Ekspor PROTA */}
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
                    <CalendarRange className="w-5 h-5 text-emerald-700" />
                    <span>Administrasi Program Tahunan (PROTA) PAI &amp; BP</span>
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Distribusi alokasi waktu satu tahun pelajaran (Semester I Ganjil &amp; Semester II Genap) berdasarkan 78 Modul Ajar dan ATP Kurikulum Merdeka.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsEditingProta(!isEditingProta)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isEditingProta
                        ? "bg-amber-400 text-slate-950 border-amber-500"
                        : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>{isEditingProta ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSaveProta}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `PROTA_PAI_BP_Kelas_${protaKelas}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                        false
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh PROTA Word (.doc)</span>
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-950" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Filter Kelas PROTA */}
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Selector Pilihan 3 JP / 4 JP */}
                  <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-300 p-1 rounded-xl mr-2">
                    <span className="text-xs font-bold text-emerald-950 px-2">Alokasi:</span>
                    {([3, 4] as const).map((jp) => (
                      <button
                        key={jp}
                        type="button"
                        onClick={() => handleSetAlokasiJp(jp)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          alokasiJpDefault === jp
                            ? "bg-[#065f46] text-white shadow-xs"
                            : "text-emerald-900 hover:bg-emerald-200/70"
                        }`}
                      >
                        {jp} JP / Minggu
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 mr-2">
                    <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Format Semester:</span>
                    <button
                      type="button"
                      onClick={() => setProtaMergeSemester(!protaMergeSemester)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                        !protaMergeSemester
                          ? "bg-emerald-100 text-emerald-900 border-emerald-300 shadow-xs"
                          : "bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200"
                      }`}
                      title="Ubah format penggabungan kolom semester"
                    >
                      <Check className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{!protaMergeSemester ? "Tiap Baris (Garis Utuh)" : "Merger Kolom"}</span>
                    </button>
                  </div>
                  <span className="text-xs font-bold text-slate-600 uppercase tracking-wider mr-1">Pilih Kelas:</span>
                  {["I", "II", "III", "IV", "V", "VI", "Semua"].map((kls) => (
                    <button
                      key={kls}
                      onClick={() => setProtaKelas(kls)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        protaKelas === kls
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      {kls === "Semua" ? "Semua Kelas (I–VI)" : `Kelas ${kls}`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* LEMBAR DOKUMEN PROTA - 1 SEMESTER = 1 LEMBAR (A4 RESMI) */}
            <div
              id="printable-area"
              style={paperLightMode ? { padding: "1.5cm 2.0cm 2.0cm 2.5cm" } : undefined}
              className={`rounded-2xl border p-4 sm:p-8 transition-colors duration-300 ${docContainerClass} ${
                previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
              }`}
            >
              <div className="space-y-12">
                {protaData.map((dataKls, klsIdx) => (
                  <div key={dataKls.kelas} className="space-y-10">
                    
                    {/* ======================================================== */}
                    {/* LEMBAR 1: PROGRAM TAHUNAN - SEMESTER I (GANJIL)        */}
                    {/* ======================================================== */}
                    <div className="prota-sheet prota-sheet-sem1 keep-together">
                      {/* KOP SURAT RESMI (jika aktif) */}
                      {useKopSurat && kopSuratUrl && (
                        <div className="kop-surat-header mb-3 text-center">
                          <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-20 w-full object-contain mx-auto" />
                          <div className="kop-surat-divider border-t-2 border-black mt-1.5 mb-3"></div>
                        </div>
                      )}

                      <div className={`doc-header-box text-center border-b-2 pb-2 mb-3.5 border-black`}>
                        <h2 className="doc-main-title text-base sm:text-[14pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                          PROGRAM TAHUNAN (PROTA) KURIKULUM MERDEKA
                        </h2>
                        <h3 className={`doc-sub-title text-xs sm:text-[12pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                          MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                        </h3>
                        <p className="text-[11pt] font-bold text-center mt-0.5 uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                          SEMESTER I (GANJIL) • TAHUN AJARAN {identitas.tahunAjaran}
                        </p>
                      </div>

                      {/* Identitas Dokumen Semester I */}
                      <div className="identitas-block mb-3 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val font-bold">{identitas.sekolah}</span>
                        </div>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Mata Pelajaran</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val">Pendidikan Agama Islam dan Budi Pekerti</span>
                        </div>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Kelas / Fase / Semester</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val font-bold">Kelas {dataKls.kelas} / Fase {dataKls.fase} / Semester I (Ganjil)</span>
                        </div>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val">{identitas.tahunAjaran}</span>
                        </div>
                      </div>

                      {/* TABEL SEMESTER I (GANJIL) - GARIS UTUH ANTI-TERPUTUS */}
                      <table className={`w-full border-collapse border ${tableBorderClass} text-xs sm:text-[11pt]`} style={{ borderCollapse: 'collapse', width: '100%', border: '1px solid #000000' }}>
                        <thead>
                          <tr className={tableHeaderBgClass} style={{ backgroundColor: '#f1f5f9' }}>
                            <th className={`border px-2 py-1.5 text-center font-bold w-10 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>No</th>
                            <th className={`border px-2.5 py-1.5 text-center font-bold w-24 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>Semester</th>
                            <th className={`border px-2.5 py-1.5 text-center font-bold w-24 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>Kode Modul</th>
                            <th className={`border px-3 py-1.5 text-center font-bold w-32 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>Elemen PAI</th>
                            <th className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                              Tujuan Pembelajaran (TP) & Lingkup Materi
                            </th>
                            <th className={`border px-2.5 py-1.5 text-center font-bold w-24 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                              Alokasi
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {dataKls.sem1Mods.map((m, idx) => (
                            <tr key={m.id} style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                              <td className={`border px-2 py-1 text-center font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                                {idx + 1}
                              </td>
                              {protaMergeSemester ? (
                                idx === 0 && (
                                  <td
                                    rowSpan={dataKls.sem1Mods.length}
                                    className={`border px-2 py-1 text-center font-bold align-middle ${tableBorderClass}`}
                                    style={{ textAlign: "center", verticalAlign: "middle", border: '1px solid #000000' }}
                                  >
                                    I (Ganjil)
                                  </td>
                                )
                              ) : (
                                <td className={`border px-2 py-1 text-center font-medium align-middle ${tableBorderClass}`} style={{ textAlign: "center", border: '1px solid #000000' }}>
                                  I (Ganjil)
                                </td>
                              )}
                              <td className={`border px-2 py-1 text-center align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                                Modul Ajar {m.nomor}
                              </td>
                              <td className={`border px-2.5 py-1 font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                                {m.elemen}
                              </td>
                              <td className={`border px-3 py-1 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                                <div className="font-bold text-[10pt] leading-tight mb-0.5">{formatTextSapaan(m.tp)}</div>
                                <div className="text-[9pt] leading-snug text-slate-700 dark:text-slate-300">
                                  <span className="font-semibold text-slate-900 dark:text-slate-100">Lingkup Materi: </span>
                                  {m.pertemuan.map((p) => p.judul).join(" • ")}
                                </div>
                              </td>
                              <td className={`border px-2 py-1 text-center font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                                <div className="text-[10pt]">{m.totalJp} JP</div>
                                <div className="text-[8.5pt] font-normal text-slate-600 dark:text-slate-400">({m.jmlPertemuan} x {alokasiJpDefault} JP)</div>
                              </td>
                            </tr>
                          ))}
                          {/* Subtotal Semester I */}
                          <tr className={tableLabelBgClass} style={{ backgroundColor: '#f8fafc', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                            <td colSpan={5} className={`border px-3 py-1.5 text-right font-bold ${tableBorderClass}`} style={{ textAlign: "right", border: '1px solid #000000' }}>
                              Jumlah Jam Pelajaran Semester I (Ganjil)
                            </td>
                            <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ textAlign: "center", border: '1px solid #000000' }}>
                              {dataKls.totalJpSem1} JP ({dataKls.totalPertSem1} Pert.)
                            </td>
                          </tr>
                        </tbody>
                      </table>

                      {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
                    </div>

                    {/* PEMISAH HALAMAN RESMI (Page Break Antara Semester I & Semester II) */}
                    <div className="page-break" style={{ pageBreakBefore: "always", breakBefore: "page", height: "1px", margin: "16px 0", clear: "both" }}></div>

                    {/* ======================================================== */}
                    {/* LEMBAR 2: PROGRAM TAHUNAN - SEMESTER II (GENAP)         */}
                    {/* ======================================================== */}
                    <div className="prota-sheet prota-sheet-sem2 keep-together">
                      {/* KOP SURAT RESMI (jika aktif) */}
                      {useKopSurat && kopSuratUrl && (
                        <div className="kop-surat-header mb-3 text-center">
                          <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-20 w-full object-contain mx-auto" />
                          <div className="kop-surat-divider border-t-2 border-black mt-1.5 mb-3"></div>
                        </div>
                      )}

                      <div className={`doc-header-box text-center border-b-2 pb-2 mb-3.5 border-black`}>
                        <h2 className="doc-main-title text-base sm:text-[14pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                          PROGRAM TAHUNAN (PROTA) KURIKULUM MERDEKA
                        </h2>
                        <h3 className={`doc-sub-title text-xs sm:text-[12pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                          MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                        </h3>
                        <p className="text-[11pt] font-bold text-center mt-0.5 uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                          SEMESTER II (GENAP) • TAHUN AJARAN {identitas.tahunAjaran}
                        </p>
                      </div>

                      {/* Identitas Dokumen Semester II */}
                      <div className="identitas-block mb-3 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val font-bold">{identitas.sekolah}</span>
                        </div>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Mata Pelajaran</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val">Pendidikan Agama Islam dan Budi Pekerti</span>
                        </div>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Kelas / Fase / Semester</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val font-bold">Kelas {dataKls.kelas} / Fase {dataKls.fase} / Semester II (Genap)</span>
                        </div>
                        <div className="identitas-row flex items-baseline">
                          <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                          <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                          <span className="identitas-val">{identitas.tahunAjaran}</span>
                        </div>
                      </div>

                      {/* TABEL SEMESTER II (GENAP) - GARIS UTUH ANTI-TERPUTUS */}
                      <table className={`w-full border-collapse border ${tableBorderClass} text-xs sm:text-[11pt]`} style={{ borderCollapse: 'collapse', width: '100%', border: '1px solid #000000' }}>
                        <thead>
                          <tr className={tableHeaderBgClass} style={{ backgroundColor: '#f1f5f9' }}>
                            <th className={`border px-2 py-1.5 text-center font-bold w-10 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>No</th>
                            <th className={`border px-2.5 py-1.5 text-center font-bold w-24 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>Semester</th>
                            <th className={`border px-2.5 py-1.5 text-center font-bold w-24 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>Kode Modul</th>
                            <th className={`border px-3 py-1.5 text-center font-bold w-32 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>Elemen PAI</th>
                            <th className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                              Tujuan Pembelajaran (TP) & Lingkup Materi
                            </th>
                            <th className={`border px-2.5 py-1.5 text-center font-bold w-24 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                              Alokasi
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {dataKls.sem2Mods.map((m, idx) => (
                            <tr key={m.id} style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                              <td className={`border px-2 py-1 text-center font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                                {idx + 1}
                              </td>
                              {protaMergeSemester ? (
                                idx === 0 && (
                                  <td
                                    rowSpan={dataKls.sem2Mods.length}
                                    className={`border px-2 py-1 text-center font-bold align-middle ${tableBorderClass}`}
                                    style={{ textAlign: "center", verticalAlign: "middle", border: '1px solid #000000' }}
                                  >
                                    II (Genap)
                                  </td>
                                )
                              ) : (
                                <td className={`border px-2 py-1 text-center font-medium align-middle ${tableBorderClass}`} style={{ textAlign: "center", border: '1px solid #000000' }}>
                                  II (Genap)
                                </td>
                              )}
                              <td className={`border px-2 py-1 text-center align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                                Modul Ajar {m.nomor}
                              </td>
                              <td className={`border px-2.5 py-1 font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                                {m.elemen}
                              </td>
                              <td className={`border px-3 py-1 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                                <div className="font-bold text-[10pt] leading-tight mb-0.5">{formatTextSapaan(m.tp)}</div>
                                <div className="text-[9pt] leading-snug text-slate-700 dark:text-slate-300">
                                  <span className="font-semibold text-slate-900 dark:text-slate-100">Lingkup Materi: </span>
                                  {m.pertemuan.map((p) => p.judul).join(" • ")}
                                </div>
                              </td>
                              <td className={`border px-2 py-1 text-center font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                                <div className="text-[10pt]">{m.totalJp} JP</div>
                                <div className="text-[8.5pt] font-normal text-slate-600 dark:text-slate-400">({m.jmlPertemuan} x {alokasiJpDefault} JP)</div>
                              </td>
                            </tr>
                          ))}
                          {/* Subtotal Semester II */}
                          <tr className={tableLabelBgClass} style={{ backgroundColor: '#f8fafc', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                            <td colSpan={5} className={`border px-3 py-1.5 text-right font-bold ${tableBorderClass}`} style={{ textAlign: "right", border: '1px solid #000000' }}>
                              Jumlah Jam Pelajaran Semester II (Genap)
                            </td>
                            <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ textAlign: "center", border: '1px solid #000000' }}>
                              {dataKls.totalJpSem2} JP ({dataKls.totalPertSem2} Pert.)
                            </td>
                          </tr>
                          {/* Cadangan / Asesmen Sumatif */}
                          <tr style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                            <td colSpan={5} className={`border px-3 py-1 text-right font-semibold ${tableBorderClass}`} style={{ textAlign: "right", border: '1px solid #000000' }}>
                              Asesmen Sumatif Tengah Semester (STS), Sumatif Akhir Semester (SAS), & Cadangan
                            </td>
                            <td className={`border px-2 py-1 text-center font-semibold ${tableBorderClass}`} style={{ textAlign: "center", border: '1px solid #000000' }}>
                              Terintegrasi
                            </td>
                          </tr>
                          {/* TOTAL 1 TAHUN */}
                          <tr className={tableHeaderBgClass} style={{ backgroundColor: '#e2e8f0', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                            <td colSpan={5} className={`border px-3 py-1.5 text-right font-bold uppercase ${tableBorderClass}`} style={{ textAlign: "right", border: '1px solid #000000' }}>
                              Total Alokasi Waktu 1 Tahun Pelajaran (Kelas {dataKls.kelas})
                            </td>
                            <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ textAlign: "center", border: '1px solid #000000' }}>
                              {dataKls.totalJpTahun} JP ({dataKls.totalPertTahun} Pert.)
                            </td>
                          </tr>
                        </tbody>
                      </table>

                      {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
                    </div>

                    {/* Pemisah Halaman Jika Memilih Semua Kelas */}
                    {klsIdx < protaData.length - 1 && (
                      <div className="page-break" style={{ pageBreakBefore: "always", breakBefore: "page", height: "1px", margin: "16px 0", clear: "both" }}></div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "promes" && isTabEnabled("promes") && (
          <div className="space-y-6">
            {/* Toolbar Filter & Ekspor PROMES */}
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
                    <CalendarDays className="w-5 h-5 text-emerald-700" />
                    <span>Administrasi Program Semester (PROMES) PAI &amp; BP</span>
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Matriks penjadwalan mingguan (Juli–Desember untuk Ganjil &amp; Januari–Juni untuk Genap) lengkap per pertemuan dan alokasi JP.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsEditingPromes(!isEditingPromes)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isEditingPromes
                        ? "bg-amber-400 text-slate-950 border-amber-500"
                        : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>{isEditingPromes ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSavePromes}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `PROMES_PAI_BP_Kelas_${promesKelas}_Sem_${promesSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                        true
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh PROMES Landscape (.doc)</span>
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-950" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Filter Kelas & Semester PROMES */}
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Selector Pilihan 3 JP / 4 JP */}
                  <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-300 p-1 rounded-xl mr-1">
                    <span className="text-xs font-bold text-emerald-950 px-2">Alokasi:</span>
                    {([3, 4] as const).map((jp) => (
                      <button
                        key={jp}
                        type="button"
                        onClick={() => handleSetAlokasiJp(jp)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          alokasiJpDefault === jp
                            ? "bg-[#065f46] text-white shadow-xs"
                            : "text-emerald-900 hover:bg-emerald-200/70"
                        }`}
                      >
                        {jp} JP / Pert.
                      </button>
                    ))}
                  </div>

                  <span className="text-xs font-bold text-slate-600 uppercase tracking-wider mr-1">Kelas:</span>
                  {["I", "II", "III", "IV", "V", "VI"].map((kls) => (
                    <button
                      key={kls}
                      onClick={() => setPromesKelas(kls)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        promesKelas === kls
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      Kelas {kls}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-slate-600 uppercase tracking-wider mr-1">Semester:</span>
                  {["I (Ganjil)", "II (Genap)"].map((sem) => (
                    <button
                      key={sem}
                      onClick={() => setPromesSemester(sem)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        promesSemester === sem
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      Semester {sem}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* LEMBAR DOKUMEN PROMES */}
            <div
              id="printable-area"
              style={paperLightMode ? { padding: "2cm 2cm 2cm 2.5cm" } : undefined}
              className={`rounded-2xl border p-6 sm:p-8 transition-colors duration-300 overflow-x-auto ${docContainerClass} ${
                previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
              }`}
            >
              {/* KOP SURAT RESMI */}
              {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

              <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  PROGRAM SEMESTER (PROMES) KURIKULUM MERDEKA
                </h2>
                <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                </h3>
              </div>

              {/* Identitas Dokumen (Tanpa Tabel / Kotak, Susun Rapi Tanpa Spasi Berlebih) */}
              <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">{identitas.sekolah}</span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Kelas / Fase / Semester</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">
                    Kelas {promesData.kelas} / Fase {promesData.fase} / Semester {promesData.semester}
                  </span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">{identitas.tahunAjaran}</span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className={`w-full border-collapse border text-xs ${tableBorderClass}`}>
                  <thead>
                    <tr className={tableHeaderBgClass}>
                      <th rowSpan={2} className={`border px-2 py-2 text-center font-bold w-8 ${tableBorderClass}`}>No</th>
                      <th rowSpan={2} className={`border px-2.5 py-2 text-center font-bold w-28 ${tableBorderClass}`}>Elemen</th>
                      <th rowSpan={2} className={`border px-3 py-2 text-center font-bold min-w-[220px] ${tableBorderClass}`}>
                        Tujuan Pembelajaran (TP) & Rincian Pertemuan
                      </th>
                      <th rowSpan={2} className={`border px-2 py-2 text-center font-bold w-12 ${tableBorderClass}`}>JP</th>
                      {promesData.bulanList.map((bln) => (
                        <th key={bln} colSpan={4} className={`border px-1 py-1.5 text-center font-bold ${tableBorderClass}`}>
                          {bln}
                        </th>
                      ))}
                    </tr>
                    <tr className={tableHeaderBgClass}>
                      {promesData.bulanList.map((bln) =>
                        [1, 2, 3, 4].map((mg) => (
                          <th key={`${bln}-${mg}`} className={`border px-1 py-1 text-center font-bold w-6 ${tableBorderClass}`}>
                            {mg}
                          </th>
                        ))
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {promesData.rows.map((mod, mIdx) => (
                      <React.Fragment key={mod.id}>
                        {/* Baris Induk Modul / TP */}
                        <tr className={tableLabelBgClass}>
                          <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>{mIdx + 1}</td>
                          <td className={`border px-2.5 py-1.5 font-bold ${tableBorderClass}`}>
                            {mod.elemen}
                            <div className="text-[10px] font-normal">Modul {mod.nomor}</div>
                          </td>
                          <td className={`border px-3 py-1.5 font-bold text-justify ${tableBorderClass}`}>
                            {formatTextSapaan(mod.tp)}
                          </td>
                          <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>
                            {mod.totalJp}
                          </td>
                          {Array.from({ length: 24 }).map((_, wIdx) => (
                            <td key={wIdx} className={`border px-1 py-1 text-center ${tableBorderClass}`}></td>
                          ))}
                        </tr>

                        {/* Baris Rincian Pertemuan & Jadwal Minggu */}
                        {mod.pertemuanScheduled.map((pert, pIdx) => (
                          <tr key={`${mod.id}-p-${pIdx}`}>
                            <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`}></td>
                            <td className={`border px-2.5 py-1.5 text-center text-[11px] ${tableBorderClass}`}>
                              Pert. {pert.pertKe}
                            </td>
                            <td className={`border px-3 py-1.5 text-justify ${tableBorderClass}`}>
                              {pert.judul}
                            </td>
                            <td className={`border px-2 py-1.5 text-center font-semibold ${tableBorderClass}`}>
                              {pert.jp || alokasiJpDefault} JP
                            </td>
                            {Array.from({ length: 24 }).map((_, wIdx) => {
                              const currentWeek = wIdx + 1;
                              const isScheduled = pert.weekIndex === currentWeek;
                              return (
                                <td
                                  key={wIdx}
                                  className={`border px-1 py-1 text-center font-bold ${tableBorderClass} ${
                                    isScheduled
                                      ? paperLightMode
                                        ? "bg-slate-200 text-black"
                                        : "bg-emerald-500/30 text-emerald-200"
                                      : ""
                                  }`}
                                  style={
                                    isScheduled
                                      ? { textAlign: "center", backgroundColor: paperLightMode ? "#e2e8f0" : undefined }
                                      : { textAlign: "center" }
                                  }
                                >
                                  {isScheduled ? String(pert.jp || alokasiJpDefault) : ""}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </React.Fragment>
                    ))}

                    {/* Baris Kegiatan Tengah Semester & Akhir Semester */}
                    <tr>
                      <td colSpan={3} className={`border px-3 py-2 font-bold text-right ${tableBorderClass}`} style={{ textAlign: "right" }}>
                        Sumatif Tengah Semester (STS) & Sumatif Akhir Semester (SAS)
                      </td>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>-</td>
                      {Array.from({ length: 24 }).map((_, wIdx) => {
                        const wk = wIdx + 1;
                        const label = wk === 11 ? "STS" : wk === 23 ? "SAS" : wk === 24 ? "RPT" : "";
                        return (
                          <td
                            key={wIdx}
                            className={`border px-0.5 py-1 text-center text-[10px] font-bold ${tableBorderClass}`}
                            style={{ textAlign: "center" }}
                          >
                            {label}
                          </td>
                        );
                      })}
                    </tr>

                    {/* Total JP Semester */}
                    <tr className={tableHeaderBgClass}>
                      <td colSpan={3} className={`border px-3 py-2 font-bold text-right uppercase ${tableBorderClass}`} style={{ textAlign: "right" }}>
                        Jumlah Jam Pelajaran Efektif Semester {promesData.semester}
                      </td>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`} style={{ textAlign: "center" }}>
                        {promesData.totalJp} JP
                      </td>
                      <td colSpan={24} className={`border px-3 py-2 text-left font-bold ${tableBorderClass}`}>
                        Total: {promesData.rows.length} Modul Ajar ({promesData.totalPertemuan} Pertemuan Tatap Muka × 3 JP = {promesData.totalJp} JP)
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================= */}
        {/* TAB 10: JURNAL MENGAJAR HARIAN (TERINTEGRASI MODUL & PROMES) */}
        {/* ======================================================= */}
        {activeTab === "jurnal-mengajar" && isTabEnabled("jurnal-mengajar") && (
          <TabJurnalMengajar
            modules={modules}
            identitas={identitas}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
            setActiveTab={safeSetActiveTab}
            setSelectedKelas={setSelectedKelas}
            setSelectedSemester={setSelectedSemester}
            setActiveModulId={setActiveModulId}
            daftarKelas={daftarKelas}
            setDaftarKelas={setDaftarKelas}
            jadwalMengajar={jadwalMengajar}
            setJadwalMengajar={setJadwalMengajar}
            alokasiJpDefault={alokasiJpDefault}
            setAlokasiJpDefault={handleSetAlokasiJp}
          />
        )}

        {/* ======================================================= */}
        {/* TAB 12: BUKU ABSENSI & PRESENSI SISWA MINGGUAN PAI     */}
        {/* ======================================================= */}
        {activeTab === "absensi" && isTabEnabled("absensi") && (
          <TabAbsensiSiswa
            modules={modules}
            identitas={identitas}
            daftarKelas={daftarKelas}
            jadwalMengajar={jadwalMengajar}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
            setActiveTab={safeSetActiveTab}
          />
        )}

        {/* ======================================================= */}
        {/* TAB 13: BUKU PENILAIAN & REKAPITULASI NILAI ASESMEN    */}
        {/* ======================================================= */}
        {activeTab === "penilaian" && isTabEnabled("penilaian") && (
          <TabPenilaian
            modules={modules}
            identitas={identitas}
            daftarKelas={daftarKelas}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
          />
        )}

        {/* ======================================================= */}
        {/* TAB 14: UPLOAD & KELOLA DATA SISWA DENGAN EXCEL         */}
        {/* ======================================================= */}
        {activeTab === "upload-siswa" && isTabEnabled("upload-siswa") && (
          <TabUploadSiswa
            daftarKelas={daftarKelas}
            showToast={showToast}
            setActiveTab={safeSetActiveTab}
          />
        )}

        {/* ======================================================= */}
        {/* TAB 15: KRITERIA KETERCAPAIAN TUJUAN PEMBELAJARAN (KKTP) */}
        {/* ======================================================= */}
        {activeTab === "kktp" && isTabEnabled("kktp") && (
          <div className="space-y-6">
            {/* Toolbar Filter & Ekspor KKTP */}
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
                    <Award className="w-5 h-5 text-emerald-700" />
                    <span>Kriteria Ketercapaian Tujuan Pembelajaran (KKTP) PAI &amp; BP</span>
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Penetapan indikator ketercapaian TP dengan pendekatan Interval Nilai dan Rubrik Ketercapaian (Baru Berkembang, Layak, Cakap, Mahir) sesuai Panduan Pembelajaran dan Asesmen Kurikulum Merdeka.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsEditingKktp(!isEditingKktp)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isEditingKktp
                        ? "bg-amber-400 text-slate-950 border-amber-500"
                        : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>{isEditingKktp ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSaveKktp}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `KKTP_PAI_BP_Kelas_${kktpKelas}_Sem_${kktpSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                        true
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh KKTP Landscape (.doc)</span>
                  </button>
                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `KKTP_Portrait_PAI_BP_Kelas_${kktpKelas}_Sem_${kktpSemester.split(" ")[0]}`,
                        false
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh KKTP Portrait (.doc)</span>
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-950" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Filter Kelas, Semester & Model Pendekatan KKTP */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Pilih Kelas
                  </label>
                  <div className="grid grid-cols-6 gap-1.5">
                    {["I", "II", "III", "IV", "V", "VI"].map((kls) => (
                      <button
                        key={kls}
                        onClick={() => setKktpKelas(kls)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          kktpKelas === kls
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {kls}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Pilih Semester
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {["I (Ganjil)", "II (Genap)", "Semua"].map((sem) => (
                      <button
                        key={sem}
                        onClick={() => setKktpSemester(sem)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          kktpSemester === sem
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {sem === "Semua" ? "1 Tahun" : sem}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Format Tampilan KKTP
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: "interval", label: "Interval Nilai & Indikator" },
                      { id: "rubrik", label: "Rubrik 4 Kriteria Lengkap" }
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setKktpModel(m.id)}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          kktpModel === m.id
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Panel Editor KKTP */}
            {isEditingKktp && (
              <div className="bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shadow-md no-print text-slate-800">
                <div className="flex items-center justify-between border-b border-amber-200 pb-3">
                  <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2">
                    <Edit3 className="w-4 h-4 text-amber-600" />
                    <span>Editor Kriteria Ketercapaian Tujuan Pembelajaran (KKTP)</span>
                  </h3>
                  <button
                    onClick={handleSaveKktp}
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Simpan Perubahan KKTP</span>
                  </button>
                </div>
                <div className="space-y-3">
                  <p className="text-xs text-slate-600 font-medium">
                    Sesuaikan rentang interval nilai dan tindak lanjut asesmen ketuntasan pembelajaran:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl space-y-1.5">
                      <span className="text-xs font-bold text-rose-800">Perlu Bimbingan</span>
                      <input
                        type="text"
                        value={kktpIntervals.perluBimbingan}
                        onChange={(e) => setKktpIntervals({ ...kktpIntervals, perluBimbingan: e.target.value })}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-rose-300 text-slate-900 font-mono font-bold"
                      />
                    </div>
                    <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl space-y-1.5">
                      <span className="text-xs font-bold text-amber-800">Cukup (Mencapai KKTP)</span>
                      <input
                        type="text"
                        value={kktpIntervals.cukup}
                        onChange={(e) => setKktpIntervals({ ...kktpIntervals, cukup: e.target.value })}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-amber-300 text-slate-900 font-mono font-bold"
                      />
                    </div>
                    <div className="p-3 bg-teal-50 border border-teal-300 rounded-xl space-y-1.5">
                      <span className="text-xs font-bold text-teal-800">Baik</span>
                      <input
                        type="text"
                        value={kktpIntervals.baik}
                        onChange={(e) => setKktpIntervals({ ...kktpIntervals, baik: e.target.value })}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-teal-300 text-slate-900 font-mono font-bold"
                      />
                    </div>
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl space-y-1.5">
                      <span className="text-xs font-bold text-emerald-800">Sangat Baik</span>
                      <input
                        type="text"
                        value={kktpIntervals.sangatBaik}
                        onChange={(e) => setKktpIntervals({ ...kktpIntervals, sangatBaik: e.target.value })}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-emerald-300 text-slate-900 font-mono font-bold"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-700 font-semibold block mb-1">Pedoman Tindak Lanjut Asesmen:</label>
                    <textarea
                      rows={2}
                      value={kktpIntervals.tindakLanjut}
                      onChange={(e) => setKktpIntervals({ ...kktpIntervals, tindakLanjut: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 focus:ring-1 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* LEMBAR DOKUMEN KKTP */}
            <div
              id="printable-area"
              style={paperLightMode ? { padding: "2.5cm 2.5cm 2.5cm 3.2cm" } : undefined}
              className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 ${docContainerClass} ${
                previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
              }`}
            >
              {/* KOP SURAT RESMI */}
              {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

              <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  KRITERIA KETERCAPAIAN TUJUAN PEMBELAJARAN (KKTP)
                </h2>
                <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                </h3>
              </div>

              {/* Identitas Dokumen (Tanpa Tabel / Kotak, Susun Rapi Tanpa Spasi Berlebih) */}
              <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">{identitas.sekolah}</span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Kelas / Fase / Semester</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">
                    Kelas {kktpData.kelas} / Fase {kktpData.fase} /{" "}
                    {kktpData.semester === "Semua" ? "Semester I & II" : `Semester ${kktpData.semester}`}
                  </span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">{identitas.tahunAjaran}</span>
                </div>
              </div>

              {/* Tabel KKTP Utama */}
              <div className="overflow-x-auto mb-6">
                {kktpModel === "interval" ? (
                  <table className={`w-full border-collapse border ${tableBorderClass}`}>
                    <thead>
                      <tr className={tableHeaderBgClass}>
                        <th rowSpan={2} className={`border px-2.5 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                        <th rowSpan={2} className={`border px-3 py-2 text-center font-bold w-32 ${tableBorderClass}`}>Elemen & Modul</th>
                        <th rowSpan={2} className={`border px-3 py-2 text-center font-bold w-48 ${tableBorderClass}`}>
                          Tujuan Pembelajaran (TP)
                        </th>
                        <th rowSpan={2} className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                          Indikator Ketercapaian Tujuan Pembelajaran (IKTP)
                        </th>
                        <th colSpan={4} className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>
                          Interval Nilai & Kriteria Ketercapaian
                        </th>
                        <th rowSpan={2} className={`border px-3 py-2 text-center font-bold w-36 ${tableBorderClass}`}>
                          Teknik Asesmen & Tindak Lanjut
                        </th>
                      </tr>
                      <tr className={tableHeaderBgClass}>
                        <th className={`border px-2 py-1.5 text-center font-bold w-20 ${tableBorderClass}`}>
                          0 – 40%<br />
                          <span className="text-[10px] font-normal">(Baru Berkembang)</span>
                        </th>
                        <th className={`border px-2 py-1.5 text-center font-bold w-20 ${tableBorderClass}`}>
                          41 – 65%<br />
                          <span className="text-[10px] font-normal">(Layak)</span>
                        </th>
                        <th className={`border px-2 py-1.5 text-center font-bold w-20 ${tableBorderClass}`}>
                          66 – 85%<br />
                          <span className="text-[10px] font-normal">(Cakap / Tuntas)</span>
                        </th>
                        <th className={`border px-2 py-1.5 text-center font-bold w-20 ${tableBorderClass}`}>
                          86 – 100%<br />
                          <span className="text-[10px] font-normal">(Mahir)</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {kktpData.items.map((item, idx) => (
                        <tr key={item.id}>
                          <td className={`border px-2.5 py-2 text-center font-bold align-top ${tableBorderClass}`}>
                            {idx + 1}
                          </td>
                          <td className={`border px-3 py-2 align-top font-bold ${tableBorderClass}`}>
                            <div>{item.elemen}</div>
                            <div className="text-xs font-normal mt-0.5">
                              Modul {item.nomor} (Sem {item.semester.split(" ")[0]})
                            </div>
                          </td>
                          <td className={`border px-3 py-2 align-top font-semibold text-justify ${tableBorderClass}`}>
                            {formatTextSapaan(item.tp)}
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                            <ol className="list-decimal pl-4 space-y-1 text-justify">
                              {item.indikatorList.map((ind, iIdx) => (
                                <li key={iIdx} className="text-justify">{formatTextSapaan(ind)}</li>
                              ))}
                            </ol>
                          </td>
                          <td className={`border px-2 py-2 align-top text-center ${tableBorderClass}`}>
                            Belum Mencapai, Remedial di seluruh bagian
                          </td>
                          <td className={`border px-2 py-2 align-top text-center ${tableBorderClass}`}>
                            Belum Mencapai Ketuntasan, Remedial di bagian yang diperlukan
                          </td>
                          <td className={`border px-2 py-2 align-top text-center font-semibold ${tableBorderClass}`}>
                            Sudah Mencapai Ketuntasan, Tidak perlu remedial (75–85)
                          </td>
                          <td className={`border px-2 py-2 align-top text-center font-semibold ${tableBorderClass}`}>
                            Sudah Mencapai Ketuntasan, Diberikan Pengayaan (86–100)
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                            {formatTextSapaan(item.asesmen)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <table className={`w-full border-collapse border ${tableBorderClass}`}>
                    <thead>
                      <tr className={tableHeaderBgClass}>
                        <th className={`border px-2.5 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                        <th className={`border px-3 py-2 text-center font-bold w-36 ${tableBorderClass}`}>
                          Elemen & Tujuan Pembelajaran
                        </th>
                        <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                          Baru Berkembang (0–60)
                        </th>
                        <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                          Layak (61–74)
                        </th>
                        <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                          Cakap / Tuntas (75–88)
                        </th>
                        <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                          Mahir (89–100)
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {kktpData.items.map((item, idx) => (
                        <tr key={item.id}>
                          <td className={`border px-2.5 py-2 text-center font-bold align-top ${tableBorderClass}`}>
                            {idx + 1}
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                            <div className="font-bold">{item.elemen} (Modul {item.nomor})</div>
                            <div className="mt-1">{formatTextSapaan(item.tp)}</div>
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                            {formatTextSapaan(item.rubrik.baruBerkembang)}
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                            {formatTextSapaan(item.rubrik.layak)}
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify font-semibold ${tableBorderClass}`}>
                            {formatTextSapaan(item.rubrik.cakap)}
                          </td>
                          <td className={`border px-3 py-2 align-top text-justify font-semibold ${tableBorderClass}`}>
                            {formatTextSapaan(item.rubrik.mahir)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Pedoman Konversi Interval Nilai KKTP */}
              <div className="mb-8 keep-together">
                <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2 ${sectionBannerClass}`}>
                  Pedoman Interval Nilai dan Tindak Lanjut Ketercapaian TP
                </h4>
                <table className={`w-full border-collapse border ${tableBorderClass}`}>
                  <thead>
                    <tr className={tableHeaderBgClass}>
                      <th className={`border px-3 py-2 text-center font-bold w-36 ${tableBorderClass}`}>Interval Nilai</th>
                      <th className={`border px-3 py-2 text-center font-bold w-44 ${tableBorderClass}`}>Kriteria / Predikat</th>
                      <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>Keterangan & Tindak Lanjut Pembelajaran</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`}>0% – 40%</td>
                      <td className={`border px-3 py-1.5 text-center font-semibold ${tableBorderClass}`}>Baru Berkembang</td>
                      <td className={`border px-3 py-1.5 text-justify ${tableBorderClass}`}>
                        Belum mencapai ketercapaian tujuan pembelajaran, memerlukan bimbingan dan remedial di seluruh bagian indikator.
                      </td>
                    </tr>
                    <tr>
                      <td className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`}>41% – 65%</td>
                      <td className={`border px-3 py-1.5 text-center font-semibold ${tableBorderClass}`}>Layak</td>
                      <td className={`border px-3 py-1.5 text-justify ${tableBorderClass}`}>
                        Belum mencapai ketuntasan penuh, memerlukan remedial/pendampingan pada bagian indikator yang belum dikuasai.
                      </td>
                    </tr>
                    <tr>
                      <td className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`}>66% – 85%</td>
                      <td className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`}>Cakap (Tuntas)</td>
                      <td className={`border px-3 py-1.5 text-justify ${tableBorderClass}`}>
                        Sudah mencapai kriteria ketercapaian tujuan pembelajaran (Tuntas), tidak perlu remedial dan dapat melanjutkan ke materi berikutnya.
                      </td>
                    </tr>
                    <tr>
                      <td className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`}>86% – 100%</td>
                      <td className={`border px-3 py-1.5 text-center font-bold ${tableBorderClass}`}>Mahir (Sangat Baik)</td>
                      <td className={`border px-3 py-1.5 text-justify ${tableBorderClass}`}>
                        Sudah melampaui kriteria ketercapaian tujuan pembelajaran dengan sangat baik, diberikan tantangan pengayaan atau tutor sebaya.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================= */}
        {/* TAB BARU: PROGRAM REMEDIAL DAN PROGRAM PENGAYAAN        */}
        {/* ======================================================= */}
        {activeTab === "remedial-pengayaan" && isTabEnabled("remedial-pengayaan") && (
          <div className="space-y-6">
            {/* Toolbar Filter & Ekspor Program Remedial & Pengayaan */}
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
                    <RefreshCw className="w-5 h-5 text-emerald-700" />
                    <span>Program Pembelajaran Remedial &amp; Program Pengayaan PAI dan BP</span>
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Disusun sesuai <strong>Panduan Pembelajaran dan Asesmen (PPA) Kurikulum Merdeka</strong> (Permendikbudristek No. 21 Tahun 2022) — Pendampingan sesuai kebutuhan belajar &amp; perluasan kompetensi.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsEditingRemedial(!isEditingRemedial)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isEditingRemedial
                        ? "bg-amber-400 text-slate-950 border-amber-500"
                        : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>{isEditingRemedial ? "Tutup Editor" : "Edit Dokumen"}</span>
                  </button>

                  <button
                    onClick={handleSaveRemedial}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `Program_Remedial_Pengayaan_PAI_Kelas_${remKelas}_Sem_${remSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                        true
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh Word Landscape (.doc)</span>
                  </button>
                  <button
                    onClick={() =>
                      handleDownloadWord(
                        "printable-area",
                        `Program_Remedial_Pengayaan_Portrait_PAI_Kelas_${remKelas}`,
                        false
                      )
                    }
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-700" />
                    <span>Unduh Word Portrait (.doc)</span>
                  </button>
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-950" />
                    <span>Simpan PDF (A4)</span>
                  </button>
                </div>
              </div>

              {/* Filter Kelas, Semester & Mode Dokumen */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Pilih Kelas
                  </label>
                  <div className="grid grid-cols-6 gap-1.5">
                    {["I", "II", "III", "IV", "V", "VI"].map((kls) => (
                      <button
                        key={kls}
                        onClick={() => setRemKelas(kls)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          remKelas === kls
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {kls}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Pilih Semester
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {["I (Ganjil)", "II (Genap)", "Semua"].map((sem) => (
                      <button
                        key={sem}
                        onClick={() => setRemSemester(sem)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          remSemester === sem
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                            : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                        }`}
                      >
                        {sem === "Semua" ? "1 Tahun" : sem}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                    Jenis Dokumen Administrasi
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setRemSubTab("program")}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        remSubTab === "program"
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>Naskah Program Lengkap</span>
                    </button>
                    <button
                      onClick={() => setRemSubTab("jurnal")}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        remSubTab === "jurnal"
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      <FileCheck className="w-3.5 h-3.5" />
                      <span>Jurnal &amp; Daftar Nilai</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Panel Input Cepat Jurnal Pelaksanaan (Jika di Subtab Jurnal) */}
              {remSubTab === "jurnal" && (
                <div className="pt-3 border-t border-emerald-200 flex flex-wrap items-center justify-between gap-3">
                  <p className="text-xs text-emerald-900 font-medium">
                    Anda dapat mengedit langsung daftar {identitas.sapaanSiswa.toLowerCase()} penerima layanan Remedial maupun Pengayaan pada tabel di bawah ini sebelum mencetak atau mengunduh Word.
                  </p>
                  <button
                    onClick={handleAddJurnalRow}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah Baris {identitas.sapaanSiswa}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Panel Editor Program Remedial & Pengayaan */}
            {isEditingRemedial && (
              <div className="bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shadow-md no-print text-slate-800">
                <div className="flex items-center justify-between border-b border-amber-200 pb-3">
                  <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2">
                    <Edit3 className="w-4 h-4 text-amber-600" />
                    <span>Editor Program Remedial &amp; Pengayaan (Kelas {remKelas} - {remSemester})</span>
                  </h3>
                  <button
                    onClick={handleSaveRemedial}
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Simpan Perubahan Remedial &amp; Pengayaan</span>
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-rose-800 font-bold block mb-1">Strategi &amp; Bentuk Program Remedial:</label>
                    <textarea
                      rows={3}
                      value={remNotes.strategiRemedial}
                      onChange={(e) => setRemNotes({ ...remNotes, strategiRemedial: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:ring-1 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-emerald-800 font-bold block mb-1">Strategi &amp; Bentuk Program Pengayaan:</label>
                    <textarea
                      rows={3}
                      value={remNotes.strategiPengayaan}
                      onChange={(e) => setRemNotes({ ...remNotes, strategiPengayaan: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 focus:ring-1 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* LEMBAR DOKUMEN RESMI PROGRAM REMEDIAL & PENGAYAAN */}
            <div
              id="printable-area"
              style={paperLightMode ? { padding: "2.5cm 2.5cm 2.5cm 3.2cm" } : undefined}
              className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 ${docContainerClass} ${
                previewOfficialLayout ? "official-doc-typography" : "leading-relaxed"
              }`}
            >
              {/* KOP SURAT RESMI */}
              {useKopSurat && kopSuratUrl && (
                  <div className="kop-surat-header mb-4 text-center">
                    <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                    <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
                  </div>
                )}

              {/* Header Dokumen */}
              <div className={`doc-header-box text-center border-b-2 pb-4 mb-6 border-black`}>
                <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  PROGRAM PEMBELAJARAN REMEDIAL DAN PROGRAM PENGAYAAN
                </h2>
                <h3 className={`doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black`} style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                  MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
                </h3>
              </div>

              {/* Identitas Satuan Pendidikan */}
              {/* Identitas Dokumen (Tanpa Tabel / Kotak, Susun Rapi Tanpa Spasi Berlebih) */}
              <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">{identitas.sekolah}</span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Mata Pelajaran</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">Pendidikan Agama Islam dan Budi Pekerti</span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Kelas / Fase / Semester</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val font-bold">
                    Kelas {remedialPengayaanData.kelas} / Fase {remedialPengayaanData.fase} /{" "}
                    {remedialPengayaanData.semester === "Semua"
                      ? "Semester I (Ganjil) & II (Genap)"
                      : `Semester ${remedialPengayaanData.semester}`}
                  </span>
                </div>
                <div className="identitas-row flex items-baseline">
                  <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran</span>
                  <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                  <span className="identitas-val">{identitas.tahunAjaran}</span>
                </div>
              </div>

              {/* TAMPILAN 1: NASKAH LENGKAP PROGRAM REMEDIAL & PENGAYAAN SESUAI ATURAN KEPENDIDIKAN */}
              {remSubTab === "program" && (
                <div className="space-y-6">
                  {/* A. Landasan Hukum dan Rasional */}
                  <div>
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2 ${sectionBannerClass}`}>
                      A. Dasar Hukum dan Prinsip Pelaksanaan (Sesuai Regulasi Pendidikan)
                    </h4>
                    <p className="text-justify mb-2">
                      Program Pembelajaran Remedial dan Pengayaan ini disusun berlandaskan regulasi resmi Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi serta Kementerian Agama Republik Indonesia, yaitu:
                    </p>
                    <ol className="list-decimal pl-6 space-y-1 text-justify">
                      <li className="text-justify">
                        <strong>Undang-Undang Nomor 20 Tahun 2003</strong> tentang Sistem Pendidikan Nasional (Pasal 12 ayat 1b: Setiap {identitas.sapaanSiswa.toLowerCase()} berhak mendapatkan pelayanan pendidikan sesuai dengan bakat, minat, dan kemampuannya).
                      </li>
                      <li className="text-justify">
                        <strong>Permendikbudristek Nomor 21 Tahun 2022</strong> tentang Standar Penilaian Pendidikan pada Pendidikan Anak Usia Dini, Jenjang Pendidikan Dasar, dan Jenjang Pendidikan Menengah.
                      </li>
                      <li className="text-justify">
                        <strong>Panduan Pembelajaran dan Asesmen (PPA) Kurikulum Merdeka</strong> yang menegaskan bahwa hasil asesmen formatif dan sumatif digunakan oleh pendidik untuk merancang tindak lanjut pembelajaran berupa intervensi <em>Remedial</em> (bagi {identitas.sapaanSiswa.toLowerCase()} yang belum mencapai Kriteria Ketercapaian Tujuan Pembelajaran/KKTP) dan <em>Pengayaan</em> (bagi {identitas.sapaanSiswa.toLowerCase()} yang telah mencapai dan melampaui KKTP).
                      </li>
                    </ol>
                  </div>

                  {/* B. Ketentuan & Bentuk Pelaksanaan Program Remedial */}
                  <div>
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2 ${sectionBannerClass}`}>
                      B. Ketentuan dan Bentuk Pelaksanaan Program Remedial
                    </h4>
                    <p className="text-justify mb-2">
                      Sesuai kaidah pedagogis Kurikulum Merdeka, <strong>Program Remedial bukan sekadar pengulangan tes (ujian ulang)</strong>, melainkan pemberian layanan pendampingan pembelajaran tambahan pada indikator Tujuan Pembelajaran (TP) yang belum dikuasai oleh {identitas.sapaanSiswa.toLowerCase()}. Bentuk pelaksanaan disesuaikan dengan persentase jumlah {identitas.sapaanSiswa.toLowerCase()} yang belum tuntas:
                    </p>
                    <table className={`w-full border-collapse border mb-3 ${tableBorderClass}`}>
                      <thead>
                        <tr className={tableHeaderBgClass}>
                          <th className={`border px-3 py-2 text-center font-bold w-44 ${tableBorderClass}`}>
                            Proporsi {identitas.sapaanSiswa} Belum Tuntas
                          </th>
                          <th className={`border px-3 py-2 text-center font-bold w-56 ${tableBorderClass}`}>
                            Bentuk Intervensi Pembelajaran Remedial
                          </th>
                          <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                            Mekanisme Pelaksanaan & Penilaian Akhir Remedial
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                            &lt; 20%<br />
                            <span className="text-xs font-normal">(Maksimal 20%)</span>
                          </td>
                          <td className={`border px-3 py-2 font-semibold ${tableBorderClass}`}>
                            1. Bimbingan Khusus Individu<br />
                            2. Pemanfaatan Tutor Sebaya
                          </td>
                          <td className={`border px-3 py-2 text-justify ${tableBorderClass}`}>
                            Guru memberikan bimbingan personal atau menugaskan teman sebaya yang sudah mahir untuk mendampingi {identitas.sapaanSiswa.toLowerCase()} pada indikator yang belum dikuasai, diakhiri asesmen ulang pada indikator tersebut.
                          </td>
                        </tr>
                        <tr>
                          <td className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                            20% – 50%<br />
                            <span className="text-xs font-normal">(Sedang)</span>
                          </td>
                          <td className={`border px-3 py-2 font-semibold ${tableBorderClass}`}>
                            Penugasan Terstruktur dalam Kelompok Kecil
                          </td>
                          <td className={`border px-3 py-2 text-justify ${tableBorderClass}`}>
                            Guru mengelompokkan {identitas.sapaanSiswa.toLowerCase()} yang memiliki kesulitan serupa, menyediakan media/lembar kerja yang disederhanakan (scaffolding), lalu melakukan asesmen formatif/sumatif ulang.
                          </td>
                        </tr>
                        <tr>
                          <td className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                            &gt; 50%<br />
                            <span className="text-xs font-normal">(Mayoritas Kelas)</span>
                          </td>
                          <td className={`border px-3 py-2 font-semibold ${tableBorderClass}`}>
                            Pembelajaran Ulang (Re-teaching) Klasikal dengan Metode & Media Berbeda
                          </td>
                          <td className={`border px-3 py-2 text-justify ${tableBorderClass}`}>
                            Guru mengevaluasi strategi mengajar sebelumnya dan melaksanakan pembelajaran ulang secara klasikal menggunakan pendekatan yang lebih konkret, visual, dan menyenangkan sebelum memberikan asesmen ulang.
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* C. Ketentuan & Bentuk Pelaksanaan Program Pengayaan */}
                  <div>
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2 ${sectionBannerClass}`}>
                      C. Ketentuan dan Bentuk Pelaksanaan Program Pengayaan
                    </h4>
                    <p className="text-justify mb-2">
                      Program Pengayaan diberikan kepada {identitas.sapaanSiswa.toLowerCase()} yang telah mencapai kategori <strong>Cakap (Tuntas)</strong> dan <strong>Mahir (86%–100%)</strong> lebih cepat dari alokasi waktu normal. Bentuk kegiatan pengayaan meliputi:
                    </p>
                    <ul className="list-disc pl-6 space-y-1 text-justify">
                      <li className="text-justify">
                        <strong>Belajar Kelompok / Proyek Eksploratif:</strong> Sekelompok {identitas.sapaanSiswa.toLowerCase()} diberikan tantangan proyek aplikatif (misalnya membuat poster dakwah, kaligrafi, atau analisis studi kasus akhlak).
                      </li>
                      <li className="text-justify">
                        <strong>Belajar Mandiri & Literasi Mendalam:</strong> {identitas.sapaanSiswa} mempelajari materi pengayaan berupa kisah keteladanan, hikmah ibadah, atau kandungan ayat Al-Qur’an secara lebih luas sesuai minatnya.
                      </li>
                      <li className="text-justify">
                        <strong>Pemberdayaan sebagai Tutor Sebaya (Peer Tutoring):</strong> Melatih kepemimpinan dan penguatan konsep {identitas.sapaanSiswa.toLowerCase()} yang mahir dengan membimbing teman sekelas dalam praktik bacaan Al-Qur’an atau tata cara ibadah.
                      </li>
                    </ul>
                  </div>

                  {/* D. Matriks Pemetaan Rencana Program Remedial & Pengayaan per Modul Ajar */}
                  <div>
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                      D. Matriks Rencana Pelaksanaan Remedial dan Pengayaan Kelas {remedialPengayaanData.kelas}
                    </h4>
                    <div className="overflow-x-auto">
                      <table className={`w-full border-collapse border ${tableBorderClass}`}>
                        <thead>
                          <tr className={tableHeaderBgClass}>
                            <th className={`border px-2.5 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                            <th className={`border px-3 py-2 text-center font-bold w-32 ${tableBorderClass}`}>
                              Elemen & Modul
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold w-52 ${tableBorderClass}`}>
                              Tujuan Pembelajaran (TP) & Indikator Ketercapaian
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                              Rencana Program Remedial<br />
                              <span className="text-[10px] font-normal">(Bagi {identitas.sapaanSiswa} Belum Mencapai KKTP / &lt; 66%)</span>
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                              Rencana Program Pengayaan<br />
                              <span className="text-[10px] font-normal">(Bagi {identitas.sapaanSiswa} Cakap & Mahir / ≥ 86%)</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {remedialPengayaanData.items.map((item, idx) => (
                            <tr key={item.id}>
                              <td className={`border px-2.5 py-2 text-center font-bold align-top ${tableBorderClass}`}>
                                {idx + 1}
                              </td>
                              <td className={`border px-3 py-2 align-top font-bold ${tableBorderClass}`}>
                                <div>{item.elemen}</div>
                                <div className="text-xs font-normal mt-1">
                                  Modul Ajar {item.nomor}
                                </div>
                                <div className="text-[11px] font-normal opacity-80">
                                  Sem {item.semester}
                                </div>
                              </td>
                              <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                                <div className="font-bold mb-1">{formatTextSapaan(item.tp)}</div>
                                <div className="text-xs underline font-semibold mb-0.5">Fokus Indikator:</div>
                                <ol className="list-decimal pl-4 space-y-0.5 text-justify">
                                  {item.indikatorUtama.map((ind, i) => (
                                    <li key={i} className="text-justify">{ind}</li>
                                  ))}
                                </ol>
                              </td>
                              <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                                <div className="mb-1.5">
                                  <span className="font-bold underline block">Strategi Intervensi Remedial:</span>
                                  <span>{formatTextSapaan(item.strategiRemedial)}</span>
                                </div>
                                <div>
                                  <span className="font-bold underline block">Bentuk Asesmen Ulang:</span>
                                  <span>{formatTextSapaan(item.bentukAsesmenRemedial)}</span>
                                </div>
                              </td>
                              <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`}>
                                <div className="mb-1.5">
                                  <span className="font-bold underline block">Aktivitas Pengayaan:</span>
                                  <span>{formatTextSapaan(item.strategiPengayaan)}</span>
                                </div>
                                <div>
                                  <span className="font-bold underline block">Bentuk Tagihan/Apresiasi:</span>
                                  <span>{item.tagihanPengayaan}</span>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAMPILAN 2: JURNAL PELAKSANAAN & DAFTAR NILAI REMEDIAL / PENGAYAAN */}
              {remSubTab === "jurnal" && (
                <div className="space-y-6">
                  <div>
                    <h4 className={`doc-section-heading text-sm sm:text-[12pt] font-bold uppercase mb-2.5 ${sectionBannerClass}`}>
                      Jurnal Pelaksanaan dan Daftar Nilai Program Remedial & Pengayaan
                    </h4>
                    <p className="text-justify mb-3">
                      Berikut adalah rekaman pelaksanaan tindak lanjut hasil asesmen sumatif lingkup materi pada Kelas {remedialPengayaanData.kelas} Semester {remedialPengayaanData.semester}:
                    </p>

                    <div className="overflow-x-auto">
                      <table className={`w-full border-collapse border ${tableBorderClass}`}>
                        <thead>
                          <tr className={tableHeaderBgClass}>
                            <th className={`border px-2 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                            <th className={`border px-3 py-2 text-center font-bold w-44 ${tableBorderClass}`}>
                              Nama {identitas.sapaanSiswa}
                            </th>
                            <th className={`border px-2.5 py-2 text-center font-bold w-24 ${tableBorderClass}`}>
                              Modul / TP
                            </th>
                            <th className={`border px-2.5 py-2 text-center font-bold w-20 ${tableBorderClass}`}>
                              Nilai Awal
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold ${tableBorderClass}`}>
                              Indikator yang Belum Tuntas / Kompetensi yang Diperkaya
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold w-52 ${tableBorderClass}`}>
                              Bentuk Layanan Tindak Lanjut (Remedial / Pengayaan)
                            </th>
                            <th className={`border px-2.5 py-2 text-center font-bold w-20 ${tableBorderClass}`}>
                              Nilai Akhir
                            </th>
                            <th className={`border px-3 py-2 text-center font-bold w-36 ${tableBorderClass}`}>
                              Keterangan Ketuntasan
                            </th>
                            <th className={`border px-2 py-2 text-center font-bold w-12 no-print ${tableBorderClass}`}>
                              Aksi
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {jurnalRemedialList.map((row, idx) => (
                            <tr key={row.id}>
                              <td className={`border px-2 py-2 text-center font-bold align-top ${tableBorderClass}`}>
                                {idx + 1}
                              </td>
                              <td className={`border px-2.5 py-1.5 align-top ${tableBorderClass}`}>
                                <input
                                  type="text"
                                  value={row.nama}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "nama", e.target.value)}
                                  className="w-full bg-transparent font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded px-1"
                                />
                              </td>
                              <td className={`border px-2 py-1.5 text-center align-top ${tableBorderClass}`}>
                                <select
                                  value={row.modulNomor}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "modulNomor", Number(e.target.value))}
                                  className="w-full bg-transparent text-center font-semibold focus:outline-none"
                                >
                                  {[1, 2, 3, 4, 5].map((num) => (
                                    <option key={num} value={num} className="bg-white text-slate-900 font-semibold">
                                      Modul {num}
                                    </option>
                                  ))}
                                </select>
                              </td>
                              <td className={`border px-2 py-1.5 text-center align-top ${tableBorderClass}`}>
                                <input
                                  type="text"
                                  value={row.nilaiAwal}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "nilaiAwal", e.target.value)}
                                  className="w-full bg-transparent text-center font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded"
                                />
                              </td>
                              <td className={`border px-2.5 py-1.5 align-top ${tableBorderClass}`}>
                                <textarea
                                  rows={2}
                                  value={row.indikatorBelumTuntas}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "indikatorBelumTuntas", e.target.value)}
                                  className="w-full bg-transparent text-justify focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded px-1"
                                />
                              </td>
                              <td className={`border px-2.5 py-1.5 align-top ${tableBorderClass}`}>
                                <textarea
                                  rows={2}
                                  value={row.bentukLayanan}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "bentukLayanan", e.target.value)}
                                  className="w-full bg-transparent text-justify focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded px-1"
                                />
                              </td>
                              <td className={`border px-2 py-1.5 text-center align-top ${tableBorderClass}`}>
                                <input
                                  type="text"
                                  value={row.nilaiAkhir}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "nilaiAkhir", e.target.value)}
                                  className="w-full bg-transparent text-center font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded"
                                />
                              </td>
                              <td className={`border px-2.5 py-1.5 align-top ${tableBorderClass}`}>
                                <input
                                  type="text"
                                  value={row.keterangan}
                                  onChange={(e) => handleUpdateJurnalRow(row.id, "keterangan", e.target.value)}
                                  className="w-full bg-transparent font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded px-1"
                                />
                              </td>
                              <td className={`border px-2 py-1.5 text-center align-middle no-print ${tableBorderClass}`}>
                                <button
                                  onClick={() => handleDeleteJurnalRow(row.id)}
                                  title="Hapus baris"
                                  className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB: RINCIAN MINGGU EFEKTIF (RME & ALOKASI WAKTU BELAJAR)*/}
        {/* ======================================================== */}
        {activeTab === "minggu-efektif" && isTabEnabled("minggu-efektif") && (
          <TabMingguEfektif
            rmeData={rmeData}
            setRmeData={setRmeData}
            isEditingRme={isEditingRme}
            setIsEditingRme={setIsEditingRme}
            handleSaveRme={handleSaveRme}
            rmeKelas={rmeKelas}
            setRmeKelas={setRmeKelas}
            rmeSemester={rmeSemester}
            setRmeSemester={setRmeSemester}
            identitas={identitas}
            modules={modules}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
          />
        )}

        {/* ======================================================== */}
        {/* TAB: PROGRAM PEMBIASAAN & KEGIATAN KEAGAMAAN ISLAM       */}
        {/* ======================================================== */}
        {activeTab === "program-keagamaan" && isTabEnabled("program-keagamaan") && (
          <TabProgramKeagamaan
            programKeagamaan={programKeagamaan}
            setProgramKeagamaan={setProgramKeagamaan}
            isEditingKeagamaan={isEditingKeagamaan}
            setIsEditingKeagamaan={setIsEditingKeagamaan}
            handleSaveKeagamaan={handleSaveKeagamaan}
            identitas={identitas}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
          />
        )}

        {/* ======================================================== */}
        {/* TAB 16: HAK AKSES PENGGUNA & MANAJEMEN PASSWORD (ADMIN) */}
        {/* ======================================================== */}
        {activeTab === "hak-akses" && isAdmin && (
          <TabHakAksesPengguna
            identitas={identitas}
            currentUser={currentUser}
            registeredSchools={registeredSchools}
            setRegisteredSchools={setRegisteredSchools}
            menuPermissions={menuPermissions}
            setMenuPermissions={setMenuPermissions}
            paperLightMode={paperLightMode}
            setPaperLightMode={setPaperLightMode}
            lineSpacing={lineSpacing}
            setLineSpacing={setLineSpacing}
            handlePrintDocument={handlePrintDocument}
            handleDownloadWord={handleDownloadWord}
            showToast={showToast}
            tableBorderClass={tableBorderClass}
            tableHeaderBgClass={tableHeaderBgClass}
            docContainerClass={docContainerClass}
            kopSuratUrl={kopSuratUrl}
            useKopSurat={useKopSurat}
          />
        )}

        {/* ========================================== */}
        {/* TAB 17: PENGATURAN IDENTITAS SEKOLAH & GURU */}
        {/* ========================================== */}
        {activeTab === "identitas" && isTabEnabled("identitas") && (
          <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-sm border-2 border-emerald-300 p-6 sm:p-8 space-y-6 text-slate-800">
            <div className="flex items-center gap-3.5 border-b border-emerald-200 pb-5">
              <div className="p-3.5 bg-emerald-100 text-emerald-800 rounded-2xl border border-emerald-300">
                <School className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h2 className="text-lg font-extrabold text-slate-900">Pengaturan Identitas Sekolah &amp; Penandatangan</h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-0.5 font-medium">
                  Data di bawah ini otomatis diterapkan ke seluruh 78 Modul Ajar (Kelas I–VI) dan dokumen ATP.
                </p>
              </div>
            </div>

            {/* Kartu Integrasi Rombel & Jadwal Mengajar */}
            <div className="p-4 bg-[#e6f7ef] border-2 border-emerald-300 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-700 text-white rounded-xl shadow-xs shrink-0">
                  <CalendarDays className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">
                    Daftar Kelas ({daftarKelas.length} Rombel) &amp; Jadwal Mengajar Mingguan ({jadwalMengajar.reduce((a, c) => a + (c.alokasiJp || 3), 0)} JP)
                  </h4>
                  <p className="text-xs text-slate-600 font-medium mt-0.5">
                    Terkonfigurasi: {daftarKelas.map((k) => k.nama).join(", ")}. Hari dan jam mengajar otomatis sinkron dengan Jurnal Mengajar.
                  </p>
                </div>
              </div>
              {isTabEnabled("jurnal-mengajar") && (
                <button
                  type="button"
                  onClick={() => setActiveTab("jurnal-mengajar")}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer shrink-0"
                >
                  Kelola Jadwal &amp; Rombel
                </button>
              )}
            </div>

            {/* Kartu Pilihan Alokasi Jam Pelajaran (3 JP / 4 JP) */}
            <div className="p-4 bg-emerald-50/80 border-2 border-emerald-300 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-[#065f46] text-white rounded-xl shadow-xs shrink-0">
                  <Clock className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">
                    Alokasi Waktu Pembelajaran: {alokasiJpDefault} JP per Minggu (1 JP = 35 Menit)
                  </h4>
                  <p className="text-xs text-slate-600 font-medium mt-0.5">
                    Pilihan ini otomatis menyelaraskan perhitungan alokasi jam pelajaran pada Modul Ajar, PROTA (Semester &amp; 1 Tahun), PROMES, dan Jurnal Mengajar.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-white p-1 rounded-xl border border-emerald-300 shrink-0">
                {([3, 4] as const).map((jp) => (
                  <button
                    key={jp}
                    type="button"
                    onClick={() => handleSetAlokasiJp(jp)}
                    className={`px-4 py-2 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                      alokasiJpDefault === jp
                        ? "bg-[#065f46] text-white shadow-xs"
                        : "text-emerald-950 hover:bg-emerald-100"
                    }`}
                  >
                    {jp} JP / Minggu
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <span>Nama Sekolah / Satuan Pendidikan</span>
                  <span className="inline-flex items-center gap-1 text-[10.5px] font-extrabold text-amber-900 bg-amber-100/90 border border-amber-300 px-2 py-0.5 rounded-md">
                    <Lock className="w-3 h-3 text-amber-700" />
                    Terkunci Sesuai Login
                  </span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={identitas.sekolah}
                    readOnly
                    disabled
                    aria-readonly="true"
                    className="w-full pl-4 pr-10 py-2.5 text-sm bg-slate-100/90 border-2 border-slate-300 text-slate-800 font-bold rounded-xl cursor-not-allowed select-none focus:outline-none"
                  />
                  <div className="absolute right-3 top-3 text-slate-400">
                    <Lock className="w-4 h-4 text-amber-700" />
                  </div>
                </div>
                <p className="text-[11px] text-slate-600 mt-1 font-medium">
                  🔒 Nama sekolah telah dikunci otomatis sesuai nama sekolah yang terdaftar saat Anda login dan tidak dapat diubah di profil guru.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Tahun Ajaran</label>
                <input
                  type="text"
                  value={identitas.tahunAjaran}
                  onChange={(e) => setIdentitas({ ...identitas, tahunAjaran: e.target.value })}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 font-semibold rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Kabupaten / Kota (Titimangsa TTD)
                </label>
                <input
                  type="text"
                  value={identitas.kota}
                  onChange={(e) => setIdentitas({ ...identitas, kota: e.target.value })}
                  placeholder="Contoh: Bekasi atau Kota Bekasi"
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 font-semibold rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-slate-600 font-bold">Pilihan:</span>
                  {["Bekasi", "Kota Bekasi", "Kabupaten Bekasi", "Kecamatan Bantargebang Kota Bekasi"].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setIdentitas({ ...identitas, kota: opt })}
                      className={`text-[10px] px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                        identitas.kota === opt
                          ? "bg-emerald-100 text-emerald-900 border-emerald-400 font-bold"
                          : "bg-slate-100 text-slate-700 border-slate-300 hover:text-emerald-950 hover:bg-emerald-50"
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-slate-500 mt-1 font-medium">
                  Nama yang diketik di atas dicetak langsung pada titimangsa ttd tanpa pengulangan kata.
                </p>
              </div>

              <div className="sm:col-span-2 p-4 bg-[#e6f7ef] rounded-2xl border border-emerald-300 space-y-2.5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <label className="text-xs font-bold text-emerald-950 uppercase tracking-wider flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Tanggal Cetak &amp; Titimangsa (Diterapkan ke Semua Dokumen)</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setTempTanggal(identitas.tanggal);
                      setTempKota(identitas.kota);
                      setShowDateModal(true);
                    }}
                    className="text-[11px] font-bold text-emerald-900 hover:text-white bg-white hover:bg-emerald-700 border border-emerald-400 px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1 shadow-xs"
                  >
                    <CalendarDays className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Buka Menu Tanggal Lengkap</span>
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={identitas.tanggal}
                    onChange={(e) => setIdentitas({ ...identitas, tanggal: e.target.value })}
                    placeholder="Contoh: 13 Juli 2026"
                    className="w-full px-4 py-2.5 text-sm bg-white border border-emerald-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold text-emerald-950"
                  />
                  <div className="flex items-center gap-2">
                    <input
                      type="date"
                      onChange={(e) => {
                        if (e.target.value) {
                          setIdentitas({ ...identitas, tanggal: formatTanggalIndo(e.target.value) });
                        }
                      }}
                      className="px-3 py-2 text-xs bg-white text-emerald-900 font-bold border border-emerald-300 rounded-xl cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] text-slate-600 font-medium">Pilih kalender</span>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-600 font-bold mr-1">Preset Cepat:</span>
                  <button
                    type="button"
                    onClick={() => {
                      const tgl = formatTanggalIndo(new Date());
                      setIdentitas({ ...identitas, tanggal: tgl });
                      showToast(`Tanggal cetak diset: Hari Ini (${tgl})`);
                    }}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition-all cursor-pointer"
                  >
                    Hari Ini ({formatTanggalIndo(new Date())})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIdentitas({ ...identitas, tanggal: "13 Juli 2026" });
                      showToast("Tanggal cetak diset: Awal Sem 1 (13 Juli 2026)");
                    }}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white hover:bg-emerald-100 text-slate-700 border border-slate-300 transition-all cursor-pointer"
                  >
                    Awal Sem 1 (13 Juli 2026)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIdentitas({ ...identitas, tanggal: "5 Januari 2027" });
                      showToast("Tanggal cetak diset: Awal Sem 2 (5 Januari 2027)");
                    }}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white hover:bg-emerald-100 text-slate-700 border border-slate-300 transition-all cursor-pointer"
                  >
                    Awal Sem 2 (5 Januari 2027)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIdentitas({ ...identitas, tanggal: "18 Desember 2026" });
                      showToast("Tanggal cetak diset: Akhir Sem 1 (18 Des 2026)");
                    }}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white hover:bg-emerald-100 text-slate-700 border border-slate-300 transition-all cursor-pointer"
                  >
                    Akhir Sem 1 (18 Des 2026)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Nama Kepala Sekolah</label>
                <input
                  type="text"
                  value={identitas.kepalaSekolah}
                  onChange={(e) => setIdentitas({ ...identitas, kepalaSekolah: e.target.value })}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 font-semibold rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">NIP Kepala Sekolah</label>
                <input
                  type="text"
                  value={identitas.nipKepsek}
                  onChange={(e) => setIdentitas({ ...identitas, nipKepsek: e.target.value })}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 font-semibold rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Nama Guru PAI dan BP</label>
                <input
                  type="text"
                  value={identitas.guruPai}
                  onChange={(e) => setIdentitas({ ...identitas, guruPai: e.target.value })}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 font-semibold rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">NIP Guru PAI dan BP</label>
                <input
                  type="text"
                  value={identitas.nipGuru}
                  onChange={(e) => setIdentitas({ ...identitas, nipGuru: e.target.value })}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 text-slate-900 font-semibold rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Istilah Sapaan di Modul Ajar</label>
                <div className="flex gap-3">
                  {["Murid", "Peserta didik"].map((sap) => (
                    <button
                      key={sap}
                      onClick={() => setIdentitas({ ...identitas, sapaanSiswa: sap })}
                      className={`px-4 py-2.5 rounded-xl text-sm font-bold border transition-all cursor-pointer ${
                        identitas.sapaanSiswa === sap
                          ? "bg-[#065f46] text-white border-emerald-700 shadow-sm"
                          : "bg-white text-slate-700 border-slate-300 hover:bg-emerald-50"
                      }`}
                    >
                      Gunakan istilah "{sap}"
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Panel Upload Logo Sekolah Resmi */}
            <div className="pt-5 border-t border-emerald-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-700" />
                    <span>Upload Logo Sekolah Resmi</span>
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Unggah gambar logo resmi sekolah (PNG transparan disarankan, JPG, WebP) untuk dijadikan lambang pada <strong>ikon di sebelah kiri judul aplikasi</strong>.
                  </p>
                </div>
                {logoSekolahUrl && (
                  <span className="text-[11px] font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-full">
                    Logo Terpasang
                  </span>
                )}
              </div>

              {logoSekolahUrl ? (
                <div className="space-y-3">
                  <div className="p-4 bg-white rounded-2xl border-2 border-emerald-300 shadow-sm flex items-center justify-center">
                    <img
                      src={logoSekolahUrl}
                      alt="Pratinjau Logo Sekolah"
                      className="max-h-24 max-w-full object-contain"
                    />
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => logoFileInputRef.current?.click()}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white flex items-center gap-2 transition-all cursor-pointer"
                    >
                      <UploadCloud className="w-4 h-4" />
                      <span>Ganti Logo Sekolah</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleRemoveLogoSekolah}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 flex items-center gap-2 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4 text-rose-600" />
                      <span>Hapus Logo Sekolah</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <div
                    onClick={() => logoFileInputRef.current?.click()}
                    className="border-2 border-dashed border-emerald-400 hover:border-emerald-600 rounded-2xl p-6 text-center cursor-pointer transition-all bg-[#e6f7ef] hover:bg-emerald-100/60"
                  >
                    <UploadCloud className="w-8 h-8 text-emerald-700 mx-auto mb-2 transition-colors" />
                    <p className="text-xs font-extrabold text-slate-900">
                      Klik di sini untuk mengunggah logo sekolah resmi
                    </p>
                    <p className="text-[11px] text-slate-600 font-medium mt-1">
                      Format: PNG, JPG, JPEG, WebP, SVG (Maks. 5 MB) • Otomatis dipasang ke Ikon Header Aplikasi
                    </p>
                  </div>
                </div>
              )}

              <input
                type="file"
                ref={logoFileInputRef}
                onChange={handleUploadLogoSekolah}
                accept="image/*"
                className="hidden"
              />
            </div>

            {/* Panel Upload Kop Surat Resmi Satuan Pendidikan */}
            <div className="pt-5 border-t border-emerald-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <School className="w-4 h-4 text-emerald-700" />
                    <span>Upload Kop Surat Resmi Sekolah</span>
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5 font-medium">
                    Unggah gambar Kop Surat resmi sekolah (PNG, JPG, WebP) untuk dijadikan kepala surat pada setiap dokumen cetak / simpan PDF.
                  </p>
                </div>
                {kopSuratUrl && (
                  <span className="text-[11px] font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-full">
                    Kop Surat Terpasang
                  </span>
                )}
              </div>

              {kopSuratUrl ? (
                <div className="space-y-3">
                  <div className="p-4 bg-white rounded-xl border border-emerald-300 shadow-sm flex items-center justify-center">
                    <img
                      src={kopSuratUrl}
                      alt="Pratinjau Kop Surat"
                      className="max-h-28 max-w-full object-contain"
                    />
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => kopFileInputRef.current?.click()}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white flex items-center gap-2 transition-all cursor-pointer"
                    >
                      <UploadCloud className="w-4 h-4" />
                      <span>Ganti Gambar Kop Surat</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleRemoveKopSurat}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 flex items-center gap-2 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4 text-rose-600" />
                      <span>Hapus Kop Surat</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <div
                    onClick={() => kopFileInputRef.current?.click()}
                    className="border-2 border-dashed border-emerald-400 hover:border-emerald-600 rounded-2xl p-6 text-center cursor-pointer transition-all bg-[#e6f7ef] hover:bg-emerald-100/60"
                  >
                    <UploadCloud className="w-8 h-8 text-emerald-700 mx-auto mb-2 transition-colors" />
                    <p className="text-xs font-extrabold text-slate-900">
                      Klik di sini untuk mengunggah gambar Kop Surat resmi sekolah
                    </p>
                    <p className="text-[11px] text-slate-600 font-medium mt-1">
                      Format: PNG, JPG, JPEG, WebP, SVG (Maks. 5 MB)
                    </p>
                  </div>
                </div>
              )}

              <input
                type="file"
                ref={kopFileInputRef}
                onChange={handleUploadKopSurat}
                accept="image/*"
                className="hidden"
              />
            </div>

            {/* Panel Manajemen Cadangan & Pemulihan Data */}
            <div className="pt-5 border-t border-emerald-200 space-y-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-700" />
                  <span>Cadangan &amp; Pemulihan Berkas Administrasi</span>
                </h3>
                <p className="text-xs text-slate-600 mt-0.5 font-medium">
                  Simpan cadangan seluruh 78 Modul Ajar, 12 Projek Kokurikuler, dan jurnal nilai yang telah Anda ubah ke dalam berkas JSON untuk diarsipkan atau dipindahkan ke komputer lain.
                </p>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImportBackup}
                accept=".json"
                className="hidden"
              />

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white transition-all flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  <FileDown className="w-4 h-4" />
                  <span>Cadangkan Data (.json)</span>
                </button>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-all flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  <UploadCloud className="w-4 h-4 text-emerald-700" />
                  <span>Pulihkan dari Cadangan (.json)</span>
                </button>
                <button
                  type="button"
                  onClick={handleResetToDefaults}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 transition-all flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4 text-rose-600" />
                  <span>Reset ke Standar Awal</span>
                </button>
              </div>
            </div>

            <div className="pt-5 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => {
                  if (isTabEnabled("modul")) {
                    setActiveTab("modul");
                    showToast("Identitas berhasil disimpan dan diterapkan ke seluruh Modul Ajar!");
                  } else {
                    setActiveTab("beranda");
                    showToast("Identitas berhasil disimpan!");
                  }
                }}
                className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-sm rounded-xl shadow-lg shadow-emerald-950/60 transition-all cursor-pointer"
              >
                Simpan &amp; Lihat Perangkat
              </button>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAMPILAN BLOKIR / AKSES DITOLAK JIKA MENU DINONAKTIFKAN */}
        {/* ======================================================== */}
        {!isAdmin && activeTab !== "beranda" && !isTabEnabled(activeTab) && (
          <div className="max-w-2xl mx-auto my-12 bg-white rounded-3xl p-8 border-2 border-rose-300 shadow-md text-center space-y-4 text-slate-800">
            <div className="w-16 h-16 rounded-2xl bg-rose-100 border border-rose-300 text-rose-700 flex items-center justify-center mx-auto">
              <Lock className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-extrabold text-slate-900">
                Menu Fitur Ini Dinonaktifkan
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Fitur menu ini sedang dinonaktifkan atau disembunyikan oleh Administrator bagi pengguna selain admin.
              </p>
              <p className="text-xs text-rose-700 font-semibold bg-rose-50 py-2.5 px-4 rounded-xl border border-rose-200 inline-block">
                Silakan hubungi Administrator (085780255805) untuk mendaftarkan atau mengaktifkan kembali akses menu ini.
              </p>
            </div>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setActiveTab("beranda")}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Kembali ke Dashboard Utama</span>
              </button>
            </div>
          </div>
        )}

      </main>
    </div>
        </>
      )}
    </div>
  );
}