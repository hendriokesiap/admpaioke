import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Users,
  UserPlus,
  Trash2,
  Edit3,
  Search,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  RefreshCw,
  Info,
  Sparkles,
  ArrowRight,
  BookOpen,
  Printer,
  ChevronRight,
  Check
} from 'lucide-react';
import { KelasRombelItem } from './TabJurnalMengajar.tsx';
import { SiswaItem, DEFAULT_NAMA_SISWA_PAI, loadSiswaFromStorage, getDefaultContohSiswa } from './TabPenilaian.tsx';
import { ModalUploadSiswaExcel } from './ModalUploadSiswaExcel.tsx';

export interface TabUploadSiswaProps {
  daftarKelas: KelasRombelItem[];
  showToast: (msg: string) => void;
  setActiveTab?: (tab: string) => void;
}

export const TabUploadSiswa: React.FC<TabUploadSiswaProps> = ({
  daftarKelas,
  showToast,
  setActiveTab
}) => {
  const [selectedRombelId, setSelectedRombelId] = useState<string>(() => {
    return daftarKelas[0]?.id || "kls-1a";
  });

  const currentRombel = useMemo(() => {
    return daftarKelas.find((k) => k.id === selectedRombelId) || daftarKelas[0];
  }, [daftarKelas, selectedRombelId]);

  // State Daftar Siswa untuk Rombel yang dipilih (Maksimal 3 contoh panduan atau kosong)
  const [daftarSiswa, setDaftarSiswa] = useState<SiswaItem[]>(() => {
    return loadSiswaFromStorage(selectedRombelId);
  });

  // Reload data saat ganti rombel
  useEffect(() => {
    setDaftarSiswa(loadSiswaFromStorage(selectedRombelId));
  }, [selectedRombelId]);

  // Simpan ke localStorage saat berubah
  const saveToStorage = (newList: SiswaItem[]) => {
    setDaftarSiswa(newList);
    try {
      localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(newList));
    } catch {}
  };

  // State Modal Upload Excel
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);

  // State Tambah Manual Modal
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [manualNama, setManualNama] = useState<string>("");
  const [manualNisn, setManualNisn] = useState<string>("");
  const [manualGender, setManualGender] = useState<"L" | "P">("L");

  // State Edit Siswa
  const [editingSiswa, setEditingSiswa] = useState<SiswaItem | null>(null);

  // State Pencarian
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Download Template Excel (.xlsx)
  const downloadTemplateExcel = () => {
    try {
      const wb = XLSX.utils.book_new();

      const templateData = [
        ["No", "NISN (Opsional)", "Nama Lengkap Siswa", "Jenis Kelamin (L/P)"],
        [1, "0014523671", "Abdullah Azzam Pratama", "L"],
        [2, "0014523672", "Ahmad Al-Fatih", "L"],
        [3, "0014523673", "Aisyah Nur Ramadhani", "P"],
        [4, "", "Bilal Habibi Syahputra", "L"],
        [5, "0014523675", "Dania Putri Salsabila", "P"],
        [6, "0014523676", "Fadhil Maulana Malik", "L"],
        [7, "0014523677", "Fatimah Az-Zahra", "P"],
        [8, "", "Hafiz Ramadhan", "L"],
        [9, "0014523679", "Khadijah Amira Sholiha", "P"],
        [10, "0014523680", "Muhammad Rayhan Arkan", "L"],
      ];

      const ws = XLSX.utils.aoa_to_sheet(templateData);
      ws["!cols"] = [{ wch: 8 }, { wch: 20 }, { wch: 35 }, { wch: 22 }];
      XLSX.utils.book_append_sheet(wb, ws, "Data Siswa");

      // Lembar Petunjuk Pengisian
      const petunjukData = [
        ["PETUNJUK PENGISIAN TEMPLATE DATA SISWA PAI & BUDI PEKERTI"],
        [""],
        ["1. Kolom 'No'", "Diisi nomor urut siswa (1, 2, 3, dst)."],
        ["2. Kolom 'NISN (Opsional)'", "Diisi 10 digit NISN. Boleh dikosongkan jika belum ada (sistem akan otomatis membuat nomor urut unik)."],
        ["3. Kolom 'Nama Lengkap Siswa'", "Wajib diisi dengan nama lengkap peserta didik tanpa gelar."],
        ["4. Kolom 'Jenis Kelamin (L/P)'", "Diisi huruf 'L' untuk Laki-laki atau 'P' untuk Perempuan (bisa juga 'Laki-laki' / 'Perempuan')."],
        ["5. Format File", "Dapat disimpan dalam format .xlsx, .xls, atau .csv sebelum diunggah kembali ke aplikasi."],
      ];
      const wsPetunjuk = XLSX.utils.aoa_to_sheet(petunjukData);
      wsPetunjuk["!cols"] = [{ wch: 30 }, { wch: 70 }];
      XLSX.utils.book_append_sheet(wb, wsPetunjuk, "Petunjuk");

      const cleanRombel = (currentRombel?.nama || "Kelas").replace(/\s+/g, "_");
      XLSX.writeFile(wb, `Template_Data_Siswa_${cleanRombel}.xlsx`);
      showToast("Template Excel (.xlsx) berhasil diunduh!");
    } catch {
      showToast("Gagal mengunduh template Excel");
    }
  };

  // Ekspor Siswa yang Ada ke Excel
  const handleExportCurrentToExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      const rows = [
        ["No", "NISN", "Nama Lengkap Siswa", "Jenis Kelamin (L/P)"],
        ...daftarSiswa.map((s, idx) => [idx + 1, s.nisn, s.nama, s.gender])
      ];
      const ws = XLSX.utils.aoa_to_sheet(rows);
      ws["!cols"] = [{ wch: 8 }, { wch: 20 }, { wch: 35 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(wb, ws, "Data Siswa");

      const cleanRombel = (currentRombel?.nama || "Kelas").replace(/\s+/g, "_");
      XLSX.writeFile(wb, `Daftar_Siswa_${cleanRombel}.xlsx`);
      showToast(`Data siswa ${currentRombel?.nama} berhasil diekspor ke Excel!`);
    } catch {
      showToast("Gagal mengekspor data ke Excel");
    }
  };

  // Callback dari Modal Upload
  const handleUploadSuccess = (newItems: SiswaItem[], mode: "replace" | "append") => {
    if (mode === "replace") {
      saveToStorage(newItems);
      showToast(`Berhasil mengganti data dengan ${newItems.length} siswa dari Excel untuk ${currentRombel?.nama}`);
    } else {
      const merged = [...daftarSiswa, ...newItems];
      saveToStorage(merged);
      showToast(`Berhasil menambahkan ${newItems.length} siswa baru ke ${currentRombel?.nama}`);
    }
  };

  // Tambah Manual
  const handleSaveManualSiswa = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualNama.trim()) {
      showToast("Nama lengkap siswa tidak boleh kosong");
      return;
    }

    const nisn = manualNisn.trim() || `012345${String(daftarSiswa.length + 1).padStart(4, "0")}`;
    const newStudent: SiswaItem = {
      id: `sis-${selectedRombelId}-${Date.now()}`,
      nisn,
      nama: manualNama.trim(),
      gender: manualGender
    };

    saveToStorage([...daftarSiswa, newStudent]);
    setManualNama("");
    setManualNisn("");
    setShowAddModal(false);
    showToast(`Siswa "${newStudent.nama}" berhasil ditambahkan.`);
  };

  // Simpan Edit
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSiswa || !editingSiswa.nama.trim()) return;

    const updated = daftarSiswa.map((s) => (s.id === editingSiswa.id ? editingSiswa : s));
    saveToStorage(updated);
    setEditingSiswa(null);
    showToast("Data siswa berhasil diperbarui.");
  };

  // Hapus Siswa
  const handleDeleteSiswa = (id: string, nama: string) => {
    const filtered = daftarSiswa.filter((s) => s.id !== id);
    saveToStorage(filtered);
    showToast(`Siswa "${nama}" telah dihapus.`);
  };

  // Reset ke 3 Contoh Siswa Panduan (Maksimal 3 Siswa)
  const handleResetToDefault = () => {
    const initial = getDefaultContohSiswa(selectedRombelId);
    saveToStorage(initial);
    showToast(`3 contoh nama siswa panduan diterapkan untuk ${currentRombel?.nama}.`);
  };

  // Kosongkan Seluruh Siswa Rombel
  const handleClearAll = () => {
    if (window.confirm(`Yakin ingin mengosongkan seluruh nama siswa pada rombel ${currentRombel?.nama}?`)) {
      saveToStorage([]);
      showToast(`Daftar siswa ${currentRombel?.nama} telah dikosongkan.`);
    }
  };

  // Filter siswa
  const filteredList = useMemo(() => {
    return daftarSiswa.filter(
      (s) =>
        s.nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.nisn.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [daftarSiswa, searchQuery]);

  // Statistik
  const countLaki = daftarSiswa.filter((s) => s.gender === "L").length;
  const countPerempuan = daftarSiswa.filter((s) => s.gender === "P").length;

  return (
    <div className="space-y-6 text-slate-800">
      
      {/* HEADER SECTION DENGAN AKSEN HIJAU TEMA UTAMA */}
      <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span>Manajemen Data Siswa &amp; Import Excel</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
              <span>Upload Data Siswa dengan File Excel</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5 font-medium">
              Unggah file Excel (format: No, NISN (opsional), Nama Lengkap Siswa, Jenis Kelamin L/P) per rombel. Data langsung terintegrasi otomatis ke <strong>Buku Nilai &amp; Penilaian</strong> serta <strong>Buku Absensi &amp; Presensi Siswa</strong>.
            </p>
          </div>

          {/* Tombol Utama: Download Template & Upload */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={downloadTemplateExcel}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
              title="Unduh format template Excel resmi dengan kolom No, NISN, Nama, L/P"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Download Template Excel</span>
            </button>

            <button
              type="button"
              onClick={() => setShowUploadModal(true)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md transition-all cursor-pointer"
            >
              <Upload className="w-4 h-4 text-emerald-200" />
              <span>Upload File Excel (.xlsx / .csv)</span>
            </button>
          </div>
        </div>

        {/* Pilihan Rombel Kelas & Ringkasan Statistik */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center pt-1">
          {/* Pemilih Rombel */}
          <div className="md:col-span-7">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-1.5">
              Pilih Rombel / Kelas Sasaran:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {daftarKelas.map((k) => (
                <button
                  key={k.id}
                  type="button"
                  onClick={() => setSelectedRombelId(k.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                    selectedRombelId === k.id
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-sm"
                      : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100"
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>{k.nama}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
                    selectedRombelId === k.id ? "bg-white/20 text-white" : "bg-emerald-200/70 text-emerald-950"
                  }`}>
                    {k.jumlahSiswa || 28}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Stats Rombel Aktif */}
          <div className="md:col-span-5 flex items-center justify-end gap-2 text-xs">
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2 flex items-center gap-2">
              <span className="font-bold text-slate-700">Total:</span>
              <span className="font-extrabold text-emerald-950 text-sm">{daftarSiswa.length} Siswa</span>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-xl px-3 py-2 flex items-center gap-1.5">
              <span className="font-bold text-blue-900">L:</span>
              <span className="font-extrabold text-blue-950">{countLaki}</span>
            </div>
            <div className="bg-pink-50 border border-pink-200 rounded-xl px-3 py-2 flex items-center gap-1.5">
              <span className="font-bold text-pink-900">P:</span>
              <span className="font-extrabold text-pink-950">{countPerempuan}</span>
            </div>
          </div>
        </div>
      </div>

      {/* PANDUAN RINGKAS CARA KERJA UPLOAD EXCEL */}
      <div className="bg-emerald-50/60 border border-emerald-300 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-200 text-emerald-900 flex items-center justify-center shrink-0 font-extrabold text-sm">
            💡
          </div>
          <div>
            <h4 className="font-bold text-emerald-950 text-sm">Petunjuk Pengisian Kolom Excel</h4>
            <p className="text-slate-700 mt-0.5">
              Download Template &rarr; Isi kolom <strong>No</strong>, <strong>NISN</strong> (boleh dikosongkan), <strong>Nama Lengkap Siswa</strong>, dan <strong>Jenis Kelamin (L/P)</strong> &rarr; Klik tombol <strong>Upload File Excel</strong> &rarr; Pilih mode simpan (Ganti Semua atau Tambahkan).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {setActiveTab && (
            <>
              <button
                type="button"
                onClick={() => setActiveTab("absensi")}
                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>Ke Menu Absensi</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("penilaian")}
                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>Ke Buku Nilai</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* DAFTAR SISWA AKTIF ROMBEL INI */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        
        {/* Toolbar Tabel */}
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-700" />
              <span>Daftar Siswa {currentRombel?.nama} (Tingkat {currentRombel?.tingkat})</span>
            </h3>
            <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
              {daftarSiswa.length} Orang
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Input Pencarian */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama atau NISN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl bg-white w-48 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-colors cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-700" />
              <span>+ Siswa Manual</span>
            </button>

            <button
              type="button"
              onClick={handleExportCurrentToExcel}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-colors cursor-pointer"
              title="Unduh daftar siswa rombel ini ke file Excel"
            >
              <Download className="w-3.5 h-3.5 text-emerald-700" />
              <span>Ekspor Excel</span>
            </button>

            <button
              type="button"
              onClick={handleResetToDefault}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 transition-colors cursor-pointer"
              title="Reset ke 3 contoh nama siswa panduan"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>3 Contoh Panduan</span>
            </button>

            <button
              type="button"
              onClick={handleClearAll}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 transition-colors cursor-pointer"
              title="Kosongkan seluruh nama siswa pada rombel ini"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
              <span>Kosongkan</span>
            </button>
          </div>
        </div>

        {/* Tabel Data Siswa */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-700 font-extrabold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4 text-center w-14">No</th>
                <th className="py-3 px-4 w-44">NISN (Nomor Induk)</th>
                <th className="py-3 px-4">Nama Lengkap Siswa</th>
                <th className="py-3 px-4 text-center w-36">Jenis Kelamin</th>
                <th className="py-3 px-4 text-center w-28">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    Tidak ada data siswa yang cocok dengan pencarian "{searchQuery}".
                  </td>
                </tr>
              ) : (
                filteredList.map((item, idx) => (
                  <tr key={item.id} className="hover:bg-emerald-50/40 transition-colors">
                    <td className="py-3 px-4 text-center font-bold text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-700">
                      {item.nisn}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900 text-sm">
                      {item.nama}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-full font-extrabold text-[11px] ${
                          item.gender === "L"
                            ? "bg-blue-100 text-blue-900 border border-blue-200"
                            : "bg-pink-100 text-pink-900 border border-pink-200"
                        }`}
                      >
                        {item.gender === "L" ? "L (Laki-laki)" : "P (Perempuan)"}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setEditingSiswa({ ...item })}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                          title="Edit nama atau NISN siswa"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteSiswa(item.id, item.nama)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Hapus siswa dari rombel"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Roster */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            Menampilkan {filteredList.length} dari {daftarSiswa.length} siswa di rombel <strong>{currentRombel?.nama}</strong>.
          </span>
          <div className="flex items-center gap-3">
            <span className="font-semibold text-blue-900">Laki-laki: {countLaki}</span>
            <span className="font-semibold text-pink-900">Perempuan: {countPerempuan}</span>
          </div>
        </div>
      </div>

      {/* MODAL UPLOAD EXCEL SISWA */}
      <ModalUploadSiswaExcel
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        currentRombel={currentRombel}
        daftarKelas={daftarKelas}
        onRombelChange={(newId) => setSelectedRombelId(newId)}
        onSuccessSave={handleUploadSuccess}
        showToast={showToast}
        existingCount={daftarSiswa.length}
      />

      {/* MODAL TAMBAH MANUAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border-2 border-emerald-300 w-full max-w-md overflow-hidden text-slate-800">
            <div className="bg-[#065f46] text-white p-4 flex items-center justify-between">
              <h3 className="font-extrabold text-sm flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-emerald-200" />
                <span>Tambah Siswa Manual ({currentRombel?.nama})</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-emerald-200 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveManualSiswa} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Nama Lengkap Siswa: <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Muhammad Al-Ghifari"
                  value={manualNama}
                  onChange={(e) => setManualNama(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  NISN <span className="text-slate-400 font-normal">(Opsional)</span>:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: 0012345678 (kosongkan jika belum ada)"
                  value={manualNisn}
                  onChange={(e) => setManualNisn(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Jenis Kelamin:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setManualGender("L")}
                    className={`py-2 px-3 rounded-xl font-bold border transition-all cursor-pointer ${
                      manualGender === "L"
                        ? "bg-blue-600 text-white border-blue-700 shadow-xs"
                        : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
                    }`}
                  >
                    L (Laki-laki)
                  </button>
                  <button
                    type="button"
                    onClick={() => setManualGender("P")}
                    className={`py-2 px-3 rounded-xl font-bold border transition-all cursor-pointer ${
                      manualGender === "P"
                        ? "bg-pink-600 text-white border-pink-700 shadow-xs"
                        : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
                    }`}
                  >
                    P (Perempuan)
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#065f46] hover:bg-emerald-800 text-white font-bold shadow-xs cursor-pointer"
                >
                  Simpan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL EDIT SISWA */}
      {editingSiswa && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border-2 border-emerald-300 w-full max-w-md overflow-hidden text-slate-800">
            <div className="bg-[#065f46] text-white p-4 flex items-center justify-between">
              <h3 className="font-extrabold text-sm flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-emerald-200" />
                <span>Edit Data Siswa</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingSiswa(null)}
                className="text-emerald-200 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Nama Lengkap Siswa:
                </label>
                <input
                  type="text"
                  required
                  value={editingSiswa.nama}
                  onChange={(e) => setEditingSiswa({ ...editingSiswa, nama: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  NISN:
                </label>
                <input
                  type="text"
                  value={editingSiswa.nisn}
                  onChange={(e) => setEditingSiswa({ ...editingSiswa, nisn: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Jenis Kelamin:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingSiswa({ ...editingSiswa, gender: "L" })}
                    className={`py-2 px-3 rounded-xl font-bold border transition-all cursor-pointer ${
                      editingSiswa.gender === "L"
                        ? "bg-blue-600 text-white border-blue-700 shadow-xs"
                        : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
                    }`}
                  >
                    L (Laki-laki)
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingSiswa({ ...editingSiswa, gender: "P" })}
                    className={`py-2 px-3 rounded-xl font-bold border transition-all cursor-pointer ${
                      editingSiswa.gender === "P"
                        ? "bg-pink-600 text-white border-pink-700 shadow-xs"
                        : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
                    }`}
                  >
                    P (Perempuan)
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingSiswa(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#065f46] hover:bg-emerald-800 text-white font-bold shadow-xs cursor-pointer"
                >
                  Perbarui Data
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
