import React, { useState, useMemo, useEffect } from 'react';
import {
  BookCheck,
  Edit3,
  Save,
  Download,
  Printer,
  Plus,
  Trash2,
  RotateCcw,
  Calendar,
  Clock,
  CheckCircle2,
  Filter,
  Sparkles,
  ExternalLink,
  Layers,
  Search,
  Check,
  CheckSquare,
  Users,
  CalendarDays,
  ArrowRight,
  GraduationCap,
  School,
  RefreshCw,
  SlidersHorizontal,
  Zap,
  MapPin,
  UserCheck,
  Building,
  Info,
  AlertTriangle,
  X
} from 'lucide-react';
import { ModalCetakJurnal } from './ModalCetakJurnal.tsx';

// ==========================================
// TIPE DATA & STRUKTUR
// ==========================================

export interface KelasRombelItem {
  id: string;
  tingkat: "I" | "II" | "III" | "IV" | "V" | "VI";
  nama: string; // e.g. "Kelas 1-A"
  fase: "A" | "B" | "C";
  waliKelas: string;
  jumlahSiswa: number;
  ruang: string;
}

export interface JadwalMengajarItem {
  id: string;
  kelasId: string;
  kelasNama: string;
  tingkat: "I" | "II" | "III" | "IV" | "V" | "VI";
  hari: "Senin" | "Selasa" | "Rabu" | "Kamis" | "Jumat" | "Sabtu";
  jamKe: string; // e.g. "1 - 3"
  waktu: string; // e.g. "07.15 - 09.00"
  alokasiJp: number; // e.g. 3
  semester: string; // "Semua" | "I (Ganjil)" | "II (Genap)"
  ruang?: string;
  keterangan?: string;
}

export interface JurnalMengajarItem {
  id: string;
  kelas: string;
  fase: string;
  semester: string;
  rombelId?: string;
  rombelNama?: string;
  modulId: string;
  modulNomor: number;
  pertemuanKe: number;
  hariTanggal: string;
  jamKe: string;
  alokasiJp: number;
  elemen: string;
  bab: string;
  materiPokok: string;
  tujuanPembelajaran: string;
  kegiatanPembelajaran: string;
  asesmen: string;
  kehadiranSiswa: string;
  refleksiKetercapaian: string;
  status: "Terlaksana" | "Tercapai" | "Terjadwal";
}

export type PeriodeCetakType = "semester" | "bulan" | "minggu" | "hari";

// Daftar nama bulan resmi Kurikulum Merdeka per semester
export const BULAN_SEMESTER_1 = ["Juli", "Agustus", "September", "Oktober", "November", "Desember"];
export const BULAN_SEMESTER_2 = ["Januari", "Februari", "Maret", "April", "Mei", "Juni"];

export const getMonthFromHariTanggal = (hariTanggal: string): string => {
  if (!hariTanggal) return "";
  const allMonths = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  for (const m of allMonths) {
    if (hariTanggal.toLowerCase().includes(m.toLowerCase())) {
      return m;
    }
  }
  return "";
};

export interface TabJurnalMengajarProps {
  modules: any[];
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
  setActiveTab?: (tab: string) => void;
  setSelectedKelas?: (kls: string) => void;
  setSelectedSemester?: (sem: string) => void;
  setActiveModulId?: (id: string) => void;
  daftarKelas?: KelasRombelItem[];
  setDaftarKelas?: React.Dispatch<React.SetStateAction<KelasRombelItem[]>>;
  jadwalMengajar?: JadwalMengajarItem[];
  setJadwalMengajar?: React.Dispatch<React.SetStateAction<JadwalMengajarItem[]>>;
  alokasiJpDefault?: 3 | 4;
  setAlokasiJpDefault?: (val: 3 | 4) => void;
}

// ==========================================
// DATA DEFAULT RESMI DAFTAR KELAS & JADWAL
// ==========================================

export const DEFAULT_DAFTAR_KELAS: KelasRombelItem[] = [
  { id: "kls-1a", tingkat: "I", nama: "Kelas 1-A", fase: "A", waliKelas: "Hj. Nurhasanah, S.Pd.", jumlahSiswa: 28, ruang: "Ruang Kelas 1A" },
  { id: "kls-2a", tingkat: "II", nama: "Kelas 2-A", fase: "A", waliKelas: "Dra. Siti Masitoh", jumlahSiswa: 28, ruang: "Ruang Kelas 2A" },
  { id: "kls-3a", tingkat: "III", nama: "Kelas 3-A", fase: "B", waliKelas: "Ahmad Fauzi, S.Pd.", jumlahSiswa: 30, ruang: "Ruang Kelas 3A" },
  { id: "kls-4a", tingkat: "IV", nama: "Kelas 4-A", fase: "B", waliKelas: "Endang Sulastri, S.Pd.", jumlahSiswa: 30, ruang: "Ruang Kelas 4A" },
  { id: "kls-5a", tingkat: "V", nama: "Kelas 5-A", fase: "C", waliKelas: "M. Ridwan, S.Pd.I.", jumlahSiswa: 32, ruang: "Ruang Kelas 5A" },
  { id: "kls-6a", tingkat: "VI", nama: "Kelas 6-A", fase: "C", waliKelas: "H. Abdul Wahid, M.Pd.", jumlahSiswa: 32, ruang: "Ruang Kelas 6A" },
];

export const DEFAULT_JADWAL_MENGAJAR: JadwalMengajarItem[] = [
  { id: "sch-1", kelasId: "kls-1a", kelasNama: "Kelas 1-A", tingkat: "I", hari: "Senin", jamKe: "1 - 3", waktu: "07.15 - 09.00", alokasiJp: 3, semester: "Semua", ruang: "Ruang Kelas 1A", keterangan: "3 JP Tatap Muka Inti" },
  { id: "sch-2", kelasId: "kls-2a", kelasNama: "Kelas 2-A", tingkat: "II", hari: "Selasa", jamKe: "1 - 3", waktu: "07.15 - 09.00", alokasiJp: 3, semester: "Semua", ruang: "Ruang Kelas 2A", keterangan: "3 JP Tatap Muka Inti" },
  { id: "sch-3", kelasId: "kls-3a", kelasNama: "Kelas 3-A", tingkat: "III", hari: "Rabu", jamKe: "1 - 3", waktu: "07.15 - 09.00", alokasiJp: 3, semester: "Semua", ruang: "Ruang Kelas 3A", keterangan: "3 JP Tatap Muka Inti" },
  { id: "sch-4", kelasId: "kls-4a", kelasNama: "Kelas 4-A", tingkat: "IV", hari: "Kamis", jamKe: "1 - 3", waktu: "07.15 - 09.00", alokasiJp: 3, semester: "Semua", ruang: "Ruang Kelas 4A", keterangan: "3 JP Tatap Muka Inti" },
  { id: "sch-5", kelasId: "kls-5a", kelasNama: "Kelas 5-A", tingkat: "V", hari: "Jumat", jamKe: "1 - 3", waktu: "07.15 - 08.45", alokasiJp: 3, semester: "Semua", ruang: "Ruang Kelas 5A", keterangan: "3 JP Tatap Muka (Jumat Pagi)" },
  { id: "sch-6", kelasId: "kls-6a", kelasNama: "Kelas 6-A", tingkat: "VI", hari: "Sabtu", jamKe: "1 - 3", waktu: "07.15 - 09.00", alokasiJp: 3, semester: "Semua", ruang: "Ruang Kelas 6A", keterangan: "3 JP Tatap Muka & Evaluasi" },
];

// ==========================================
// HELPER PERHITUNGAN TANGGAL & JADWAL
// ==========================================

export const calculateScheduleDate = (
  semester: string,
  weekIndex: number,
  hariNama?: string
): string => {
  const isGanjil = semester.includes("Ganjil") || semester.includes("I");
  const baseMonday = isGanjil ? new Date(2026, 6, 20) : new Date(2027, 0, 11);
  
  const dayOffsetMap: Record<string, number> = {
    "Senin": 0,
    "Selasa": 1,
    "Rabu": 2,
    "Kamis": 3,
    "Jumat": 4,
    "Sabtu": 5,
    "Minggu": 6
  };
  
  const offsetDays = (hariNama && dayOffsetMap[hariNama] !== undefined)
    ? dayOffsetMap[hariNama]
    : 0;
  
  const targetTime = baseMonday.getTime() + ((weekIndex - 1) * 7 + offsetDays) * 24 * 60 * 60 * 1000;
  const targetDate = new Date(targetTime);
  
  const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const months = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  
  const finalDayName = hariNama || days[targetDate.getDay()];
  const dateNum = targetDate.getDate();
  const monthName = months[targetDate.getMonth()];
  const yearNum = targetDate.getFullYear();
  
  return `${finalDayName}, ${dateNum} ${monthName} ${yearNum}`;
};

// Generator otomatis entri Jurnal Mengajar dari seluruh 78 Modul Ajar disesuaikan dengan Jadwal Mengajar & Rombel
export const generateDefaultJurnalList = (
  modules: any[],
  classes: KelasRombelItem[] = DEFAULT_DAFTAR_KELAS,
  schedule: JadwalMengajarItem[] = DEFAULT_JADWAL_MENGAJAR,
  defaultJp: number = 3
): JurnalMengajarItem[] => {
  const items: JurnalMengajarItem[] = [];
  const kelasOrder: ("I" | "II" | "III" | "IV" | "V" | "VI")[] = ["I", "II", "III", "IV", "V", "VI"];
  const semOrder = ["I (Ganjil)", "II (Genap)"];

  kelasOrder.forEach((kls) => {
    const rombel = classes.find((c) => c.tingkat === kls) || {
      id: `kls-${kls.toLowerCase()}`,
      tingkat: kls,
      nama: `Kelas ${kls}`,
      fase: (kls === "I" || kls === "II" ? "A" : kls === "III" || kls === "IV" ? "B" : "C") as "A" | "B" | "C",
      waliKelas: "Wali Kelas",
      jumlahSiswa: 28,
      ruang: `Ruang Kelas ${kls}`
    };

    const sch = schedule.find((s) => s.kelasId === rombel.id || s.tingkat === kls);
    const scheduledDay = sch?.hari || "Senin";
    const effectiveJp = sch?.alokasiJp || defaultJp || 3;
    const scheduledHours = sch
      ? `${sch.jamKe} (${sch.waktu}) • ${effectiveJp} JP`
      : `1 - ${effectiveJp} (07.15 - 09.00) • ${effectiveJp} JP`;

    semOrder.forEach((sem) => {
      const classMods = modules.filter((m) => m.kelas === kls && m.semester === sem);
      let weekCursor = 1;

      classMods.forEach((mod) => {
        const pertemuanList = mod.pertemuan || [];
        pertemuanList.forEach((pert: any, idx: number) => {
          const calculatedDate = calculateScheduleDate(sem, weekCursor, scheduledDay);
          const pertNum = pert.pertemuanKe || idx + 1;
          const babTitle = (mod.bab && !mod.bab.includes("undefined")) ? mod.bab : `Bab ${mod.nomor} (${mod.elemen || "PAI & BP"})`;
          const subJudulMatch = pert.judul ? pert.judul.replace(/^Pertemuan\s+Ke-\d+\s*\((.*)\)$/, '$1') : "";
          const subTopicFromMod = mod.subTopik?.[idx] || "";
          const materiTitle = (mod.materi && !mod.materi.includes("undefined")) 
            ? mod.materi 
            : (subTopicFromMod || subJudulMatch || mod.tp || "Materi Pokok Pembelajaran");

          items.push({
            id: `jm-${kls.toLowerCase()}-${sem.includes("Ganjil") ? "s1" : "s2"}-m${mod.nomor}-p${pertNum}`,
            kelas: kls,
            fase: mod.fase || rombel.fase,
            semester: sem,
            rombelId: rombel.id,
            rombelNama: rombel.nama,
            modulId: mod.id,
            modulNomor: mod.nomor,
            pertemuanKe: pertNum,
            hariTanggal: calculatedDate,
            jamKe: scheduledHours,
            alokasiJp: effectiveJp,
            elemen: mod.elemen || "Al-Qur’an-Hadis",
            bab: babTitle,
            materiPokok: materiTitle,
            tujuanPembelajaran: mod.tp,
            kegiatanPembelajaran: pert.kegiatan || `Aktivitas memahami materi "${materiTitle}". Murid berdiskusi kelompok, membaca ayat/lafaz, dan unjuk pemahaman mindful & joyful.`,
            asesmen: mod.asesmen ? mod.asesmen.split(".")[0] + " (Formatif & Unjuk Kerja)" : "Asesmen Formatif (Observasi Sikap & Kinerja)",
            kehadiranSiswa: `Hadir: ${rombel.jumlahSiswa}/${rombel.jumlahSiswa} (Lengkap)`,
            refleksiKetercapaian: "Seluruh murid antusias mengikuti pembelajaran dengan pendekatan mendalam (deep learning). 100% murid tuntas mencapai KKTP.",
            status: "Terlaksana"
          });

          weekCursor += 1;
        });
      });
    });
  });

  return items;
};

// ==========================================
// KOMPONEN UTAMA TAB JURNAL MENGAJAR
// ==========================================

export const TabJurnalMengajar: React.FC<TabJurnalMengajarProps> = ({
  modules,
  identitas,
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat,
  setActiveTab,
  setSelectedKelas,
  setSelectedSemester,
  setActiveModulId,
  daftarKelas: externalDaftarKelas,
  setDaftarKelas: setExternalDaftarKelas,
  jadwalMengajar: externalJadwalMengajar,
  setJadwalMengajar: setExternalJadwalMengajar,
  alokasiJpDefault = 3,
  setAlokasiJpDefault
}) => {
  // State Sub-Tab Tampilan: 'jurnal' (Lembar Jurnal Harian) | 'jadwal' (Input Rombel & Jadwal Mengajar)
  const [activeSubTab, setActiveSubTab] = useState<"jurnal" | "jadwal">("jurnal");

  // State Daftar Rombel / Kelas
  const [daftarKelas, setDaftarKelas] = useState<KelasRombelItem[]>(() => {
    if (externalDaftarKelas && externalDaftarKelas.length > 0) return externalDaftarKelas;
    try {
      const saved = localStorage.getItem("perangkat_daftar_kelas");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_DAFTAR_KELAS;
  });

  // State Jadwal Mengajar Mingguan
  const [jadwalMengajar, setJadwalMengajar] = useState<JadwalMengajarItem[]>(() => {
    if (externalJadwalMengajar && externalJadwalMengajar.length > 0) return externalJadwalMengajar;
    try {
      const saved = localStorage.getItem("perangkat_jadwal_mengajar");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_JADWAL_MENGAJAR;
  });

  // Sinkronisasi Daftar Kelas & Jadwal ke LocalStorage dan parent
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_daftar_kelas", JSON.stringify(daftarKelas));
      if (setExternalDaftarKelas) setExternalDaftarKelas(daftarKelas);
    } catch {}
  }, [daftarKelas]);

  useEffect(() => {
    try {
      localStorage.setItem("perangkat_jadwal_mengajar", JSON.stringify(jadwalMengajar));
      if (setExternalJadwalMengajar) setExternalJadwalMengajar(jadwalMengajar);
    } catch {}
  }, [jadwalMengajar]);

  // State Filter Jurnal
  const [filterKelas, setFilterKelas] = useState<string>("I");
  const [filterRombelId, setFilterRombelId] = useState<string>("Semua");
  const [filterSemester, setFilterSemester] = useState<string>("I (Ganjil)");
  const [searchKeyword, setSearchKeyword] = useState<string>("");
  const [isEditing, setIsEditing] = useState<boolean>(false);

  // State Pilihan Periode Cetak Jurnal (1 Semester / Per Bulan / Per Minggu / Per Hari)
  const [periodeCetak, setPeriodeCetak] = useState<PeriodeCetakType>("semester");
  const [selectedBulan, setSelectedBulan] = useState<string>("Juli");
  const [selectedMinggu, setSelectedMinggu] = useState<number>(1);
  const [selectedPertemuanHari, setSelectedPertemuanHari] = useState<string | number>("1");
  const [showModalCetak, setShowModalCetak] = useState<boolean>(false);

  // Sinkronkan pilihan bulan default saat semester berganti
  useEffect(() => {
    const isGanjil = filterSemester.includes("Ganjil") || filterSemester.includes("I");
    if (isGanjil) {
      if (!BULAN_SEMESTER_1.includes(selectedBulan)) {
        setSelectedBulan("Juli");
      }
    } else {
      if (!BULAN_SEMESTER_2.includes(selectedBulan)) {
        setSelectedBulan("Januari");
      }
    }
  }, [filterSemester]);

  // Form State untuk Tambah / Edit Rombel
  const [showAddRombelModal, setShowAddRombelModal] = useState(false);
  const [editingRombel, setEditingRombel] = useState<KelasRombelItem | null>(null);
  const [formRombel, setFormRombel] = useState<{
    tingkat: "I" | "II" | "III" | "IV" | "V" | "VI";
    nama: string;
    waliKelas: string;
    jumlahSiswa: number;
    ruang: string;
  }>({
    tingkat: "I",
    nama: "",
    waliKelas: "",
    jumlahSiswa: 28,
    ruang: ""
  });

  // Form State untuk Tambah / Edit Slot Jadwal
  const [showAddJadwalModal, setShowAddJadwalModal] = useState(false);
  const [editingJadwal, setEditingJadwal] = useState<JadwalMengajarItem | null>(null);
  const [formJadwal, setFormJadwal] = useState<{
    kelasId: string;
    hari: "Senin" | "Selasa" | "Rabu" | "Kamis" | "Jumat" | "Sabtu";
    jamKe: string;
    waktu: string;
    alokasiJp: number;
    semester: string;
    keterangan: string;
  }>({
    kelasId: daftarKelas[0]?.id || "kls-1a",
    hari: "Senin",
    jamKe: "1 - 3",
    waktu: "07.15 - 09.00",
    alokasiJp: 3,
    semester: "Semua",
    keterangan: "3 JP Tatap Muka Inti"
  });

  // Dialog Konfirmasi In-App (Pengganti window.confirm agar 100% bekerja di Iframe & Browser)
  const [deleteRombelDialog, setDeleteRombelDialog] = useState<{ show: boolean; item: KelasRombelItem | null }>({
    show: false,
    item: null
  });
  const [deleteJadwalDialog, setDeleteJadwalDialog] = useState<{ show: boolean; item: JadwalMengajarItem | null }>({
    show: false,
    item: null
  });
  const [deleteJurnalDialog, setDeleteJurnalDialog] = useState<{ show: boolean; item: JurnalMengajarItem | null }>({
    show: false,
    item: null
  });
  const [resetSyncDialog, setResetSyncDialog] = useState<boolean>(false);

  // State Data Jurnal Mengajar
  const [jurnalList, setJurnalList] = useState<JurnalMengajarItem[]>(() => {
    try {
      const saved = localStorage.getItem("perangkat_jurnal_mengajar");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Sanitasi otomatis data yang sebelumnya berisi "undefined"
          return parsed.map((item: any) => {
            let updated = { ...item };
            const hasUndefinedBab = !updated.bab || updated.bab.includes("undefined");
            const hasUndefinedMateri = !updated.materiPokok || updated.materiPokok.includes("undefined");
            if (hasUndefinedBab || hasUndefinedMateri) {
              const matchedMod = modules.find((m) => m.id === updated.modulId || (m.kelas === updated.kelas && m.nomor === updated.modulNomor));
              const pert = matchedMod?.pertemuan?.[(updated.pertemuanKe || 1) - 1];
              const subMatch = pert?.judul ? pert.judul.replace(/^Pertemuan\s+Ke-\d+\s*\((.*)\)$/, '$1') : "";
              const subTopic = matchedMod?.subTopik?.[(updated.pertemuanKe || 1) - 1] || "";
              if (hasUndefinedBab) {
                updated.bab = `Bab ${updated.modulNomor || (matchedMod?.nomor || 1)} (${updated.elemen || matchedMod?.elemen || "PAI & BP"})`;
              }
              if (hasUndefinedMateri) {
                updated.materiPokok = subTopic || subMatch || matchedMod?.tp || "Materi Pokok Pembelajaran";
              }
            }
            return updated;
          });
        }
      }
    } catch {}
    return generateDefaultJurnalList(modules, daftarKelas, jadwalMengajar, alokasiJpDefault || 3);
  });

  // Simpan otomatis jurnalList ke localStorage
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_jurnal_mengajar", JSON.stringify(jurnalList));
    } catch (e) {
      console.warn("Gagal menyimpan jurnal mengajar:", e);
    }
  }, [jurnalList]);

  // Dengarkan pembaruan sinkronisasi dari Buku Presensi Siswa
  useEffect(() => {
    const handleJurnalUpdated = () => {
      try {
        const saved = localStorage.getItem("perangkat_jurnal_mengajar");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setJurnalList(parsed);
          }
        }
      } catch {}
    };

    window.addEventListener("perangkat_jurnal_updated", handleJurnalUpdated);
    return () => {
      window.removeEventListener("perangkat_jurnal_updated", handleJurnalUpdated);
    };
  }, []);

  // Deteksi Rombel & Jadwal Aktif untuk Kelas / Filter yang dipilih
  const currentRombel = useMemo(() => {
    if (filterRombelId !== "Semua") {
      return daftarKelas.find((k) => k.id === filterRombelId);
    }
    return daftarKelas.find((k) => k.tingkat === filterKelas);
  }, [daftarKelas, filterRombelId, filterKelas]);

  const currentSchedule = useMemo(() => {
    if (currentRombel) {
      return jadwalMengajar.find((j) => j.kelasId === currentRombel.id || j.tingkat === currentRombel.tingkat);
    }
    return jadwalMengajar.find((j) => j.tingkat === filterKelas);
  }, [jadwalMengajar, currentRombel, filterKelas]);

  // 1. Data Terfilter Dasar (Berdasarkan Kelas, Rombel, Semester & Kata Kunci)
  const filteredJurnalBase = useMemo(() => {
    return jurnalList.filter((item) => {
      const matchKelas = filterKelas === "Semua" || item.kelas === filterKelas;
      const matchRombel =
        filterRombelId === "Semua" ||
        item.rombelId === filterRombelId ||
        (!item.rombelId && currentRombel && item.kelas === currentRombel.tingkat);
      const matchSemester = filterSemester === "Semua" || item.semester === filterSemester;
      const matchSearch =
        !searchKeyword ||
        (item.materiPokok || "").toLowerCase().includes(searchKeyword.toLowerCase()) ||
        (item.bab || "").toLowerCase().includes(searchKeyword.toLowerCase()) ||
        (item.elemen || "").toLowerCase().includes(searchKeyword.toLowerCase()) ||
        (item.tujuanPembelajaran || "").toLowerCase().includes(searchKeyword.toLowerCase());
      return matchKelas && matchRombel && matchSemester && matchSearch;
    });
  }, [jurnalList, filterKelas, filterRombelId, filterSemester, searchKeyword, currentRombel]);

  // Sinkronkan pilihan pertemuan hari default ke item pertama jika berganti kelas / semester
  useEffect(() => {
    if (filteredJurnalBase.length > 0) {
      const exists = filteredJurnalBase.some(
        (item, idx) =>
          item.id === String(selectedPertemuanHari) ||
          item.hariTanggal === String(selectedPertemuanHari) ||
          String(idx + 1) === String(selectedPertemuanHari)
      );
      if (!exists) {
        setSelectedPertemuanHari(filteredJurnalBase[0].id);
      }
    }
  }, [filterKelas, filterSemester, filterRombelId, filteredJurnalBase]);

  // 2. Data Terfilter Sesuai Pilihan Periode Cetak (1 Semester / Per Bulan / Per Minggu / Per Hari)
  const filteredJurnal = useMemo(() => {
    if (periodeCetak === "bulan") {
      return filteredJurnalBase.filter(
        (item) => getMonthFromHariTanggal(item.hariTanggal) === selectedBulan
      );
    }
    if (periodeCetak === "minggu") {
      const matched = filteredJurnalBase.filter((item, idx) => {
        return (idx + 1) === selectedMinggu || item.id === String(selectedMinggu);
      });
      if (matched.length > 0) return matched;
      return filteredJurnalBase.slice(0, 1);
    }
    if (periodeCetak === "hari") {
      const matched = filteredJurnalBase.filter((item, idx) => {
        if (selectedPertemuanHari && (item.id === String(selectedPertemuanHari) || item.hariTanggal === String(selectedPertemuanHari))) {
          return true;
        }
        if (selectedPertemuanHari && String(selectedPertemuanHari) === String(idx + 1)) {
          return true;
        }
        return false;
      });
      if (matched.length > 0) {
        // Tepat 1 pertemuan sesuai tanggal yang dipilih, tidak menampilkan pertemuan bab lain
        return matched.slice(0, 1);
      }
      return filteredJurnalBase.slice(0, 1);
    }
    return filteredJurnalBase;
  }, [filteredJurnalBase, periodeCetak, selectedBulan, selectedMinggu, selectedPertemuanHari]);

  // Generate Nama Berkas Cetak & Unduh Sesuai Periode dengan safe fallbacks
  const getDocFilename = () => {
    const rombelNama = (currentRombel?.nama || `Kelas_${filterKelas || "I"}`).replace(/\s+/g, "_");
    const sekolah = (identitas?.sekolah || "SD").replace(/\s+/g, "_");
    const sem = (filterSemester || "I").split(" ")[0];

    if (periodeCetak === "hari") {
      const activeItem = filteredJurnal[0];
      const tglSlug = activeItem?.hariTanggal
        ? activeItem.hariTanggal.replace(/[^a-zA-Z0-9]/g, "_")
        : `Pertemuan_${selectedPertemuanHari || 1}`;
      return `Jurnal_Harian_PAI_${rombelNama}_${tglSlug}_${sekolah}`;
    } else if (periodeCetak === "minggu") {
      return `Jurnal_Mingguan_PAI_${rombelNama}_Pekan_${selectedMinggu || 1}_Sem_${sem}_${sekolah}`;
    } else if (periodeCetak === "bulan") {
      return `Jurnal_Bulanan_PAI_${rombelNama}_Bulan_${selectedBulan || "Juli"}_Sem_${sem}_${sekolah}`;
    }
    return `Jurnal_1_Semester_PAI_${rombelNama}_Sem_${sem}_${sekolah}`;
  };

  // Statistik Jurnal
  const stats = useMemo(() => {
    const totalPertemuan = filteredJurnal.length;
    const totalJp = filteredJurnal.reduce((acc, cur) => acc + (cur.alokasiJp || 3), 0);
    const terlaksanaCount = filteredJurnal.filter((i) => i.status === "Terlaksana").length;
    return {
      totalPertemuan,
      totalJp,
      terlaksanaCount,
      persentase: totalPertemuan > 0 ? Math.round((terlaksanaCount / totalPertemuan) * 100) : 100
    };
  }, [filteredJurnal]);

  // Total JP Mengajar Mingguan Guru (dari Jadwal)
  const totalJpMingguan = useMemo(() => {
    return jadwalMengajar.reduce((acc, cur) => acc + (cur.alokasiJp || 3), 0);
  }, [jadwalMengajar]);

  // ==========================================
  // LOGIKA MENYESUAIKAN JURNAL DENGAN JADWAL
  // ==========================================

  // Sesuaikan Jurnal untuk 1 Kelas Tertentu berdasarkan Jadwal Mengajarnya
  const handleApplyScheduleToCurrentClass = () => {
    const targetKls = filterKelas === "Semua" ? "I" : filterKelas;
    const targetRombel = currentRombel || daftarKelas.find((k) => k.tingkat === targetKls);
    const sch = currentSchedule || jadwalMengajar.find((j) => j.tingkat === targetKls);

    if (!sch) {
      showToast(`Jadwal mengajar untuk Kelas ${targetKls} belum diinput. Silakan atur jadwal terlebih dahulu.`);
      return;
    }

    const scheduledDay = sch.hari;
    const scheduledHours = `${sch.jamKe} (${sch.waktu}) • ${sch.alokasiJp} JP`;
    const jumlahSiswa = targetRombel?.jumlahSiswa || 28;

    const semOrder = ["I (Ganjil)", "II (Genap)"];

    setJurnalList((prev) => {
      const nextList = [...prev];
      semOrder.forEach((sem) => {
        const itemsOfSem = nextList.filter((item) => item.kelas === targetKls && item.semester === sem);
        itemsOfSem.forEach((item, idx) => {
          const weekIdx = idx + 1;
          item.hariTanggal = calculateScheduleDate(sem, weekIdx, scheduledDay);
          item.jamKe = scheduledHours;
          item.alokasiJp = sch.alokasiJp || 3;
          if (targetRombel) {
            item.rombelId = targetRombel.id;
            item.rombelNama = targetRombel.nama;
            item.kehadiranSiswa = `Hadir: ${jumlahSiswa}/${jumlahSiswa} (Lengkap)`;
          }
        });
      });
      return nextList;
    });

    showToast(`Berhasil! Jurnal Kelas ${targetRombel?.nama || targetKls} otomatis disesuaikan dengan jadwal ${scheduledDay} (${sch.waktu}).`);
  };

  // Sesuaikan SELURUH Jurnal Mengajar untuk SEMUA Kelas dengan Jadwalnya masing-masing
  const handleApplyAllSchedulesToJurnal = () => {
    let totalUpdated = 0;
    setJurnalList((prev) => {
      const updatedList = prev.map((item) => {
        const sch = jadwalMengajar.find((j) => (item.rombelId && j.kelasId === item.rombelId) || j.tingkat === item.kelas);
        const rombel = daftarKelas.find((k) => (item.rombelId && k.id === item.rombelId) || k.tingkat === item.kelas);

        if (sch) {
          const calculatedDate = calculateScheduleDate(item.semester, item.pertemuanKe, sch.hari);
          const hours = `${sch.jamKe} (${sch.waktu}) • ${sch.alokasiJp} JP`;
          totalUpdated++;
          return {
            ...item,
            hariTanggal: calculatedDate,
            jamKe: hours,
            alokasiJp: sch.alokasiJp || 3,
            rombelId: rombel?.id || item.rombelId,
            rombelNama: rombel?.nama || item.rombelNama || `Kelas ${item.kelas}`,
            kehadiranSiswa: rombel ? `Hadir: ${rombel.jumlahSiswa}/${rombel.jumlahSiswa} (Lengkap)` : item.kehadiranSiswa
          };
        }
        return item;
      });
      return updatedList;
    });

    showToast(`Sukses! ${totalUpdated} pertemuan jurnal di semua kelas telah disinkronkan dengan jadwal mengajar mingguan.`);
  };

  // Sesuaikan Kehadiran Siswa pada Jurnal dengan Data Presensi / Absensi Siswa
  const handleSyncAttendanceFromPresensi = () => {
    const targetKls = filterKelas === "Semua" ? "I" : filterKelas;
    const targetRombel = currentRombel || daftarKelas.find((k) => k.tingkat === targetKls);
    const targetSem = filterSemester === "Semua" ? "I (Ganjil)" : filterSemester;
    const rombelId = targetRombel?.id || `kls-${targetKls.toLowerCase()}`;

    try {
      const rawAbsensi = localStorage.getItem(`perangkat_absensi_${rombelId}_${targetSem}`);
      const rawSiswa = localStorage.getItem(`perangkat_siswa_${rombelId}`);

      let siswaList: any[] = [];
      if (rawSiswa) {
        try {
          siswaList = JSON.parse(rawSiswa);
        } catch {}
      }
      const totalSiswa = siswaList.length || targetRombel?.jumlahSiswa || 28;

      let absensiData: Record<number, Record<string, string>> = {};
      if (rawAbsensi) {
        try {
          absensiData = JSON.parse(rawAbsensi);
        } catch {}
      }

      let updatedCount = 0;
      setJurnalList((prev) =>
        prev.map((item) => {
          const matchRombel =
            item.rombelId === rombelId || (!item.rombelId && item.kelas === targetKls);
          const matchSem = filterSemester === "Semua" || item.semester === targetSem;

          if (matchRombel && matchSem) {
            const pertKe = item.pertemuanKe;
            const pertMap = absensiData[pertKe];

            let hadir = 0;
            let sakit = 0;
            let izin = 0;
            let alpa = 0;

            if (pertMap && typeof pertMap === "object") {
              Object.values(pertMap).forEach((st) => {
                if (st === "H") hadir++;
                else if (st === "S") sakit++;
                else if (st === "I") izin++;
                else if (st === "A") alpa++;
              });
              const recordedCount = hadir + sakit + izin + alpa;
              if (recordedCount < totalSiswa) {
                hadir += totalSiswa - recordedCount;
              }
            } else {
              hadir = totalSiswa;
            }

            let kehadiranStr = "";
            if (hadir === totalSiswa) {
              kehadiranStr = `Hadir: ${totalSiswa}/${totalSiswa} (100% - Lengkap)`;
            } else {
              const pct = Math.round((hadir / totalSiswa) * 100);
              const parts = [`Hadir: ${hadir}/${totalSiswa} (${pct}%)`];
              if (sakit > 0) parts.push(`S: ${sakit}`);
              if (izin > 0) parts.push(`I: ${izin}`);
              if (alpa > 0) parts.push(`A: ${alpa}`);
              kehadiranStr = parts.join(" • ");
            }

            updatedCount++;
            return {
              ...item,
              kehadiranSiswa: kehadiranStr
            };
          }
          return item;
        })
      );

      showToast(
        `Berhasil! ${updatedCount} pertemuan jurnal ${targetRombel?.nama || `Kelas ${targetKls}`} disinkronkan dengan presensi siswa.`
      );
    } catch (e) {
      console.error(e);
      showToast("Gagal menyinkronkan dengan buku presensi siswa.");
    }
  };

  // Handler Update Field Jurnal Manual
  const handleUpdateItem = (id: string, field: keyof JurnalMengajarItem, value: any) => {
    setJurnalList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  // Handler Tambah Pertemuan Manual
  const handleAddManualRow = () => {
    const targetKelas = filterKelas === "Semua" ? "I" : filterKelas;
    const targetSem = filterSemester === "Semua" ? "I (Ganjil)" : filterSemester;
    const nextPert = filteredJurnal.length + 1;
    const sch = currentSchedule || jadwalMengajar.find((j) => j.tingkat === targetKelas);
    const dayName = sch?.hari || "Senin";
    const hours = sch ? `${sch.jamKe} (${sch.waktu}) • ${sch.alokasiJp} JP` : "1 - 3 (07.15 - 09.00) • 3 JP";
    const jmlSiswa = currentRombel?.jumlahSiswa || 28;

    const newItem: JurnalMengajarItem = {
      id: `jm-${Date.now()}`,
      kelas: targetKelas,
      fase: targetKelas === "I" || targetKelas === "II" ? "A" : targetKelas === "III" || targetKelas === "IV" ? "B" : "C",
      semester: targetSem,
      rombelId: currentRombel?.id,
      rombelNama: currentRombel?.nama || `Kelas ${targetKelas}`,
      modulId: "",
      modulNomor: nextPert,
      pertemuanKe: nextPert,
      hariTanggal: calculateScheduleDate(targetSem, nextPert, dayName),
      jamKe: hours,
      alokasiJp: sch?.alokasiJp || 3,
      elemen: "Al-Qur’an-Hadis",
      bab: "Pertemuan Tambahan / Penguatan Karakter",
      materiPokok: "Aktivitas Praktik Pembiasaan Ibadah & Literasi Qur'an",
      tujuanPembelajaran: "Murid mampu mempraktikkan materi pembelajaran dalam kehidupan sehari-hari.",
      kegiatanPembelajaran: "Pendahuluan: apersepsi & doa. Inti: unjuk kerja dan pendampingan terbimbing. Penutup: refleksi bersama.",
      asesmen: "Asesmen Formatif (Observasi Kinerja & Catatan Anekdot)",
      kehadiranSiswa: `Hadir: ${jmlSiswa}/${jmlSiswa}`,
      refleksiKetercapaian: "Kegiatan terlaksana dengan tertib dan lancar.",
      status: "Terlaksana"
    };

    setJurnalList((prev) => [...prev, newItem]);
    showToast("Baris pertemuan baru berhasil ditambahkan!");
  };

  // Handler Hapus Baris Jurnal dengan Dialog Konfirmasi
  const handleRequestDeleteJurnal = (item: JurnalMengajarItem) => {
    setDeleteJurnalDialog({ show: true, item });
  };

  const executeDeleteJurnal = () => {
    if (!deleteJurnalDialog.item) return;
    const { id, pertemuanKe, materiPokok } = deleteJurnalDialog.item;
    setJurnalList((prev) => prev.filter((item) => item.id !== id));
    showToast(`Pertemuan ke-${pertemuanKe} ("${(materiPokok || "Materi").slice(0, 30)}...") berhasil dihapus dari jurnal.`);
    setDeleteJurnalDialog({ show: false, item: null });
  };

  // Reset Ulang ke Modul Ajar + Jadwal dengan Dialog Konfirmasi
  const handleRequestResetSync = () => {
    setResetSyncDialog(true);
  };

  const executeResetToModulAjar = () => {
    const freshList = generateDefaultJurnalList(modules, daftarKelas, jadwalMengajar);
    setJurnalList(freshList);
    try {
      localStorage.setItem("perangkat_jurnal_mengajar", JSON.stringify(freshList));
    } catch {}
    showToast("Jurnal Mengajar berhasil disinkronkan kembali dengan 78 Modul Ajar & Jadwal Mengajar!");
    setResetSyncDialog(false);
  };

  // ==========================================
  // HANDLER DAFTAR ROMBEL KELAS
  // ==========================================

  const handleOpenAddRombel = () => {
    setEditingRombel(null);
    setFormRombel({
      tingkat: "I",
      nama: `Kelas 1-B`,
      waliKelas: "",
      jumlahSiswa: 28,
      ruang: "Ruang Kelas"
    });
    setShowAddRombelModal(true);
  };

  const handleOpenEditRombel = (item: KelasRombelItem) => {
    setEditingRombel(item);
    setFormRombel({
      tingkat: item.tingkat,
      nama: item.nama,
      waliKelas: item.waliKelas,
      jumlahSiswa: item.jumlahSiswa,
      ruang: item.ruang || ""
    });
    setShowAddRombelModal(true);
  };

  const handleSaveRombel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRombel.nama.trim()) {
      showToast("Nama kelas / rombel tidak boleh kosong.");
      return;
    }

    const calculatedFase: "A" | "B" | "C" =
      formRombel.tingkat === "I" || formRombel.tingkat === "II"
        ? "A"
        : formRombel.tingkat === "III" || formRombel.tingkat === "IV"
        ? "B"
        : "C";

    if (editingRombel) {
      setDaftarKelas((prev) =>
        prev.map((k) =>
          k.id === editingRombel.id
            ? {
                ...k,
                tingkat: formRombel.tingkat,
                nama: formRombel.nama,
                fase: calculatedFase,
                waliKelas: formRombel.waliKelas || "Wali Kelas",
                jumlahSiswa: Number(formRombel.jumlahSiswa) || 28,
                ruang: formRombel.ruang || `Ruang ${formRombel.nama}`
              }
            : k
        )
      );
      setJadwalMengajar((prev) =>
        prev.map((j) =>
          j.kelasId === editingRombel.id
            ? { ...j, kelasNama: formRombel.nama, tingkat: formRombel.tingkat }
            : j
        )
      );
      setJurnalList((prev) =>
        prev.map((item) =>
          item.rombelId === editingRombel.id
            ? { ...item, kelas: formRombel.tingkat, rombelNama: formRombel.nama }
            : item
        )
      );
      showToast(`Data ${formRombel.nama} berhasil diperbarui.`);
    } else {
      const newId = `kls-${Date.now().toString(36)}`;
      const newRombel: KelasRombelItem = {
        id: newId,
        tingkat: formRombel.tingkat,
        nama: formRombel.nama,
        fase: calculatedFase,
        waliKelas: formRombel.waliKelas || "Wali Kelas",
        jumlahSiswa: Number(formRombel.jumlahSiswa) || 28,
        ruang: formRombel.ruang || `Ruang ${formRombel.nama}`
      };
      setDaftarKelas((prev) => [...prev, newRombel]);

      // Otomatis buat entri jurnal mengajar untuk rombel baru yang diinput
      const newJournalItems = generateDefaultJurnalList(modules, [newRombel], jadwalMengajar, alokasiJpDefault || 3);
      setJurnalList((prev) => [...prev, ...newJournalItems]);

      // Langsung arahkan filter ke rombel baru ini
      setFilterRombelId(newId);
      setFilterKelas(formRombel.tingkat);

      showToast(`Kelas ${newRombel.nama} berhasil ditambahkan dan jurnal mengajarnya telah siap!`);
    }

    setShowAddRombelModal(false);
  };

  // Handler Hapus Rombel In-App Modal
  const handleRequestDeleteRombel = (item: KelasRombelItem) => {
    if (daftarKelas.length <= 1) {
      showToast("Minimal harus memiliki 1 rombel kelas dalam daftar.");
      return;
    }
    setDeleteRombelDialog({ show: true, item });
  };

  const executeDeleteRombel = () => {
    if (!deleteRombelDialog.item) return;
    const { id, nama } = deleteRombelDialog.item;
    setDaftarKelas((prev) => prev.filter((k) => k.id !== id));
    setJadwalMengajar((prev) => prev.filter((j) => j.kelasId !== id));
    setJurnalList((prev) => prev.filter((item) => item.rombelId !== id));
    if (filterRombelId === id) {
      setFilterRombelId("Semua");
    }
    showToast(`Rombel ${nama} dan jurnal terkait berhasil dihapus.`);
    setDeleteRombelDialog({ show: false, item: null });
  };

  // ==========================================
  // HANDLER JADWAL MENGAJAR MINGGUAN
  // ==========================================

  const handleOpenAddJadwal = (prefillHari?: "Senin" | "Selasa" | "Rabu" | "Kamis" | "Jumat" | "Sabtu") => {
    setEditingJadwal(null);
    setFormJadwal({
      kelasId: daftarKelas[0]?.id || "",
      hari: prefillHari || "Senin",
      jamKe: "1 - 3",
      waktu: "07.15 - 09.00",
      alokasiJp: 3,
      semester: "Semua",
      keterangan: "3 JP Tatap Muka Inti"
    });
    setShowAddJadwalModal(true);
  };

  const handleOpenEditJadwal = (item: JadwalMengajarItem) => {
    setEditingJadwal(item);
    setFormJadwal({
      kelasId: item.kelasId,
      hari: item.hari,
      jamKe: item.jamKe,
      waktu: item.waktu,
      alokasiJp: item.alokasiJp,
      semester: item.semester || "Semua",
      keterangan: item.keterangan || ""
    });
    setShowAddJadwalModal(true);
  };

  const handleSaveJadwal = (e: React.FormEvent) => {
    e.preventDefault();
    const rombel = daftarKelas.find((k) => k.id === formJadwal.kelasId);
    if (!rombel) {
      showToast("Pilih kelas yang valid untuk jadwal.");
      return;
    }

    if (editingJadwal) {
      setJadwalMengajar((prev) =>
        prev.map((j) =>
          j.id === editingJadwal.id
            ? {
                ...j,
                kelasId: rombel.id,
                kelasNama: rombel.nama,
                tingkat: rombel.tingkat,
                hari: formJadwal.hari,
                jamKe: formJadwal.jamKe,
                waktu: formJadwal.waktu,
                alokasiJp: Number(formJadwal.alokasiJp) || 3,
                semester: formJadwal.semester,
                ruang: rombel.ruang,
                keterangan: formJadwal.keterangan
              }
            : j
        )
      );
      showToast(`Jadwal hari ${formJadwal.hari} (${rombel.nama}) berhasil diperbarui.`);
    } else {
      const newSlot: JadwalMengajarItem = {
        id: `sch-${Date.now().toString(36)}`,
        kelasId: rombel.id,
        kelasNama: rombel.nama,
        tingkat: rombel.tingkat,
        hari: formJadwal.hari,
        jamKe: formJadwal.jamKe,
        waktu: formJadwal.waktu,
        alokasiJp: Number(formJadwal.alokasiJp) || 3,
        semester: formJadwal.semester,
        ruang: rombel.ruang,
        keterangan: formJadwal.keterangan || "3 JP Tatap Muka Inti"
      };
      setJadwalMengajar((prev) => [...prev, newSlot]);
      showToast(`Slot jadwal ${rombel.nama} (${formJadwal.hari}) berhasil ditambahkan!`);
    }

    setShowAddJadwalModal(false);
  };

  // Handler Hapus Slot Jadwal In-App Modal
  const handleRequestDeleteJadwal = (item: JadwalMengajarItem) => {
    setDeleteJadwalDialog({ show: true, item });
  };

  const executeDeleteJadwal = () => {
    if (!deleteJadwalDialog.item) return;
    const { id, kelasNama, hari } = deleteJadwalDialog.item;
    setJadwalMengajar((prev) => prev.filter((j) => j.id !== id));
    showToast(`Slot jadwal ${kelasNama} (${hari}) berhasil dihapus.`);
    setDeleteJadwalDialog({ show: false, item: null });
  };

  const currentFase =
    filterKelas === "I" || filterKelas === "II"
      ? "A"
      : filterKelas === "III" || filterKelas === "IV"
      ? "B"
      : "C";

  return (
    <div className="space-y-6">
      {/* ======================================================== */}
      {/* NAVIGASI SUB-TAB: JURNAL MENGAJAR vs JADWAL & ROMBEL     */}
      {/* ======================================================== */}
      <div className="bg-white rounded-2xl p-2.5 border-2 border-emerald-300 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 no-print">
        <div className="flex items-center gap-1.5 p-1 bg-emerald-50 rounded-xl border border-emerald-200">
          <button
            onClick={() => setActiveSubTab("jurnal")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === "jurnal"
                ? "bg-[#065f46] text-white shadow-md shadow-emerald-950/20"
                : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100"
            }`}
          >
            <BookCheck className="w-4 h-4" />
            <span>📖 Lembar Jurnal Mengajar Harian</span>
          </button>

          <button
            onClick={() => setActiveSubTab("jadwal")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === "jadwal"
                ? "bg-[#065f46] text-white shadow-md shadow-emerald-950/20"
                : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100"
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            <span>📅 Daftar Kelas &amp; Jadwal Mengajar ({daftarKelas.length} Rombel • {totalJpMingguan} JP)</span>
          </button>
        </div>

        <div className="flex items-center gap-2 px-2 text-xs font-semibold text-slate-700">
          <Info className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>Klik tombol merah <strong>[🗑️ Hapus]</strong> di kolom Aksi untuk menghapus baris jurnal yang tidak sesuai.</span>
        </div>
      </div>

      {/* ======================================================== */}
      {/* TAMPILAN 1: LEMBAR JURNAL MENGAJAR HARIAN                */}
      {/* ======================================================== */}
      {activeSubTab === "jurnal" && (
        <div className="space-y-6">
          {/* Panel Toolbar & Filter Jurnal Mengajar */}
          <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-5 no-print text-slate-800">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Administrasi Harian Terintegrasi Kurikulum Merdeka &amp; Jadwal Mengajar</span>
                </div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
                  <BookCheck className="w-5 h-5 text-emerald-700" />
                  <span>Jurnal Mengajar Harian Guru PAI &amp; Budi Pekerti</span>
                </h2>
                <p className="text-xs text-slate-600 mt-0.5 font-medium">
                  Agenda dan catatan pelaksanaan pembelajaran harian yang <strong>terintegrasi langsung</strong> dengan Program Semester (PROMES), 78 Modul Ajar Deep Learning, dan Jadwal Mengajar Kelas.
                </p>
              </div>

              {/* Tombol Aksi Cetak & Unduh Word */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Selector Alokasi JP (3 JP / 4 JP) */}
                <div className="flex items-center gap-1 bg-emerald-50 border border-emerald-300 p-1 rounded-xl">
                  <span className="text-[11px] font-bold text-emerald-950 px-1.5">Alokasi:</span>
                  {([3, 4] as const).map((jp) => (
                    <button
                      key={jp}
                      type="button"
                      onClick={() => {
                        if (setAlokasiJpDefault) setAlokasiJpDefault(jp);
                        setJurnalList((prev) =>
                          prev.map((item) => ({
                            ...item,
                            alokasiJp: jp,
                            jamKe: item.jamKe
                              .replace(/•\s*\d+\s*JP/, `• ${jp} JP`)
                              .replace(/^1\s*-\s*\d+/, `1 - ${jp}`)
                          }))
                        );
                        showToast(`Alokasi jurnal mengajar disesuaikan ke ${jp} JP per pertemuan`);
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                        (alokasiJpDefault || 3) === jp
                          ? "bg-[#065f46] text-white shadow-xs"
                          : "text-emerald-900 hover:bg-emerald-200/60"
                      }`}
                    >
                      {jp} JP
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    isEditing
                      ? "bg-amber-400 text-slate-950 border-amber-500 shadow-sm"
                      : "bg-white text-slate-800 border-slate-300 hover:bg-emerald-50"
                  }`}
                >
                  <Edit3 className="w-4 h-4 text-amber-700" />
                  <span>{isEditing ? "Tutup Editor" : "Edit Jurnal"}</span>
                </button>

                <button
                  onClick={handleAddManualRow}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-all cursor-pointer shadow-xs"
                  title="Tambah entri jurnal / pertemuan tambahan"
                >
                  <Plus className="w-4 h-4 text-emerald-700" />
                  <span>Tambah Pertemuan</span>
                </button>

                <button
                  type="button"
                  onClick={handleSyncAttendanceFromPresensi}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white transition-all cursor-pointer shadow-xs"
                  title="Ambil dan sinkronkan catatan kehadiran murid dari Buku Presensi Siswa"
                >
                  <UserCheck className="w-4 h-4 text-amber-300" />
                  <span>Ambil dari Presensi</span>
                </button>

                <button
                  onClick={handleRequestResetSync}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-all cursor-pointer shadow-xs"
                  title="Sinkronkan ulang materi dengan Modul Ajar dan Jadwal Mengajar"
                >
                  <RotateCcw className="w-4 h-4 text-slate-600" />
                  <span>Sinkronkan Ulang</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowModalCetak(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-md transition-all cursor-pointer"
                  title="Pilihan cetak jurnal: per hari, per minggu, per bulan, atau 1 semester"
                >
                  <Printer className="w-4 h-4 text-slate-950" />
                  <span>Cetak Jurnal (Pilihan Periode)</span>
                </button>

                <button
                  onClick={() =>
                    handleDownloadWord(
                      "printable-area",
                      getDocFilename(),
                      true
                    )
                  }
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  title="Unduh jurnal sesuai periode aktif ke format Word"
                >
                  <Download className="w-4 h-4 text-emerald-700" />
                  <span>Unduh Word (.doc)</span>
                </button>

                <button
                  onClick={() =>
                    handlePrintDocument(
                      "printable-area",
                      getDocFilename(),
                      "landscape"
                    )
                  }
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-950 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  title="Simpan / cetak PDF A4 sesuai periode aktif"
                >
                  <Printer className="w-4 h-4 text-emerald-800" />
                  <span>Simpan PDF (A4)</span>
                </button>
              </div>
            </div>

            {/* Banner Jadwal Terhubung untuk Kelas yang Dipilih */}
            <div className="p-3.5 bg-[#e6f7ef] border border-emerald-300 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-700 text-white rounded-xl shadow-xs shrink-0">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-extrabold text-slate-900 flex items-center gap-2 flex-wrap">
                    <span>Jadwal Terhubung: {currentRombel?.nama || `Kelas ${filterKelas}`}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-950 border border-emerald-300 font-bold">
                      Fase {currentFase}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-700 mt-0.5 font-medium">
                    {currentSchedule ? (
                      <>
                        Diajar setiap hari <strong>{currentSchedule.hari}</strong>, Pukul <strong>{currentSchedule.waktu}</strong> (Jam ke {currentSchedule.jamKe}, {currentSchedule.alokasiJp} JP) • Ruang: <strong>{currentSchedule.ruang || currentRombel?.ruang || "-"}</strong> • Wali Kelas: <strong>{currentRombel?.waliKelas || "-"}</strong> ({currentRombel?.jumlahSiswa || 28} Murid)
                      </>
                    ) : (
                      <span className="text-amber-800 font-bold">
                        ⚠️ Belum ada jadwal mingguan untuk kelas ini. Klik tombol di kanan untuk mengatur jadwal.
                      </span>
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
                <button
                  type="button"
                  onClick={handleApplyScheduleToCurrentClass}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
                  title="Sesuaikan tanggal dan jam pada seluruh baris jurnal kelas ini dengan jadwal mengajar"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-300" />
                  <span>Sesuaikan dengan Jadwal Ini</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab("jadwal")}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-100 text-emerald-950 border border-emerald-300 transition-all cursor-pointer"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Atur Jadwal</span>
                </button>
              </div>
            </div>

            {/* Bilah Pilihan Cepat Rombel yang Diinput */}
            <div className="bg-[#e6f7ef] p-3.5 rounded-2xl border-2 border-emerald-300 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs font-extrabold text-emerald-950 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-700" />
                  <span>Jurnal untuk Rombel yang Diinput (Klik Kelas untuk Menampilkan Jurnalnya):</span>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveSubTab("jadwal")}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-950 underline flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Tambah / Input Rombel Baru</span>
                </button>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {daftarKelas.map((k) => {
                  const isSel = filterRombelId === k.id || (filterRombelId === "Semua" && currentRombel?.id === k.id);
                  const sch = jadwalMengajar.find((j) => j.kelasId === k.id);
                  return (
                    <button
                      key={k.id}
                      type="button"
                      onClick={() => {
                        setFilterRombelId(k.id);
                        setFilterKelas(k.tingkat);
                      }}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-2 ${
                        isSel
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md ring-2 ring-emerald-400"
                          : "bg-white text-slate-700 border-slate-300 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      <span>{k.nama}</span>
                      <span className={`text-[10.5px] px-2 py-0.5 rounded-md font-semibold ${isSel ? "bg-white/20 text-white" : "bg-emerald-100 text-emerald-900 border border-emerald-300"}`}>
                        {sch ? `${sch.hari} (${sch.jamKe})` : `${k.jumlahSiswa} Siswa`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Filter Kelas, Rombel, Semester & Pencarian */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
              {/* Filter Tingkat Kelas */}
              <div className="lg:col-span-3">
                <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
                  Tingkat Kelas:
                </label>
                <div className="grid grid-cols-7 gap-1">
                  {["Semua", "I", "II", "III", "IV", "V", "VI"].map((kls) => (
                    <button
                      key={kls}
                      onClick={() => {
                        setFilterKelas(kls);
                        setFilterRombelId("Semua");
                      }}
                      className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        filterKelas === kls
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      {kls}
                    </button>
                  ))}
                </div>
              </div>

              {/* Filter Rombongan Belajar (Rombel yang diinput) */}
              <div className="lg:col-span-3">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[11px] font-extrabold text-slate-700 uppercase tracking-wider">
                    Pilih Rombel / Kelas Input:
                  </label>
                  <button
                    type="button"
                    onClick={() => setActiveSubTab("jadwal")}
                    className="text-[10px] font-bold text-emerald-800 hover:underline"
                  >
                    + Kelola Rombel
                  </button>
                </div>
                <select
                  value={filterRombelId}
                  onChange={(e) => {
                    setFilterRombelId(e.target.value);
                    if (e.target.value !== "Semua") {
                      const found = daftarKelas.find((k) => k.id === e.target.value);
                      if (found) setFilterKelas(found.tingkat);
                    }
                  }}
                  className="w-full text-xs px-3 py-2 rounded-xl bg-emerald-50/70 border border-emerald-300 text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  <option value="Semua">Semua Rombel (Tingkat {filterKelas})</option>
                  {daftarKelas
                    .filter((k) => filterKelas === "Semua" || k.tingkat === filterKelas)
                    .map((k) => {
                      const sch = jadwalMengajar.find((j) => j.kelasId === k.id);
                      return (
                        <option key={k.id} value={k.id}>
                          {k.nama} • {sch ? `${sch.hari} (${sch.waktu})` : "Belum ada jadwal"} • {k.jumlahSiswa} Murid
                        </option>
                      );
                    })}
                </select>
              </div>

              {/* Filter Semester */}
              <div className="lg:col-span-2">
                <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
                  Semester:
                </label>
                <div className="grid grid-cols-2 gap-1">
                  {["I (Ganjil)", "II (Genap)"].map((sem) => (
                    <button
                      key={sem}
                      onClick={() => setFilterSemester(sem)}
                      className={`py-2 px-1 text-center rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        filterSemester === sem
                          ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                          : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                      }`}
                    >
                      {sem.split(" ")[0]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Cari Pembelajaran */}
              <div className="lg:col-span-2">
                <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
                  Cari Pembelajaran:
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-emerald-700 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Cari materi / TP..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-emerald-50/60 border border-emerald-300 text-slate-900 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              {/* Ringkasan Statistik */}
              <div className="lg:col-span-2 grid grid-cols-2 gap-1.5">
                <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2 text-center shadow-xs">
                  <span className="block text-[9px] text-emerald-900 uppercase font-extrabold">Pertemuan</span>
                  <span className="text-sm font-extrabold text-emerald-800">{stats.totalPertemuan}x</span>
                </div>
                <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-2 text-center shadow-xs">
                  <span className="block text-[9px] text-teal-900 uppercase font-extrabold">Total JP</span>
                  <span className="text-sm font-extrabold text-teal-800">{stats.totalJp} JP</span>
                </div>
              </div>
            </div>

            {/* Petunjuk Aksi Hapus Baris Jurnal */}
            <div className="flex items-center justify-between flex-wrap gap-2 pt-3 border-t border-emerald-200 text-xs">
              <div className="flex items-center gap-2 text-slate-700 font-medium">
                <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 border border-rose-300 font-bold text-[11px]">
                  Tombol Aksi Hapus
                </span>
                <span>
                  Gunakan tombol merah <strong>[🗑️ Hapus]</strong> di kolom paling kanan tabel di bawah untuk menghapus pertemuan atau materi jurnal yang <strong>tidak sesuai</strong>.
                </span>
              </div>
              {jurnalList.length < 78 * 2 && (
                <button
                  type="button"
                  onClick={handleRequestResetSync}
                  className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 underline flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3 text-emerald-700" />
                  <span>Pulihkan / Reset Semua Data Modul</span>
                </button>
              )}
            </div>
          </div>

          {/* ======================================================== */}
          {/* BILAH PILIHAN PERIODE CETAK JURNAL (1 SEMESTER / BULAN / MINGGU / HARI) */}
          {/* ======================================================== */}
          <div className="bg-white rounded-2xl border-2 border-emerald-300 p-4 space-y-3 shadow-xs text-slate-800 no-print">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                  <Printer className="w-4 h-4 text-emerald-800" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-slate-900 uppercase tracking-wide flex items-center gap-2">
                    <span>Pilihan Periode Tampilan &amp; Cetak Jurnal</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-950 font-bold border border-emerald-300">
                      Aktif: {periodeCetak === "semester" ? "1 Semester" : periodeCetak === "bulan" ? `Bulan ${selectedBulan}` : periodeCetak === "minggu" ? `Pekan Ke-${selectedMinggu}` : `Harian (${filteredJurnal[0]?.hariTanggal || "1 Pertemuan"})`}
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Pilih rentang cetak: <strong>1 Semester</strong>, <strong>Per Bulan</strong>, <strong>Per Minggu</strong>, atau <strong>Per Hari</strong> untuk disesuaikan dengan kebutuhan administrasi &amp; supervisi.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowModalCetak(true)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-xs transition-all cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-slate-950" />
                  <span>Dialog Cetak Jurnal...</span>
                </button>
              </div>
            </div>

            {/* 4 Pilihan Utama Periode */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: "semester", label: "1 Semester Penuh", icon: "📅", desc: "Seluruh pertemuan semester" },
                { id: "bulan", label: "Per Bulan", icon: "🗓️", desc: "Laporan bulanan guru / TPG" },
                { id: "minggu", label: "Per Minggu (Pekan)", icon: "📆", desc: "Pekan efektif belajar" },
                { id: "hari", label: "Per Hari (Pertemuan)", icon: "📝", desc: "Lembar jurnal harian" }
              ].map((p) => {
                const isSel = periodeCetak === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPeriodeCetak(p.id as PeriodeCetakType)}
                    className={`p-2.5 rounded-xl border-2 text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSel
                        ? "bg-[#065f46] text-white border-emerald-800 shadow-md ring-2 ring-emerald-400"
                        : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100"
                    }`}
                  >
                    <div>
                      <span className="block font-extrabold text-xs">{p.label}</span>
                      <span className={`text-[10px] ${isSel ? "text-emerald-100" : "text-slate-500"}`}>{p.desc}</span>
                    </div>
                    <span className="text-base shrink-0">{p.icon}</span>
                  </button>
                );
              })}
            </div>

            {/* Parameter Sub-Pilihan Berdasarkan Periode yang Aktif */}
            {periodeCetak === "bulan" && (
              <div className="pt-2 border-t border-emerald-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <span className="font-bold text-slate-700 shrink-0">Pilih Bulan ({filterSemester}):</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {(filterSemester.includes("Ganjil") || filterSemester.includes("I") ? BULAN_SEMESTER_1 : BULAN_SEMESTER_2).map((b) => {
                    const isB = selectedBulan === b;
                    const countB = filteredJurnalBase.filter((item) => getMonthFromHariTanggal(item.hariTanggal) === b).length;
                    return (
                      <button
                        key={b}
                        type="button"
                        onClick={() => setSelectedBulan(b)}
                        className={`px-3 py-1.5 rounded-lg font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                          isB
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-xs"
                            : "bg-white text-slate-700 border-slate-300 hover:bg-emerald-50"
                        }`}
                      >
                        <span>{b}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${isB ? "bg-white/20 text-white" : "bg-emerald-100 text-emerald-950 border border-emerald-200"}`}>
                          {countB}x
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {periodeCetak === "minggu" && (
              <div className="pt-2 border-t border-emerald-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <span className="font-bold text-slate-700 shrink-0">Pilih Pekan Efektif:</span>
                <div className="flex flex-wrap items-center gap-1.5 max-h-24 overflow-y-auto p-1">
                  {filteredJurnalBase.map((item, idx) => {
                    const pekanNum = idx + 1;
                    const isMg = selectedMinggu === pekanNum;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setSelectedMinggu(pekanNum)}
                        className={`px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                          isMg
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-xs"
                            : "bg-white text-slate-700 border-slate-300 hover:bg-emerald-50"
                        }`}
                        title={`${item.hariTanggal} • ${item.materiPokok}`}
                      >
                        Pekan {pekanNum}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {periodeCetak === "hari" && (
              <div className="pt-2 border-t border-emerald-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <span className="font-bold text-slate-700 shrink-0">Pilih Pertemuan Sesuai Tanggal:</span>
                <select
                  value={
                    filteredJurnalBase.some((item) => item.id === String(selectedPertemuanHari))
                      ? String(selectedPertemuanHari)
                      : (filteredJurnalBase.find((item) => item.hariTanggal === String(selectedPertemuanHari))?.id ||
                         filteredJurnalBase.find((item, idx) => String(idx + 1) === String(selectedPertemuanHari))?.id ||
                         filteredJurnalBase[0]?.id || "")
                  }
                  onChange={(e) => setSelectedPertemuanHari(e.target.value)}
                  className="w-full sm:w-auto flex-1 font-bold px-3 py-1.5 rounded-lg border border-emerald-300 bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  {filteredJurnalBase.map((item, idx) => (
                    <option key={item.id} value={item.id}>
                      Pertemuan #{idx + 1} ({item.hariTanggal}) • {item.bab} ({(item.materiPokok || "Materi").slice(0, 50)}...)
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Panel Editor Cepat (Muncul jika tombol Edit Jurnal aktif) */}
          {isEditing && (
            <div className="bg-white border-2 border-amber-400 rounded-2xl p-5 space-y-4 shadow-md no-print text-slate-800">
              <div className="flex items-center justify-between border-b border-amber-200 pb-3">
                <h3 className="text-sm font-bold text-amber-900 flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-amber-600" />
                  <span>Editor Kustomisasi Jurnal Harian Mengajar Guru ({currentRombel?.nama || `Kelas ${filterKelas}`} - {filterSemester})</span>
                </h3>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    showToast("Perubahan jurnal mengajar berhasil disimpan!");
                  }}
                  className="px-4 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Selesai &amp; Simpan</span>
                </button>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                Anda dapat menyesuaikan Hari/Tanggal tatap muka, Jam Ke-, Kehadiran Siswa, serta Catatan Refleksi Guru untuk setiap pertemuan. Perubahan langsung terupdate pada lembar cetak di bawah ini:
              </p>
              <div className="max-h-72 overflow-y-auto space-y-3 pr-2">
                {filteredJurnal.map((item) => (
                  <div key={item.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-950 border border-emerald-300">
                          Pertemuan {item.pertemuanKe} ({item.rombelNama || `Kelas ${item.kelas}`})
                        </span>
                        <span className="text-xs font-bold text-slate-900">{item.bab}</span>
                      </div>
                      <button
                        onClick={() => handleRequestDeleteJurnal(item)}
                        className="flex items-center gap-1 px-2 py-1 text-xs font-bold text-rose-600 hover:text-white hover:bg-rose-600 rounded-lg border border-rose-200 transition-colors cursor-pointer"
                        title="Hapus baris ini"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Hapus Pertemuan</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Hari &amp; Tanggal:</label>
                        <input
                          type="text"
                          value={item.hariTanggal}
                          onChange={(e) => handleUpdateItem(item.id, "hariTanggal", e.target.value)}
                          className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Jam Ke- &amp; JP:</label>
                        <input
                          type="text"
                          value={item.jamKe}
                          onChange={(e) => handleUpdateItem(item.id, "jamKe", e.target.value)}
                          className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Kehadiran Siswa:</label>
                        <input
                          type="text"
                          value={item.kehadiranSiswa}
                          onChange={(e) => handleUpdateItem(item.id, "kehadiranSiswa", e.target.value)}
                          className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Status Pelaksanaan:</label>
                        <select
                          value={item.status}
                          onChange={(e) => handleUpdateItem(item.id, "status", e.target.value as any)}
                          className="w-full text-xs px-2 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 font-semibold"
                        >
                          <option value="Terlaksana">Terlaksana</option>
                          <option value="Tercapai">Tercapai</option>
                          <option value="Terjadwal">Terjadwal</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Catatan Refleksi / Ketercapaian:</label>
                      <input
                        type="text"
                        value={item.refleksiKetercapaian}
                        onChange={(e) => handleUpdateItem(item.id, "refleksiKetercapaian", e.target.value)}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-900 font-medium"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* LEMBAR DOKUMEN CETAK RESMI: JURNAL HARIAN MENGAJAR GURU  */}
          {/* ======================================================== */}
          <div
            id="printable-area"
            style={paperLightMode ? { padding: "2cm 2cm 2cm 2.5cm" } : undefined}
            className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 overflow-x-auto ${docContainerClass} official-doc-typography`}
          >
            {/* KOP SURAT RESMI */}
            {useKopSurat && kopSuratUrl && (
              <div className="kop-surat-header mb-4 text-center">
                <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
              </div>
            )}

            {/* Judul Utama Dokumen Jurnal Mengajar */}
            <div className="doc-header-box text-center border-b-2 pb-4 mb-6 border-black">
              <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                {periodeCetak === "hari" && `JURNAL HARIAN PELAKSANAAN PEMBELAJARAN (HARIAN)`}
                {periodeCetak === "minggu" && `JURNAL PELAKSANAAN PEMBELAJARAN MINGGUAN (PEKAN KE-${selectedMinggu || 1})`}
                {periodeCetak === "bulan" && `JURNAL PELAKSANAAN PEMBELAJARAN BULANAN (BULAN ${(selectedBulan || "Juli").toUpperCase()})`}
                {periodeCetak === "semester" && `JURNAL HARIAN PELAKSANAAN PEMBELAJARAN (JURNAL MENGAJAR GURU)`}
              </h2>
              <h3 className="doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
              </h3>
              <p className="text-xs sm:text-[11pt] font-semibold text-center mt-1" style={{ margin: "2pt 0 0 0" }}>
                KURIKULUM MERDEKA • PEMBELAJARAN MENDALAM (DEEP LEARNING)
              </p>
            </div>

            {/* Identitas Dokumen (Rata Kiri, Titik Dua Sejajar Rapi) */}
            <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-2xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Satuan Pendidikan</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">{identitas?.sekolah || "SD Negeri"}</span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Kelas / Rombel / Fase</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">
                  {currentRombel ? `${currentRombel.nama} (Tingkat ${currentRombel.tingkat})` : `Kelas ${filterKelas || "I"}`} / Fase {currentFase || "A"}
                </span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Semester / Tahun Ajaran</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">
                  {filterSemester === "Semua" ? "Semester I & II" : (filterSemester || "I (Ganjil)")} / {identitas?.tahunAjaran || "2026/2027"}
                </span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Periode Jurnal</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">
                  {periodeCetak === "semester" && `1 Semester Penuh (${filterSemester === "Semua" ? "Semester I & II" : (filterSemester || "I (Ganjil)")})`}
                  {periodeCetak === "bulan" && `Bulan ${selectedBulan || "Juli"} • ${filterSemester || "I (Ganjil)"}`}
                  {periodeCetak === "minggu" && `Pekan Ke-${selectedMinggu || 1} • ${filterSemester || "I (Ganjil)"}`}
                  {periodeCetak === "hari" && (
                    filteredJurnal[0]
                      ? `${filteredJurnal[0].hariTanggal} (Pertemuan Ke-${filteredJurnal[0].pertemuanKe || 1})`
                      : `Pertemuan Ke-${selectedPertemuanHari || 1} • ${filterSemester || "I (Ganjil)"}`
                  )}
                </span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Guru Mata Pelajaran</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">{identitas.guruPai} (NIP. {identitas.nipGuru})</span>
              </div>
            </div>

            {/* Tabel Utama Jurnal Mengajar */}
            <div className="overflow-x-auto print:overflow-visible">
              <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%' }}>
                <thead>
                  <tr className={tableHeaderBgClass}>
                    <th className={`border px-2 py-2 text-center font-bold w-[4%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      No
                    </th>
                    <th className={`border px-2.5 py-2 text-center font-bold w-[13%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Hari / Tanggal
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[9%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Jam Ke- &amp; JP
                    </th>
                    <th className={`border px-3 py-2 text-center font-bold w-[17%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Bab &amp; Materi Pokok Pembelajaran
                    </th>
                    <th className={`border px-3 py-2 text-center font-bold w-[18%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Tujuan Pembelajaran (TP Modul)
                    </th>
                    <th className={`border px-3 py-2 text-center font-bold w-[17%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Kegiatan Pembelajaran (Aktivitas)
                    </th>
                    <th className={`border px-2.5 py-2 text-center font-bold w-[9%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Bentuk Asesmen
                    </th>
                    <th className={`border px-2.5 py-2 text-center font-bold w-[9%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Kehadiran &amp; Refleksi Guru
                    </th>
                    {/* KOLOM AKSI HAPUS (HANYA DITAMPILKAN DI LAYAR / EDITOR, OTOMATIS TIDAK TERCETAK SAAT PRINT / WORD) */}
                    <th
                      className={`border px-2 py-2 text-center font-bold w-[6%] no-print ${tableBorderClass}`}
                      style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', backgroundColor: '#fef2f2', color: '#991b1b' }}
                    >
                      Aksi
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredJurnal.length === 0 ? (
                    <tr>
                      <td colSpan={9} className={`border px-4 py-8 text-center text-slate-500 italic ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                        Tidak ada data jurnal mengajar yang sesuai dengan filter kelas atau semester yang dipilih.
                      </td>
                    </tr>
                  ) : (
                    filteredJurnal.map((item, idx) => (
                      <tr key={item.id} className="keep-together">
                        <td className={`border px-2 py-2 text-center font-bold align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'center' }}>
                          {idx + 1}
                        </td>
                        <td className={`border px-2.5 py-2 align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'left' }}>
                          <div className="font-bold">{item.hariTanggal}</div>
                          <div className="text-[10px] text-slate-600 mt-0.5">Pertemuan Ke-{item.pertemuanKe}</div>
                          {item.modulId && setActiveTab && setSelectedKelas && setSelectedSemester && setActiveModulId && (
                            <button
                              onClick={() => {
                                setSelectedKelas(item.kelas);
                                setSelectedSemester(item.semester);
                                setActiveModulId(item.modulId);
                                setActiveTab("modul");
                                showToast(`Membuka Modul Ajar ${item.modulNomor} Kelas ${item.kelas}`);
                              }}
                              className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-900 border border-emerald-300 font-sans font-semibold hover:bg-emerald-200 transition-colors no-print cursor-pointer"
                            >
                              <ExternalLink className="w-2.5 h-2.5 text-emerald-700" />
                              <span>Buka Modul</span>
                            </button>
                          )}
                        </td>
                        <td className={`border px-2 py-2 text-center align-top font-semibold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'center' }}>
                          <div>{item.jamKe}</div>
                          <div className="text-[10px] text-slate-600 font-normal mt-0.5">{item.rombelNama || `Kelas ${item.kelas}`}</div>
                        </td>
                        <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                          <div className="font-bold text-[10.5pt]">
                            {(!item.bab || item.bab.includes("undefined"))
                              ? `Bab ${item.modulNomor || 1} (${item.elemen || "PAI & BP"})`
                              : item.bab}
                          </div>
                          <div className="mt-1 font-semibold text-slate-900">
                            {(!item.materiPokok || item.materiPokok.includes("undefined"))
                              ? (item.tujuanPembelajaran ? item.tujuanPembelajaran.slice(0, 90) : "Materi Pokok Pembelajaran")
                              : item.materiPokok}
                          </div>
                          <div className="text-[10px] text-slate-600 mt-0.5 font-medium">Elemen: {item.elemen || "Al-Qur’an-Hadis"}</div>
                        </td>
                        <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                          <p className="leading-snug" style={{ margin: 0, padding: 0 }}>
                            {item.tujuanPembelajaran}
                          </p>
                        </td>
                        <td className={`border px-3 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                          <p className="leading-snug text-[10.5pt]" style={{ margin: 0, padding: 0 }}>
                            {item.kegiatanPembelajaran}
                          </p>
                        </td>
                        <td className={`border px-2.5 py-2 align-top text-justify ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'justify' }}>
                          <p className="leading-snug text-[10.5pt]" style={{ margin: 0, padding: 0 }}>
                            {item.asesmen}
                          </p>
                        </td>
                        <td className={`border px-2.5 py-2 align-top ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'top', textAlign: 'left' }}>
                          <div className="font-semibold text-emerald-950">{item.kehadiranSiswa}</div>
                          <div className="text-[10pt] text-slate-800 mt-1 leading-snug">{item.refleksiKetercapaian}</div>
                          <div className="mt-1.5 inline-block text-[9.5pt] font-bold text-emerald-900 border border-emerald-300 bg-emerald-50 px-1.5 py-0.5 rounded">
                            ✓ {item.status}
                          </div>
                        </td>
                        {/* TOMBOL AKSI HAPUS LANGSUNG DARI TABEL */}
                        <td
                          className={`border px-2 py-2 text-center align-middle no-print ${tableBorderClass}`}
                          style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}
                        >
                          <button
                            type="button"
                            onClick={() => handleRequestDeleteJurnal(item)}
                            title="Hapus pertemuan jurnal ini (jika materi/pertemuan tidak sesuai)"
                            className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold text-rose-700 bg-rose-50 hover:bg-rose-600 hover:text-white border border-rose-300 transition-all cursor-pointer shadow-xs group"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-600 group-hover:text-white shrink-0" />
                            <span>Hapus</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}

                  {/* Baris Total / Rekapitulasi */}
                  {filteredJurnal.length > 0 && (
                    <tr className="bg-slate-50 font-bold" style={{ backgroundColor: '#f8fafc' }}>
                      <td colSpan={3} className={`border px-3 py-2 text-right ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'right' }}>
                        Rekapitulasi Pelaksanaan:
                      </td>
                      <td colSpan={5} className={`border px-3 py-2 text-left ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'left' }}>
                        Total: {stats.totalPertemuan} Pertemuan Tatap Muka ({stats.totalJp} JP) • Keterlaksanaan Pembelajaran: {stats.terlaksanaCount} Pertemuan ({stats.persentase}%)
                      </td>
                      <td className={`border px-2 py-2 text-center text-xs text-slate-400 no-print ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                        -
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
            <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
              <tbody>
                <tr style={{ border: 'none', background: 'transparent' }}>
                  <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                    <div style={{ height: "70px", minHeight: "70px" }}></div>
                    <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                  </td>
                  <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                    <div style={{ height: "70px", minHeight: "70px" }}></div>
                    <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAMPILAN 2: INPUT DAFTAR KELAS & JADWAL MENGAJAR GURU    */}
      {/* ======================================================== */}
      {activeSubTab === "jadwal" && (
        <div className="space-y-6">
          {/* Header Panel Jadwal & Rombel */}
          <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
                  <CalendarDays className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Pengaturan Jadwal Mengajar &amp; Rombongan Belajar (Rombel)</span>
                </div>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-emerald-700" />
                  <span>Daftar Kelas yang Diampu &amp; Jadwal Mengajar Mingguan</span>
                </h2>
                <p className="text-xs text-slate-600 mt-0.5 font-medium">
                  Atur daftar rombel (nama kelas, wali kelas, jumlah murid) dan jadwal mengajar mingguan Anda. Data ini <strong>secara otomatis menjadi dasar penentuan Hari/Tanggal dan Jam Pelaksanaan pada Jurnal Mengajar Harian</strong>.
                </p>
              </div>

              {/* Tombol Sinkronisasi Master ke Seluruh Jurnal */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleApplyAllSchedulesToJurnal}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 transition-all cursor-pointer"
                >
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>Terapkan Jadwal ke Seluruh Jurnal Mengajar</span>
                </button>

                <button
                  onClick={() =>
                    handleDownloadWord(
                      "printable-jadwal-area",
                      `Jadwal_Mengajar_Mingguan_PAI_${identitas.guruPai.replace(/\s+/g, "_")}_${identitas.tahunAjaran.replace(/\//g, "-")}`,
                      true
                    )
                  }
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-700" />
                  <span>Unduh Word Jadwal</span>
                </button>

                <button
                  onClick={() =>
                    handlePrintDocument(
                      "printable-jadwal-area",
                      `Jadwal_Mengajar_Mingguan_PAI_${identitas.guruPai.replace(/\s+/g, "_")}`,
                      "landscape"
                    )
                  }
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-slate-950" />
                  <span>Cetak PDF Jadwal (A4)</span>
                </button>
              </div>
            </div>

            {/* Statistik Ringkas */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-3 text-center shadow-xs">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Total Rombel Kelas</span>
                <span className="text-lg font-extrabold text-emerald-800">{daftarKelas.length} Rombel</span>
              </div>
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-3 text-center shadow-xs">
                <span className="block text-[10px] text-teal-900 uppercase font-extrabold">Total Beban Mengajar</span>
                <span className="text-lg font-extrabold text-teal-800">{totalJpMingguan} JP / Minggu</span>
              </div>
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-3 text-center shadow-xs">
                <span className="block text-[10px] text-sky-900 uppercase font-extrabold">Slot Jadwal Terisi</span>
                <span className="text-lg font-extrabold text-sky-800">{jadwalMengajar.length} Hari/Sesi</span>
              </div>
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-xl p-3 text-center shadow-xs">
                <span className="block text-[10px] text-amber-900 uppercase font-extrabold">Total Murid Diampu</span>
                <span className="text-lg font-extrabold text-amber-800">
                  {daftarKelas.reduce((acc, cur) => acc + (cur.jumlahSiswa || 0), 0)} Murid
                </span>
              </div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* BAGIAN 1: INPUT & PENGELOLAAN DAFTAR KELAS (ROMBEL)      */}
          {/* ======================================================== */}
          <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-700" />
                <h3 className="text-sm font-extrabold text-slate-900">
                  1. Daftar Rombongan Belajar (Rombel) yang Diampu
                </h3>
              </div>
              <button
                type="button"
                onClick={handleOpenAddRombel}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 text-emerald-200" />
                <span>Tambah Rombel Kelas Baru</span>
              </button>
            </div>

            {/* Grid Kartu Rombel */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {daftarKelas.map((item) => {
                const sch = jadwalMengajar.find((j) => j.kelasId === item.id);
                return (
                  <div
                    key={item.id}
                    className="p-4 bg-emerald-50/50 rounded-2xl border-2 border-emerald-200 hover:border-emerald-400 transition-all space-y-3 relative group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-slate-900 text-base">{item.nama}</h4>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-950 border border-emerald-300">
                            Fase {item.fase}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 font-semibold">Tingkat Kelas {item.tingkat} SD</p>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditRombel(item)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-900 hover:bg-emerald-100 transition-colors cursor-pointer"
                          title="Edit rombel"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRequestDeleteRombel(item)}
                          className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-100 transition-colors cursor-pointer"
                          title="Hapus rombel kelas ini"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1 text-xs text-slate-700">
                      <div className="flex items-center gap-1.5">
                        <UserCheck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>Wali Kelas: <strong>{item.waliKelas || "Belum diisi"}</strong></span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>Jumlah Murid: <strong>{item.jumlahSiswa} Murid</strong></span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Building className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>Ruang: <strong>{item.ruang || "-"}</strong></span>
                      </div>
                    </div>

                    {/* Status Jadwal */}
                    <div className="pt-2 border-t border-emerald-200 flex items-center justify-between text-xs">
                      {sch ? (
                        <div className="flex items-center gap-1 text-emerald-950 font-bold">
                          <Clock className="w-3.5 h-3.5 text-emerald-700" />
                          <span>{sch.hari}, {sch.waktu} ({sch.jamKe})</span>
                        </div>
                      ) : (
                        <span className="text-amber-800 text-[11px] font-bold">⚠️ Belum ada jadwal</span>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setFilterKelas(item.tingkat);
                          setFilterRombelId(item.id);
                          setActiveSubTab("jurnal");
                        }}
                        className="text-[11px] font-bold text-emerald-800 hover:underline flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>Buka Jurnal</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ======================================================== */}
          {/* BAGIAN 2: JADWAL MENGAJAR MINGGUAN GURU PAI              */}
          {/* ======================================================== */}
          <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-700" />
                <h3 className="text-sm font-extrabold text-slate-900">
                  2. Jadwal Mengajar Mingguan (Senin s.d. Sabtu)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => handleOpenAddJadwal("Senin")}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 text-emerald-200" />
                <span>Tambah Slot Jadwal</span>
              </button>
            </div>

            {/* Grid Jadwal Berdasarkan Hari */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"] as const).map((day) => {
                const daySlots = jadwalMengajar.filter((j) => j.hari === day);
                return (
                  <div key={day} className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-slate-900 text-sm">{day}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
                          {daySlots.reduce((a, c) => a + (c.alokasiJp || 3), 0)} JP
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleOpenAddJadwal(day)}
                        className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-0.5 cursor-pointer"
                        title={`Tambah slot jam hari ${day}`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah</span>
                      </button>
                    </div>

                    {daySlots.length === 0 ? (
                      <p className="text-xs text-slate-400 italic py-3 text-center">Tidak ada jadwal mengajar</p>
                    ) : (
                      <div className="space-y-2">
                        {daySlots.map((slot) => (
                          <div
                            key={slot.id}
                            className="p-3 bg-white rounded-xl border border-emerald-200 shadow-xs space-y-1.5 hover:border-emerald-400 transition-all"
                          >
                            <div className="flex items-start justify-between gap-1">
                              <div>
                                <span className="font-extrabold text-emerald-950 text-xs block">
                                  {slot.kelasNama} (Tingkat {slot.tingkat})
                                </span>
                                <span className="text-[11px] text-slate-600 font-semibold">
                                  Jam ke {slot.jamKe} • Pukul {slot.waktu}
                                </span>
                              </div>
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditJadwal(slot)}
                                  className="p-1 text-slate-500 hover:text-emerald-800 cursor-pointer"
                                  title="Edit slot"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRequestDeleteJadwal(slot)}
                                  className="p-1 text-rose-500 hover:text-rose-700 cursor-pointer"
                                  title="Hapus slot jadwal ini"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                              <span>Alokasi: <strong>{slot.alokasiJp} JP</strong></span>
                              <span>Ruang: <strong>{slot.ruang || "-"}</strong></span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* ======================================================== */}
          {/* BAGIAN 3: LEMBAR CETAK RESMI: JADWAL MENGAJAR GURU       */}
          {/* ======================================================== */}
          <div
            id="printable-jadwal-area"
            style={paperLightMode ? { padding: "2cm 2cm 2cm 2.5cm" } : undefined}
            className={`rounded-2xl border p-6 sm:p-10 transition-colors duration-300 overflow-x-auto ${docContainerClass} official-doc-typography`}
          >
            {/* KOP SURAT */}
            {useKopSurat && kopSuratUrl && (
              <div className="kop-surat-header mb-4 text-center">
                <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
                <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
              </div>
            )}

            {/* Header Dokumen Jadwal */}
            <div className="doc-header-box text-center border-b-2 pb-4 mb-6 border-black">
              <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                JADWAL MENGAJAR MINGGUAN GURU PAI DAN BUDI PEKERTI
              </h2>
              <h3 className="doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
                SATUAN PENDIDIKAN {identitas.sekolah.toUpperCase()}
              </h3>
              <p className="text-xs sm:text-[11pt] font-semibold text-center mt-1" style={{ margin: "2pt 0 0 0" }}>
                TAHUN AJARAN {identitas.tahunAjaran} • BEBAN KERJA: {totalJpMingguan} JP / MINGGU
              </p>
            </div>

            {/* Identitas Guru */}
            <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-2xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Nama Guru</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">{identitas.guruPai}</span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">NIP Guru</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val">{identitas.nipGuru}</span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Mata Pelajaran</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val font-bold">Pendidikan Agama Islam dan Budi Pekerti</span>
              </div>
              <div className="identitas-row flex items-baseline">
                <span className="identitas-label w-48 font-bold shrink-0">Jumlah Rombel Diampu</span>
                <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
                <span className="identitas-val">{daftarKelas.length} Rombongan Belajar ({daftarKelas.map(k => k.nama).join(", ")})</span>
              </div>
            </div>

            {/* Tabel Matriks Jadwal Pelajaran Mingguan */}
            <div className="overflow-x-auto print:overflow-visible mb-6">
              <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%' }}>
                <thead>
                  <tr className={tableHeaderBgClass}>
                    <th className={`border px-2 py-2 text-center font-bold w-[6%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Jam Ke-
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[12%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Waktu (WIB)
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[14%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Senin
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[14%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Selasa
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[14%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Rabu
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[14%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Kamis
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[13%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Jumat
                    </th>
                    <th className={`border px-2 py-2 text-center font-bold w-[13%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                      Sabtu
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { jam: "1 - 3", time: "07.15 - 09.00" },
                    { jam: "Istirahat", time: "09.00 - 09.30", isBreak: true },
                    { jam: "4 - 6", time: "09.30 - 11.00" },
                    { jam: "7 - 8", time: "11.15 - 12.15" }
                  ].map((row, rIdx) => {
                    if (row.isBreak) {
                      return (
                        <tr key={rIdx} className="bg-slate-100" style={{ backgroundColor: '#f1f5f9' }}>
                          <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                            -
                          </td>
                          <td className={`border px-2 py-1.5 text-center font-semibold text-xs ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                            {row.time}
                          </td>
                          <td colSpan={6} className={`border px-2 py-1.5 text-center font-bold tracking-wider text-xs uppercase ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                            ISTIRAHAT &amp; PEMBIASAAN SHOLAT DHUHA / LITERASI
                          </td>
                        </tr>
                      );
                    }

                    return (
                      <tr key={rIdx}>
                        <td className={`border px-2 py-2.5 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                          {row.jam}
                        </td>
                        <td className={`border px-2 py-2.5 text-center font-semibold text-xs ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                          {row.time}
                        </td>
                        {(["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"] as const).map((day) => {
                          const slot = jadwalMengajar.find(
                            (j) => j.hari === day && (j.jamKe.includes(row.jam) || (row.jam === "1 - 3" && j.jamKe === "1 - 3"))
                          );
                          return (
                            <td
                              key={day}
                              className={`border px-2 py-2 text-center align-middle ${tableBorderClass}`}
                              style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}
                            >
                              {slot ? (
                                <div>
                                  <div className="font-extrabold text-sm">{slot.kelasNama}</div>
                                  <div className="text-[10px] font-semibold text-slate-700">PAI &amp; BP ({slot.alokasiJp} JP)</div>
                                  <div className="text-[9px] text-slate-500 mt-0.5">{slot.ruang || "-"}</div>
                                </div>
                              ) : (
                                <span className="text-slate-300 text-xs">-</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Tabel Rincian Rombel & Wali Kelas */}
            <h4 className="font-bold text-sm mb-2">Rincian Rombongan Belajar &amp; Alokasi Beban Mengajar:</h4>
            <div className="overflow-x-auto print:overflow-visible mb-6">
              <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%' }}>
                <thead>
                  <tr className={tableHeaderBgClass}>
                    <th className={`border px-2 py-1.5 text-center font-bold w-[5%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>No</th>
                    <th className={`border px-3 py-1.5 text-center font-bold w-[18%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Nama Rombel</th>
                    <th className={`border px-2 py-1.5 text-center font-bold w-[12%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Tingkat &amp; Fase</th>
                    <th className={`border px-3 py-1.5 text-center font-bold w-[25%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Wali Kelas</th>
                    <th className={`border px-2 py-1.5 text-center font-bold w-[12%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Jumlah Siswa</th>
                    <th className={`border px-3 py-1.5 text-center font-bold w-[18%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Hari &amp; Jam Mengajar</th>
                    <th className={`border px-2 py-1.5 text-center font-bold w-[10%] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Beban JP</th>
                  </tr>
                </thead>
                <tbody>
                  {daftarKelas.map((k, idx) => {
                    const sch = jadwalMengajar.find((j) => j.kelasId === k.id);
                    return (
                      <tr key={k.id}>
                        <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>{idx + 1}</td>
                        <td className={`border px-3 py-1.5 font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>{k.nama}</td>
                        <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>Kelas {k.tingkat} (Fase {k.fase})</td>
                        <td className={`border px-3 py-1.5 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>{k.waliKelas || "-"}</td>
                        <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>{k.jumlahSiswa} Murid</td>
                        <td className={`border px-3 py-1.5 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                          {sch ? `${sch.hari}, ${sch.waktu}` : "-"}
                        </td>
                        <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                          {sch?.alokasiJp || 3} JP
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="bg-slate-50 font-bold" style={{ backgroundColor: '#f8fafc' }}>
                    <td colSpan={4} className={`border px-3 py-2 text-right ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'right' }}>
                      Total Beban Mengajar Mingguan:
                    </td>
                    <td className={`border px-2 py-2 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                      {daftarKelas.reduce((a, c) => a + (c.jumlahSiswa || 0), 0)} Murid
                    </td>
                    <td className={`border px-3 py-2 ${tableBorderClass}`} style={{ border: '1px solid #000000' }}>
                      {jadwalMengajar.length} Sesi Tatap Muka
                    </td>
                    <td className={`border px-2 py-2 text-center text-emerald-950 font-extrabold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                      {totalJpMingguan} JP
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Tanda Tangan Resmi */}
            <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
              <tbody>
                <tr style={{ border: 'none', background: 'transparent' }}>
                  <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                    <div style={{ height: "70px", minHeight: "70px" }}></div>
                    <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                  </td>
                  <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                    <div style={{ height: "70px", minHeight: "70px" }}></div>
                    <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                    <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL FORM: TAMBAH / EDIT ROMBEL KELAS                   */}
      {/* ======================================================== */}
      {showAddRombelModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-emerald-400 p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-700" />
                <span>{editingRombel ? "Edit Rombel Kelas" : "Tambah Rombel Kelas Baru"}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddRombelModal(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveRombel} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Tingkat Kelas SD:</label>
                <select
                  value={formRombel.tingkat}
                  onChange={(e) => setFormRombel({ ...formRombel, tingkat: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-bold text-slate-900"
                >
                  <option value="I">Kelas I (Fase A)</option>
                  <option value="II">Kelas II (Fase A)</option>
                  <option value="III">Kelas III (Fase B)</option>
                  <option value="IV">Kelas IV (Fase B)</option>
                  <option value="V">Kelas V (Fase C)</option>
                  <option value="VI">Kelas VI (Fase C)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Rombel / Label Kelas:</label>
                <input
                  type="text"
                  placeholder="Contoh: Kelas 1-A atau 1-B"
                  value={formRombel.nama}
                  onChange={(e) => setFormRombel({ ...formRombel, nama: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-semibold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Wali Kelas:</label>
                <input
                  type="text"
                  placeholder="Contoh: Hj. Nurhasanah, S.Pd."
                  value={formRombel.waliKelas}
                  onChange={(e) => setFormRombel({ ...formRombel, waliKelas: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-medium text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Jumlah Siswa:</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={formRombel.jumlahSiswa}
                    onChange={(e) => setFormRombel({ ...formRombel, jumlahSiswa: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-semibold text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Ruang Kelas:</label>
                  <input
                    type="text"
                    placeholder="Contoh: Ruang 1A"
                    value={formRombel.ruang}
                    onChange={(e) => setFormRombel({ ...formRombel, ruang: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-medium text-slate-900"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddRombelModal(false)}
                  className="px-4 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs cursor-pointer"
                >
                  Simpan Rombel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL FORM: TAMBAH / EDIT SLOT JADWAL MENGAJAR           */}
      {/* ======================================================== */}
      {showAddJadwalModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-emerald-400 p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-700" />
                <span>{editingJadwal ? "Edit Slot Jadwal Mengajar" : "Tambah Slot Jadwal Mengajar"}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddJadwalModal(false)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveJadwal} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Pilih Kelas / Rombel yang Diajar:</label>
                <select
                  value={formJadwal.kelasId}
                  onChange={(e) => setFormJadwal({ ...formJadwal, kelasId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-bold text-slate-900 cursor-pointer"
                  required
                >
                  {daftarKelas.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.nama} (Tingkat {k.tingkat} • Fase {k.fase})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Hari Mengajar:</label>
                  <select
                    value={formJadwal.hari}
                    onChange={(e) => setFormJadwal({ ...formJadwal, hari: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-bold text-slate-900 cursor-pointer"
                  >
                    <option value="Senin">Senin</option>
                    <option value="Selasa">Selasa</option>
                    <option value="Rabu">Rabu</option>
                    <option value="Kamis">Kamis</option>
                    <option value="Jumat">Jumat</option>
                    <option value="Sabtu">Sabtu</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Alokasi Beban JP:</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={formJadwal.alokasiJp}
                    onChange={(e) => setFormJadwal({ ...formJadwal, alokasiJp: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-semibold text-slate-900"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Jam Ke-:</label>
                  <input
                    type="text"
                    placeholder="Contoh: 1 - 3"
                    value={formJadwal.jamKe}
                    onChange={(e) => setFormJadwal({ ...formJadwal, jamKe: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-semibold text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Rentang Waktu:</label>
                  <input
                    type="text"
                    placeholder="Contoh: 07.15 - 09.00"
                    value={formJadwal.waktu}
                    onChange={(e) => setFormJadwal({ ...formJadwal, waktu: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-semibold text-slate-900"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Berlaku untuk Semester:</label>
                <select
                  value={formJadwal.semester}
                  onChange={(e) => setFormJadwal({ ...formJadwal, semester: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-medium text-slate-900 cursor-pointer"
                >
                  <option value="Semua">Semua Semester (Semester 1 &amp; 2)</option>
                  <option value="I (Ganjil)">Semester I (Ganjil) Saja</option>
                  <option value="II (Genap)">Semester II (Genap) Saja</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Keterangan / Aktivitas:</label>
                <input
                  type="text"
                  placeholder="Contoh: 3 JP Tatap Muka Inti"
                  value={formJadwal.keterangan}
                  onChange={(e) => setFormJadwal({ ...formJadwal, keterangan: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 font-medium text-slate-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddJadwalModal(false)}
                  className="px-4 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs cursor-pointer"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DIALOG KONFIRMASI IN-APP: HAPUS ROMBEL KELAS            */}
      {/* ======================================================== */}
      {deleteRombelDialog.show && deleteRombelDialog.item && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-rose-400 p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center gap-3 border-b border-rose-200 pb-3">
              <div className="p-2.5 rounded-2xl bg-rose-100 text-rose-700">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900">Konfirmasi Hapus Rombel</h3>
                <p className="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan</p>
              </div>
            </div>

            <div className="text-xs text-slate-700 space-y-2">
              <p>
                Apakah Anda yakin ingin menghapus <strong>{deleteRombelDialog.item.nama}</strong> (Tingkat {deleteRombelDialog.item.tingkat}) dari daftar kelas?
              </p>
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 font-medium">
                ⚠️ Seluruh slot jadwal mengajar yang terhubung dengan rombel ini juga akan dihapus.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeleteRombelDialog({ show: false, item: null })}
                className="px-4 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDeleteRombel}
                className="px-5 py-2 rounded-xl font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Hapus Rombel</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DIALOG KONFIRMASI IN-APP: HAPUS SLOT JADWAL              */}
      {/* ======================================================== */}
      {deleteJadwalDialog.show && deleteJadwalDialog.item && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-rose-400 p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center gap-3 border-b border-rose-200 pb-3">
              <div className="p-2.5 rounded-2xl bg-rose-100 text-rose-700">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900">Hapus Slot Jadwal Mengajar</h3>
                <p className="text-xs text-slate-500">Konfirmasi penghapusan slot jadwal</p>
              </div>
            </div>

            <p className="text-xs text-slate-700">
              Apakah Anda yakin ingin menghapus jadwal hari <strong>{deleteJadwalDialog.item.hari}</strong> untuk <strong>{deleteJadwalDialog.item.kelasNama}</strong> (Pukul {deleteJadwalDialog.item.waktu}, {deleteJadwalDialog.item.alokasiJp} JP)?
            </p>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeleteJadwalDialog({ show: false, item: null })}
                className="px-4 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDeleteJadwal}
                className="px-5 py-2 rounded-xl font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Hapus Slot</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DIALOG KONFIRMASI IN-APP: HAPUS BARIS JURNAL TIDAK SESUAI*/}
      {/* ======================================================== */}
      {deleteJurnalDialog.show && deleteJurnalDialog.item && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-rose-400 p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center gap-3 border-b border-rose-200 pb-3">
              <div className="p-2.5 rounded-2xl bg-rose-100 text-rose-700">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900">Hapus Pertemuan Jurnal</h3>
                <p className="text-xs text-slate-500">Hapus materi atau pertemuan yang tidak sesuai</p>
              </div>
            </div>

            <div className="text-xs text-slate-700 space-y-2">
              <p>
                Apakah Anda ingin menghapus baris jurnal berikut dari lembar mengajar?
              </p>
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <div className="font-bold text-slate-900">
                  Pertemuan Ke-{deleteJurnalDialog.item.pertemuanKe} • {deleteJurnalDialog.item.hariTanggal}
                </div>
                <div className="font-semibold text-emerald-950">
                  {deleteJurnalDialog.item.bab}
                </div>
                <div className="text-slate-600">
                  Materi: {deleteJurnalDialog.item.materiPokok}
                </div>
              </div>
              <p className="text-[11px] text-slate-500">
                Baris ini akan dihilangkan dari tabel jurnal dan lembar cetak resmi. Anda dapat mengembalikannya kapan saja lewat tombol "Sinkronkan Ulang".
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeleteJurnalDialog({ show: false, item: null })}
                className="px-4 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDeleteJurnal}
                className="px-5 py-2 rounded-xl font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Hapus Baris Ini</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DIALOG KONFIRMASI IN-APP: SINKRONISASI ULANG JURNAL       */}
      {/* ======================================================== */}
      {resetSyncDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-emerald-400 p-6 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center gap-3 border-b border-emerald-200 pb-3">
              <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900">Sinkronkan Ulang Jurnal Mengajar</h3>
                <p className="text-xs text-slate-500">Integrasi 78 Modul Ajar &amp; Jadwal Mengajar</p>
              </div>
            </div>

            <div className="text-xs text-slate-700 space-y-2">
              <p>
                Apakah Anda ingin menyinkronkan ulang seluruh data Jurnal Mengajar dengan <strong>78 Modul Ajar resmi</strong> dan <strong>Jadwal Mengajar yang telah diinput</strong>?
              </p>
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-950 font-medium">
                ✓ Seluruh materi, tujuan pembelajaran (TP), dan tanggal berdasarkan hari jadwal akan diperbarui secara otomatis.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setResetSyncDialog(false)}
                className="px-4 py-2 rounded-xl font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeResetToModulAjar}
                className="px-5 py-2 rounded-xl font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ya, Sinkronkan Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL PILIHAN PERIODE CETAK JURNAL */}
      <ModalCetakJurnal
        isOpen={showModalCetak}
        onClose={() => setShowModalCetak(false)}
        currentRombel={currentRombel}
        filterKelas={filterKelas}
        filterSemester={filterSemester}
        identitas={identitas}
        jurnalListKelasSemester={filteredJurnalBase}
        periodeCetak={periodeCetak}
        setPeriodeCetak={setPeriodeCetak}
        selectedBulan={selectedBulan}
        setSelectedBulan={setSelectedBulan}
        selectedMinggu={selectedMinggu}
        setSelectedMinggu={setSelectedMinggu}
        selectedPertemuanHari={selectedPertemuanHari}
        setSelectedPertemuanHari={setSelectedPertemuanHari}
        handlePrintDocument={handlePrintDocument}
        handleDownloadWord={handleDownloadWord}
        showToast={showToast}
      />
    </div>
  );
};
