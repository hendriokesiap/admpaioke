import React, { useState, useMemo, useEffect } from 'react';
import {
  Award,
  Users,
  Search,
  Download,
  Printer,
  Plus,
  Trash2,
  Edit3,
  Save,
  CheckCircle2,
  FileSpreadsheet,
  FileText,
  Sparkles,
  RotateCcw,
  SlidersHorizontal,
  ChevronRight,
  TrendingUp,
  UserPlus,
  Check,
  AlertCircle,
  HelpCircle,
  ClipboardPaste,
  BookOpen
} from 'lucide-react';
import { KelasRombelItem } from './TabJurnalMengajar.tsx';
import { ModalUploadSiswaExcel } from './ModalUploadSiswaExcel.tsx';

// ==========================================
// TIPE DATA PENILAIAN SISWA
// ==========================================

export interface SiswaItem {
  id: string;
  nisn: string;
  nama: string;
  gender: "L" | "P";
}

export interface CustomKolomPenilaian {
  id: string;
  nama: string;
  kategori: "Formatif" | "Sumatif";
  babNomor?: number;
  bobot: number; // default 100
}

export interface NilaiSiswaRecord {
  siswaId: string;
  // Nilai formatif per bab: { [babNomor]: { f1?: number, f2?: number, f3?: number } }
  formatif: Record<string, Record<string, number>>;
  // Nilai sumatif lingkup materi per bab: { [babNomor]: number }
  sumatifLm: Record<string, number>;
  // Nilai kustom: { [customKolomId]: number }
  kustom: Record<string, number>;
  // Nilai STS dan SAS
  sts?: number;
  sas?: number;
}

export interface TabPenilaianProps {
  modules: any[];
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  daftarKelas: KelasRombelItem[];
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
}

// Nama-nama siswa contoh panduan untuk kelas PAI (maksimal 3 nama siswa sebagai contoh atau panduan)
export const DEFAULT_NAMA_SISWA_PAI: { nama: string; gender: "L" | "P" }[] = [
  { nama: "Ahmad Al-Fatih", gender: "L" },
  { nama: "Aisyah Nur Ramadhani", gender: "P" },
  { nama: "Muhammad Rayhan Arkan", gender: "L" }
];

// Helper generator maksimal 3 nama siswa sebagai contoh/panduan
export const getDefaultContohSiswa = (rombelId: string): SiswaItem[] => {
  return DEFAULT_NAMA_SISWA_PAI.slice(0, 3).map((item, idx) => ({
    id: `sis-${rombelId}-${idx + 1}`,
    nisn: `012345${String(idx + 1).padStart(4, "0")}`,
    nama: item.nama,
    gender: item.gender
  }));
};

// Helper pemuat data siswa dari storage dengan pembersihan data mock 28 siswa bawaan lama
export const loadSiswaFromStorage = (rombelId: string): SiswaItem[] => {
  try {
    const saved = localStorage.getItem(`perangkat_siswa_${rombelId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        // Jika data di localStorage berasal dari default 28 siswa mock bawaan lama
        const isOldMockData = parsed.length > 3 && parsed.some((s: any) =>
          s.nama === "Bilal Habibi Pratama" ||
          s.nama === "Dania Putri Salsabila" ||
          s.nama === "Fadhil Maulana" ||
          s.nama === "Fatimah Az-Zahra" ||
          s.nama === "Hafiz Ramadhan" ||
          s.nama === "Zulfa Safitri" ||
          s.nama === "Umar Al-Khattab"
        );
        if (isOldMockData) {
          const cleaned = getDefaultContohSiswa(rombelId);
          try {
            localStorage.setItem(`perangkat_siswa_${rombelId}`, JSON.stringify(cleaned));
          } catch {}
          return cleaned;
        }
        return parsed;
      }
    }
  } catch {}
  return getDefaultContohSiswa(rombelId);
};

export const TabPenilaian: React.FC<TabPenilaianProps> = ({
  modules,
  identitas,
  daftarKelas,
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat
}) => {
  // 1. Filter Kelas / Rombel & Semester
  const [selectedRombelId, setSelectedRombelId] = useState<string>(() => {
    return daftarKelas[0]?.id || "kls-1a";
  });
  const [selectedSemester, setSelectedSemester] = useState<string>("I (Ganjil)");
  const [kktpStandard, setKktpStandard] = useState<number>(75);

  // Sub-Tab Penilaian: 'input-bab' (Input Nilai per Bab) | 'rekap' (Rekapitulasi Nilai Akhir / Rapor)
  const [activeViewMode, setActiveViewMode] = useState<"input-bab" | "rekap">("input-bab");

  // Rombel yang sedang aktif
  const currentRombel = useMemo(() => {
    return daftarKelas.find((k) => k.id === selectedRombelId) || daftarKelas[0];
  }, [daftarKelas, selectedRombelId]);

  const currentTingkat = currentRombel?.tingkat || "I";

  // Lingkup Materi (Bab) dari modul kelas & semester yang dipilih
  const classModules = useMemo(() => {
    return modules
      .filter((m) => m.kelas === currentTingkat && m.semester === selectedSemester)
      .sort((a, b) => a.nomor - b.nomor);
  }, [modules, currentTingkat, selectedSemester]);

  // Bab aktif yang sedang diinput nilainya
  const [activeBabNomor, setActiveBabNomor] = useState<number>(1);

  // Pastikan activeBabNomor valid dengan classModules
  useEffect(() => {
    if (classModules.length > 0 && !classModules.some((m) => m.nomor === activeBabNomor)) {
      setActiveBabNomor(classModules[0].nomor);
    }
  }, [classModules, activeBabNomor]);

  const activeModul = useMemo(() => {
    return classModules.find((m) => m.nomor === activeBabNomor) || classModules[0];
  }, [classModules, activeBabNomor]);

  // 2. State Daftar Siswa per Rombel (Maksimal 3 nama siswa sebagai contoh/panduan atau dikosongkan)
  const [daftarSiswa, setDaftarSiswa] = useState<SiswaItem[]>(() => {
    return loadSiswaFromStorage(selectedRombelId);
  });

  // Load ulang daftar siswa saat berganti rombel
  useEffect(() => {
    setDaftarSiswa(loadSiswaFromStorage(selectedRombelId));
  }, [selectedRombelId]);

  // Simpan daftar siswa ke LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(daftarSiswa));
    } catch {}
  }, [daftarSiswa, selectedRombelId]);

  // Handler Kosongkan Daftar Siswa
  const handleClearAllStudents = () => {
    if (window.confirm(`Apakah Anda yakin ingin mengosongkan seluruh nama siswa pada rombel ${currentRombel?.nama}? Anda dapat mengunggah file Excel atau menginput nama secara manual kapan saja.`)) {
      setDaftarSiswa([]);
      try {
        localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify([]));
      } catch {}
      showToast(`Daftar siswa pada ${currentRombel?.nama} telah dikosongkan.`);
    }
  };

  // Handler Terapkan 3 Contoh Siswa Panduan
  const handleReset3Examples = () => {
    const examples = getDefaultContohSiswa(selectedRombelId);
    setDaftarSiswa(examples);
    try {
      localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(examples));
    } catch {}
    showToast(`3 contoh nama siswa panduan diterapkan pada ${currentRombel?.nama}.`);
  };

  // 3. State Kolom Penilaian Kustom (Input Manual Jenis Penilaian)
  const [customKolomList, setCustomKolomList] = useState<CustomKolomPenilaian[]>(() => {
    try {
      const saved = localStorage.getItem(`perangkat_kolom_nilai_${selectedRombelId}_${selectedSemester}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(`perangkat_kolom_nilai_${selectedRombelId}_${selectedSemester}`, JSON.stringify(customKolomList));
    } catch {}
  }, [customKolomList, selectedRombelId, selectedSemester]);

  // 4. State Nilai Siswa Record
  const [nilaiRecords, setNilaiRecords] = useState<Record<string, NilaiSiswaRecord>>(() => {
    try {
      const saved = localStorage.getItem(`perangkat_nilai_${selectedRombelId}_${selectedSemester}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  // Muat ulang nilai saat rombel / semester berganti
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`perangkat_nilai_${selectedRombelId}_${selectedSemester}`);
      if (saved) {
        setNilaiRecords(JSON.parse(saved));
        return;
      }
    } catch {}
    setNilaiRecords({});
  }, [selectedRombelId, selectedSemester]);

  // Simpan nilai ke LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(`perangkat_nilai_${selectedRombelId}_${selectedSemester}`, JSON.stringify(nilaiRecords));
    } catch {}
  }, [nilaiRecords, selectedRombelId, selectedSemester]);

  // 5. Modal State: Tambah Siswa & Tambah Kolom Kustom
  const [showAddSiswaModal, setShowAddSiswaModal] = useState(false);
  const [showUploadExcelModal, setShowUploadExcelModal] = useState(false);
  const [newSiswaNama, setNewSiswaNama] = useState("");
  const [newSiswaNisn, setNewSiswaNisn] = useState("");
  const [newSiswaGender, setNewSiswaGender] = useState<"L" | "P">("L");

  const [showPasteModal, setShowPasteModal] = useState(false);
  const [pastedNames, setPastedNames] = useState("");

  const [showAddKolomModal, setShowAddKolomModal] = useState(false);
  const [newKolomNama, setNewKolomNama] = useState("");
  const [newKolomKategori, setNewKolomKategori] = useState<"Formatif" | "Sumatif">("Formatif");

  const handleSaveFromExcel = (newItems: SiswaItem[], mode: "replace" | "append") => {
    if (mode === "replace") {
      setDaftarSiswa(newItems);
      showToast(`Berhasil mengganti dengan ${newItems.length} siswa dari file Excel untuk ${currentRombel?.nama}!`);
    } else {
      setDaftarSiswa((prev) => [...prev, ...newItems]);
      showToast(`Berhasil menambahkan ${newItems.length} siswa baru dari file Excel ke ${currentRombel?.nama}!`);
    }
  };

  // Handler Nilai
  const handleUpdateNilai = (
    siswaId: string,
    type: "formatif" | "sumatifLm" | "kustom" | "sts" | "sas",
    keyOrSubKey: string,
    value: number
  ) => {
    const val = isNaN(value) ? 0 : Math.max(0, Math.min(100, value));

    setNilaiRecords((prev) => {
      const existing = prev[siswaId] || {
        siswaId,
        formatif: {},
        sumatifLm: {},
        kustom: {}
      };

      const updated = { ...existing };

      if (type === "formatif") {
        const babKey = String(activeBabNomor);
        const currentBabF = { ...(updated.formatif[babKey] || {}) };
        currentBabF[keyOrSubKey] = val;
        updated.formatif = { ...updated.formatif, [babKey]: currentBabF };
      } else if (type === "sumatifLm") {
        const babKey = String(activeBabNomor);
        updated.sumatifLm = { ...updated.sumatifLm, [babKey]: val };
      } else if (type === "kustom") {
        updated.kustom = { ...updated.kustom, [keyOrSubKey]: val };
      } else if (type === "sts") {
        updated.sts = val;
      } else if (type === "sas") {
        updated.sas = val;
      }

      return { ...prev, [siswaId]: updated };
    });
  };

  // Pengisian Cepat / Simulasi
  const handleFillAllAverage = (score: number) => {
    setNilaiRecords((prev) => {
      const updated = { ...prev };
      const babKey = String(activeBabNomor);

      daftarSiswa.forEach((sis) => {
        const rec = updated[sis.id] || { siswaId: sis.id, formatif: {}, sumatifLm: {}, kustom: {} };
        const currentBabF = { ...(rec.formatif[babKey] || {}) };
        currentBabF["f1"] = score;
        currentBabF["f2"] = score;
        currentBabF["f3"] = score;
        rec.formatif = { ...rec.formatif, [babKey]: currentBabF };
        rec.sumatifLm = { ...rec.sumatifLm, [babKey]: score };
        updated[sis.id] = rec;
      });

      return updated;
    });
    showToast(`Seluruh nilai Bab ${activeBabNomor} berhasil diisi ${score}`);
  };

  const handleGenerateRealisticScores = () => {
    setNilaiRecords((prev) => {
      const updated = { ...prev };

      daftarSiswa.forEach((sis) => {
        const rec = updated[sis.id] || { siswaId: sis.id, formatif: {}, sumatifLm: {}, kustom: {} };

        classModules.forEach((m) => {
          const bKey = String(m.nomor);
          const base = 75 + Math.floor(Math.random() * 21); // 75 - 95
          rec.formatif[bKey] = {
            f1: Math.min(100, base + Math.floor(Math.random() * 6) - 2),
            f2: Math.min(100, base + Math.floor(Math.random() * 6) - 2),
            f3: Math.min(100, base + Math.floor(Math.random() * 6) - 2)
          };
          rec.sumatifLm[bKey] = Math.min(100, base + Math.floor(Math.random() * 5));
        });

        rec.sts = 78 + Math.floor(Math.random() * 18);
        rec.sas = 80 + Math.floor(Math.random() * 18);
        updated[sis.id] = rec;
      });

      return updated;
    });
    showToast("Berhasil menghasilkan simulasi nilai realistis seluruh siswa!");
  };

  const handleResetScores = () => {
    setNilaiRecords({});
    showToast("Seluruh nilai siswa berhasil direset.");
  };

  // Tambah Siswa Baru
  const handleAddSiswa = () => {
    if (!newSiswaNama.trim()) {
      showToast("Nama siswa tidak boleh kosong");
      return;
    }
    const newId = `sis-${selectedRombelId}-${Date.now()}`;
    const nisn = newSiswaNisn.trim() || `012345${Math.floor(1000 + Math.random() * 9000)}`;
    const newSiswa: SiswaItem = {
      id: newId,
      nisn,
      nama: newSiswaNama.trim(),
      gender: newSiswaGender
    };
    setDaftarSiswa((prev) => [...prev, newSiswa]);
    setNewSiswaNama("");
    setNewSiswaNisn("");
    setShowAddSiswaModal(false);
    showToast(`Siswa "${newSiswa.nama}" berhasil ditambahkan ke ${currentRombel?.nama}`);
  };

  // Tempel Nama Siswa Massal
  const handlePasteMassal = () => {
    if (!pastedNames.trim()) return;
    const lines = pastedNames.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (lines.length === 0) return;

    const newItems: SiswaItem[] = lines.map((name, i) => {
      // bersihkan nomor urut jika ada (misal: "1. Ahmad" -> "Ahmad")
      const cleanName = name.replace(/^\d+[\.\)\-\s]+/, "").trim();
      return {
        id: `sis-${selectedRombelId}-${Date.now()}-${i}`,
        nisn: `012345${Math.floor(1000 + Math.random() * 9000)}`,
        nama: cleanName,
        gender: "L"
      };
    });

    setDaftarSiswa((prev) => [...prev, ...newItems]);
    setPastedNames("");
    setShowPasteModal(false);
    showToast(`Berhasil menambahkan ${newItems.length} siswa sekaligus!`);
  };

  const handleDeleteSiswa = (id: string, nama: string) => {
    setDaftarSiswa((prev) => prev.filter((s) => s.id !== id));
    showToast(`Siswa "${nama}" berhasil dihapus dari daftar.`);
  };

  // Tambah Kolom Kustom
  const handleAddCustomKolom = () => {
    if (!newKolomNama.trim()) {
      showToast("Nama kolom penilaian tidak boleh kosong");
      return;
    }
    const col: CustomKolomPenilaian = {
      id: `col-${Date.now()}`,
      nama: newKolomNama.trim(),
      kategori: newKolomKategori,
      bobot: 100
    };
    setCustomKolomList((prev) => [...prev, col]);
    setNewKolomNama("");
    setShowAddKolomModal(false);
    showToast(`Kolom penilaian "${col.nama}" berhasil ditambahkan.`);
  };

  const handleDeleteCustomKolom = (id: string) => {
    setCustomKolomList((prev) => prev.filter((c) => c.id !== id));
    showToast("Kolom penilaian kustom dihapus.");
  };

  // Kalkulasi Rekap Nilai Siswa
  const rekapCalculations = useMemo(() => {
    return daftarSiswa.map((sis) => {
      const rec = nilaiRecords[sis.id] || { siswaId: sis.id, formatif: {}, sumatifLm: {}, kustom: {} };

      // Rata-rata per Bab
      const babScores: Record<number, number> = {};
      let totalSumatifLm = 0;
      let countLm = 0;

      classModules.forEach((m) => {
        const bKey = String(m.nomor);
        const slm = rec.sumatifLm?.[bKey];
        if (typeof slm === "number" && slm > 0) {
          babScores[m.nomor] = slm;
          totalSumatifLm += slm;
          countLm += 1;
        } else {
          // Jika belum ada nilai sumatif LM, ambil rata-rata formatif bab tersebut
          const fObj = rec.formatif?.[bKey] || {};
          const fVals = Object.values(fObj).filter((v) => typeof v === "number" && v > 0);
          if (fVals.length > 0) {
            const avgF = Math.round(fVals.reduce((a, c) => a + c, 0) / fVals.length);
            babScores[m.nomor] = avgF;
            totalSumatifLm += avgF;
            countLm += 1;
          } else {
            babScores[m.nomor] = 0;
          }
        }
      });

      const avgSumatifLm = countLm > 0 ? Math.round(totalSumatifLm / countLm) : 0;
      const stsVal = rec.sts || avgSumatifLm || 0;
      const sasVal = rec.sas || avgSumatifLm || 0;

      // Rumus Nilai Akhir (NA) Rapor Kemendikbud:
      // NA = (2 * Rata-rata SLM + STS + SAS) / 4
      const nilaiAkhir = countLm > 0
        ? Math.round((2 * avgSumatifLm + stsVal + sasVal) / 4)
        : 0;

      // Predikat & Ketercapaian KKTP
      let predikat = "Perlu Bimbingan";
      let badgeColor = "bg-rose-100 text-rose-900 border-rose-300";
      if (nilaiAkhir >= 90) {
        predikat = "Sangat Baik (A)";
        badgeColor = "bg-emerald-100 text-emerald-950 border-emerald-400 font-extrabold";
      } else if (nilaiAkhir >= 80) {
        predikat = "Baik (B)";
        badgeColor = "bg-teal-100 text-teal-950 border-teal-400 font-bold";
      } else if (nilaiAkhir >= kktpStandard) {
        predikat = "Cukup (C)";
        badgeColor = "bg-amber-100 text-amber-950 border-amber-300 font-semibold";
      }

      const isTuntas = nilaiAkhir >= kktpStandard;

      // Deskripsi Rapor Otomatis
      let deskripsi = `Menunjukkan pemahaman dalam menguasai tujuan pembelajaran PAI & BP Semester ${selectedSemester.split(" ")[0]}.`;
      if (nilaiAkhir >= 85) {
        deskripsi = `Menunjukkan penguasaan sangat baik dalam memahami materi seluruh bab serta aktif mempraktikkan ajaran Islam dengan penuh penghayatan.`;
      } else if (!isTuntas && nilaiAkhir > 0) {
        deskripsi = `Perlu bimbingan dan penguatan lebih lanjut dalam pemahaman materi pembelajaran dan latihan unjuk kerja.`;
      }

      return {
        siswa: sis,
        babScores,
        avgSumatifLm,
        sts: stsVal,
        sas: sasVal,
        nilaiAkhir,
        predikat,
        badgeColor,
        isTuntas,
        deskripsi
      };
    });
  }, [daftarSiswa, nilaiRecords, classModules, kktpStandard, selectedSemester]);

  // Statistik Kelas Keseluruhan
  const statsKelas = useMemo(() => {
    const validScores = rekapCalculations.map((r) => r.nilaiAkhir).filter((n) => n > 0);
    const totalSiswa = rekapCalculations.length;
    if (validScores.length === 0) {
      return { avg: 0, highest: 0, lowest: 0, tuntasCount: 0, tuntasPersen: 0 };
    }
    const highest = Math.max(...validScores);
    const lowest = Math.min(...validScores);
    const avg = Math.round(validScores.reduce((a, c) => a + c, 0) / validScores.length);
    const tuntasCount = rekapCalculations.filter((r) => r.isTuntas && r.nilaiAkhir > 0).length;
    const tuntasPersen = Math.round((tuntasCount / totalSiswa) * 100);
    return { avg, highest, lowest, tuntasCount, tuntasPersen };
  }, [rekapCalculations]);

  // Ekspor CSV
  const handleExportCsv = () => {
    const header = ["No", "NISN", "Nama Siswa", "L/P", ...classModules.map((m) => `Bab ${m.nomor}`), "Rata-rata SLM", "STS", "SAS", "Nilai Akhir", "Predikat", "Ketercapaian KKTP"];
    const rows = rekapCalculations.map((r, i) => [
      i + 1,
      `'${r.siswa.nisn}`,
      `"${r.siswa.nama}"`,
      r.siswa.gender,
      ...classModules.map((m) => r.babScores[m.nomor] || 0),
      r.avgSumatifLm,
      r.sts,
      r.sas,
      r.nilaiAkhir,
      `"${r.predikat}"`,
      r.isTuntas ? "Tuntas" : "Belum Tuntas"
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [header.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Rekap_Nilai_PAI_${currentRombel?.nama.replace(/\s+/g, "_")}_Sem_${selectedSemester.split(" ")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Rekap nilai berhasil diekspor ke Excel / CSV!");
  };

  return (
    <div className="space-y-6">
      {/* TOOLBAR UTAMA MENU PENILAIAN */}
      <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-5 no-print text-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
              <Award className="w-3.5 h-3.5 text-emerald-700" />
              <span>Buku Penilaian &amp; Rekap Nilai Asesmen Kurikulum Merdeka</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
              <span>Buku Nilai &amp; Asesmen PAI &amp; BP ({currentRombel?.nama || `Kelas ${currentTingkat}`})</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5 font-medium">
              Kelola daftar nama siswa per rombel, nilai formatif, sumatif per lingkup materi (Bab), STS, SAS, serta rekapitulasi nilai rapor otomatis.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Toggle Tampilan Input Bab vs Rekapitulasi */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-300">
              <button
                type="button"
                onClick={() => setActiveViewMode("input-bab")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeViewMode === "input-bab"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Input Nilai per Bab</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveViewMode("rekap")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeViewMode === "rekap"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Rekap Nilai Rapor</span>
              </button>
            </div>

            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
              title="Unduh format spreadsheet / Excel CSV"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>Ekspor CSV / Excel</span>
            </button>

            <button
              onClick={() =>
                handleDownloadWord(
                  "printable-penilaian-area",
                  `Buku_Nilai_PAI_${currentRombel?.nama.replace(/\s+/g, "_")}_Sem_${selectedSemester.split(" ")[0]}_${identitas.sekolah.replace(/\s+/g, "_")}`,
                  true
                )
              }
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Word (.doc)</span>
            </button>

            <button
              onClick={() =>
                handlePrintDocument(
                  "printable-penilaian-area",
                  `Buku_Nilai_PAI_${currentRombel?.nama}_Sem_${selectedSemester.split(" ")[0]}`,
                  "landscape"
                )
              }
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Cetak / PDF (A4)</span>
            </button>
          </div>
        </div>

        {/* Pilihan Rombel / Kelas Input & Semester */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          {/* Pilih Rombel Input */}
          <div className="md:col-span-5">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              Pilih Rombongan Belajar (Rombel yang Diinput):
            </label>
            <div className="flex items-center gap-1.5 flex-wrap">
              {daftarKelas.map((rombel) => (
                <button
                  key={rombel.id}
                  type="button"
                  onClick={() => setSelectedRombelId(rombel.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    selectedRombelId === rombel.id
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                      : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                  }`}
                >
                  {rombel.nama} ({rombel.jumlahSiswa} Murid)
                </button>
              ))}
            </div>
          </div>

          {/* Pilih Semester */}
          <div className="md:col-span-3">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              Semester:
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {["I (Ganjil)", "II (Genap)"].map((sem) => (
                <button
                  key={sem}
                  type="button"
                  onClick={() => setSelectedSemester(sem)}
                  className={`py-2 px-2 text-center rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    selectedSemester === sem
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                      : "bg-emerald-50/70 text-slate-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-950"
                  }`}
                >
                  {sem.split(" ")[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Standar KKTP / Interval Nilai */}
          <div className="md:col-span-2">
            <label className="block text-[11px] font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              Kriteria KKTP:
            </label>
            <div className="flex items-center gap-1.5 bg-emerald-50/70 border border-emerald-300 rounded-xl px-3 py-1.5">
              <span className="text-xs font-bold text-slate-600">KKTP =</span>
              <input
                type="number"
                min={60}
                max={95}
                value={kktpStandard}
                onChange={(e) => setKktpStandard(parseInt(e.target.value, 10) || 75)}
                className="w-14 text-xs font-extrabold text-emerald-950 bg-white border border-slate-300 rounded px-1.5 py-0.5 text-center"
              />
              <span className="text-[10px] text-slate-500 font-bold">Poin</span>
            </div>
          </div>

          {/* Tombol Kelola Siswa */}
          <div className="md:col-span-2 flex items-center gap-1.5 justify-end">
            <button
              type="button"
              onClick={() => setShowUploadExcelModal(true)}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white transition-all shadow-xs cursor-pointer shrink-0"
              title="Upload daftar siswa dengan file Excel (.xlsx / .csv)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
              <span>Upload Excel</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAddSiswaModal(true)}
              className="flex items-center justify-center gap-1 px-2.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-colors shadow-xs cursor-pointer"
              title="Tambah siswa manual satu per satu"
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-700" />
              <span>+ Siswa</span>
            </button>
            <button
              type="button"
              onClick={() => setShowPasteModal(true)}
              className="flex items-center justify-center p-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 transition-colors shadow-xs cursor-pointer"
              title="Tempel daftar nama siswa massal"
            >
              <ClipboardPaste className="w-4 h-4 text-emerald-700" />
            </button>
          </div>
        </div>

        {/* Pilihan Lingkup Materi (Sesuai Bab) jika mode 'input-bab' */}
        {activeViewMode === "input-bab" && (
          <div className="pt-3 border-t border-emerald-200">
            <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
              <label className="text-[11px] font-extrabold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-emerald-700" />
                <span>Pilih Lingkup Materi (Sesuai Bab):</span>
              </label>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddKolomModal(true)}
                  className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                >
                  <Plus className="w-3 h-3 text-emerald-700" />
                  <span>+ Kolom Penilaian Kustom</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleFillAllAverage(85)}
                  className="text-[11px] font-bold text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200 border border-slate-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  title="Isi seluruh siswa pada bab ini dengan nilai 85"
                >
                  Isi Rata-rata 85
                </button>
                <button
                  type="button"
                  onClick={handleGenerateRealisticScores}
                  className="text-[11px] font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3 text-amber-700" />
                  <span>Simulasi Nilai</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {classModules.map((mod) => (
                <button
                  key={mod.id}
                  type="button"
                  onClick={() => setActiveBabNomor(mod.nomor)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeBabNomor === mod.nomor
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-md"
                      : "bg-white text-slate-700 border-slate-300 hover:bg-emerald-50"
                  }`}
                >
                  <span className="w-5 h-5 rounded-md bg-white/20 text-current text-[10px] flex items-center justify-center font-bold">
                    {mod.nomor}
                  </span>
                  <span>Bab {mod.nomor}: {mod.elemen}</span>
                </button>
              ))}
            </div>

            {activeModul && (
              <div className="mt-3 p-3 bg-emerald-50/70 rounded-xl border border-emerald-200 text-xs">
                <div className="font-extrabold text-slate-900">
                  Lingkup Materi Bab {activeModul.nomor}: <span className="text-emerald-950">{activeModul.elemen}</span>
                </div>
                <div className="text-slate-700 mt-0.5">
                  <strong>TP:</strong> {activeModul.tp}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* TAMPILAN 1: INPUT NILAI PER LINGKUP MATERI (BAB AKTIF)   */}
      {/* ======================================================== */}
      {activeViewMode === "input-bab" && (
        <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <span>Lembar Input Nilai Bab {activeBabNomor} ({currentRombel?.nama})</span>
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Ketik nilai angka (0 s.d. 100) langsung pada kotak isian siswa di bawah ini. Nilai otomatis tersimpan secara instan.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-slate-600 font-bold bg-slate-100 border border-slate-300 px-2.5 py-1 rounded-lg">
                Total: {daftarSiswa.length} Siswa
              </span>

              <button
                type="button"
                onClick={handleReset3Examples}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                title="Terapkan 3 contoh nama siswa sebagai panduan"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>3 Contoh Panduan</span>
              </button>

              <button
                type="button"
                onClick={handleClearAllStudents}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                title="Kosongkan seluruh nama siswa pada rombel ini"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Kosongkan Siswa</span>
              </button>

              <button
                type="button"
                onClick={() => setShowUploadExcelModal(true)}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-950 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                title="Unggah data siswa dari file Excel"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                <span>Upload Excel</span>
              </button>

              <button
                type="button"
                onClick={() => setShowAddSiswaModal(true)}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-white bg-[#065f46] hover:bg-emerald-800 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-white" />
                <span>Tambah Siswa</span>
              </button>

              <button
                type="button"
                onClick={handleResetScores}
                className="text-[11px] font-bold text-slate-700 hover:text-rose-700 hover:bg-rose-50 border border-slate-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
              >
                Reset Nilai
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-slate-300 text-xs text-slate-900">
              <thead>
                <tr className="bg-emerald-50 border-b border-slate-300">
                  <th className="border border-slate-300 px-2.5 py-2 text-center font-bold w-10">No</th>
                  <th className="border border-slate-300 px-3 py-2 text-center font-bold w-24">NISN</th>
                  <th className="border border-slate-300 px-3 py-2 text-left font-bold min-w-[180px]">Nama Siswa</th>
                  <th className="border border-slate-300 px-2 py-2 text-center font-bold w-12">L/P</th>
                  
                  {/* Kolom Formatif Default */}
                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-emerald-100/60 min-w-[90px]">
                    <div>Formatif 1</div>
                    <div className="text-[10px] font-normal text-slate-600">Tugas / Kuis</div>
                  </th>
                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-emerald-100/60 min-w-[90px]">
                    <div>Formatif 2</div>
                    <div className="text-[10px] font-normal text-slate-600">Praktik / Hafalan</div>
                  </th>
                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-emerald-100/60 min-w-[90px]">
                    <div>Formatif 3</div>
                    <div className="text-[10px] font-normal text-slate-600">Observasi Sikap</div>
                  </th>

                  {/* Kolom Sumatif Lingkup Materi */}
                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-teal-100 min-w-[100px] text-teal-950">
                    <div>Sumatif LM</div>
                    <div className="text-[10px] font-semibold text-teal-800">Tes / Asesmen Bab</div>
                  </th>

                  {/* Kolom Kustom yang Ditambahkan Pengguna */}
                  {customKolomList.map((col) => (
                    <th key={col.id} className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-amber-50 min-w-[110px]">
                      <div className="flex items-center justify-center gap-1">
                        <span>{col.nama}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteCustomKolom(col.id)}
                          className="text-rose-600 hover:text-rose-800"
                          title="Hapus kolom ini"
                        >
                          ×
                        </button>
                      </div>
                      <div className="text-[10px] font-normal text-slate-600">({col.kategori})</div>
                    </th>
                  ))}

                  {/* Rata-rata Bab */}
                  <th className="border border-slate-300 px-2.5 py-2 text-center font-bold bg-emerald-200/70 w-20 text-emerald-950">
                    Nilai Bab
                  </th>
                  <th className="border border-slate-300 px-2.5 py-2 text-center font-bold w-24">Status</th>
                  <th className="border border-slate-300 px-2 py-2 text-center font-bold w-14">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {daftarSiswa.length === 0 ? (
                  <tr>
                    <td colSpan={13 + customKolomList.length} className="py-10 px-4 text-center bg-slate-50/50">
                      <div className="flex flex-col items-center justify-center max-w-md mx-auto space-y-3">
                        <div className="w-12 h-12 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-700 shadow-xs border border-emerald-300">
                          <Users className="w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-800 text-sm">Daftar Siswa Masih Kosong</h4>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            Belum ada nama siswa untuk {currentRombel?.nama}. Anda dapat mengunggah file Excel, menambah siswa secara manual, atau menggunakan 3 nama siswa sebagai contoh panduan.
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                          <button
                            type="button"
                            onClick={handleReset3Examples}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-300 transition-all cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Gunakan 3 Contoh Siswa Panduan</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowUploadExcelModal(true)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
                          >
                            <FileSpreadsheet className="w-3.5 h-3.5" />
                            <span>Upload File Excel</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowAddSiswaModal(true)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-all cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Tambah Siswa Manual</span>
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ) : (
                  daftarSiswa.map((sis, idx) => {
                  const rec = nilaiRecords[sis.id] || { siswaId: sis.id, formatif: {}, sumatifLm: {}, kustom: {} };
                  const babKey = String(activeBabNomor);
                  const fObj = rec.formatif?.[babKey] || {};
                  const slmVal = rec.sumatifLm?.[babKey] || 0;

                  // Hitung rata-rata Bab
                  const fVals = [fObj["f1"], fObj["f2"], fObj["f3"]].filter((v) => typeof v === "number" && v > 0);
                  const avgF = fVals.length > 0 ? fVals.reduce((a, c) => a + c, 0) / fVals.length : 0;
                  const finalBabScore = slmVal > 0 ? slmVal : Math.round(avgF);
                  const isTuntas = finalBabScore >= kktpStandard;

                  return (
                    <tr key={sis.id} className="hover:bg-slate-50 border-b border-slate-200">
                      <td className="border border-slate-300 px-2 py-1.5 text-center font-bold">{idx + 1}</td>
                      <td className="border border-slate-300 px-2 py-1.5 text-center text-[11px] font-mono">{sis.nisn}</td>
                      <td className="border border-slate-300 px-3 py-1.5 font-bold text-slate-900">{sis.nama}</td>
                      <td className="border border-slate-300 px-2 py-1.5 text-center font-semibold text-slate-600">{sis.gender}</td>

                      {/* Input Formatif 1 */}
                      <td className="border border-slate-300 p-1 text-center bg-emerald-50/30">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={fObj["f1"] ?? ""}
                          placeholder="-"
                          onChange={(e) => handleUpdateNilai(sis.id, "formatif", "f1", parseInt(e.target.value, 10))}
                          className="w-16 text-center text-xs font-bold py-1 px-1 bg-white border border-slate-300 rounded focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      {/* Input Formatif 2 */}
                      <td className="border border-slate-300 p-1 text-center bg-emerald-50/30">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={fObj["f2"] ?? ""}
                          placeholder="-"
                          onChange={(e) => handleUpdateNilai(sis.id, "formatif", "f2", parseInt(e.target.value, 10))}
                          className="w-16 text-center text-xs font-bold py-1 px-1 bg-white border border-slate-300 rounded focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      {/* Input Formatif 3 */}
                      <td className="border border-slate-300 p-1 text-center bg-emerald-50/30">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={fObj["f3"] ?? ""}
                          placeholder="-"
                          onChange={(e) => handleUpdateNilai(sis.id, "formatif", "f3", parseInt(e.target.value, 10))}
                          className="w-16 text-center text-xs font-bold py-1 px-1 bg-white border border-slate-300 rounded focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500"
                        />
                      </td>

                      {/* Input Sumatif LM (Bab) */}
                      <td className="border border-slate-300 p-1 text-center bg-teal-50">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={slmVal > 0 ? slmVal : ""}
                          placeholder="-"
                          onChange={(e) => handleUpdateNilai(sis.id, "sumatifLm", babKey, parseInt(e.target.value, 10))}
                          className="w-18 text-center text-xs font-extrabold py-1 px-1 bg-white border-2 border-teal-400 rounded text-teal-950 focus:border-teal-600 focus:ring-1 focus:ring-teal-500 shadow-xs"
                        />
                      </td>

                      {/* Input Kolom Kustom */}
                      {customKolomList.map((col) => (
                        <td key={col.id} className="border border-slate-300 p-1 text-center bg-amber-50/40">
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={rec.kustom?.[col.id] ?? ""}
                            placeholder="-"
                            onChange={(e) => handleUpdateNilai(sis.id, "kustom", col.id, parseInt(e.target.value, 10))}
                            className="w-16 text-center text-xs font-bold py-1 px-1 bg-white border border-amber-300 rounded focus:border-amber-600 focus:ring-1 focus:ring-amber-500"
                          />
                        </td>
                      ))}

                      {/* Skor Akhir Bab Ini */}
                      <td className="border border-slate-300 px-2 py-1 text-center font-extrabold text-sm bg-emerald-100/50 text-emerald-950">
                        {finalBabScore > 0 ? finalBabScore : "-"}
                      </td>

                      {/* Status KKTP */}
                      <td className="border border-slate-300 px-2 py-1 text-center">
                        {finalBabScore > 0 ? (
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                              isTuntas
                                ? "bg-emerald-100 text-emerald-900 border border-emerald-300"
                                : "bg-rose-100 text-rose-800 border border-rose-300"
                            }`}
                          >
                            {isTuntas ? "✓ Tuntas" : "Bimbingan"}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[10px]">-</span>
                        )}
                      </td>

                      {/* Aksi Hapus Siswa */}
                      <td className="border border-slate-300 px-1 py-1 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteSiswa(sis.id, sis.nama)}
                          className="p-1 text-rose-600 hover:text-white hover:bg-rose-600 rounded transition-colors"
                          title="Hapus siswa ini"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                }))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAMPILAN 2: REKAPITULASI NILAI LINGKUP MATERI & RAPOR    */}
      {/* ======================================================== */}
      {activeViewMode === "rekap" && (
        <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-5 no-print text-slate-800">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <span>Rekapitulasi Nilai Akhir &amp; Capaian Rapor ({currentRombel?.nama} - {selectedSemester})</span>
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Nilai Akhir (NA) dihitung otomatis: <strong>NA = (2 × Rata-rata Lingkup Materi + STS + SAS) ÷ 4</strong>.
              </p>
            </div>

            {/* Kotak Ringkasan Statistik */}
            <div className="flex items-center gap-2 flex-wrap text-xs">
              <div className="bg-emerald-50 border border-emerald-300 px-3 py-1.5 rounded-xl font-bold text-emerald-950">
                Rata-rata: <span className="text-sm font-extrabold text-emerald-700">{statsKelas.avg}</span>
              </div>
              <div className="bg-teal-50 border border-teal-300 px-3 py-1.5 rounded-xl font-bold text-teal-950">
                Tertinggi: <span className="text-sm font-extrabold text-teal-700">{statsKelas.highest}</span>
              </div>
              <div className="bg-amber-50 border border-amber-300 px-3 py-1.5 rounded-xl font-bold text-amber-950">
                Ketuntasan KKTP: <span className="text-sm font-extrabold text-amber-800">{statsKelas.tuntasPersen}%</span>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-slate-300 text-xs text-slate-900">
              <thead>
                <tr className="bg-[#e6f7ef] border-b border-slate-300">
                  <th className="border border-slate-300 px-2 py-2 text-center font-bold w-10">No</th>
                  <th className="border border-slate-300 px-2.5 py-2 text-center font-bold w-24">NISN</th>
                  <th className="border border-slate-300 px-3 py-2 text-left font-bold min-w-[170px]">Nama Siswa</th>
                  <th className="border border-slate-300 px-1.5 py-2 text-center font-bold w-10">L/P</th>

                  {/* Kolom Lingkup Materi (Bab 1, Bab 2, dst.) */}
                  {classModules.map((m) => (
                    <th key={m.id} className="border border-slate-300 px-2 py-1.5 text-center font-bold min-w-[75px] bg-emerald-100/60">
                      <div>Bab {m.nomor}</div>
                      <div className="text-[9px] font-normal text-slate-600 truncate max-w-[80px]" title={m.elemen}>
                        {m.elemen}
                      </div>
                    </th>
                  ))}

                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-teal-100 min-w-[80px] text-teal-950">
                    Rata SLM
                  </th>
                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-amber-50 min-w-[75px]">
                    STS
                  </th>
                  <th className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-amber-50 min-w-[75px]">
                    SAS
                  </th>
                  <th className="border border-slate-300 px-2 py-2 text-center font-extrabold bg-[#065f46] text-white min-w-[80px]">
                    Nilai Akhir
                  </th>
                  <th className="border border-slate-300 px-2 py-2 text-center font-bold min-w-[100px]">Predikat</th>
                  <th className="border border-slate-300 px-3 py-2 text-left font-bold min-w-[200px]">Capaian Kompetensi Rapor</th>
                </tr>
              </thead>
              <tbody>
                {rekapCalculations.map((row, idx) => (
                  <tr key={row.siswa.id} className="hover:bg-slate-50 border-b border-slate-200">
                    <td className="border border-slate-300 px-2 py-1.5 text-center font-bold">{idx + 1}</td>
                    <td className="border border-slate-300 px-2 py-1.5 text-center text-[11px] font-mono">{row.siswa.nisn}</td>
                    <td className="border border-slate-300 px-3 py-1.5 font-bold text-slate-900">{row.siswa.nama}</td>
                    <td className="border border-slate-300 px-1.5 py-1.5 text-center font-semibold text-slate-600">{row.siswa.gender}</td>

                    {/* Nilai Bab per Bab */}
                    {classModules.map((m) => {
                      const score = row.babScores[m.nomor] || 0;
                      return (
                        <td key={m.id} className="border border-slate-300 px-2 py-1.5 text-center font-semibold">
                          {score > 0 ? score : "-"}
                        </td>
                      );
                    })}

                    <td className="border border-slate-300 px-2 py-1.5 text-center font-bold bg-teal-50 text-teal-950">
                      {row.avgSumatifLm > 0 ? row.avgSumatifLm : "-"}
                    </td>

                    {/* Input Langsung STS & SAS di Rekap */}
                    <td className="border border-slate-300 p-1 text-center bg-amber-50/30">
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={row.sts > 0 ? row.sts : ""}
                        placeholder="-"
                        onChange={(e) => handleUpdateNilai(row.siswa.id, "sts", "", parseInt(e.target.value, 10))}
                        className="w-14 text-center text-xs font-bold py-1 px-1 bg-white border border-slate-300 rounded"
                      />
                    </td>
                    <td className="border border-slate-300 p-1 text-center bg-amber-50/30">
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={row.sas > 0 ? row.sas : ""}
                        placeholder="-"
                        onChange={(e) => handleUpdateNilai(row.siswa.id, "sas", "", parseInt(e.target.value, 10))}
                        className="w-14 text-center text-xs font-bold py-1 px-1 bg-white border border-slate-300 rounded"
                      />
                    </td>

                    <td className="border border-slate-300 px-2 py-1.5 text-center font-extrabold text-sm bg-emerald-50 text-emerald-950">
                      {row.nilaiAkhir > 0 ? row.nilaiAkhir : "-"}
                    </td>

                    <td className="border border-slate-300 px-2 py-1 text-center">
                      {row.nilaiAkhir > 0 ? (
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${row.badgeColor}`}>
                          {row.predikat}
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    <td className="border border-slate-300 px-2.5 py-1.5 text-slate-800 text-[10.5px] leading-snug">
                      {row.nilaiAkhir > 0 ? row.deskripsi : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAMPILAN 3: DOKUMEN CETAK RESMI BUKU NILAI A4 RESMI     */}
      {/* ======================================================== */}
      <div
        id="printable-penilaian-area"
        style={paperLightMode ? { padding: "1.5cm 2.0cm 2.0cm 2.5cm" } : undefined}
        className={`rounded-2xl border p-4 sm:p-8 transition-colors duration-300 ${docContainerClass} ${
          activeViewMode === "input-bab" ? "hidden print:block" : "block"
        }`}
      >
        {/* Kop Surat Resmi */}
        {useKopSurat && kopSuratUrl && (
          <div className="kop-surat-header mb-4 text-center">
            <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-20 w-full object-contain mx-auto" />
            <div className="kop-surat-divider border-t-2 border-black mt-1.5 mb-3"></div>
          </div>
        )}

        {/* Header Judul Dokumen Cetak */}
        <div className="doc-header-box text-center border-b-2 pb-3 mb-4 border-black">
          <h2 className="doc-main-title text-base sm:text-[14pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            BUKU PENILAIAN &amp; REKAPITULASI ASESMEN HASIL BELAJAR PESERTA DIDIK
          </h2>
          <h3 className="doc-sub-title text-xs sm:text-[12pt] font-bold uppercase tracking-wider text-center text-black" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
          </h3>
          <p className="text-[11pt] font-bold text-center mt-1 uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            KURIKULUM MERDEKA • TAHUN AJARAN {identitas.tahunAjaran}
          </p>
        </div>

        {/* Identitas Dokumen Cetak */}
        <div className="identitas-block mb-4 space-y-0.5 text-xs sm:text-[11pt] max-w-2xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Satuan Pendidikan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold uppercase">{identitas.sekolah}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Rombongan Belajar / Fase</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {currentRombel?.nama || `Kelas ${currentTingkat}`} / Fase {currentRombel?.fase || "A"}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Semester / Tahun Ajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {selectedSemester} / {identitas.tahunAjaran}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Kriteria Ketercapaian TP (KKTP)</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{kktpStandard} (Skala 100)</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Guru Mata Pelajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.guruPai} (NIP. {identitas.nipGuru})</span>
          </div>
        </div>

        {/* Tabel Rekap Resmi Cetak */}
        <div className="overflow-x-auto print:overflow-visible">
          <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%' }}>
            <thead>
              <tr className={tableHeaderBgClass}>
                <th className={`border px-2 py-2 text-center font-bold w-[4%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  No
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[9%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  NISN
                </th>
                <th className={`border px-3 py-2 text-left font-bold w-[22%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'left' }}>
                  Nama Peserta Didik
                </th>
                <th className={`border px-1.5 py-2 text-center font-bold w-[4%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  L/P
                </th>

                {/* Lingkup Materi (Bab) */}
                {classModules.map((m) => (
                  <th key={m.id} className={`border px-1.5 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    <div>Bab {m.nomor}</div>
                    <div className="text-[8pt] font-normal">{m.elemen}</div>
                  </th>
                ))}

                <th className={`border px-2 py-2 text-center font-bold w-[7%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Rata SLM
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[6%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  STS
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[6%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  SAS
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[7%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', backgroundColor: '#e2e8f0' }}>
                  Nilai Akhir
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[9%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Predikat
                </th>
                <th className={`border px-2 py-2 text-center font-bold w-[8%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  KKTP
                </th>
              </tr>
            </thead>
            <tbody>
              {rekapCalculations.map((row, idx) => (
                <tr key={row.siswa.id} className="text-[10pt]" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <td className={`border px-2 py-1 text-center align-middle font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {idx + 1}
                  </td>
                  <td className={`border px-2 py-1 text-center align-middle font-mono text-[9pt] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.siswa.nisn}
                  </td>
                  <td className={`border px-2.5 py-1 align-middle font-bold text-black ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'left' }}>
                    {row.siswa.nama}
                  </td>
                  <td className={`border px-1.5 py-1 text-center align-middle ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.siswa.gender}
                  </td>

                  {/* Nilai Bab */}
                  {classModules.map((m) => {
                    const score = row.babScores[m.nomor] || 0;
                    return (
                      <td key={m.id} className={`border px-1.5 py-1 text-center align-middle font-semibold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                        {score > 0 ? score : "-"}
                      </td>
                    );
                  })}

                  <td className={`border px-2 py-1 text-center align-middle font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.avgSumatifLm > 0 ? row.avgSumatifLm : "-"}
                  </td>
                  <td className={`border px-2 py-1 text-center align-middle ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.sts > 0 ? row.sts : "-"}
                  </td>
                  <td className={`border px-2 py-1 text-center align-middle ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.sas > 0 ? row.sas : "-"}
                  </td>
                  <td className={`border px-2 py-1 text-center align-middle font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center', backgroundColor: '#f1f5f9' }}>
                    {row.nilaiAkhir > 0 ? row.nilaiAkhir : "-"}
                  </td>
                  <td className={`border px-2 py-1 text-center align-middle font-bold text-[9pt] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.nilaiAkhir > 0 ? row.predikat.split(" ")[0] : "-"}
                  </td>
                  <td className={`border px-2 py-1 text-center align-middle font-bold text-[9pt] ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {row.nilaiAkhir > 0 ? (row.isTuntas ? "Tuntas" : "Bimbingan") : "-"}
                  </td>
                </tr>
              ))}

              {/* Baris Rata-rata Kelas */}
              {rekapCalculations.length > 0 && (
                <tr className="bg-slate-50 font-bold" style={{ backgroundColor: '#f8fafc', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <td colSpan={4 + classModules.length} className={`border px-3 py-1.5 text-right ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'right' }}>
                    Rata-rata Nilai Kelas ({currentRombel?.nama}):
                  </td>
                  <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {statsKelas.avg > 0 ? statsKelas.avg : "-"}
                  </td>
                  <td colSpan={2} className={`border px-2 py-1.5 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    Ketuntasan KKTP:
                  </td>
                  <td className={`border px-2 py-1.5 text-center font-extrabold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {statsKelas.avg > 0 ? statsKelas.avg : "-"}
                  </td>
                  <td colSpan={2} className={`border px-2 py-1.5 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {statsKelas.tuntasPersen}% Tuntas
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Tanda Tangan Pengesahan Resmi (Tanpa Kotak Garis) */}
        <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <tbody>
            <tr style={{ border: 'none', background: 'transparent' }}>
              <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
              </td>
              <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru Mata Pelajaran PAI &amp; BP</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* ======================================================== */}
      {/* MODAL: TAMBAH SISWA BARU                                 */}
      {/* ======================================================== */}
      {showAddSiswaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs no-print">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border-2 border-emerald-400 space-y-4">
            <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-emerald-700" />
              <span>Tambah Peserta Didik Baru ({currentRombel?.nama})</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Lengkap Siswa:</label>
                <input
                  type="text"
                  placeholder="Contoh: Muhammad Rayhan"
                  value={newSiswaNama}
                  onChange={(e) => setNewSiswaNama(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">NISN / Nomor Induk (Opsional):</label>
                <input
                  type="text"
                  placeholder="Contoh: 0123456789"
                  value={newSiswaNisn}
                  onChange={(e) => setNewSiswaNisn(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Jenis Kelamin:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewSiswaGender("L")}
                    className={`py-2 rounded-xl border font-bold transition-all ${
                      newSiswaGender === "L"
                        ? "bg-[#065f46] text-white border-emerald-800"
                        : "bg-slate-50 text-slate-700 border-slate-300"
                    }`}
                  >
                    Laki-Laki (L)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewSiswaGender("P")}
                    className={`py-2 rounded-xl border font-bold transition-all ${
                      newSiswaGender === "P"
                        ? "bg-[#065f46] text-white border-emerald-800"
                        : "bg-slate-50 text-slate-700 border-slate-300"
                    }`}
                  >
                    Perempuan (P)
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowAddSiswaModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleAddSiswa}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] text-white hover:bg-emerald-800 shadow-sm"
              >
                Simpan Siswa
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: TEMPEL NAMA SISWA MASSAL                          */}
      {/* ======================================================== */}
      {showPasteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs no-print">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border-2 border-emerald-400 space-y-4">
            <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <ClipboardPaste className="w-5 h-5 text-emerald-700" />
              <span>Tempel Daftar Nama Siswa Massal ({currentRombel?.nama})</span>
            </h3>

            <p className="text-xs text-slate-600 font-medium">
              Salin dari Excel, Word, atau pesan WhatsApp, lalu tempel di kotak bawah ini. Pisahkan satu nama siswa per baris.
            </p>

            <textarea
              rows={8}
              value={pastedNames}
              onChange={(e) => setPastedNames(e.target.value)}
              placeholder={"1. Ahmad Al-Fatih\n2. Aisyah Putri\n3. Bilal Ramadhan\n4. Dania Salsabila"}
              className="w-full p-3 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium font-sans"
            />

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowPasteModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handlePasteMassal}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] text-white hover:bg-emerald-800 shadow-sm"
              >
                Impor Semua Siswa
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: TAMBAH KOLOM PENILAIAN KUSTOM (INPUT MANUAL)      */}
      {/* ======================================================== */}
      {showAddKolomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs no-print">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border-2 border-emerald-400 space-y-4">
            <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <Plus className="w-5 h-5 text-emerald-700" />
              <span>Tambah Jenis Penilaian Kustom / Manual</span>
            </h3>

            <p className="text-xs text-slate-600 font-medium">
              Tambahkan kolom penilaian tambahan sesuai kebutuhan spesifik Anda (contoh: Praktik Sholat, Hafalan Doa Harian, Kuis Asmaul Husna, Tugas Mandiri, dll.).
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama / Jenis Penilaian:</label>
                <input
                  type="text"
                  placeholder="Contoh: Hafalan Surat Pendek"
                  value={newKolomNama}
                  onChange={(e) => setNewKolomNama(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Kategori Penilaian:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewKolomKategori("Formatif")}
                    className={`py-2 rounded-xl border font-bold transition-all ${
                      newKolomKategori === "Formatif"
                        ? "bg-[#065f46] text-white border-emerald-800"
                        : "bg-slate-50 text-slate-700 border-slate-300"
                    }`}
                  >
                    Formatif
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewKolomKategori("Sumatif")}
                    className={`py-2 rounded-xl border font-bold transition-all ${
                      newKolomKategori === "Sumatif"
                        ? "bg-[#065f46] text-white border-emerald-800"
                        : "bg-slate-50 text-slate-700 border-slate-300"
                    }`}
                  >
                    Sumatif
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowAddKolomModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleAddCustomKolom}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] text-white hover:bg-emerald-800 shadow-sm"
              >
                Tambahkan Kolom
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL UPLOAD EXCEL SISWA */}
      <ModalUploadSiswaExcel
        isOpen={showUploadExcelModal}
        onClose={() => setShowUploadExcelModal(false)}
        currentRombel={currentRombel}
        daftarKelas={daftarKelas}
        onRombelChange={(newId) => setSelectedRombelId(newId)}
        onSuccessSave={handleSaveFromExcel}
        showToast={showToast}
        existingCount={daftarSiswa.length}
      />
    </div>
  );
};
