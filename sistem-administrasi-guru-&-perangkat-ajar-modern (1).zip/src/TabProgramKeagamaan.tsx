import React, { useState } from 'react';
import {
  MoonStar,
  Edit3,
  Save,
  Download,
  Printer,
  Sun,
  Moon,
  Clock,
  CheckCircle2,
  Calendar,
  Layers,
  Sparkles,
  BookOpen,
  Plus,
  Trash2,
  HeartHandshake,
  Award,
  ChevronDown
} from 'lucide-react';
import { ProgramKeagamaanData, KegiatanPhbi, JadwalJumat, MatriksProgram } from './dataProgramKeagamaan.ts';

interface TabProgramKeagamaanProps {
  programKeagamaan: ProgramKeagamaanData;
  setProgramKeagamaan: React.Dispatch<React.SetStateAction<ProgramKeagamaanData>>;
  isEditingKeagamaan: boolean;
  setIsEditingKeagamaan: (val: boolean) => void;
  handleSaveKeagamaan: () => void;
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId: string) => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
}

export const TabProgramKeagamaan: React.FC<TabProgramKeagamaanProps> = ({
  programKeagamaan,
  setProgramKeagamaan,
  isEditingKeagamaan,
  setIsEditingKeagamaan,
  handleSaveKeagamaan,
  identitas,
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat
}) => {
  // Update fields di programKeagamaan
  const handleUpdateField = (field: keyof ProgramKeagamaanData, val: any) => {
    setProgramKeagamaan((prev) => ({ ...prev, [field]: val }));
  };

  // Update item PHBI
  const handleUpdatePhbi = (idx: number, field: keyof KegiatanPhbi, val: any) => {
    setProgramKeagamaan((prev) => {
      const list = [...prev.phbi];
      list[idx] = { ...list[idx], [field]: val };
      return { ...prev, phbi: list };
    });
  };

  // Update item Jumat
  const handleUpdateJumat = (idx: number, field: keyof JadwalJumat, val: any) => {
    setProgramKeagamaan((prev) => {
      const list = [...prev.jumatPagi.jadwal];
      list[idx] = { ...list[idx], [field]: val };
      return { ...prev, jumatPagi: { ...prev.jumatPagi, jadwal: list } };
    });
  };

  // Update matriks
  const handleUpdateMatriks = (idx: number, field: keyof MatriksProgram, val: any) => {
    setProgramKeagamaan((prev) => {
      const list = [...prev.matriks];
      list[idx] = { ...list[idx], [field]: val };
      return { ...prev, matriks: list };
    });
  };

  return (
    <div className="space-y-6">
      {/* TOOLBAR ATAS: EDIT, SIMPAN, THEME, SPASI, WORD & CETAK */}
      {/* TOOLBAR PROGRAM KEAGAMAAN */}
      <div className="bg-white rounded-2xl border-2 border-emerald-300 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print shadow-sm text-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-100 rounded-2xl border border-emerald-300 text-emerald-800">
            <MoonStar className="w-6 h-6 text-emerald-700" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span>Program Pembiasaan &amp; Kegiatan Keagamaan Islam</span>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
                Resmi SD
              </span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5 font-medium">
              PHBI (1 Muharram, Maulid Nabi, Isra' Mi'raj) &amp; Pembiasaan Jumat Pagi Bergantian (Dhuha, Zikir/Asmaul Husna, Tahsin/Tahfidz)
            </p>
          </div>
        </div>

        {/* Buttons Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Toggle Spasi */}
          <button
            onClick={() => setLineSpacing(lineSpacing === "1.5" ? "1.15" : "1.5")}
            className="px-3 py-2 rounded-xl text-xs font-bold bg-white text-slate-800 border border-slate-300 hover:bg-emerald-50 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Ubah spasi baris dokumen resmi"
          >
            <Clock className="w-3.5 h-3.5 text-emerald-700" />
            <span>Spasi {lineSpacing}</span>
          </button>

          {/* Tombol Edit & Simpan */}
          {isEditingKeagamaan ? (
            <button
              onClick={handleSaveKeagamaan}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm flex items-center gap-2 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Perubahan</span>
            </button>
          ) : (
            <button
              onClick={() => setIsEditingKeagamaan(true)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-slate-800 border border-slate-300 flex items-center gap-2 transition-all cursor-pointer"
            >
              <Edit3 className="w-4 h-4 text-emerald-700" />
              <span>Edit Program</span>
            </button>
          )}

          {/* Tombol Unduh Word */}
          <button
            onClick={() => handleDownloadWord("printable-area", `Program_Keagamaan_Islam_${identitas.sekolah.replace(/\s+/g, '_')}_${identitas.tahunAjaran.replace(/\//g, '-')}`)}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 flex items-center gap-2 transition-all shadow-xs cursor-pointer"
            title="Unduh dokumen Word resmi A4 margin 1.5 - 2.5 - 2.0 - 2.0 cm"
          >
            <Download className="w-4 h-4 text-emerald-700" />
            <span>Unduh Word</span>
          </button>

          {/* Tombol Cetak / PDF */}
          <button
            onClick={() => handlePrintDocument("printable-area")}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm flex items-center gap-2 transition-all cursor-pointer"
            title="Cetak A4 / Simpan PDF resmi"
          >
            <Printer className="w-4 h-4" />
            <span>Simpan PDF (A4)</span>
          </button>
        </div>
      </div>

      {/* DOKUMEN CETAK RESMI: PROGRAM KEAGAMAAN ISLAM */}
      <div
        id="printable-area"
        className={`max-w-4xl mx-auto rounded-3xl p-6 sm:p-12 transition-all border ${docContainerClass} official-doc-typography`}
        style={{ minHeight: "29.7cm" }}
      >
        {/* KOP SURAT RESMI SEKOLAH (Jika Diaktifkan) */}
        {useKopSurat && kopSuratUrl && (
          <div className="kop-surat-header mb-4 text-center">
            <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
            <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
          </div>
        )}

        {/* KOP / JUDUL DOKUMEN RESMI */}
        <div className="doc-header-box text-center mb-6 border-b-2 border-black/80 pb-3 keep-together" style={{ lineHeight: 1.15 }}>
          <h2 className="doc-main-title font-bold text-base sm:text-lg tracking-wide uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            PROGRAM PEMBIASAAN DAN KEGIATAN KEAGAMAAN ISLAM
          </h2>
          <h3 className="doc-sub-title font-bold text-sm sm:text-base tracking-wide uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            SATUAN PENDIDIKAN SEKOLAH DASAR
          </h3>
          <p className="text-xs sm:text-sm font-semibold uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            {identitas.sekolah} • TAHUN AJARAN {identitas.tahunAjaran}
          </p>
        </div>

        {/* ======================================================== */}
        {/* BAB I: PENDAHULUAN                                       */}
        {/* ======================================================== */}
        <div className="mb-8 space-y-4">
          <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
            BAB I. PENDAHULUAN
          </h4>

          {/* A. Latar Belakang */}
          <div className="space-y-2">
            <h5 className="font-bold text-xs sm:text-sm text-black dark:text-emerald-300">
              A. Latar Belakang
            </h5>
            {isEditingKeagamaan ? (
              <textarea
                rows={7}
                value={programKeagamaan.latarBelakang}
                onChange={(e) => handleUpdateField("latarBelakang", e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-700 bg-slate-900/90 text-xs sm:text-sm text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            ) : (
              <div className="space-y-2 text-xs sm:text-sm leading-relaxed text-justify">
                {programKeagamaan.latarBelakang.split('\n\n').map((par, i) => (
                  <p key={i} className="indent-first text-justify">
                    {par}
                  </p>
                ))}
              </div>
            )}
          </div>

          {/* B. Dasar Hukum */}
          <div className="space-y-2 pt-2">
            <h5 className="font-bold text-xs sm:text-sm text-black dark:text-emerald-300">
              B. Dasar Hukum
            </h5>
            <ol className="list-decimal pl-6 space-y-1.5 text-xs sm:text-sm text-justify">
              {programKeagamaan.dasarHukum.map((hukum, idx) => (
                <li key={idx} className="text-justify leading-relaxed">
                  {isEditingKeagamaan ? (
                    <input
                      type="text"
                      value={hukum}
                      onChange={(e) => {
                        const updated = [...programKeagamaan.dasarHukum];
                        updated[idx] = e.target.value;
                        handleUpdateField("dasarHukum", updated);
                      }}
                      className="w-full px-2 py-1 rounded border bg-transparent text-xs"
                    />
                  ) : (
                    <span>{hukum}</span>
                  )}
                </li>
              ))}
            </ol>
          </div>

          {/* C. Tujuan Program */}
          <div className="space-y-2 pt-2">
            <h5 className="font-bold text-xs sm:text-sm text-black dark:text-emerald-300">
              C. Tujuan Kegiatan
            </h5>
            <ol className="list-decimal pl-6 space-y-1.5 text-xs sm:text-sm text-justify">
              {programKeagamaan.tujuan.map((tuj, idx) => (
                <li key={idx} className="text-justify leading-relaxed">
                  {isEditingKeagamaan ? (
                    <input
                      type="text"
                      value={tuj}
                      onChange={(e) => {
                        const updated = [...programKeagamaan.tujuan];
                        updated[idx] = e.target.value;
                        handleUpdateField("tujuan", updated);
                      }}
                      className="w-full px-2 py-1 rounded border bg-transparent text-xs"
                    />
                  ) : (
                    <span>{tuj}</span>
                  )}
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* ======================================================== */}
        {/* BAB II: PROGRAM KEGIATAN KEAGAMAAN                       */}
        {/* ======================================================== */}
        <div className="mb-8 space-y-6">
          <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
            BAB II. RANCANGAN PROGRAM KEGIATAN KEAGAMAAN ISLAM
          </h4>

          {/* A. PERINGATAN HARI BESAR ISLAM (PHBI) */}
          <div className="space-y-4">
            <div className="bg-emerald-500/10 dark:bg-emerald-500/20 p-3 rounded-xl border border-emerald-500/30">
              <h5 className="font-bold text-xs sm:text-sm text-emerald-900 dark:text-emerald-300 uppercase tracking-wide flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>A. Peringatan Hari Besar Islam (PHBI)</span>
              </h5>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                Diselenggarakan untuk memuliakan syiar Islam dan menanamkan penghayatan sirah nabawiyah kepada peserta didik:
              </p>
            </div>

            <div className="space-y-4">
              {programKeagamaan.phbi.map((keg, idx) => (
                <div
                  key={keg.id}
                  className="p-4 rounded-2xl border border-black/30 dark:border-slate-700 bg-white dark:bg-slate-900/60 space-y-3 keep-together shadow-sm"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b pb-2">
                    <h6 className="font-bold text-xs sm:text-sm text-black dark:text-white">
                      {idx + 1}. {keg.nama}
                    </h6>
                    <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-500/30 self-start sm:self-auto">
                      {keg.waktu}
                    </span>
                  </div>

                  <table className="w-full border-collapse no-border text-xs sm:text-sm">
                    <tbody>
                      <tr>
                        <td className="w-36 py-0.5 font-semibold label-col">Tema Kegiatan</td>
                        <td className="w-3 py-0.5">:</td>
                        <td className="py-0.5 italic">
                          {isEditingKeagamaan ? (
                            <input
                              type="text"
                              value={keg.tema}
                              onChange={(e) => handleUpdatePhbi(idx, "tema", e.target.value)}
                              className="w-full px-2 py-0.5 border rounded bg-transparent"
                            />
                          ) : (
                            `"${keg.tema}"`
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className="py-0.5 font-semibold label-col">Sasaran Peserta</td>
                        <td className="py-0.5">:</td>
                        <td className="py-0.5">
                          {isEditingKeagamaan ? (
                            <input
                              type="text"
                              value={keg.sasaran}
                              onChange={(e) => handleUpdatePhbi(idx, "sasaran", e.target.value)}
                              className="w-full px-2 py-0.5 border rounded bg-transparent"
                            />
                          ) : (
                            keg.sasaran
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className="py-0.5 font-semibold label-col">Penanggung Jawab</td>
                        <td className="py-0.5">:</td>
                        <td className="py-0.5">
                          {isEditingKeagamaan ? (
                            <input
                              type="text"
                              value={keg.penanggungJawab}
                              onChange={(e) => handleUpdatePhbi(idx, "penanggungJawab", e.target.value)}
                              className="w-full px-2 py-0.5 border rounded bg-transparent"
                            />
                          ) : (
                            keg.penanggungJawab
                          )}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <div>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Rangkaian &amp; Bentuk Kegiatan:
                    </span>
                    <ul className="list-disc pl-5 mt-1 space-y-1 text-xs text-justify">
                      {keg.bentukKegiatan.map((bk, bIdx) => (
                        <li key={bIdx} className="leading-relaxed">
                          {isEditingKeagamaan ? (
                            <input
                              type="text"
                              value={bk}
                              onChange={(e) => {
                                const updatedBk = [...keg.bentukKegiatan];
                                updatedBk[bIdx] = e.target.value;
                                handleUpdatePhbi(idx, "bentukKegiatan", updatedBk);
                              }}
                              className="w-full px-2 py-0.5 border rounded bg-transparent text-xs"
                            />
                          ) : (
                            bk
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* B. KEGIATAN PEMBIASAAN JUMAT PAGI (ROTATING SCHEME) */}
          <div className="space-y-4 pt-4">
            <div className="bg-sky-500/10 dark:bg-sky-500/20 p-3 rounded-xl border border-sky-500/30">
              <h5 className="font-bold text-xs sm:text-sm text-sky-900 dark:text-sky-300 uppercase tracking-wide flex items-center gap-2">
                <HeartHandshake className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span>B. Kegiatan Pembiasaan Jumat Pagi (Setiap Minggu Bergantian)</span>
              </h5>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                Waktu Pelaksanaan: <strong>{programKeagamaan.jumatPagi.waktuPelaksanaan}</strong> • Tempat: <strong>{programKeagamaan.jumatPagi.tempat}</strong>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {programKeagamaan.jumatPagi.jadwal.map((jad, idx) => (
                <div
                  key={jad.pekan}
                  className="p-4 rounded-2xl border border-black/30 dark:border-slate-700 bg-white dark:bg-slate-900/60 space-y-2 keep-together shadow-sm"
                >
                  <div className="flex items-center justify-between border-b pb-2">
                    <span className="font-bold text-xs text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-500/30">
                      {jad.pekan}
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">Pembiasaan Rutin</span>
                  </div>

                  <h6 className="font-bold text-xs sm:text-sm text-black dark:text-white">
                    {jad.kegiatan}
                  </h6>

                  {isEditingKeagamaan ? (
                    <textarea
                      rows={3}
                      value={jad.deskripsi}
                      onChange={(e) => handleUpdateJumat(idx, "deskripsi", e.target.value)}
                      className="w-full p-2 text-xs border rounded bg-transparent"
                    />
                  ) : (
                    <p className="text-xs leading-relaxed text-justify text-slate-700 dark:text-slate-300">
                      {jad.deskripsi}
                    </p>
                  )}

                  <div className="pt-2 border-t text-[11px] text-slate-600 dark:text-slate-400 italic">
                    <strong>Tujuan:</strong> {jad.tujuan}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ======================================================== */}
        {/* BAB III: MATRIKS JADWAL & INDIKATOR KETERCAPAIAN         */}
        {/* ======================================================== */}
        <div className="mb-8 space-y-4">
          <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
            BAB III. MATRIKS JADWAL DAN INDIKATOR KEBERHASILAN
          </h4>

          {/* TABEL MULTI-HALAMAN RESMI DENGAN THEAD BERULANG */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-xs sm:text-sm">
              <thead>
                <tr className={tableHeaderBgClass}>
                  <th className={`border px-2 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                  <th className={`border px-3 py-2 text-left font-bold w-48 ${tableBorderClass}`}>Jenis Kegiatan</th>
                  <th className={`border px-2.5 py-2 text-center font-bold w-36 ${tableBorderClass}`}>Waktu / Frekuensi</th>
                  <th className={`border px-2.5 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Sasaran</th>
                  <th className={`border px-3 py-2 text-left font-bold w-32 ${tableBorderClass}`}>Penanggung Jawab</th>
                  <th className={`border px-3 py-2 text-left font-bold ${tableBorderClass}`}>Indikator Ketercapaian / Bukti Fisik</th>
                </tr>
              </thead>
              <tbody>
                {programKeagamaan.matriks.map((row, idx) => (
                  <tr key={row.no}>
                    <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>{row.no}</td>
                    <td className={`border px-3 py-2 font-semibold ${tableBorderClass}`}>
                      {isEditingKeagamaan ? (
                        <input
                          type="text"
                          value={row.kegiatan}
                          onChange={(e) => handleUpdateMatriks(idx, "kegiatan", e.target.value)}
                          className="w-full px-1 py-0.5 border rounded bg-transparent"
                        />
                      ) : (
                        row.kegiatan
                      )}
                    </td>
                    <td className={`border px-2.5 py-2 text-center text-xs ${tableBorderClass}`}>
                      {isEditingKeagamaan ? (
                        <input
                          type="text"
                          value={row.waktu}
                          onChange={(e) => handleUpdateMatriks(idx, "waktu", e.target.value)}
                          className="w-full px-1 py-0.5 border rounded bg-transparent text-center"
                        />
                      ) : (
                        row.waktu
                      )}
                    </td>
                    <td className={`border px-2.5 py-2 text-center text-xs ${tableBorderClass}`}>
                      {isEditingKeagamaan ? (
                        <input
                          type="text"
                          value={row.sasaran}
                          onChange={(e) => handleUpdateMatriks(idx, "sasaran", e.target.value)}
                          className="w-full px-1 py-0.5 border rounded bg-transparent text-center"
                        />
                      ) : (
                        row.sasaran
                      )}
                    </td>
                    <td className={`border px-3 py-2 text-xs ${tableBorderClass}`}>
                      {isEditingKeagamaan ? (
                        <input
                          type="text"
                          value={row.penanggungJawab}
                          onChange={(e) => handleUpdateMatriks(idx, "penanggungJawab", e.target.value)}
                          className="w-full px-1 py-0.5 border rounded bg-transparent"
                        />
                      ) : (
                        row.penanggungJawab
                      )}
                    </td>
                    <td className={`border px-3 py-2 text-xs ${tableBorderClass}`}>
                      {isEditingKeagamaan ? (
                        <textarea
                          rows={2}
                          value={row.indikator}
                          onChange={(e) => handleUpdateMatriks(idx, "indikator", e.target.value)}
                          className="w-full px-1 py-0.5 border rounded bg-transparent text-xs"
                        />
                      ) : (
                        row.indikator
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* ======================================================== */}
        {/* BAB IV: PENUTUP                                          */}
        {/* ======================================================== */}
        <div className="mb-10 space-y-3 keep-together">
          <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
            BAB IV. PENUTUP
          </h4>

          {isEditingKeagamaan ? (
            <textarea
              rows={4}
              value={programKeagamaan.penutup}
              onChange={(e) => handleUpdateField("penutup", e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-900/90 text-xs sm:text-sm text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          ) : (
            <p className="indent-first text-xs sm:text-sm leading-relaxed text-justify">
              {programKeagamaan.penutup}
            </p>
          )}
        </div>

        {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
      </div>
    </div>
  );
};
