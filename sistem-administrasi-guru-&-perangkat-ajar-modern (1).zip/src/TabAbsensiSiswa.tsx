import React, { useState, useMemo, useEffect } from 'react';
import {
  UserCheck,
  Users,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Download,
  Printer,
  Sparkles,
  RefreshCw,
  Search,
  Check,
  ChevronRight,
  BookCheck,
  CalendarDays,
  FileText,
  UserPlus,
  Trash2,
  Edit3,
  SlidersHorizontal,
  Info,
  ShieldCheck,
  BookOpen
} from 'lucide-react';
import { KelasRombelItem, calculateScheduleDate } from './TabJurnalMengajar.tsx';
import { SiswaItem, DEFAULT_NAMA_SISWA_PAI, loadSiswaFromStorage, getDefaultContohSiswa } from './TabPenilaian.tsx';
import { ModalUploadSiswaExcel } from './ModalUploadSiswaExcel.tsx';

// ==========================================
// TIPE DATA ABSENSI SISWA
// ==========================================

export type StatusKehadiran = "H" | "S" | "I" | "A";

export interface PertemuanAbsensiInfo {
  pertemuanKe: number;
  hariTanggal: string;
  jamKe: string;
  alokasiJp: number;
  bab: string;
  materiPokok: string;
}

export interface TabAbsensiSiswaProps {
  modules: any[];
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  daftarKelas: KelasRombelItem[];
  jadwalMengajar?: any[];
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
  setActiveTab?: (tab: string) => void;
}

export const TabAbsensiSiswa: React.FC<TabAbsensiSiswaProps> = ({
  modules,
  identitas,
  daftarKelas,
  jadwalMengajar = [],
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat,
  setActiveTab
}) => {
  // 1. Filter Rombel & Semester
  const [selectedRombelId, setSelectedRombelId] = useState<string>(() => {
    return daftarKelas[0]?.id || "kls-1a";
  });
  const [selectedSemester, setSelectedSemester] = useState<string>("I (Ganjil)");

  // Mode Tampilan: 'input' (Input Presensi Mingguan) | 'rekap' (Leger Rekapitulasi Presensi Semester)
  const [activeSubTab, setActiveSubTab] = useState<"input" | "rekap">("input");

  // Rombel yang sedang aktif
  const currentRombel = useMemo(() => {
    return daftarKelas.find((k) => k.id === selectedRombelId) || daftarKelas[0];
  }, [daftarKelas, selectedRombelId]);

  const currentTingkat = currentRombel?.tingkat || "I";

  // Jadwal mengajar mingguan untuk rombel ini
  const currentSchedule = useMemo(() => {
    return jadwalMengajar.find((j) => j.kelasId === currentRombel?.id || j.tingkat === currentTingkat);
  }, [jadwalMengajar, currentRombel, currentTingkat]);

  // Daftar Pertemuan Terintegrasi Modul & PROMES untuk Rombel & Semester ini
  // Sebagai Guru Mata Pelajaran (PAI), pertemuan berlangsung 1 kali dalam seminggu
  const pertemuanList: PertemuanAbsensiInfo[] = useMemo(() => {
    const classMods = modules.filter(
      (m) => m.kelas === currentTingkat && m.semester === selectedSemester
    );
    const dayName = currentSchedule?.hari || "Senin";
    const hours = currentSchedule
      ? `${currentSchedule.jamKe} (${currentSchedule.waktu}) • ${currentSchedule.alokasiJp} JP`
      : "1 - 3 (07.15 - 09.00) • 3 JP";
    const jpCount = currentSchedule?.alokasiJp || 3;

    const list: PertemuanAbsensiInfo[] = [];
    let weekCursor = 1;

    classMods.forEach((mod) => {
      const perts = mod.pertemuan || [];
      perts.forEach((p: any, idx: number) => {
        const pertNum = weekCursor;
        const subTopic = mod.subTopik?.[idx] || (p.judul ? p.judul.replace(/^Pertemuan\s+Ke-\d+\s*\((.*)\)$/, '$1') : "") || mod.tp || "Materi Pembelajaran";
        const babTitle = (mod.bab && !mod.bab.includes("undefined")) ? mod.bab : `Bab ${mod.nomor} (${mod.elemen || "PAI & BP"})`;

        list.push({
          pertemuanKe: pertNum,
          hariTanggal: calculateScheduleDate(selectedSemester, weekCursor, dayName),
          jamKe: hours,
          alokasiJp: jpCount,
          bab: babTitle,
          materiPokok: subTopic
        });

        weekCursor += 1;
      });
    });

    // Minimal 16 pertemuan jika modul kurang dari 16
    if (list.length < 16) {
      const needed = 16 - list.length;
      const startIdx = list.length;
      for (let i = 1; i <= needed; i++) {
        const curWeek = startIdx + i;
        list.push({
          pertemuanKe: curWeek,
          hariTanggal: calculateScheduleDate(selectedSemester, curWeek, dayName),
          jamKe: hours,
          alokasiJp: jpCount,
          bab: "Penguatan & Evaluasi Karakter PAI",
          materiPokok: "Aktivitas Praktik Ibadah, Pembiasaan Harian, & Asesmen Sumatif Akhir"
        });
      }
    }

    return list;
  }, [modules, currentTingkat, selectedSemester, currentSchedule]);

  // Pertemuan aktif yang sedang diisi presensinya
  const [activePertemuanKe, setActivePertemuanKe] = useState<number>(1);

  // Pastikan activePertemuanKe selalu valid
  useEffect(() => {
    if (activePertemuanKe > pertemuanList.length && pertemuanList.length > 0) {
      setActivePertemuanKe(1);
    }
  }, [pertemuanList, activePertemuanKe]);

  const currentPertemuanInfo = useMemo(() => {
    return pertemuanList.find((p) => p.pertemuanKe === activePertemuanKe) || pertemuanList[0];
  }, [pertemuanList, activePertemuanKe]);

  // 2. Daftar Siswa Rombel (Tersinkronisasi 100% dengan TabPenilaian & localStorage - Maksimal 3 contoh atau kosong)
  const [daftarSiswa, setDaftarSiswa] = useState<SiswaItem[]>(() => {
    return loadSiswaFromStorage(selectedRombelId);
  });

  // Reload daftar siswa saat berganti rombel
  useEffect(() => {
    setDaftarSiswa(loadSiswaFromStorage(selectedRombelId));
  }, [selectedRombelId]);

  // Simpan daftarSiswa ke localStorage agar TabPenilaian dan TabAbsensi selalu sama
  useEffect(() => {
    try {
      localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(daftarSiswa));
    } catch {}
  }, [daftarSiswa, selectedRombelId]);

  // Handler Kosongkan Seluruh Siswa Rombel
  const handleClearAllStudents = () => {
    if (window.confirm(`Apakah Anda yakin ingin mengosongkan seluruh nama siswa pada rombel ${currentRombel?.nama}?`)) {
      setDaftarSiswa([]);
      try {
        localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify([]));
      } catch {}
      showToast(`Daftar siswa pada ${currentRombel?.nama} telah dikosongkan.`);
    }
  };

  // Handler Terapkan 3 Contoh Siswa Panduan
  const handleReset3Examples = () => {
    const examples = getDefaultContohSiswa(selectedRombelId);
    setDaftarSiswa(examples);
    try {
      localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(examples));
    } catch {}
    showToast(`3 contoh nama siswa panduan diterapkan pada ${currentRombel?.nama}.`);
  };

  const [showUploadExcelModal, setShowUploadExcelModal] = useState<boolean>(false);

  const handleSaveFromExcel = (newItems: SiswaItem[], mode: "replace" | "append") => {
    if (mode === "replace") {
      setDaftarSiswa(newItems);
      try {
        localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(newItems));
      } catch {}
      showToast(`Berhasil mengganti data dengan ${newItems.length} siswa dari file Excel untuk ${currentRombel?.nama}!`);
    } else {
      const merged = [...daftarSiswa, ...newItems];
      setDaftarSiswa(merged);
      try {
        localStorage.setItem(`perangkat_siswa_${selectedRombelId}`, JSON.stringify(merged));
      } catch {}
      showToast(`Berhasil menambahkan ${newItems.length} siswa baru dari file Excel ke ${currentRombel?.nama}!`);
    }
  };

  // 3. State Data Kehadiran / Presensi Siswa:
  // Struktur: { [pertemuanKe: number]: { [siswaId: string]: "H" | "S" | "I" | "A" } }
  const [dataAbsensi, setDataAbsensi] = useState<Record<number, Record<string, StatusKehadiran>>>(() => {
    try {
      const saved = localStorage.getItem(`perangkat_absensi_${selectedRombelId}_${selectedSemester}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === "object") return parsed;
      }
    } catch {}
    return {};
  });

  // Catatan pertemuan guru (misal: alasan izin, murid sakit, catatan pembiasaan)
  const [catatanPertemuan, setCatatanPertemuan] = useState<Record<number, string>>(() => {
    try {
      const saved = localStorage.getItem(`perangkat_catatan_absensi_${selectedRombelId}_${selectedSemester}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === "object") return parsed;
      }
    } catch {}
    return {};
  });

  // Simpan data absensi ke localStorage saat berubah
  useEffect(() => {
    try {
      localStorage.setItem(
        `perangkat_absensi_${selectedRombelId}_${selectedSemester}`,
        JSON.stringify(dataAbsensi)
      );
    } catch {}
  }, [dataAbsensi, selectedRombelId, selectedSemester]);

  // Simpan catatan pertemuan
  useEffect(() => {
    try {
      localStorage.setItem(
        `perangkat_catatan_absensi_${selectedRombelId}_${selectedSemester}`,
        JSON.stringify(catatanPertemuan)
      );
    } catch {}
  }, [catatanPertemuan, selectedRombelId, selectedSemester]);

  // Muat ulang absensi saat berganti rombel atau semester
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`perangkat_absensi_${selectedRombelId}_${selectedSemester}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === "object") {
          setDataAbsensi(parsed);
        } else {
          setDataAbsensi({});
        }
      } else {
        setDataAbsensi({});
      }
    } catch {
      setDataAbsensi({});
    }

    try {
      const savedNotes = localStorage.getItem(`perangkat_catatan_absensi_${selectedRombelId}_${selectedSemester}`);
      if (savedNotes) {
        const parsed = JSON.parse(savedNotes);
        setCatatanPertemuan(parsed || {});
      } else {
        setCatatanPertemuan({});
      }
    } catch {
      setCatatanPertemuan({});
    }
  }, [selectedRombelId, selectedSemester]);

  // Search filter
  const [searchSiswa, setSearchSiswa] = useState("");

  const filteredSiswa = useMemo(() => {
    if (!searchSiswa.trim()) return daftarSiswa;
    const q = searchSiswa.toLowerCase();
    return daftarSiswa.filter(
      (s) => s.nama.toLowerCase().includes(q) || s.nisn.includes(q)
    );
  }, [daftarSiswa, searchSiswa]);

  // Helper mendapatkan status kehadiran siswa (default: "H" jika belum diubah)
  const getSiswaStatus = (pertKe: number, siswaId: string): StatusKehadiran => {
    return dataAbsensi[pertKe]?.[siswaId] || "H";
  };

  // Handler ubah status kehadiran siswa
  const handleChangeStatus = (pertKe: number, siswaId: string, status: StatusKehadiran) => {
    setDataAbsensi((prev) => {
      const pertMap = { ...(prev[pertKe] || {}) };
      pertMap[siswaId] = status;
      return {
        ...prev,
        [pertKe]: pertMap
      };
    });
  };

  // Handler Set Semua Siswa Hadir (H) untuk pertemuan aktif
  const handleSetAllHadir = (pertKe: number) => {
    const newMap: Record<string, StatusKehadiran> = {};
    daftarSiswa.forEach((s) => {
      newMap[s.id] = "H";
    });
    setDataAbsensi((prev) => ({
      ...prev,
      [pertKe]: newMap
    }));
    showToast(`Seluruh siswa (${daftarSiswa.length} murid) pada Pertemuan Ke-${pertKe} ditandai Hadir (H).`);
  };

  // Handler Reset Presensi Pertemuan Ini
  const handleResetPertemuan = (pertKe: number) => {
    setDataAbsensi((prev) => {
      const next = { ...prev };
      delete next[pertKe];
      return next;
    });
    showToast(`Presensi Pertemuan Ke-${pertKe} dikembalikan ke default.`);
  };

  // Statistik Presensi untuk Pertemuan Aktif
  const activePertemuanStats = useMemo(() => {
    let hadir = 0;
    let sakit = 0;
    let izin = 0;
    let alpa = 0;

    daftarSiswa.forEach((s) => {
      const st = getSiswaStatus(activePertemuanKe, s.id);
      if (st === "H") hadir++;
      else if (st === "S") sakit++;
      else if (st === "I") izin++;
      else if (st === "A") alpa++;
    });

    const total = daftarSiswa.length;
    const pctHadir = total > 0 ? Math.round((hadir / total) * 100) : 100;

    return { total, hadir, sakit, izin, alpa, pctHadir };
  }, [daftarSiswa, dataAbsensi, activePertemuanKe]);

  // Format ringkasan kehadiran string untuk sinkronisasi ke Jurnal
  const formatKehadiranString = (pertKe: number) => {
    let hadir = 0;
    let sakit = 0;
    let izin = 0;
    let alpa = 0;

    daftarSiswa.forEach((s) => {
      const st = getSiswaStatus(pertKe, s.id);
      if (st === "H") hadir++;
      else if (st === "S") sakit++;
      else if (st === "I") izin++;
      else if (st === "A") alpa++;
    });

    const total = daftarSiswa.length;
    if (hadir === total) {
      return `Hadir: ${total}/${total} (100% - Lengkap)`;
    }
    const pct = total > 0 ? Math.round((hadir / total) * 100) : 100;
    const parts = [`Hadir: ${hadir}/${total} (${pct}%)`];
    if (sakit > 0) parts.push(`S: ${sakit}`);
    if (izin > 0) parts.push(`I: ${izin}`);
    if (alpa > 0) parts.push(`A: ${alpa}`);
    return parts.join(" • ");
  };

  // ==========================================
  // SINKRONISASI PRESENSI KE JURNAL MENGAJAR
  // ==========================================
  const handleSyncToJurnalMengajar = () => {
    try {
      const rawJurnal = localStorage.getItem("perangkat_jurnal_mengajar");
      if (!rawJurnal) {
        showToast("Data jurnal mengajar belum dibuat. Buka tab Jurnal Mengajar terlebih dahulu.");
        return;
      }

      const parsedJurnal = JSON.parse(rawJurnal);
      if (!Array.isArray(parsedJurnal)) return;

      let syncedCount = 0;
      const updatedJurnal = parsedJurnal.map((item: any) => {
        // Cek apakah item ini cocok dengan rombel dan semester aktif
        const matchRombel =
          item.rombelId === selectedRombelId ||
          (!item.rombelId && item.kelas === currentTingkat);
        const matchSem = item.semester === selectedSemester;

        if (matchRombel && matchSem) {
          const pertKe = item.pertemuanKe;
          // Buat string kehadiran dari data presensi riil
          const kehadiranStr = formatKehadiranString(pertKe);
          syncedCount++;
          return {
            ...item,
            kehadiranSiswa: kehadiranStr
          };
        }
        return item;
      });

      localStorage.setItem("perangkat_jurnal_mengajar", JSON.stringify(updatedJurnal));
      // Dispatch custom event agar tab jurnal langsung bereaksi jika dibuka
      window.dispatchEvent(new Event("perangkat_jurnal_updated"));

      showToast(
        `Sukses! Kehadiran ${syncedCount} pertemuan jurnal (${currentRombel?.nama} - ${selectedSemester}) berhasil disinkronkan dengan presensi siswa.`
      );
    } catch (e) {
      console.error(e);
      showToast("Gagal menyinkronkan ke jurnal mengajar.");
    }
  };

  // ==========================================
  // REKAPITULASI SEMESTER SELURUH SISWA (LEGER)
  // ==========================================
  const rekapSemester = useMemo(() => {
    const totalPerts = pertemuanList.length;

    const siswaRekap = daftarSiswa.map((siswa, idx) => {
      let h = 0;
      let s = 0;
      let i = 0;
      let a = 0;

      pertemuanList.forEach((p) => {
        const st = getSiswaStatus(p.pertemuanKe, siswa.id);
        if (st === "H") h++;
        else if (st === "S") s++;
        else if (st === "I") i++;
        else if (st === "A") a++;
      });

      const totalHadirSakitIzin = h + s + i;
      const persen = totalPerts > 0 ? Math.round((h / totalPerts) * 100) : 100;

      let predikat = "Sangat Baik";
      if (persen < 75) predikat = "Perlu Perhatian";
      else if (persen < 85) predikat = "Cukup";
      else if (persen < 95) predikat = "Baik";

      return {
        no: idx + 1,
        id: siswa.id,
        nisn: siswa.nisn,
        nama: siswa.nama,
        gender: siswa.gender,
        h,
        s,
        i,
        a,
        persen,
        predikat
      };
    });

    const sumH = siswaRekap.reduce((acc, cur) => acc + cur.h, 0);
    const sumS = siswaRekap.reduce((acc, cur) => acc + cur.s, 0);
    const sumI = siswaRekap.reduce((acc, cur) => acc + cur.i, 0);
    const sumA = siswaRekap.reduce((acc, cur) => acc + cur.a, 0);
    const avgPersen =
      siswaRekap.length > 0
        ? Math.round(siswaRekap.reduce((acc, cur) => acc + cur.persen, 0) / siswaRekap.length)
        : 100;

    return {
      siswaRekap,
      totalPerts,
      sumH,
      sumS,
      sumI,
      sumA,
      avgPersen
    };
  }, [daftarSiswa, pertemuanList, dataAbsensi]);

  // ==========================================
  // EKSPOR CSV / EXCEL
  // ==========================================
  const handleExportCsv = () => {
    const headers = [
      "No",
      "NISN",
      "Nama Siswa",
      "L/P",
      ...pertemuanList.map((p) => `P${p.pertemuanKe} (${p.hariTanggal.split(",")[1]?.trim() || `Mg ${p.pertemuanKe}`})`),
      "Total Hadir (H)",
      "Sakit (S)",
      "Izin (I)",
      "Alpa (A)",
      "Persentase (%)",
      "Keterangan"
    ];

    const rows = rekapSemester.siswaRekap.map((sr) => {
      const pertsStatus = pertemuanList.map((p) => getSiswaStatus(p.pertemuanKe, sr.id));
      return [
        sr.no,
        sr.nisn,
        `"${sr.nama}"`,
        sr.gender,
        ...pertsStatus,
        sr.h,
        sr.s,
        sr.i,
        sr.a,
        `${sr.persen}%`,
        `"${sr.predikat}"`
      ];
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute(
      "download",
      `Presensi_PAI_${currentRombel?.nama.replace(/\s+/g, "_")}_Sem_${selectedSemester.split(" ")[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Berkas Rekapitulasi Presensi CSV berhasil diunduh!");
  };

  return (
    <div className="space-y-6">
      {/* ======================================================== */}
      {/* TOOLBAR FILTER & HEADER MENU ABSENSI SISWA               */}
      {/* ======================================================== */}
      <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>Presensi Guru Mata Pelajaran PAI &amp; Budi Pekerti (1x Pertemuan / Minggu)</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
              <UserCheck className="w-5 h-5 text-emerald-700" />
              <span>Buku Absensi &amp; Presensi Siswa Kurikulum Merdeka</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5 font-medium">
              Kelola kehadiran tatap muka mingguan per rombel yang diinput, jadwal mengajar, dan <strong>sinkronkan langsung dengan kolom kehadiran pada Jurnal Mengajar Harian Guru</strong>.
            </p>
          </div>

          {/* Tombol Aksi Cetak & Sinkronisasi */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleSyncToJurnalMengajar}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 transition-all cursor-pointer"
              title="Sinkronkan status kehadiran siswa dari menu ini langsung ke dalam catatan Jurnal Mengajar Harian"
            >
              <RefreshCw className="w-4 h-4 text-amber-300" />
              <span>Sinkronkan ke Jurnal Mengajar</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>Ekspor Excel (.csv)</span>
            </button>

            <button
              onClick={() =>
                handleDownloadWord(
                  "printable-absensi-area",
                  `Buku_Presensi_PAI_${currentRombel?.nama.replace(/\s+/g, "_")}_Sem_${selectedSemester.split(" ")[0]}`,
                  true
                )
              }
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Word (.doc)</span>
            </button>

            <button
              onClick={() =>
                handlePrintDocument(
                  "printable-absensi-area",
                  `Buku_Presensi_PAI_${currentRombel?.nama.replace(/\s+/g, "_")}_Sem_${selectedSemester.split(" ")[0]}`,
                  "landscape"
                )
              }
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Simpan PDF (A4 Landscape)</span>
            </button>
          </div>
        </div>

        {/* PILL SWITCHER ROMBEL CEPAT (Sesuai Rombel yang Diinput) */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-extrabold text-slate-800">
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-emerald-700" />
              <span>Pilih Rombongan Belajar (Rombel yang Diinput Guru):</span>
            </span>
            <span className="text-[11px] font-semibold text-emerald-800">
              Total: {daftarKelas.length} Rombel Tersedia
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {daftarKelas.map((rombel) => {
              const isSelected = rombel.id === selectedRombelId;
              const sch = jadwalMengajar.find((j) => j.kelasId === rombel.id || j.tingkat === rombel.tingkat);
              return (
                <button
                  key={rombel.id}
                  type="button"
                  onClick={() => setSelectedRombelId(rombel.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 border ${
                    isSelected
                      ? "bg-[#065f46] text-white border-emerald-800 shadow-md shadow-emerald-950/20"
                      : "bg-[#e6f7ef] text-slate-800 border-emerald-300 hover:bg-emerald-100"
                  }`}
                >
                  <span>{rombel.nama}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-md font-semibold ${
                      isSelected ? "bg-emerald-800 text-white" : "bg-white text-slate-700 border border-emerald-200"
                    }`}
                  >
                    {rombel.jumlahSiswa} Murid
                  </span>
                  {sch && (
                    <span
                      className={`text-[9.5px] px-1.5 py-0.2 rounded-md font-semibold ${
                        isSelected ? "bg-emerald-900 text-amber-300" : "bg-emerald-200 text-emerald-950"
                      }`}
                    >
                      {sch.hari}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Baris Filter Semester & Navigasi Sub-Tab Presensi */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center pt-1 border-t border-emerald-200">
          <div className="md:col-span-4 flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700 shrink-0">Semester:</span>
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-300 w-full">
              {["I (Ganjil)", "II (Genap)"].map((sem) => (
                <button
                  key={sem}
                  type="button"
                  onClick={() => setSelectedSemester(sem)}
                  className={`flex-1 py-1 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedSemester === sem
                      ? "bg-[#065f46] text-white shadow-xs"
                      : "text-slate-700 hover:text-slate-900"
                  }`}
                >
                  {sem}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-8 flex flex-wrap items-center justify-start md:justify-end gap-2">
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-300">
              <button
                type="button"
                onClick={() => setActiveSubTab("input")}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeSubTab === "input"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Input Presensi Mingguan</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveSubTab("rekap")}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeSubTab === "rekap"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Rekapitulasi Semester (Leger Resmi)</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowUploadExcelModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
              title="Upload data siswa dengan file Excel (.xlsx / .csv)"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>Upload Excel Siswa</span>
            </button>
          </div>
        </div>

        {/* Banner Info Jadwal & Terintegrasi Jurnal */}
        <div className="p-3.5 bg-[#e6f7ef] border border-emerald-300 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-700 text-white rounded-xl shadow-xs shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <div className="font-extrabold text-slate-900 flex items-center gap-2 flex-wrap">
                <span>Rombel: {currentRombel?.nama} (Tingkat {currentTingkat} • Fase {currentRombel?.fase})</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-950 border border-emerald-300 font-bold">
                  {daftarSiswa.length} Murid
                </span>
              </div>
              <p className="text-[11px] text-slate-700 mt-0.5 font-medium">
                {currentSchedule ? (
                  <>
                    Jadwal Tatap Muka: <strong>Setiap {currentSchedule.hari}</strong>, Pukul <strong>{currentSchedule.waktu}</strong> (Jam ke {currentSchedule.jamKe} • {currentSchedule.alokasiJp} JP) • Wali Kelas: <strong>{currentRombel?.waliKelas || "-"}</strong> • Ruang: <strong>{currentRombel?.ruang || "-"}</strong>
                  </>
                ) : (
                  <span className="text-amber-800 font-bold">
                    Jadwal mengajar belum diatur. Absensi otomatis berjalan mingguan pada hari Senin.
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end md:self-auto text-xs">
            <span className="font-extrabold text-emerald-950 bg-emerald-100 border border-emerald-300 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Rata-rata Kehadiran: {rekapSemester.avgPersen}%</span>
            </span>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* TAMPILAN 1: INPUT PRESENSI MINGGUAN (PER PERTEMUAN)      */}
      {/* ======================================================== */}
      {activeSubTab === "input" && (
        <div className="space-y-6">
          {/* Selector Pertemuan Mingguan */}
          <div className="bg-white rounded-2xl border-2 border-emerald-300 p-4 space-y-3 shadow-sm no-print text-slate-800">
            <div className="flex items-center justify-between flex-wrap gap-2 border-b border-emerald-200 pb-2.5">
              <span className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                <CalendarDays className="w-4 h-4 text-emerald-700" />
                <span>Pilih Pertemuan Tatap Muka ({pertemuanList.length} Minggu Efektif):</span>
              </span>
              <span className="text-xs text-slate-600 font-medium">
                Satu pertemuan mewakili satu tatap muka mingguan Guru PAI &amp; BP
              </span>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
              {pertemuanList.map((p) => {
                const isSelected = p.pertemuanKe === activePertemuanKe;
                // Hitung status pertemuan ini
                let h = 0;
                let s = 0;
                let i = 0;
                let a = 0;
                daftarSiswa.forEach((st) => {
                  const stat = getSiswaStatus(p.pertemuanKe, st.id);
                  if (stat === "H") h++;
                  else if (stat === "S") s++;
                  else if (stat === "I") i++;
                  else if (stat === "A") a++;
                });
                const hasAbsen = s > 0 || i > 0 || a > 0;

                return (
                  <button
                    key={p.pertemuanKe}
                    type="button"
                    onClick={() => setActivePertemuanKe(p.pertemuanKe)}
                    className={`shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex flex-col items-center min-w-[76px] border ${
                      isSelected
                        ? "bg-[#065f46] text-white border-emerald-800 shadow-md shadow-emerald-950/20"
                        : "bg-slate-50 text-slate-700 border-slate-300 hover:bg-emerald-50"
                    }`}
                  >
                    <span>Mg ke-{p.pertemuanKe}</span>
                    <span
                      className={`text-[9.5px] font-semibold mt-0.5 px-1.5 py-0.2 rounded ${
                        isSelected
                          ? "bg-emerald-800 text-white"
                          : hasAbsen
                          ? "bg-amber-100 text-amber-900 border border-amber-300"
                          : "bg-emerald-100 text-emerald-900"
                      }`}
                    >
                      {hasAbsen ? `H:${h} | S:${s}` : `${h} Hadir`}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Kartu Detail Pertemuan Aktif & Form Absensi Cepat */}
          <div className="bg-white rounded-2xl border-2 border-emerald-300 p-5 space-y-4 shadow-sm no-print text-slate-800">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
              <div>
                <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-1">
                  <span>Pertemuan Ke-{activePertemuanKe} ({selectedSemester})</span>
                  <span>•</span>
                  <span>{currentPertemuanInfo?.hariTanggal}</span>
                </div>
                <h3 className="text-base font-extrabold text-slate-900">
                  {currentPertemuanInfo?.bab}
                </h3>
                <p className="text-xs text-slate-700 font-medium mt-0.5 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                  <span>Materi Pembelajaran: <strong>{currentPertemuanInfo?.materiPokok}</strong></span>
                </p>
              </div>

              {/* Tombol Isi Cepat: Semua Hadir (H) & Reset */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSetAllHadir(activePertemuanKe)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
                  title="Tandai semua murid hadir sekaligus"
                >
                  <Check className="w-4 h-4 text-emerald-200" />
                  <span>✓ Set Semua Hadir (H)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleResetPertemuan(activePertemuanKe)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 shadow-xs transition-all cursor-pointer"
                  title="Kembalikan presensi pertemuan ini ke default"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-rose-600" />
                  <span>Reset Pertemuan</span>
                </button>
              </div>
            </div>

            {/* Rekap Ringkas Kartu Status Pertemuan Ini */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="bg-[#e6f7ef] border border-emerald-300 rounded-xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Total Siswa</span>
                <span className="text-base font-extrabold text-emerald-800">{activePertemuanStats.total} Murid</span>
              </div>
              <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Hadir (H)</span>
                <span className="text-base font-extrabold text-emerald-700">{activePertemuanStats.hadir} Murid</span>
              </div>
              <div className="bg-amber-50 border border-amber-300 rounded-xl p-3 text-center">
                <span className="block text-[10px] text-amber-900 uppercase font-extrabold">Sakit (S)</span>
                <span className="text-base font-extrabold text-amber-700">{activePertemuanStats.sakit} Murid</span>
              </div>
              <div className="bg-sky-50 border border-sky-300 rounded-xl p-3 text-center">
                <span className="block text-[10px] text-sky-900 uppercase font-extrabold">Izin (I)</span>
                <span className="text-base font-extrabold text-sky-700">{activePertemuanStats.izin} Murid</span>
              </div>
              <div className="bg-rose-50 border border-rose-300 rounded-xl p-3 text-center col-span-2 sm:col-span-1">
                <span className="block text-[10px] text-rose-900 uppercase font-extrabold">Alpa (A)</span>
                <span className="text-base font-extrabold text-rose-700">{activePertemuanStats.alpa} Murid</span>
              </div>
            </div>

            {/* Toolbar Aksi Siswa & Pencarian */}
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Cari nama atau NISN murid..."
                    value={searchSiswa}
                    onChange={(e) => setSearchSiswa(e.target.value)}
                    className="w-full text-xs pl-9 pr-3 py-2 rounded-xl bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-900"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleReset3Examples}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 transition-colors cursor-pointer"
                  title="Terapkan 3 contoh nama siswa sebagai panduan"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>3 Contoh Panduan</span>
                </button>

                <button
                  type="button"
                  onClick={handleClearAllStudents}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 transition-colors cursor-pointer"
                  title="Kosongkan seluruh nama siswa pada rombel ini"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Kosongkan Siswa</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowUploadExcelModal(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-colors cursor-pointer"
                  title="Unggah data siswa dari file Excel"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Upload Excel</span>
                </button>
              </div>

              <div className="text-xs text-slate-600 font-medium">
                Petunjuk: Klik tombol <strong>H</strong> (Hadir), <strong>S</strong> (Sakit), <strong>I</strong> (Izin), atau <strong>A</strong> (Alpa).
              </div>
            </div>

            {/* Tabel Interaktif Daftar Presensi Siswa */}
            <div className="overflow-x-auto border border-emerald-300 rounded-xl">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className="bg-[#065f46] text-white">
                    <th className="px-3 py-2.5 text-center font-bold w-[6%]">No</th>
                    <th className="px-3 py-2.5 text-center font-bold w-[12%]">NISN</th>
                    <th className="px-4 py-2.5 text-left font-bold w-[34%]">Nama Lengkap Siswa</th>
                    <th className="px-3 py-2.5 text-center font-bold w-[8%]">L/P</th>
                    <th className="px-4 py-2.5 text-center font-bold w-[40%]">
                      Status Kehadiran Pertemuan Ke-{activePertemuanKe}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-200">
                  {filteredSiswa.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-10 px-4 text-center bg-slate-50/50">
                        <div className="flex flex-col items-center justify-center max-w-md mx-auto space-y-3">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-700 shadow-xs border border-emerald-300">
                            <Users className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-800 text-sm">Daftar Siswa Masih Kosong</h4>
                            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                              Belum ada nama siswa untuk {currentRombel?.nama}. Anda dapat mengunggah file Excel data siswa atau menggunakan 3 nama siswa sebagai contoh panduan.
                            </p>
                          </div>
                          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={handleReset3Examples}
                              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-300 transition-all cursor-pointer"
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>Gunakan 3 Contoh Siswa Panduan</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setShowUploadExcelModal(true)}
                              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-xs transition-all cursor-pointer"
                            >
                              <FileSpreadsheet className="w-3.5 h-3.5" />
                              <span>Upload File Excel</span>
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredSiswa.map((siswa, idx) => {
                    const status = getSiswaStatus(activePertemuanKe, siswa.id);

                    return (
                      <tr key={siswa.id} className="hover:bg-emerald-50/60 transition-colors">
                        <td className="px-3 py-2.5 text-center font-bold text-slate-700">{idx + 1}</td>
                        <td className="px-3 py-2.5 text-center font-mono text-slate-600">{siswa.nisn}</td>
                        <td className="px-4 py-2.5 text-left font-bold text-slate-900">
                          {siswa.nama}
                        </td>
                        <td className="px-3 py-2.5 text-center font-semibold text-slate-700">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              siswa.gender === "L"
                                ? "bg-blue-100 text-blue-900 border border-blue-300"
                                : "bg-pink-100 text-pink-900 border border-pink-300"
                            }`}
                          >
                            {siswa.gender}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Tombol Hadir (H) */}
                            <button
                              type="button"
                              onClick={() => handleChangeStatus(activePertemuanKe, siswa.id, "H")}
                              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                                status === "H"
                                  ? "bg-emerald-600 text-white shadow-xs scale-105"
                                  : "bg-emerald-50 text-emerald-900 hover:bg-emerald-200/60 border border-emerald-300"
                              }`}
                            >
                              H (Hadir)
                            </button>

                            {/* Tombol Sakit (S) */}
                            <button
                              type="button"
                              onClick={() => handleChangeStatus(activePertemuanKe, siswa.id, "S")}
                              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                                status === "S"
                                  ? "bg-amber-500 text-white shadow-xs scale-105"
                                  : "bg-amber-50 text-amber-900 hover:bg-amber-200/60 border border-amber-300"
                              }`}
                            >
                              S (Sakit)
                            </button>

                            {/* Tombol Izin (I) */}
                            <button
                              type="button"
                              onClick={() => handleChangeStatus(activePertemuanKe, siswa.id, "I")}
                              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                                status === "I"
                                  ? "bg-sky-500 text-white shadow-xs scale-105"
                                  : "bg-sky-50 text-sky-900 hover:bg-sky-200/60 border border-sky-300"
                              }`}
                            >
                              I (Izin)
                            </button>

                            {/* Tombol Alpa (A) */}
                            <button
                              type="button"
                              onClick={() => handleChangeStatus(activePertemuanKe, siswa.id, "A")}
                              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                                status === "A"
                                  ? "bg-rose-600 text-white shadow-xs scale-105"
                                  : "bg-rose-50 text-rose-900 hover:bg-rose-200/60 border border-rose-300"
                              }`}
                            >
                              A (Alpa)
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }))}
                </tbody>
              </table>
            </div>

            {/* Input Catatan Guru untuk Pertemuan Ini */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Catatan Kejadian Khusus / Pembiasaan Siswa pada Pertemuan Ke-{activePertemuanKe}:
              </label>
              <textarea
                rows={2}
                value={catatanPertemuan[activePertemuanKe] || ""}
                onChange={(e) =>
                  setCatatanPertemuan((prev) => ({
                    ...prev,
                    [activePertemuanKe]: e.target.value
                  }))
                }
                placeholder="Contoh: Seluruh murid mengikuti hafalan surat pendek dengan baik; Ananda Fadhil izin sakit demam; Pembiasaan membaca doa sebelum belajar terlaksana tertib."
                className="w-full text-xs p-3 rounded-xl bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 font-medium"
              />
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAMPILAN 2: REKAPITULASI SEMESTER (LEGER DOKUMEN CETAK)  */}
      {/* ======================================================== */}
      <div
        id="printable-absensi-area"
        style={paperLightMode ? { padding: "1.8cm 1.5cm 1.8cm 2cm" } : undefined}
        className={`rounded-2xl border p-6 sm:p-8 transition-colors duration-300 overflow-x-auto ${docContainerClass} official-doc-typography ${
          activeSubTab === "input" ? "hidden" : "block"
        }`}
      >
        {/* KOP SURAT RESMI */}
        {useKopSurat && kopSuratUrl && (
          <div className="kop-surat-header mb-4 text-center">
            <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
            <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
          </div>
        )}

        {/* Header Dokumen Presensi Resmi */}
        <div className="doc-header-box text-center border-b-2 pb-4 mb-6 border-black">
          <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            BUKU PRESENSI &amp; DAFTAR HADIR SISWA TATAP MUKA MINGGUAN
          </h2>
          <h3 className="doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
          </h3>
          <p className="text-xs sm:text-[11pt] font-semibold text-center mt-1" style={{ margin: "2pt 0 0 0" }}>
            KURIKULUM MERDEKA • PEMBELAJARAN MENDALAM (DEEP LEARNING)
          </p>
        </div>

        {/* Identitas Dokumen Presensi (Rata Kiri, Titik Dua Sejajar Rapi) */}
        <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-2xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Satuan Pendidikan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.sekolah}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Kelas / Rombel / Fase</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {currentRombel?.nama} (Tingkat {currentTingkat}) / Fase {currentRombel?.fase}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Semester / Tahun Ajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {selectedSemester} / {identitas.tahunAjaran}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Jadwal Mengajar Mingguan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">
              {currentSchedule ? `${currentSchedule.hari}, Pukul ${currentSchedule.waktu} (${currentSchedule.alokasiJp} JP)` : "Setiap Senin"}
            </span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Guru Mata Pelajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.guruPai} (NIP. {identitas.nipGuru})</span>
          </div>
        </div>

        {/* Tabel Leger Presensi Semesteran */}
        <div className="overflow-x-auto print:overflow-visible">
          <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%', fontSize: '9pt' }}>
            <thead>
              <tr className={tableHeaderBgClass}>
                <th rowSpan={2} className={`border px-1.5 py-1.5 text-center font-bold w-[3%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  No
                </th>
                <th rowSpan={2} className={`border px-2 py-1.5 text-center font-bold w-[8%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  NISN
                </th>
                <th rowSpan={2} className={`border px-3 py-1.5 text-left font-bold w-[22%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'left' }}>
                  Nama Siswa
                </th>
                <th rowSpan={2} className={`border px-1 py-1.5 text-center font-bold w-[3%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  L/P
                </th>
                <th colSpan={pertemuanList.length} className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Pertemuan Tatap Muka Mingguan Semester {selectedSemester.split(" ")[0]}
                </th>
                <th colSpan={4} className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  Rekapitulasi
                </th>
                <th rowSpan={2} className={`border px-1.5 py-1.5 text-center font-bold w-[5%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                  %
                </th>
              </tr>
              <tr className={tableHeaderBgClass}>
                {pertemuanList.map((p) => (
                  <th
                    key={p.pertemuanKe}
                    className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`}
                    style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', minWidth: '22px' }}
                    title={`Pertemuan Ke-${p.pertemuanKe}: ${p.hariTanggal} - ${p.bab}`}
                  >
                    {p.pertemuanKe}
                  </th>
                ))}
                <th className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', width: '3%' }}>H</th>
                <th className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', width: '3%' }}>S</th>
                <th className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', width: '3%' }}>I</th>
                <th className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', width: '3%' }}>A</th>
              </tr>
            </thead>
            <tbody>
              {rekapSemester.siswaRekap.map((sr) => (
                <tr key={sr.id} className="keep-together">
                  <td className={`border px-1.5 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.no}
                  </td>
                  <td className={`border px-2 py-1 text-center font-mono ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.nisn}
                  </td>
                  <td className={`border px-3 py-1 font-semibold text-slate-900 ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'left' }}>
                    {sr.nama}
                  </td>
                  <td className={`border px-1 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.gender}
                  </td>

                  {/* Nilai Status per Pertemuan */}
                  {pertemuanList.map((p) => {
                    const st = getSiswaStatus(p.pertemuanKe, sr.id);
                    const colorStyle =
                      st === "H"
                        ? { color: '#047857', fontWeight: 'bold' }
                        : st === "S"
                        ? { color: '#b45309', fontWeight: 'bold', backgroundColor: '#fef3c7' }
                        : st === "I"
                        ? { color: '#0369a1', fontWeight: 'bold', backgroundColor: '#e0f2fe' }
                        : { color: '#b91c1c', fontWeight: 'bold', backgroundColor: '#fee2e2' };

                    return (
                      <td
                        key={p.pertemuanKe}
                        className={`border px-0.5 py-1 text-center ${tableBorderClass}`}
                        style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center', ...colorStyle }}
                      >
                        {st}
                      </td>
                    );
                  })}

                  {/* Rekapitulasi H, S, I, A */}
                  <td className={`border px-1 py-1 text-center font-bold text-emerald-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.h}
                  </td>
                  <td className={`border px-1 py-1 text-center font-semibold text-amber-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.s}
                  </td>
                  <td className={`border px-1 py-1 text-center font-semibold text-sky-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.i}
                  </td>
                  <td className={`border px-1 py-1 text-center font-semibold text-rose-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.a}
                  </td>
                  <td className={`border px-1.5 py-1 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>
                    {sr.persen}%
                  </td>
                </tr>
              ))}

              {/* Baris Total / Rekapitulasi Kelas */}
              <tr className="bg-slate-100 font-bold" style={{ backgroundColor: '#f1f5f9' }}>
                <td colSpan={4} className={`border px-3 py-1.5 text-right font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'right' }}>
                  Jumlah Kehadiran Seluruh Siswa:
                </td>
                {pertemuanList.map((p) => {
                  let hadirCount = 0;
                  daftarSiswa.forEach((st) => {
                    if (getSiswaStatus(p.pertemuanKe, st.id) === "H") hadirCount++;
                  });
                  return (
                    <td
                      key={p.pertemuanKe}
                      className={`border px-0.5 py-1 text-center text-[8pt] font-bold ${tableBorderClass}`}
                      style={{ border: '1px solid #000000', textAlign: 'center' }}
                    >
                      {hadirCount}
                    </td>
                  );
                })}
                <td className={`border px-1 py-1.5 text-center font-bold text-emerald-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                  {rekapSemester.sumH}
                </td>
                <td className={`border px-1 py-1.5 text-center font-bold text-amber-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                  {rekapSemester.sumS}
                </td>
                <td className={`border px-1 py-1.5 text-center font-bold text-sky-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                  {rekapSemester.sumI}
                </td>
                <td className={`border px-1 py-1.5 text-center font-bold text-rose-800 ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                  {rekapSemester.sumA}
                </td>
                <td className={`border px-1.5 py-1.5 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                  {rekapSemester.avgPersen}%
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Keterangan Singkat Status Presensi */}
        <div className="mt-3 flex items-center justify-between text-[8.5pt] text-slate-700 font-medium">
          <div className="flex items-center gap-4">
            <span><strong>Keterangan:</strong></span>
            <span><strong>H</strong>: Hadir</span>
            <span><strong>S</strong>: Sakit</span>
            <span><strong>I</strong>: Izin</span>
            <span><strong>A</strong>: Alpa / Tanpa Keterangan</span>
          </div>
          <div>
            <span>Rata-rata Tingkat Kehadiran Kelas: <strong>{rekapSemester.avgPersen}%</strong></span>
          </div>
        </div>

        {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
        <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <tbody>
            <tr style={{ border: 'none', background: 'transparent' }}>
              <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
              </td>
              <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru Mata Pelajaran PAI dan BP</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* MODAL UPLOAD EXCEL SISWA */}
      <ModalUploadSiswaExcel
        isOpen={showUploadExcelModal}
        onClose={() => setShowUploadExcelModal(false)}
        currentRombel={currentRombel}
        daftarKelas={daftarKelas}
        onRombelChange={(newId) => setSelectedRombelId(newId)}
        onSuccessSave={handleSaveFromExcel}
        showToast={showToast}
        existingCount={daftarSiswa.length}
      />
    </div>
  );
};
