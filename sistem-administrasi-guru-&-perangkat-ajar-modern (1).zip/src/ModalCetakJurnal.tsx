import React, { useState, useMemo } from 'react';
import {
  Printer,
  Download,
  Calendar,
  CalendarDays,
  Clock,
  CheckCircle2,
  X,
  FileText,
  Sparkles,
  Info,
  Layers,
  ChevronRight,
  BookOpen
} from 'lucide-react';
import {
  KelasRombelItem,
  JurnalMengajarItem,
  PeriodeCetakType,
  BULAN_SEMESTER_1,
  BULAN_SEMESTER_2,
  getMonthFromHariTanggal
} from './TabJurnalMengajar.tsx';

export interface ModalCetakJurnalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRombel: KelasRombelItem | undefined;
  filterKelas: string;
  filterSemester: string;
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
  };
  jurnalListKelasSemester: JurnalMengajarItem[];
  periodeCetak: PeriodeCetakType;
  setPeriodeCetak: (val: PeriodeCetakType) => void;
  selectedBulan: string;
  setSelectedBulan: (val: string) => void;
  selectedMinggu: number;
  setSelectedMinggu: (val: number) => void;
  selectedPertemuanHari: string | number;
  setSelectedPertemuanHari: (val: any) => void;
  handlePrintDocument: (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
}

export const ModalCetakJurnal: React.FC<ModalCetakJurnalProps> = ({
  isOpen,
  onClose,
  currentRombel,
  filterKelas,
  filterSemester,
  identitas,
  jurnalListKelasSemester,
  periodeCetak,
  setPeriodeCetak,
  selectedBulan,
  setSelectedBulan,
  selectedMinggu,
  setSelectedMinggu,
  selectedPertemuanHari,
  setSelectedPertemuanHari,
  handlePrintDocument,
  handleDownloadWord,
  showToast
}) => {
  const [orientation, setOrientation] = useState<"landscape" | "portrait">("landscape");

  const isSemesterGanjil = (filterSemester || "").includes("Ganjil") || (filterSemester || "").includes("I");
  const listBulan = isSemesterGanjil ? BULAN_SEMESTER_1 : BULAN_SEMESTER_2;

  // Daftar Pertemuan Unik dengan safe fallback untuk setiap atribut
  const pertemuanOptions = useMemo(() => {
    return (jurnalListKelasSemester || []).map((item, idx) => ({
      id: item.id || `jm-${idx + 1}`,
      pertemuanUrut: idx + 1,
      pertemuanKe: item.pertemuanKe || idx + 1,
      hariTanggal: item.hariTanggal || `Pertemuan ${idx + 1}`,
      materiPokok: item.materiPokok || item.tujuanPembelajaran || "Materi Pembelajaran",
      bab: item.bab || `Bab ${item.modulNomor || 1}`,
      jamKe: item.jamKe || "1 - 3"
    }));
  }, [jurnalListKelasSemester]);

  // Hitung jumlah pertemuan dan JP yang akan dicetak berdasarkan pilihan
  const previewData = useMemo(() => {
    let items = jurnalListKelasSemester || [];
    if (periodeCetak === "bulan") {
      items = items.filter(
        (item) => getMonthFromHariTanggal(item.hariTanggal) === selectedBulan
      );
    } else if (periodeCetak === "minggu") {
      items = items.filter(
        (item, idx) => (idx + 1) === selectedMinggu || item.id === String(selectedMinggu)
      );
    } else if (periodeCetak === "hari") {
      items = items.filter((item, idx) => {
        if (selectedPertemuanHari && (item.id === String(selectedPertemuanHari) || item.hariTanggal === String(selectedPertemuanHari))) {
          return true;
        }
        if (selectedPertemuanHari && String(selectedPertemuanHari) === String(idx + 1)) {
          return true;
        }
        if (!selectedPertemuanHari && idx === 0) {
          return true;
        }
        return false;
      });
      // Fallback: pastikan jika mode per hari, hanya 1 item yang diambil
      if (items.length === 0 && (jurnalListKelasSemester || []).length > 0) {
        items = (jurnalListKelasSemester || []).slice(0, 1);
      } else if (items.length > 1) {
        items = items.slice(0, 1);
      }
    }

    const totalJp = items.reduce((acc, cur) => acc + (cur.alokasiJp || 3), 0);
    return {
      count: items.length,
      totalJp,
      items
    };
  }, [jurnalListKelasSemester, periodeCetak, selectedBulan, selectedMinggu, selectedPertemuanHari]);

  // Generate Nama File Cetak Dokumen dengan perlindungan null/undefined
  const getDocFilename = () => {
    const rombelNama = (currentRombel?.nama || `Kelas_${filterKelas || "I"}`).replace(/\s+/g, "_");
    const sekolah = (identitas?.sekolah || "SD").replace(/\s+/g, "_");
    const sem = (filterSemester || "I").split(" ")[0];

    if (periodeCetak === "hari") {
      const activeItem = previewData.items[0];
      const tglSlug = activeItem?.hariTanggal
        ? activeItem.hariTanggal.replace(/[^a-zA-Z0-9]/g, "_")
        : `Pertemuan_${selectedPertemuanHari || 1}`;
      return `Jurnal_Harian_PAI_${rombelNama}_${tglSlug}_${sekolah}`;
    } else if (periodeCetak === "minggu") {
      return `Jurnal_Mingguan_PAI_${rombelNama}_Pekan_${selectedMinggu || 1}_Sem_${sem}_${sekolah}`;
    } else if (periodeCetak === "bulan") {
      return `Jurnal_Bulanan_PAI_${rombelNama}_Bulan_${selectedBulan || "Juli"}_Sem_${sem}_${sekolah}`;
    }
    return `Jurnal_1_Semester_PAI_${rombelNama}_Sem_${sem}_${sekolah}`;
  };

  const handleExecutePrint = () => {
    if (previewData.count === 0) {
      showToast("Tidak ada pertemuan jurnal untuk periode yang dipilih.");
      return;
    }
    const docTitle = getDocFilename();
    onClose();
    setTimeout(() => {
      handlePrintDocument("printable-area", docTitle, orientation);
      showToast(`Membuka dialog cetak Jurnal (${periodeCetak.toUpperCase()})`);
    }, 60);
  };

  const handleExecuteWord = () => {
    if (previewData.count === 0) {
      showToast("Tidak ada pertemuan jurnal untuk periode yang dipilih.");
      return;
    }
    const docTitle = getDocFilename();
    onClose();
    setTimeout(() => {
      handleDownloadWord("printable-area", docTitle, orientation === "landscape");
      showToast(`Mengunduh berkas Word Jurnal (${periodeCetak.toUpperCase()})`);
    }, 60);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border-2 border-emerald-300 w-full max-w-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-slate-800">
        
        {/* Header Modal */}
        <div className="bg-gradient-to-r from-[#065f46] via-[#047857] to-[#059669] text-white p-4 sm:p-5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center border border-white/30 shadow-xs">
              <Printer className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-emerald-200/30 text-emerald-100 border border-emerald-300/30">
                  Cetak Jurnal Mengajar
                </span>
                <span className="text-xs text-emerald-100 font-semibold">
                  {currentRombel?.nama || `Kelas ${filterKelas}`} • {filterSemester}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-extrabold tracking-tight">
                Pilihan Periode Cetak Jurnal Guru
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="Tutup dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Modal */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 text-xs sm:text-sm text-slate-700">
          
          {/* Langkah 1: Pilih Jenis Periode Cetak */}
          <div>
            <label className="block text-xs font-extrabold text-slate-800 uppercase tracking-wider mb-2">
              1. Pilih Periode Jurnal yang Ingin Dicetak:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              
              {/* Opsi 1: 1 Semester */}
              <button
                type="button"
                onClick={() => setPeriodeCetak("semester")}
                className={`p-3 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  periodeCetak === "semester"
                    ? "bg-[#e6f7ef] border-[#065f46] shadow-sm text-emerald-950 ring-2 ring-emerald-400"
                    : "bg-slate-50 border-slate-200 hover:bg-emerald-50/50 text-slate-700"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-xs">1 Semester</span>
                  <span className="text-base">📅</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Seluruh pertemuan (16-20 pekan)
                </p>
              </button>

              {/* Opsi 2: Per Bulan */}
              <button
                type="button"
                onClick={() => setPeriodeCetak("bulan")}
                className={`p-3 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  periodeCetak === "bulan"
                    ? "bg-[#e6f7ef] border-[#065f46] shadow-sm text-emerald-950 ring-2 ring-emerald-400"
                    : "bg-slate-50 border-slate-200 hover:bg-emerald-50/50 text-slate-700"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-xs">Per Bulan</span>
                  <span className="text-base">🗓️</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Laporan bulanan guru / TPG
                </p>
              </button>

              {/* Opsi 3: Per Minggu */}
              <button
                type="button"
                onClick={() => setPeriodeCetak("minggu")}
                className={`p-3 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  periodeCetak === "minggu"
                    ? "bg-[#e6f7ef] border-[#065f46] shadow-sm text-emerald-950 ring-2 ring-emerald-400"
                    : "bg-slate-50 border-slate-200 hover:bg-emerald-50/50 text-slate-700"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-xs">Per Minggu</span>
                  <span className="text-base">📆</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Per pekan efektif pembelajaran
                </p>
              </button>

              {/* Opsi 4: Per Hari */}
              <button
                type="button"
                onClick={() => setPeriodeCetak("hari")}
                className={`p-3 rounded-xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  periodeCetak === "hari"
                    ? "bg-[#e6f7ef] border-[#065f46] shadow-sm text-emerald-950 ring-2 ring-emerald-400"
                    : "bg-slate-50 border-slate-200 hover:bg-emerald-50/50 text-slate-700"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-xs">Per Hari</span>
                  <span className="text-base">📝</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Lembar harian 1 pertemuan
                </p>
              </button>
            </div>
          </div>

          {/* Langkah 2: Parameter Spesifik Sesuai Pilihan */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            
            {/* JIKA MEMILIH 1 SEMESTER */}
            {periodeCetak === "semester" && (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-lg shrink-0">
                  📅
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                    Mencetak 1 Semester Penuh ({filterSemester})
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Mencakup seluruh daftar pertemuan dari awal hingga akhir semester untuk <strong>{currentRombel?.nama || `Kelas ${filterKelas}`}</strong>.
                  </p>
                </div>
              </div>
            )}

            {/* JIKA MEMILIH PER BULAN */}
            {periodeCetak === "bulan" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-emerald-700" />
                    <span>Pilih Bulan Pembelajaran ({filterSemester}):</span>
                  </label>
                  <span className="text-[11px] font-bold text-emerald-900">
                    Bulan Aktif: <strong>{selectedBulan}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  {listBulan.map((bulan) => {
                    const isSel = selectedBulan === bulan;
                    const itemsInMonth = jurnalListKelasSemester.filter(
                      (item) => getMonthFromHariTanggal(item.hariTanggal) === bulan
                    );
                    return (
                      <button
                        key={bulan}
                        type="button"
                        onClick={() => setSelectedBulan(bulan)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                          isSel
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-sm"
                            : "bg-white text-slate-700 border-slate-200 hover:bg-emerald-50"
                        }`}
                      >
                        <span>{bulan}</span>
                        <span className={`text-[10px] font-semibold ${isSel ? "text-emerald-100" : "text-slate-400"}`}>
                          {itemsInMonth.length}x Pertemuan
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* JIKA MEMILIH PER MINGGU */}
            {periodeCetak === "minggu" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                    <CalendarDays className="w-4 h-4 text-emerald-700" />
                    <span>Pilih Pekan / Minggu Ke-:</span>
                  </label>
                  <span className="text-[11px] font-bold text-emerald-900">
                    Pekan Ke-{selectedMinggu}
                  </span>
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 max-h-36 overflow-y-auto p-1">
                  {pertemuanOptions.map((opt, idx) => {
                    const pekanNum = idx + 1;
                    const isSel = selectedMinggu === pekanNum;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSelectedMinggu(pekanNum)}
                        className={`py-2 px-1 text-center rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          isSel
                            ? "bg-[#065f46] text-white border-emerald-800 shadow-sm"
                            : "bg-white text-slate-700 border-slate-200 hover:bg-emerald-50"
                        }`}
                        title={`${opt.hariTanggal} • ${opt.materiPokok}`}
                      >
                        <span>Mg {pekanNum}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Detail Pekan Terpilih */}
                {(() => {
                  const selOpt = pertemuanOptions[selectedMinggu - 1] || pertemuanOptions[0];
                  if (!selOpt) return null;
                  return (
                    <div className="bg-white p-2.5 rounded-xl border border-emerald-200 text-xs mt-1.5 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900">
                          {selOpt.hariTanggal || "-"}
                        </span>
                        <p className="text-[11px] text-slate-600 truncate max-w-md">
                          {selOpt.bab} • {selOpt.materiPokok || "Materi Pembelajaran"}
                        </p>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 font-bold shrink-0">
                        Pekan #{selectedMinggu}
                      </span>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* JIKA MEMILIH PER HARI */}
            {periodeCetak === "hari" && (
              <div className="space-y-2">
                <label className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-emerald-700" />
                  <span>Pilih Tanggal / Pertemuan Harian:</span>
                </label>

                {pertemuanOptions.length > 0 ? (
                  <select
                    value={
                      pertemuanOptions.some((p) => p.id === String(selectedPertemuanHari))
                        ? String(selectedPertemuanHari)
                        : (pertemuanOptions.find((p) => p.hariTanggal === String(selectedPertemuanHari))?.id ||
                           pertemuanOptions.find((p) => String(p.pertemuanUrut) === String(selectedPertemuanHari))?.id ||
                           pertemuanOptions[0]?.id || "")
                    }
                    onChange={(e) => setSelectedPertemuanHari(e.target.value)}
                    className="w-full text-xs font-bold p-2.5 rounded-xl bg-white border border-emerald-300 text-slate-800 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    {pertemuanOptions.map((opt) => (
                      <option key={opt.id} value={opt.id}>
                        Pertemuan #{opt.pertemuanUrut} ({opt.hariTanggal}) • {opt.bab} ({(opt.materiPokok || "Materi").slice(0, 45)}...)
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-xs">
                    Belum ada pertemuan jurnal untuk kelas & semester yang dipilih.
                  </div>
                )}

                {/* Info Card Hari yang Dipilih */}
                {(() => {
                  const selOpt =
                    pertemuanOptions.find((p) => p.id === String(selectedPertemuanHari)) ||
                    pertemuanOptions.find((p) => p.hariTanggal === String(selectedPertemuanHari)) ||
                    pertemuanOptions.find((p) => String(p.pertemuanUrut) === String(selectedPertemuanHari)) ||
                    pertemuanOptions[0];

                  if (!selOpt) return null;

                  return (
                    <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-emerald-950">
                          {selOpt.hariTanggal}
                        </span>
                        <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                          Pertemuan Ke-{selOpt.pertemuanUrut}
                        </span>
                      </div>
                      <p className="text-xs text-slate-800 font-semibold">
                        {selOpt.bab}
                      </p>
                      <p className="text-[11px] text-slate-600">
                        Materi: {selOpt.materiPokok || "Materi Pembelajaran"}
                      </p>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Langkah 3: Orientasi Kertas Dokumen */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-200">
            <div>
              <span className="font-extrabold text-xs text-slate-800 block">
                Orientasi Format Kertas:
              </span>
              <span className="text-[11px] text-slate-600">
                Pilih tata letak dokumen sesuai kebutuhan cetak
              </span>
            </div>

            <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-emerald-300">
              <button
                type="button"
                onClick={() => setOrientation("landscape")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  orientation === "landscape"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                Landscape (Melebar)
              </button>
              <button
                type="button"
                onClick={() => setOrientation("portrait")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  orientation === "portrait"
                    ? "bg-[#065f46] text-white shadow-xs"
                    : "text-slate-700 hover:text-slate-900"
                }`}
              >
                Portrait (Tegak)
              </button>
            </div>
          </div>

          {/* Ringkasan Dokumen Siap Cetak */}
          <div className="bg-slate-100 rounded-xl p-3 flex items-center justify-between text-xs">
            <div className="space-y-0.5">
              <span className="font-extrabold text-slate-900">
                Data Siap Dicetak:
              </span>
              <p className="text-[11px] text-slate-600">
                Target: {currentRombel?.nama || `Kelas ${filterKelas}`} • {previewData.count} Pertemuan ({previewData.totalJp} JP)
              </p>
            </div>
            <div className="text-right">
              <span className="font-mono text-[10px] text-emerald-950 font-bold bg-white px-2 py-1 rounded border border-slate-300">
                A4 • {orientation.toUpperCase()}
              </span>
            </div>
          </div>

        </div>

        {/* Footer Modal dengan Tombol Cetak PDF & Word */}
        <div className="bg-slate-50 border-t border-slate-200 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Batal
          </button>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handleExecuteWord}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Word (.doc)</span>
            </button>

            <button
              type="button"
              onClick={handleExecutePrint}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-md transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Cetak / Simpan PDF (A4)</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
