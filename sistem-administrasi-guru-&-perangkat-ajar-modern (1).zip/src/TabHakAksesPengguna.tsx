import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldCheck,
  UserPlus,
  Users,
  KeyRound,
  Lock,
  Unlock,
  Copy,
  Check,
  Edit3,
  Trash2,
  RefreshCw,
  Search,
  Download,
  Printer,
  FileSpreadsheet,
  Sparkles,
  AlertCircle,
  Eye,
  EyeOff,
  School,
  CheckCircle2,
  XCircle,
  Info,
  Calendar,
  Layers,
  ChevronRight,
  LayoutDashboard,
  FileText,
  BookOpen,
  BarChart3,
  Compass,
  CalendarCheck,
  CalendarRange,
  CalendarDays,
  BookCheck,
  UserCheck,
  Award,
  MoonStar,
  CheckSquare,
  Square
} from 'lucide-react';

// ==========================================
// TIPE DATA PENGGUNA & HAK AKSES
// ==========================================

export interface UserAccount {
  id: string;
  namaLengkap: string;
  namaSekolah: string;
  password: string; // Tepat 5 karakter kombinasi huruf kapital dan angka atau Dinamis
  role: "admin" | "guru";
  status: "aktif" | "nonaktif";
  createdAt: string;
  lastLogin?: string;
  keterangan?: string;
}

// Tipe Data Sekolah Terdaftar (Hanya sekolah yang terdaftar yang memiliki hak akses)
export interface RegisteredSchool {
  id: string;
  nama: string;
  npsn?: string;
  alamat?: string;
  tanggalDaftar: string;
  keterangan?: string;
  status: "aktif" | "nonaktif";
}

// ==========================================
// TIPE & DEFINISI KONTROL HAK AKSES MENU FITUR (NON-ADMIN)
// ==========================================

export interface AppMenuDefinition {
  id: string;
  nomor: string;
  label: string;
  kategori: "Utama" | "Perangkat Pembelajaran" | "Perencanaan" | "Pelaksanaan & Presensi" | "Evaluasi & Asesmen" | "Pengelolaan Data & Kegiatan";
  deskripsi: string;
  badge?: string;
  iconName?: string;
}

export const APP_MENU_DEFINITIONS: AppMenuDefinition[] = [
  { id: "beranda", nomor: "01", label: "Dashboard / Beranda Administrasi", kategori: "Utama", deskripsi: "Ringkasan administrasi, kalender kegiatan, dan navigasi cepat dokumen." },
  { id: "identitas", nomor: "02", label: "Profil Guru & Pengaturan Identitas", kategori: "Utama", deskripsi: "Profil guru, nama sekolah terdaftar (terkunci), NIP, dan kepala sekolah." },
  { id: "modul", nomor: "03", label: "Modul Ajar Deep Learning (78 Modul)", kategori: "Perangkat Pembelajaran", deskripsi: "78 Modul ajar lengkap 3 format pembelajaran mendalam (Kelas I-VI).", badge: "78 Modul" },
  { id: "materi-bab", nomor: "04", label: "Materi Pokok & Bab Pembelajaran", kategori: "Perangkat Pembelajaran", deskripsi: "Daftar Bab dan rincian materi per pertemuan PAI & BP.", badge: "Lengkap" },
  { id: "kokurikuler", nomor: "05", label: "Modul Projek Kokurikuler (P5-PPRA)", kategori: "Perangkat Pembelajaran", deskripsi: "12 Modul projek penguatan profil pelajar Pancasila & Rahmatan lil 'Alamin.", badge: "12 Modul" },
  { id: "analisis-cp", nomor: "06", label: "Analisis Capaian Pembelajaran (CP)", kategori: "Perencanaan", deskripsi: "Analisis pemetaan elemen CP ke tujuan pembelajaran (TP) dan alokasi JP." },
  { id: "atp", nomor: "07", label: "Alur Tujuan Pembelajaran (ATP)", kategori: "Perencanaan", deskripsi: "ATP komprehensif Fase A, B, dan C dilengkapi alur tujuan bertahap." },
  { id: "minggu-efektif", nomor: "08", label: "Rincian Minggu Efektif (RME)", kategori: "Perencanaan", deskripsi: "Perhitungan minggu efektif dan distribusi alokasi jam pembelajaran." },
  { id: "prota", nomor: "09", label: "Program Tahunan (PROTA)", kategori: "Perencanaan", deskripsi: "Program tahunan pembelajaran PAI & BP seluruh tingkatan kelas." },
  { id: "promes", nomor: "10", label: "Program Semester (PROMES)", kategori: "Perencanaan", deskripsi: "Distribusi materi dan jadwal pembelajaran semester ganjil dan genap." },
  { id: "jurnal-mengajar", nomor: "11", label: "Jurnal & Jadwal Mengajar Harian", kategori: "Pelaksanaan & Presensi", deskripsi: "Jurnal mengajar harian tersinkronisasi materi bab, rombel, dan presensi.", badge: "Terintegrasi" },
  { id: "absensi", nomor: "12", label: "Presensi & Absensi Siswa", kategori: "Pelaksanaan & Presensi", deskripsi: "Pencatatan kehadiran siswa mingguan terintegrasi langsung dengan jurnal.", badge: "Mingguan" },
  { id: "penilaian", nomor: "13", label: "Buku Nilai & Penilaian", kategori: "Evaluasi & Asesmen", deskripsi: "Nilai formatif, sumatif lingkup materi, asesmen sumatif, dan buku rapor.", badge: "Rapor" },
  { id: "upload-siswa", nomor: "14", label: "Upload Data Siswa (Excel)", kategori: "Pengelolaan Data & Kegiatan", deskripsi: "Unggah daftar siswa via file Excel dan kelola data murid per rombel.", badge: "Excel" },
  { id: "kktp", nomor: "15", label: "Kriteria Ketercapaian TP (KKTP)", kategori: "Evaluasi & Asesmen", deskripsi: "Interval nilai dan rubrik 4 kriteria ketercapaian tujuan pembelajaran." },
  { id: "remedial-pengayaan", nomor: "16", label: "Program Remedial & Pengayaan", kategori: "Evaluasi & Asesmen", deskripsi: "Perencanaan dan jurnal pelaksanaan tindak lanjut remedial & pengayaan." },
  { id: "program-keagamaan", nomor: "17", label: "Program Keagamaan Islam", kategori: "Pengelolaan Data & Kegiatan", deskripsi: "Program pembiasaan ibadah Jumat, sholat berjamaah, dan peringatan PHBI." }
];

export const DEFAULT_MENU_PERMISSIONS: Record<string, boolean> = {
  "beranda": true,
  "identitas": true,
  "modul": true,
  "materi-bab": true,
  "kokurikuler": true,
  "analisis-cp": true,
  "atp": true,
  "minggu-efektif": true,
  "prota": true,
  "promes": true,
  "jurnal-mengajar": true,
  "absensi": true,
  "penilaian": true,
  "upload-siswa": true,
  "kktp": true,
  "remedial-pengayaan": true,
  "program-keagamaan": true
};

// Daftar Sekolah Terdaftar Default Sistem (Otomatis Terdaftar & Aktif pada Seluruh Link Publish)
export const DEFAULT_REGISTERED_SCHOOLS: RegisteredSchool[] = [
  {
    id: "sch-cikud2",
    nama: "SD NEGERI CIKETING UDIK 2",
    npsn: "20223048",
    alamat: "Jl. Pangkalan 5, Ciketing Udik, Bantargebang, Kota Bekasi",
    tanggalDaftar: "01/07/2026",
    keterangan: "Sekolah Induk Administrator (SUHENDRI, S.Pd.I)",
    status: "aktif"
  },
  {
    id: "sch-cikud1",
    nama: "SD NEGERI CIKETING UDIK 1",
    npsn: "20223047",
    alamat: "Jl. Raya Narogong, Ciketing Udik, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-cikud3",
    nama: "SD NEGERI CIKETING UDIK 3",
    npsn: "20223049",
    alamat: "Jl. Pangkalan 2, Ciketing Udik, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-cikud4",
    nama: "SD NEGERI CIKETING UDIK 4",
    npsn: "20223050",
    alamat: "Jl. Pangkalan 4, Ciketing Udik, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-cikud5",
    nama: "SD NEGERI CIKETING UDIK 5",
    npsn: "20223051",
    alamat: "Jl. Pangkalan 1B, Ciketing Udik, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-btg1",
    nama: "SD NEGERI BANTARGEBANG 1",
    npsn: "20223052",
    alamat: "Jl. Raya Narogong Km 11, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-btg2",
    nama: "SD NEGERI BANTARGEBANG 2",
    npsn: "20223053",
    alamat: "Jl. Bantargebang Selatan, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-btg3",
    nama: "SD NEGERI BANTARGEBANG 3",
    npsn: "20223054",
    alamat: "Jl. Raya Siliwangi, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-btg4",
    nama: "SD NEGERI BANTARGEBANG 4",
    npsn: "20223055",
    alamat: "Jl. Perumahan Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-btg5",
    nama: "SD NEGERI BANTARGEBANG 5",
    npsn: "20223056",
    alamat: "Jl. Bantargebang Utara, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-sumbat1",
    nama: "SD NEGERI SUMUR BATU 1",
    npsn: "20223057",
    alamat: "Jl. Sumur Batu, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-sumbat2",
    nama: "SD NEGERI SUMUR BATU 2",
    npsn: "20223058",
    alamat: "Jl. Pangkalan 6, Sumur Batu, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  },
  {
    id: "sch-cikiw1",
    nama: "SD NEGERI CIKIWILEK 1",
    npsn: "20223059",
    alamat: "Jl. Cikiwul, Bantargebang, Kota Bekasi",
    tanggalDaftar: "15/07/2026",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  }
];

// Helper Mengambil dan Menggabungkan Daftar Sekolah Terdaftar
// Memastikan seluruh sekolah standar otomatis aktif di link publish/terbaru
// tanpa menimpa sekolah kustom baru atau memunculkan kembali sekolah yang pernah dihapus admin.
export const getInitialRegisteredSchools = (): RegisteredSchool[] => {
  try {
    // 1. Baca ID / nama sekolah yang pernah dihapus oleh Administrator
    let deletedIds: string[] = [];
    const savedDeleted = localStorage.getItem("perangkat_deleted_school_ids");
    if (savedDeleted) {
      try {
        deletedIds = JSON.parse(savedDeleted) || [];
      } catch {}
    }

    // 2. Filter sekolah default yang belum pernah dihapus oleh admin
    const activeDefaults = DEFAULT_REGISTERED_SCHOOLS.filter((sch) => {
      const normName = sch.nama.toLowerCase().replace(/[^a-z0-9]/g, "");
      return !deletedIds.includes(sch.id) && !deletedIds.includes(normName);
    });

    // 3. Baca sekolah yang tersimpan di localStorage
    const saved = localStorage.getItem("perangkat_registered_schools");
    if (!saved) {
      return activeDefaults;
    }

    const parsed = JSON.parse(saved);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return activeDefaults;
    }

    // 4. Gabungkan: Pertahankan status dan data yang ada di localStorage
    const mergedMap = new Map<string, RegisteredSchool>();

    // Tambahkan default aktif terlebih dahulu
    activeDefaults.forEach((sch) => {
      const norm = sch.nama.toLowerCase().replace(/[^a-z0-9]/g, "");
      mergedMap.set(norm, sch);
    });

    // Timpa/gabungkan dengan data yang ada di localStorage (termasuk sekolah kustom dan perubahan status)
    parsed.forEach((sch: RegisteredSchool) => {
      if (!sch || !sch.nama) return;
      const norm = sch.nama.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (!deletedIds.includes(sch.id) && !deletedIds.includes(norm)) {
        mergedMap.set(norm, sch);
      }
    });

    const result = Array.from(mergedMap.values());
    return result.length > 0 ? result : activeDefaults;
  } catch {
    return DEFAULT_REGISTERED_SCHOOLS;
  }
};

// Helper Password Dinamis Harian (Format TanggalBulanTahun ddmmyy, contoh: 081126)
export const getTodayPassword = (): string => {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, '0');
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const yy = String(now.getFullYear()).slice(-2);
  return `${dd}${mm}${yy}`;
};

// Helper Validasi Password Dinamis
export const isValidDailyPassword = (inputPass: string): boolean => {
  if (!inputPass) return false;
  const clean = inputPass.trim().replace(/[^0-9]/g, "");
  const today = getTodayPassword();
  if (clean === today) return true;

  // Cek jika mengetik format 8 digit (08112026)
  const now = new Date();
  const fullToday = `${String(now.getDate()).padStart(2, '0')}${String(now.getMonth() + 1).padStart(2, '0')}${now.getFullYear()}`;
  if (clean === fullToday) return true;

  // Toleransi 1 hari sebelumnya / setelahnya (jika selisih jam perangkat)
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const passY = `${String(yesterday.getDate()).padStart(2, '0')}${String(yesterday.getMonth() + 1).padStart(2, '0')}${String(yesterday.getFullYear()).slice(-2)}`;
  if (clean === passY) return true;

  const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const passT = `${String(tomorrow.getDate()).padStart(2, '0')}${String(tomorrow.getMonth() + 1).padStart(2, '0')}${String(tomorrow.getFullYear()).slice(-2)}`;
  if (clean === passT) return true;

  return false;
};

// Helper Deteksi Akun Administrator: SUHENDRI, S.Pd.I di SD NEGERI CIKETING UDIK 2
export const isMatchedAdmin = (guruName: string, sekolahName: string): boolean => {
  const gNorm = (guruName || "").toLowerCase().replace(/[\s\.\,]/g, "");
  const sNorm = (sekolahName || "").toLowerCase().replace(/[\s\.\,]/g, "");

  const isSuhendri = gNorm.includes("suhendri");
  const isCikud2 = sNorm.includes("ciketingudik2") || (sNorm.includes("ciketing") && sNorm.includes("2"));

  return isSuhendri && isCikud2;
};

// Helper Pencarian Sekolah yang Cocok dengan Input Guru (Toleran format SDN, SD Negeri, spasi, kapital, dan angka)
export const findMatchedSchool = (inputSchool: string, schools: RegisteredSchool[]): RegisteredSchool | undefined => {
  if (!inputSchool) return undefined;
  const clean = inputSchool.trim().toLowerCase();
  const stripped = clean.replace(/[^a-z0-9]/g, "");
  const normalized = clean.replace(/^(sd\s*n|sd\s*negeri|sdn)\b/i, "sd negeri").replace(/[^a-z0-9]/g, "");
  const numNorm = normalized.replace(/0+([1-9])/g, "$1");

  return schools.find((sch) => {
    const schClean = sch.nama.trim().toLowerCase();
    const schStripped = schClean.replace(/[^a-z0-9]/g, "");
    const schNorm = schClean.replace(/^(sd\s*n|sd\s*negeri|sdn)\b/i, "sd negeri").replace(/[^a-z0-9]/g, "");
    const schNumNorm = schNorm.replace(/0+([1-9])/g, "$1");

    return (
      clean === schClean ||
      stripped === schStripped ||
      normalized === schNorm ||
      numNorm === schNumNorm ||
      schClean.includes(clean) ||
      clean.includes(schClean)
    );
  });
};

// Generator Password Otomatis: 5 karakter kombinasi huruf kapital dan angka
export const generateRandomPassword5 = (): string => {
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const numbers = "23456789";
  const allChars = letters + numbers;

  let pwd = "";
  pwd += letters.charAt(Math.floor(Math.random() * letters.length));
  pwd += numbers.charAt(Math.floor(Math.random() * numbers.length));
  for (let i = 2; i < 5; i++) {
    pwd += allChars.charAt(Math.floor(Math.random() * allChars.length));
  }

  return pwd
    .split("")
    .sort(() => Math.random() - 0.5)
    .join("");
};

// Data Pengguna Default Sistem
export const DEFAULT_USER_ACCOUNTS: UserAccount[] = [
  {
    id: "admin-suhendri",
    namaLengkap: "SUHENDRI, S.Pd.I",
    namaSekolah: "SD NEGERI CIKETING UDIK 2",
    password: "Dinamis (Format ddmmyy)",
    role: "admin",
    status: "aktif",
    createdAt: "01/07/2026",
    lastLogin: "Hari Ini",
    keterangan: "Administrator Sistem Utama (Guru PAI & BP SD Negeri Ciketing Udik 2)"
  },
  {
    id: "usr-nurhasanah",
    namaLengkap: "Hj. Nurhasanah, S.Pd.",
    namaSekolah: "SD NEGERI CIKETING UDIK 2",
    password: "Dinamis (Format ddmmyy)",
    role: "guru",
    status: "aktif",
    createdAt: "15/07/2026",
    keterangan: "Guru PAI & BP Fase A (Kelas 1 & 2)"
  },
  {
    id: "usr-ahmadfauzi",
    namaLengkap: "Ahmad Fauzi, S.Pd.I",
    namaSekolah: "SD NEGERI CIKETING UDIK 2",
    password: "Dinamis (Format ddmmyy)",
    role: "guru",
    status: "aktif",
    createdAt: "18/07/2026",
    keterangan: "Guru PAI & BP Fase B (Kelas 3 & 4)"
  }
];

export interface TabHakAksesPenggunaProps {
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  currentUser?: {
    id: string;
    namaLengkap: string;
    namaSekolah: string;
    role: "admin" | "guru";
  } | null;
  registeredSchools?: RegisteredSchool[];
  setRegisteredSchools?: React.Dispatch<React.SetStateAction<RegisteredSchool[]>>;
  menuPermissions?: Record<string, boolean>;
  setMenuPermissions?: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId?: string, docTitle?: string, preferredOrientation?: "portrait" | "landscape") => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
}

export const TabHakAksesPengguna: React.FC<TabHakAksesPenggunaProps> = ({
  identitas,
  currentUser,
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  registeredSchools,
  setRegisteredSchools,
  menuPermissions,
  setMenuPermissions,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat
}) => {
  // State Daftar Sekolah Terdaftar (Hanya sekolah yang terdaftar yang memiliki hak akses)
  const [schools, setSchools] = useState<RegisteredSchool[]>(() => {
    if (registeredSchools && registeredSchools.length > 0) return registeredSchools;
    return getInitialRegisteredSchools();
  });

  // Sinkronisasi jika prop registeredSchools dari parent diperbarui
  useEffect(() => {
    if (registeredSchools && registeredSchools.length > 0) {
      setSchools(registeredSchools);
    }
  }, [registeredSchools]);

  // Sinkronisasi schools ke LocalStorage dan parent
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_registered_schools", JSON.stringify(schools));
      if (setRegisteredSchools) setRegisteredSchools(schools);
    } catch (e) {
      console.warn("Gagal menyimpan sekolah terdaftar:", e);
    }
  }, [schools, setRegisteredSchools]);

  // State Izin Akses Menu Fitur (Non-Admin / Saat Dishare)
  const [localMenuPermissions, setLocalMenuPermissions] = useState<Record<string, boolean>>(() => {
    if (menuPermissions) return menuPermissions;
    try {
      const saved = localStorage.getItem("perangkat_menu_permissions");
      if (saved) return { ...DEFAULT_MENU_PERMISSIONS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_MENU_PERMISSIONS;
  });

  // Sinkronisasi menuPermissions ke LocalStorage & parent
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_menu_permissions", JSON.stringify(localMenuPermissions));
      if (setMenuPermissions) setMenuPermissions(localMenuPermissions);
    } catch (e) {
      console.warn("Gagal menyimpan izin menu:", e);
    }
  }, [localMenuPermissions, setMenuPermissions]);

  // Statistik Menu Aktif / Terkunci untuk Guru Non-Admin
  const activeMenuCount = useMemo(() => {
    return APP_MENU_DEFINITIONS.filter((m) => localMenuPermissions[m.id] !== false).length;
  }, [localMenuPermissions]);

  const hiddenMenuCount = useMemo(() => {
    return APP_MENU_DEFINITIONS.length - activeMenuCount;
  }, [activeMenuCount]);

  // Sinkronisasi jika prop menuPermissions dari parent berubah
  useEffect(() => {
    if (menuPermissions) {
      setLocalMenuPermissions(menuPermissions);
    }
  }, [menuPermissions]);

  // Handler Toggle Izin Akses Menu
  const handleToggleMenu = (menuId: string) => {
    const currentStatus = localMenuPermissions[menuId] !== false;
    const nextStatus = !currentStatus;
    const updated = {
      ...localMenuPermissions,
      [menuId]: nextStatus
    };
    try {
      localStorage.setItem("perangkat_menu_permissions", JSON.stringify(updated));
    } catch {}
    setLocalMenuPermissions(updated);
    if (setMenuPermissions) {
      setMenuPermissions(updated);
    }
    const label = APP_MENU_DEFINITIONS.find((m) => m.id === menuId)?.label || menuId;
    showToast(`Menu "${label}" ${nextStatus ? "diaktifkan untuk guru & share" : "dinonaktifkan (disembunyikan dari guru)"}.`);
  };

  const handleEnableAllMenus = () => {
    const allEnabled: Record<string, boolean> = {};
    APP_MENU_DEFINITIONS.forEach((m) => { allEnabled[m.id] = true; });
    try {
      localStorage.setItem("perangkat_menu_permissions", JSON.stringify(allEnabled));
    } catch {}
    setLocalMenuPermissions(allEnabled);
    if (setMenuPermissions) {
      setMenuPermissions(allEnabled);
    }
    showToast("Seluruh 17 fitur menu telah diaktifkan untuk guru & share!");
  };

  const handleDisableAllMenus = () => {
    const allDisabled: Record<string, boolean> = {};
    APP_MENU_DEFINITIONS.forEach((m) => {
      allDisabled[m.id] = m.id === "beranda"; // Dashboard tetap aktif
    });
    try {
      localStorage.setItem("perangkat_menu_permissions", JSON.stringify(allDisabled));
    } catch {}
    setLocalMenuPermissions(allDisabled);
    if (setMenuPermissions) {
      setMenuPermissions(allDisabled);
    }
    showToast("Semua fitur menu dinonaktifkan untuk non-admin (kecuali Dashboard).");
  };

  const handleResetMenuPermissions = () => {
    try {
      localStorage.setItem("perangkat_menu_permissions", JSON.stringify(DEFAULT_MENU_PERMISSIONS));
    } catch {}
    setLocalMenuPermissions(DEFAULT_MENU_PERMISSIONS);
    if (setMenuPermissions) {
      setMenuPermissions(DEFAULT_MENU_PERMISSIONS);
    }
    showToast("Pengaturan hak akses menu dikembalikan ke default.");
  };

  // Subtab Aktif: "sekolah" (Kelola Sekolah Terdaftar) | "menu" (Hak Akses Menu Fitur) | "pengguna" (Data Pengguna & Password)
  const [activeSection, setActiveSection] = useState<"sekolah" | "menu" | "pengguna">("sekolah");

  // State Modal Tambah / Edit Sekolah
  const [showSchoolModal, setShowSchoolModal] = useState(false);
  const [editingSchoolId, setEditingSchoolId] = useState<string | null>(null);
  const [formSchool, setFormSchool] = useState<{
    nama: string;
    npsn: string;
    alamat: string;
    keterangan: string;
    status: "aktif" | "nonaktif";
  }>({
    nama: "",
    npsn: "",
    alamat: "",
    keterangan: "Satuan Pendidikan Terdaftar",
    status: "aktif"
  });

  // Modal Konfirmasi Hapus Sekolah
  const [deleteSchoolDialog, setDeleteSchoolDialog] = useState<{
    show: boolean;
    school: RegisteredSchool | null;
  }>({
    show: false,
    school: null
  });

  // State Daftar Akun Pengguna (Persisten di LocalStorage)
  const [users, setUsers] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem("perangkat_user_accounts");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_USER_ACCOUNTS;
  });

  // Simpan perubahan ke LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem("perangkat_user_accounts", JSON.stringify(users));
    } catch (e) {
      console.warn("Gagal menyimpan akun pengguna:", e);
    }
  }, [users]);

  // State Filter & Pencarian
  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState<"semua" | "admin" | "guru">("semua");
  const [filterStatus, setFilterStatus] = useState<"semua" | "aktif" | "nonaktif">("semua");

  // State Visibility Password di Tabel
  const [showAllPasswords, setShowAllPasswords] = useState(false);
  const [revealedPasswordId, setRevealedPasswordId] = useState<string | null>(null);

  // State Modal Tambah / Edit Pengguna
  const [showModal, setShowModal] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [formData, setFormData] = useState<{
    namaLengkap: string;
    namaSekolah: string;
    password: string;
    role: "admin" | "guru";
    status: "aktif" | "nonaktif";
    keterangan: string;
  }>({
    namaLengkap: "",
    namaSekolah: identitas.sekolah || "SD Negeri Ciketing Udik 2",
    password: generateRandomPassword5(),
    role: "guru",
    status: "aktif",
    keterangan: "Guru Mata Pelajaran PAI & BP"
  });

  // Modal Konfirmasi Hapus
  const [deleteDialog, setDeleteDialog] = useState<{
    show: boolean;
    user: UserAccount | null;
  }>({
    show: false,
    user: null
  });

  // ==========================================
  // HANDLERS KELOLA SEKOLAH TERDAFTAR (ADMIN)
  // ==========================================
  const handleOpenAddSchool = () => {
    setEditingSchoolId(null);
    setFormSchool({
      nama: "",
      npsn: "",
      alamat: "",
      keterangan: "Satuan Pendidikan Terdaftar",
      status: "aktif"
    });
    setShowSchoolModal(true);
  };

  const handleOpenEditSchool = (sch: RegisteredSchool) => {
    setEditingSchoolId(sch.id);
    setFormSchool({
      nama: sch.nama,
      npsn: sch.npsn || "",
      alamat: sch.alamat || "",
      keterangan: sch.keterangan || "",
      status: sch.status
    });
    setShowSchoolModal(true);
  };

  const handleSaveSchool = (e: React.FormEvent) => {
    e.preventDefault();
    const namaClean = formSchool.nama.trim().toUpperCase();
    if (!namaClean) {
      showToast("Nama sekolah wajib diisi!");
      return;
    }

    if (editingSchoolId) {
      setSchools((prev) =>
        prev.map((s) =>
          s.id === editingSchoolId
            ? {
                ...s,
                nama: namaClean,
                npsn: formSchool.npsn.trim(),
                alamat: formSchool.alamat.trim(),
                keterangan: formSchool.keterangan.trim(),
                status: formSchool.status
              }
            : s
        )
      );
      showToast(`Data sekolah "${namaClean}" berhasil diperbarui.`);
    } else {
      const already = schools.some(
        (s) => s.nama.trim().toLowerCase() === namaClean.toLowerCase()
      );
      if (already) {
        showToast(`Sekolah "${namaClean}" sudah terdaftar sebelumnya.`);
        return;
      }

      // Hapus dari daftar sekolah terhapus jika sebelumnya pernah dihapus
      try {
        const savedDeleted = localStorage.getItem("perangkat_deleted_school_ids");
        if (savedDeleted) {
          const deletedIds: string[] = JSON.parse(savedDeleted);
          const normName = namaClean.toLowerCase().replace(/[^a-z0-9]/g, "");
          const filtered = deletedIds.filter((id) => id !== normName);
          localStorage.setItem("perangkat_deleted_school_ids", JSON.stringify(filtered));
        }
      } catch {}

      const newSch: RegisteredSchool = {
        id: `sch-${Date.now().toString(36)}`,
        nama: namaClean,
        npsn: formSchool.npsn.trim(),
        alamat: formSchool.alamat.trim(),
        tanggalDaftar: new Date().toLocaleDateString("id-ID"),
        keterangan: formSchool.keterangan.trim() || "Satuan Pendidikan Terdaftar",
        status: formSchool.status
      };
      setSchools((prev) => [...prev, newSch]);
      showToast(`Sekolah "${namaClean}" berhasil didaftarkan! Guru sekolah ini kini dapat login.`);
    }

    setShowSchoolModal(false);
  };

  const handleToggleSchoolStatus = (sch: RegisteredSchool) => {
    if (sch.nama.toUpperCase().includes("CIKETING UDIK 2")) {
      showToast("Sekolah Induk Administrator tidak dapat dinonaktifkan!");
      return;
    }
    const nextStatus = sch.status === "aktif" ? "nonaktif" : "aktif";
    setSchools((prev) =>
      prev.map((s) => (s.id === sch.id ? { ...s, status: nextStatus } : s))
    );
    showToast(`Status sekolah "${sch.nama}" diubah menjadi: ${nextStatus === "aktif" ? "AKTIF" : "NONAKTIF"}`);
  };

  const handleRequestDeleteSchool = (sch: RegisteredSchool) => {
    if (sch.nama.toUpperCase().includes("CIKETING UDIK 2")) {
      showToast("Sekolah Induk Administrator (SD NEGERI CIKETING UDIK 2) tidak boleh dihapus!");
      return;
    }
    setDeleteSchoolDialog({ show: true, school: sch });
  };

  const executeDeleteSchool = () => {
    if (!deleteSchoolDialog.school) return;
    const sch = deleteSchoolDialog.school;
    const schName = sch.nama;

    // Catat ID dan nama yang dinormalisasi ke deletedSchoolIds di localStorage agar tidak otomatis muncul kembali
    try {
      const savedDeleted = localStorage.getItem("perangkat_deleted_school_ids");
      const deletedIds: string[] = savedDeleted ? JSON.parse(savedDeleted) : [];
      const normName = sch.nama.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (!deletedIds.includes(sch.id)) deletedIds.push(sch.id);
      if (!deletedIds.includes(normName)) deletedIds.push(normName);
      localStorage.setItem("perangkat_deleted_school_ids", JSON.stringify(deletedIds));
    } catch {}

    setSchools((prev) => prev.filter((s) => s.id !== sch.id));
    setDeleteSchoolDialog({ show: false, school: null });
    showToast(`Sekolah "${schName}" berhasil dihapus dari daftar hak akses.`);
  };

  // Pulihkan seluruh daftar sekolah standar ke kondisi awal aktif
  const handleRestoreDefaultSchools = () => {
    try {
      localStorage.removeItem("perangkat_deleted_school_ids");
      localStorage.setItem("perangkat_registered_schools", JSON.stringify(DEFAULT_REGISTERED_SCHOOLS));
    } catch {}
    setSchools(DEFAULT_REGISTERED_SCHOOLS);
    if (setRegisteredSchools) setRegisteredSchools(DEFAULT_REGISTERED_SCHOOLS);
    showToast("Seluruh daftar sekolah standar (Ciketing Udik 1-5, Bantargebang, dsb) berhasil dipulihkan & aktif!");
  };

  // Salin Kredensial ke Clipboard
  const handleCopyCredentials = (user: UserAccount) => {
    const text =
      `*KREDENSIAL LOGIN PORTAL ADMINISTRASI GURU PAI & BP*\n` +
      `--------------------------------------------------\n` +
      `👤 Nama Pengguna : ${user.namaLengkap}\n` +
      `🏫 Nama Sekolah  : ${user.namaSekolah}\n` +
      `🔑 Password Akses : ${user.password} (5 Karakter Kapital/Angka)\n` +
      `🛡️ Peran Akun    : ${user.role === "admin" ? "Administrator" : "Guru PAI & BP"}\n` +
      `📌 Status Akun   : ${user.status === "aktif" ? "Aktif (Diberi Akses)" : "Nonaktif (Terkunci)"}\n` +
      `--------------------------------------------------\n` +
      `Gunakan nama, sekolah, dan password di atas untuk masuk ke sistem.`;

    navigator.clipboard.writeText(text);
    showToast(`Kredensial login untuk ${user.namaLengkap} berhasil disalin! Siap dikirim ke guru.`);
  };

  // Buka Modal Tambah Pengguna
  const handleOpenAddModal = () => {
    setEditingUserId(null);
    setFormData({
      namaLengkap: "",
      namaSekolah: identitas.sekolah || "SD Negeri Ciketing Udik 2",
      password: generateRandomPassword5(),
      role: "guru",
      status: "aktif",
      keterangan: "Guru Mata Pelajaran PAI & BP"
    });
    setShowModal(true);
  };

  // Buka Modal Edit Pengguna
  const handleOpenEditModal = (user: UserAccount) => {
    setEditingUserId(user.id);
    setFormData({
      namaLengkap: user.namaLengkap,
      namaSekolah: user.namaSekolah,
      password: user.password,
      role: user.role,
      status: user.status,
      keterangan: user.keterangan || ""
    });
    setShowModal(true);
  };

  // Simpan Form (Tambah / Edit)
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    const nama = formData.namaLengkap.trim();
    const sekolah = formData.namaSekolah.trim();
    const pass = formData.password.trim().toUpperCase();

    if (!nama) {
      showToast("Nama lengkap pengguna wajib diisi.");
      return;
    }
    if (!sekolah) {
      showToast("Nama sekolah wajib diisi.");
      return;
    }
    if (pass.length !== 5) {
      showToast("Password harus tepat 5 karakter kombinasi huruf kapital dan angka!");
      return;
    }

    if (editingUserId) {
      // Edit User
      setUsers((prev) =>
        prev.map((u) =>
          u.id === editingUserId
            ? {
                ...u,
                namaLengkap: nama,
                namaSekolah: sekolah,
                password: pass,
                role: formData.role,
                status: formData.status,
                keterangan: formData.keterangan
              }
            : u
        )
      );
      showToast(`Data pengguna ${nama} berhasil diperbarui.`);
    } else {
      // Tambah User Baru
      const newUser: UserAccount = {
        id: `usr-${Date.now().toString(36)}`,
        namaLengkap: nama,
        namaSekolah: sekolah,
        password: pass,
        role: formData.role,
        status: formData.status,
        createdAt: new Date().toLocaleDateString("id-ID"),
        keterangan: formData.keterangan
      };
      setUsers((prev) => [...prev, newUser]);
      showToast(`Pengguna baru ${nama} berhasil ditambahkan dengan password ${pass}!`);
    }

    setShowModal(false);
  };

  // Toggle Status Aktif / Nonaktif
  const handleToggleStatus = (user: UserAccount) => {
    if (user.role === "admin" && user.id === "admin-master") {
      showToast("Akun Administrator Utama tidak boleh dinonaktifkan!");
      return;
    }

    const nextStatus = user.status === "aktif" ? "nonaktif" : "aktif";
    setUsers((prev) =>
      prev.map((u) => (u.id === user.id ? { ...u, status: nextStatus } : u))
    );

    showToast(
      `Status pengguna ${user.namaLengkap} diubah menjadi: ${
        nextStatus === "aktif" ? "AKTIF (Bisa Login)" : "NONAKTIF (Akses Dikunci)"
      }`
    );
  };

  // Reset Password Cepat (Generate 5 Karakter Acak Baru)
  const handleQuickResetPassword = (user: UserAccount) => {
    const newPass = generateRandomPassword5();
    setUsers((prev) =>
      prev.map((u) => (u.id === user.id ? { ...u, password: newPass } : u))
    );
    showToast(`Password untuk ${user.namaLengkap} di-reset menjadi: ${newPass}`);
  };

  // Hapus User
  const handleRequestDelete = (user: UserAccount) => {
    if (user.role === "admin" && user.id === "admin-master") {
      showToast("Akun Administrator Utama tidak boleh dihapus!");
      return;
    }
    setDeleteDialog({ show: true, user });
  };

  const executeDelete = () => {
    if (!deleteDialog.user) return;
    const name = deleteDialog.user.namaLengkap;
    setUsers((prev) => prev.filter((u) => u.id !== deleteDialog.user?.id));
    showToast(`Pengguna ${name} berhasil dihapus.`);
    setDeleteDialog({ show: false, user: null });
  };

  // Filter Data Pengguna
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const matchRole = filterRole === "semua" || u.role === filterRole;
      const matchStatus = filterStatus === "semua" || u.status === filterStatus;
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !searchQuery.trim() ||
        u.namaLengkap.toLowerCase().includes(q) ||
        u.namaSekolah.toLowerCase().includes(q) ||
        u.password.toLowerCase().includes(q);
      return matchRole && matchStatus && matchSearch;
    });
  }, [users, filterRole, filterStatus, searchQuery]);

  // Statistik Ringkas
  const stats = useMemo(() => {
    const total = users.length;
    const aktif = users.filter((u) => u.status === "aktif").length;
    const nonaktif = users.filter((u) => u.status === "nonaktif").length;
    const adminCount = users.filter((u) => u.role === "admin").length;
    const guruCount = users.filter((u) => u.role === "guru").length;
    return { total, aktif, nonaktif, adminCount, guruCount };
  }, [users]);

  // Ekspor CSV
  const handleExportCsv = () => {
    const headers = ["No", "Nama Lengkap", "Nama Sekolah", "Role", "Password", "Status", "Tanggal Dibuat", "Keterangan"];
    const rows = filteredUsers.map((u, idx) => [
      idx + 1,
      `"${u.namaLengkap}"`,
      `"${u.namaSekolah}"`,
      u.role.toUpperCase(),
      `"${u.password}"`,
      u.status.toUpperCase(),
      `"${u.createdAt}"`,
      `"${u.keterangan || "-"}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Daftar_Hak_Akses_Pengguna_PAI_${identitas.sekolah.replace(/\s+/g, "_")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Berkas daftar pengguna CSV berhasil diunduh!");
  };

  return (
    <div className="space-y-6">
      {/* ======================================================== */}
      {/* HEADER & TOOLBAR HAK AKSES PENGGUNA                      */}
      {/* ======================================================== */}
      <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 no-print text-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-200 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-950 border border-emerald-300 mb-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
              <span>Menu Khusus Administrator • Kontrol Akses &amp; Keamanan Aplikasi</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2.5">
              <KeyRound className="w-5 h-5 text-emerald-700" />
              <span>Hak Akses Pengguna &amp; Kelola Sekolah Terdaftar</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5 font-medium">
              Aplikasi diamankan secara terpusat: <strong>hanya sekolah yang didaftarkan oleh Administrator yang diizinkan mengakses portal</strong>. Password dinamis harian format tanggalbulantahun ({getTodayPassword()}) berlaku untuk seluruh pengguna.
            </p>
          </div>

          {/* Tombol Aksi Sesuai Subtab */}
          <div className="flex flex-wrap items-center gap-2">
            {activeSection === "sekolah" && (
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleOpenAddSchool}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 transition-all cursor-pointer"
                >
                  <School className="w-4 h-4 text-emerald-200" />
                  <span>+ Daftarkan Sekolah Baru</span>
                </button>
                <button
                  type="button"
                  onClick={handleRestoreDefaultSchools}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
                  title="Pulihkan dan aktifkan seluruh daftar sekolah standar (SDN Ciketing Udik 1-5, dsb)"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-emerald-700" />
                  <span>↺ Pulihkan Sekolah Standar</span>
                </button>
              </div>
            )}

            {activeSection === "menu" && (
              <>
                <button
                  type="button"
                  onClick={handleEnableAllMenus}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 transition-all cursor-pointer"
                >
                  <CheckSquare className="w-4 h-4 text-emerald-200" />
                  <span>✓ Centang Semua</span>
                </button>
                <button
                  type="button"
                  onClick={handleDisableAllMenus}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 shadow-xs transition-all cursor-pointer"
                >
                  <Square className="w-4 h-4 text-rose-600" />
                  <span>✕ Nonaktifkan Semua</span>
                </button>
              </>
            )}

            {activeSection === "pengguna" && (
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 transition-all cursor-pointer"
              >
                <UserPlus className="w-4 h-4 text-emerald-200" />
                <span>+ Tambah Pengguna Baru</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>Ekspor Excel (.csv)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                handleDownloadWord(
                  "printable-hak-akses-area",
                  `Rekap_Hak_Akses_${identitas.sekolah.replace(/\s+/g, "_")}`,
                  true
                )
              }
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Unduh Word (.doc)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                handlePrintDocument(
                  "printable-hak-akses-area",
                  `Rekap_Hak_Akses_${identitas.sekolah.replace(/\s+/g, "_")}`,
                  "landscape"
                )
              }
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Simpan PDF (A4)</span>
            </button>
          </div>
        </div>

        {/* Tab Selector: 1. Kelola Sekolah vs 2. Hak Akses Menu Fitur vs 3. Data Pengguna Guru */}
        <div className="flex flex-col sm:flex-row items-stretch p-1 bg-emerald-50 rounded-2xl border-2 border-emerald-300 gap-1">
          <button
            type="button"
            onClick={() => setActiveSection("sekolah")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeSection === "sekolah"
                ? "bg-[#065f46] text-white shadow-md shadow-emerald-950/20"
                : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100"
            }`}
          >
            <School className="w-4 h-4 shrink-0" />
            <span>1. Kelola Sekolah ({schools.length})</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${activeSection === "sekolah" ? "bg-white/20 text-white" : "bg-emerald-200 text-emerald-950"}`}>
              Izin Login
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection("menu")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeSection === "menu"
                ? "bg-[#065f46] text-white shadow-md shadow-emerald-950/20"
                : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100"
            }`}
          >
            <Layers className="w-4 h-4 shrink-0" />
            <span>2. Hak Akses Menu Fitur</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${activeSection === "menu" ? "bg-white/20 text-white" : "bg-emerald-200 text-emerald-950"}`}>
              {activeMenuCount} Aktif
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection("pengguna")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeSection === "pengguna"
                ? "bg-[#065f46] text-white shadow-md shadow-emerald-950/20"
                : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100"
            }`}
          >
            <Users className="w-4 h-4 shrink-0" />
            <span>3. Pengguna Guru ({users.length})</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${activeSection === "pengguna" ? "bg-white/20 text-white" : "bg-emerald-200 text-emerald-950"}`}>
              Riwayat
            </span>
          </button>
        </div>

        {/* Tampilan Sesuai Subtab Aktif */}
        {activeSection === "sekolah" && (
          <div className="space-y-4 pt-1">
            {/* Kartu Statistik Sekolah Terdaftar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Total Sekolah Terdaftar</span>
                <span className="text-lg font-extrabold text-emerald-800">{schools.length} Sekolah</span>
              </div>
              <div className="bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Akses Aktif (Bisa Login)</span>
                <span className="text-lg font-extrabold text-emerald-700">{schools.filter(s => s.status === "aktif").length} Sekolah</span>
              </div>
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-amber-900 uppercase font-extrabold">Password Dinamis Hari Ini</span>
                <span className="text-base font-extrabold text-amber-900 font-mono tracking-wider mt-0.5 block">{getTodayPassword()}</span>
                <span className="text-[10px] text-amber-700 font-semibold block">Format: ddmmyy</span>
              </div>
              <div className="bg-slate-50 border-2 border-slate-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-slate-700 uppercase font-extrabold">Akun Administrator</span>
                <span className="text-xs font-extrabold text-slate-900 mt-1 block">SUHENDRI, S.Pd.I</span>
                <span className="text-[10px] text-emerald-800 font-semibold block">SD NEGERI CIKETING UDIK 2</span>
              </div>
            </div>

            {/* Box Info Aturan Hak Akses Login */}
            <div className="p-4 bg-emerald-50/80 border-2 border-emerald-300 rounded-2xl text-xs space-y-2">
              <div className="flex items-center gap-2 text-emerald-950 font-extrabold">
                <Info className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Aturan Hak Akses Login Portal Administrasi:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-700 leading-relaxed pl-1">
                <li>
                  <strong>Hanya Sekolah Terdaftar:</strong> Pengguna hanya bisa login jika nama sekolah yang diinputkan sesuai dengan daftar sekolah terdaftar di bawah ini.
                </li>
                <li>
                  <strong>Nama Guru Dinamis:</strong> Guru dari sekolah terdaftar bebas menginputkan nama lengkap masing-masing saat login.
                </li>
                <li>
                  <strong>Password Dinamis:</strong> Password login harian otomatis mengikuti tanggal hari ini dengan format tanggalbulantahun (contoh hari ini: <span className="font-mono font-bold text-emerald-900 bg-white px-2 py-0.5 rounded border border-emerald-300">{getTodayPassword()}</span>).
                </li>
                <li>
                  <strong>Admin Otomatis:</strong> Administrator login langsung menggunakan nama guru <strong>"SUHENDRI, S.Pd.I"</strong> dan nama sekolah <strong>"SD NEGERI CIKETING UDIK 2"</strong> dengan password dinamis harian yang sama, tanpa memerlukan menu login terpisah.
                </li>
              </ul>
            </div>
          </div>
        )}

        {activeSection === "menu" && (
          <div className="space-y-4 pt-1">
            {/* Kartu Statistik Menu Fitur Non-Admin */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Total Menu Aplikasi</span>
                <span className="text-lg font-extrabold text-emerald-800">{APP_MENU_DEFINITIONS.length} Menu</span>
              </div>
              <div className="bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Aktif untuk Guru &amp; Share</span>
                <span className="text-lg font-extrabold text-emerald-700">{activeMenuCount} Menu Aktif</span>
              </div>
              <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-rose-900 uppercase font-extrabold">Menu Disembunyikan</span>
                <span className="text-lg font-extrabold text-rose-700">{hiddenMenuCount} Menu Dikunci</span>
              </div>
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-amber-900 uppercase font-extrabold">Hak Akses Administrator</span>
                <span className="text-xs font-extrabold text-amber-900 block mt-1">100% Akses Penuh</span>
                <span className="text-[10px] text-amber-700 font-semibold block">Admin selalu melihat seluruh menu</span>
              </div>
            </div>

            {/* Box Penjelasan Kontrol Tanda Centang Menu */}
            <div className="p-4 bg-emerald-50/80 border-2 border-emerald-300 rounded-2xl text-xs space-y-2">
              <div className="flex items-center gap-2 text-emerald-950 font-extrabold">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Petunjuk Kontrol Tanda Centang Menu Fitur untuk Guru &amp; Link Share:</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                Beri tanda centang <strong>[✓]</strong> pada menu yang ingin Anda aktifkan sehingga dapat diakses oleh guru saat login atau ketika aplikasi di-share. Hapus tanda centang <strong>[ ]</strong> untuk menyembunyikan menu tersebut dari pengguna non-admin. Administrator (SUHENDRI, S.Pd.I) selalu memiliki akses penuh ke seluruh menu aplikasi.
              </p>
            </div>
          </div>
        )}

        {activeSection === "pengguna" && (
          <div className="space-y-4 pt-1">
            {/* Kartu Statistik Akses Pengguna */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#e6f7ef] border-2 border-emerald-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Total Pengguna</span>
                <span className="text-lg font-extrabold text-emerald-800">{stats.total} Akun</span>
              </div>
              <div className="bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-emerald-900 uppercase font-extrabold">Akses Aktif (Bisa Masuk)</span>
                <span className="text-lg font-extrabold text-emerald-700">{stats.aktif} Akun</span>
              </div>
              <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-rose-900 uppercase font-extrabold">Akses Terkunci (Nonaktif)</span>
                <span className="text-lg font-extrabold text-rose-700">{stats.nonaktif} Akun</span>
              </div>
              <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-3 text-center">
                <span className="block text-[10px] text-amber-900 uppercase font-extrabold">Password Dinamis Harian</span>
                <span className="text-sm font-extrabold text-amber-800 font-mono mt-1 block">{getTodayPassword()}</span>
              </div>
            </div>

            {/* Filter & Pencarian Pengguna */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari berdasarkan nama guru, sekolah, atau keterangan..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-900"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-300 text-xs">
                  <span className="text-slate-600 font-bold px-1">Peran:</span>
                  {(["semua", "guru", "admin"] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setFilterRole(r)}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                        filterRole === r ? "bg-[#065f46] text-white shadow-xs" : "text-slate-700 hover:text-slate-900"
                      }`}
                    >
                      {r === "semua" ? "Semua" : r === "guru" ? "Guru PAI" : "Admin"}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-300 text-xs">
                  <span className="text-slate-600 font-bold px-1">Status:</span>
                  {(["semua", "aktif", "nonaktif"] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setFilterStatus(s)}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                        filterStatus === s ? "bg-[#065f46] text-white shadow-xs" : "text-slate-700 hover:text-slate-900"
                      }`}
                    >
                      {s === "semua" ? "Semua" : s === "aktif" ? "Aktif" : "Nonaktif"}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setShowAllPasswords(!showAllPasswords)}
                  className="px-3 py-2 rounded-xl text-xs font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                  title="Tampilkan atau sembunyikan seluruh password"
                >
                  {showAllPasswords ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-emerald-700" />}
                  <span>{showAllPasswords ? "Sembunyikan Password" : "Lihat Password"}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* SUBTAB 1: TABEL SEKOLAH TERDAFTAR (ADMIN BISA INPUT)     */}
      {/* ======================================================== */}
      {activeSection === "sekolah" && (
        <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 overflow-hidden no-print text-slate-800">
          <div className="bg-[#065f46] text-white px-5 py-3 font-extrabold text-xs sm:text-sm flex items-center justify-between">
            <div className="flex items-center gap-2">
              <School className="w-4 h-4 text-emerald-200" />
              <span>Daftar Satuan Pendidikan yang Memiliki Hak Akses Login</span>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-xs font-bold">
              {schools.length} Sekolah Terdaftar
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-emerald-100/80 text-emerald-950 font-extrabold border-b border-emerald-300">
                  <th className="px-3 py-3 text-center w-[5%]">No</th>
                  <th className="px-4 py-3 text-left w-[32%]">Nama Sekolah / Satuan Pendidikan</th>
                  <th className="px-3 py-3 text-center w-[15%]">NPSN</th>
                  <th className="px-4 py-3 text-left w-[25%]">Alamat / Wilayah</th>
                  <th className="px-3 py-3 text-center w-[11%]">Status Akses</th>
                  <th className="px-3 py-3 text-center w-[12%]">Aksi Administrator</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-emerald-200 bg-white">
                {schools.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500 italic">
                      Belum ada sekolah yang didaftarkan. Klik tombol "+ Daftarkan Sekolah Baru" di atas.
                    </td>
                  </tr>
                ) : (
                  schools.map((sch, idx) => {
                    const isPrimaryAdminSchool = sch.nama.toUpperCase().includes("CIKETING UDIK 2");

                    return (
                      <tr
                        key={sch.id}
                        className={`hover:bg-emerald-50/60 transition-colors ${
                          sch.status === "nonaktif" ? "bg-rose-50/40" : ""
                        }`}
                      >
                        <td className="px-3 py-3 text-center font-bold text-slate-700">{idx + 1}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-extrabold text-slate-900 text-sm">{sch.nama}</span>
                            {isPrimaryAdminSchool && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-950 border border-amber-300">
                                Sekolah Induk Admin
                              </span>
                            )}
                          </div>
                          {sch.keterangan && (
                            <p className="text-[11px] text-slate-500 mt-0.5">{sch.keterangan}</p>
                          )}
                          <div className="text-[10px] text-emerald-800 font-semibold mt-0.5">
                            Terdaftar: {sch.tanggalDaftar}
                          </div>
                        </td>
                        <td className="px-3 py-3 text-center font-mono font-bold text-slate-800">
                          {sch.npsn || "-"}
                        </td>
                        <td className="px-4 py-3 text-slate-700 text-xs">
                          {sch.alamat || "Kota Bekasi"}
                        </td>
                        <td className="px-3 py-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleSchoolStatus(sch)}
                            className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition-all cursor-pointer flex items-center justify-center gap-1 mx-auto ${
                              sch.status === "aktif"
                                ? "bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200"
                                : "bg-rose-100 text-rose-900 border-rose-300 hover:bg-rose-200"
                            }`}
                            title={`Klik untuk ${sch.status === "aktif" ? "menonaktifkan izin akses" : "mengaktifkan izin akses"}`}
                          >
                            {sch.status === "aktif" ? (
                              <>
                                <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                                <span>Aktif (Diizinkan)</span>
                              </>
                            ) : (
                              <>
                                <XCircle className="w-3 h-3 text-rose-700" />
                                <span>Nonaktif (Dikunci)</span>
                              </>
                            )}
                          </button>
                        </td>
                        <td className="px-3 py-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenEditSchool(sch)}
                              className="p-1.5 rounded-lg text-amber-700 hover:bg-amber-100 border border-amber-200 cursor-pointer"
                              title="Edit data sekolah terdaftar"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRequestDeleteSchool(sch)}
                              disabled={isPrimaryAdminSchool}
                              className={`p-1.5 rounded-lg border transition-colors ${
                                isPrimaryAdminSchool
                                  ? "text-slate-300 border-slate-200 cursor-not-allowed"
                                  : "text-rose-700 hover:bg-rose-100 border-rose-200 cursor-pointer"
                              }`}
                              title={isPrimaryAdminSchool ? "Sekolah induk admin tidak boleh dihapus" : "Hapus sekolah ini"}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUBTAB: KONTROL HAK AKSES MENU FITUR (TANDA CENTANG)     */}
      {/* ======================================================== */}
      {activeSection === "menu" && (
        <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 overflow-hidden no-print text-slate-800 space-y-4 p-5">
          {/* Header Action Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-200 pb-4">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-700" />
                <span>Pengaturan Menu Fitur yang Diaktifkan (Guru &amp; Link Share)</span>
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Admin dapat memilih mengaktifkan atau menonaktifkan fitur menu dengan tanda centang <strong>[✓]</strong>.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleEnableAllMenus}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-[#065f46] text-white hover:bg-emerald-800 transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
                title="Aktifkan seluruh menu untuk guru"
              >
                <CheckSquare className="w-3.5 h-3.5" />
                <span>✓ Centang Semua</span>
              </button>
              <button
                type="button"
                onClick={handleDisableAllMenus}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white text-rose-700 border border-rose-300 hover:bg-rose-50 transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
                title="Nonaktifkan semua menu kecuali Beranda"
              >
                <Square className="w-3.5 h-3.5" />
                <span>✕ Nonaktifkan Semua</span>
              </button>
              <button
                type="button"
                onClick={handleResetMenuPermissions}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Kembalikan ke pengaturan standar"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>↺ Reset Standar</span>
              </button>
            </div>
          </div>

          {/* Grid Checklist Menu Fitur */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {APP_MENU_DEFINITIONS.map((menu) => {
              const isChecked = localMenuPermissions[menu.id] !== false;
              return (
                <div
                  key={menu.id}
                  onClick={() => handleToggleMenu(menu.id)}
                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3 select-none relative group ${
                    isChecked
                      ? "bg-[#e6f7ef] border-emerald-400 shadow-xs hover:border-emerald-600"
                      : "bg-slate-50 border-slate-300 opacity-75 hover:opacity-100 hover:border-slate-400"
                  }`}
                >
                  <div className="pt-0.5">
                    <input
                      type="checkbox"
                      id={`chk-menu-${menu.id}`}
                      checked={isChecked}
                      onChange={() => handleToggleMenu(menu.id)}
                      onClick={(e) => e.stopPropagation()}
                      className="w-5 h-5 text-emerald-700 rounded-md border-2 border-emerald-500 cursor-pointer accent-[#065f46]"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <label
                        htmlFor={`chk-menu-${menu.id}`}
                        className="font-extrabold text-xs text-slate-900 cursor-pointer leading-tight"
                      >
                        {menu.nomor}. {menu.label}
                      </label>
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-md font-bold uppercase tracking-wider shrink-0 border ${
                          isChecked
                            ? "bg-emerald-100 text-emerald-900 border-emerald-300"
                            : "bg-rose-100 text-rose-900 border-rose-300"
                        }`}
                      >
                        {isChecked ? "✓ Aktif" : "✕ Dikunci"}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[10px] font-semibold text-emerald-900 bg-white/80 px-1.5 py-0.5 rounded border border-emerald-200">
                        {menu.kategori}
                      </span>
                      {menu.badge && (
                        <span className="text-[10px] font-bold text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-300">
                          {menu.badge}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-600 mt-1.5 leading-snug">
                      {menu.deskripsi}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Info Footer */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p>
                <strong>Status Akses Administrator:</strong> Administrator (<strong>SUHENDRI, S.Pd.I</strong> di <strong>SD NEGERI CIKETING UDIK 2</strong>) memiliki akses penuh ke seluruh 17 menu dan Menu Khusus Administrator #18 "Hak Akses Pengguna &amp; Sekolah".
              </p>
              <p className="text-[11px] text-slate-500">
                Menu yang tidak dicentang otomatis disembunyikan dari sidebar navigasi dan dashboard bagi guru non-admin dan pengguna yang membuka link share.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUBTAB 3: TABEL MANAJEMEN PENGGUNA & PASSWORD             */}
      {/* ======================================================== */}

      {activeSection === "pengguna" && (
        <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 overflow-hidden no-print text-slate-800">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="bg-[#065f46] text-white font-bold">
                <th className="px-3 py-3 text-center w-[4%]">No</th>
                <th className="px-4 py-3 text-left w-[24%]">Nama Pengguna / Guru</th>
                <th className="px-4 py-3 text-left w-[22%]">Nama Sekolah</th>
                <th className="px-3 py-3 text-center w-[15%]">Password (5 Karakter)</th>
                <th className="px-3 py-3 text-center w-[10%]">Peran</th>
                <th className="px-3 py-3 text-center w-[10%]">Status Akses</th>
                <th className="px-3 py-3 text-center w-[15%]">Aksi Administrator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-emerald-200">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500 italic">
                    Tidak ditemukan pengguna yang sesuai dengan filter atau kata kunci pencarian.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user, idx) => {
                  const isVisible = showAllPasswords || revealedPasswordId === user.id;

                  return (
                    <tr
                      key={user.id}
                      className={`hover:bg-emerald-50/70 transition-colors ${
                        user.status === "nonaktif" ? "bg-rose-50/40" : ""
                      }`}
                    >
                      <td className="px-3 py-3 text-center font-bold text-slate-700">{idx + 1}</td>
                      <td className="px-4 py-3 text-left">
                        <div className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                          <span>{user.namaLengkap}</span>
                          {user.role === "admin" && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded font-extrabold bg-amber-400 text-slate-950">
                              Admin
                            </span>
                          )}
                        </div>
                        {user.keterangan && (
                          <div className="text-[11px] text-slate-600 mt-0.5">{user.keterangan}</div>
                        )}
                        <div className="text-[10px] text-slate-400 mt-0.5">Dibuat: {user.createdAt}</div>
                      </td>
                      <td className="px-4 py-3 text-left font-semibold text-slate-800">
                        <div className="flex items-center gap-1.5">
                          <School className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                          <span>{user.namaSekolah}</span>
                        </div>
                      </td>

                      {/* KOLOM PASSWORD 5 KARAKTER KAPITAL & ANGKA */}
                      <td className="px-3 py-3 text-center">
                        <div className="inline-flex items-center gap-1.5 bg-slate-100 border border-slate-300 px-2.5 py-1.5 rounded-xl">
                          <span className="font-mono font-extrabold text-sm tracking-widest text-emerald-950">
                            {isVisible ? user.password : "•••••"}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setRevealedPasswordId(revealedPasswordId === user.id ? null : user.id)
                            }
                            className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                            title={isVisible ? "Sembunyikan password" : "Lihat password"}
                          >
                            {isVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleQuickResetPassword(user)}
                            className="p-1 text-emerald-700 hover:text-emerald-950 cursor-pointer"
                            title="Generate ulang password 5 karakter baru secara acak"
                          >
                            <RefreshCw className="w-3.5 h-3.5 text-emerald-700 hover:rotate-180 transition-transform" />
                          </button>
                        </div>
                      </td>

                      <td className="px-3 py-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                            user.role === "admin"
                              ? "bg-amber-100 text-amber-950 border border-amber-300"
                              : "bg-emerald-100 text-emerald-950 border border-emerald-300"
                          }`}
                        >
                          {user.role === "admin" ? "ADMINISTRATOR" : "GURU PAI"}
                        </span>
                      </td>

                      <td className="px-3 py-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(user)}
                          className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition-all cursor-pointer flex items-center justify-center gap-1 mx-auto ${
                            user.status === "aktif"
                              ? "bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200"
                              : "bg-rose-100 text-rose-900 border-rose-300 hover:bg-rose-200"
                          }`}
                          title={`Klik untuk ${user.status === "aktif" ? "menonaktifkan (kunci akses)" : "mengaktifkan kembali"}`}
                        >
                          {user.status === "aktif" ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                              <span>Aktif</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3 h-3 text-rose-700" />
                              <span>Nonaktif</span>
                            </>
                          )}
                        </button>
                      </td>

                      <td className="px-3 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {/* Salin Kredensial */}
                          <button
                            type="button"
                            onClick={() => handleCopyCredentials(user)}
                            className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-100 border border-emerald-200 cursor-pointer"
                            title="Salin Nama, Sekolah, dan Password untuk dikirim ke guru"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit User */}
                          <button
                            type="button"
                            onClick={() => handleOpenEditModal(user)}
                            className="p-1.5 rounded-lg text-amber-700 hover:bg-amber-100 border border-amber-200 cursor-pointer"
                            title="Ubah data pengguna / atur password"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          {/* Hapus User */}
                          <button
                            type="button"
                            onClick={() => handleRequestDelete(user)}
                            className="p-1.5 rounded-lg text-rose-700 hover:bg-rose-100 border border-rose-200 cursor-pointer"
                            title="Hapus akun pengguna"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      )}

      {/* ======================================================== */}
      {/* MODAL TAMBAH / EDIT SEKOLAH TERDAFTAR                    */}
      {/* ======================================================== */}
      {showSchoolModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border-2 border-emerald-500 space-y-5 animate-scaleIn text-slate-800">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl border border-emerald-300">
                  <School className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    {editingSchoolId ? "Ubah Data Sekolah Terdaftar" : "Daftarkan Nama Sekolah Baru"}
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    Sekolah yang terdaftar di sini dapat langsung digunakan guru untuk login.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSchoolModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSchool} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nama Satuan Pendidikan / Sekolah (Wajib):
                </label>
                <input
                  type="text"
                  required
                  value={formSchool.nama}
                  onChange={(e) => setFormSchool({ ...formSchool, nama: e.target.value.toUpperCase() })}
                  placeholder="Contoh: SD NEGERI BANTARGEBANG 1"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-bold uppercase focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    NPSN (Nomor Pokok Sekolah):
                  </label>
                  <input
                    type="text"
                    value={formSchool.npsn}
                    onChange={(e) => setFormSchool({ ...formSchool, npsn: e.target.value })}
                    placeholder="Contoh: 20223048"
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-semibold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Status Hak Akses:
                  </label>
                  <select
                    value={formSchool.status}
                    onChange={(e) => setFormSchool({ ...formSchool, status: e.target.value as any })}
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-bold focus:outline-none"
                  >
                    <option value="aktif">Aktif (Diizinkan Login)</option>
                    <option value="nonaktif">Nonaktif (Akses Dikunci)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Alamat / Wilayah:
                </label>
                <input
                  type="text"
                  value={formSchool.alamat}
                  onChange={(e) => setFormSchool({ ...formSchool, alamat: e.target.value })}
                  placeholder="Contoh: Jl. Pangkalan 5, Bantargebang, Kota Bekasi"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-medium focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Keterangan Tambahan:
                </label>
                <input
                  type="text"
                  value={formSchool.keterangan}
                  onChange={(e) => setFormSchool({ ...formSchool, keterangan: e.target.value })}
                  placeholder="Contoh: Satuan Pendidikan Binaan Dinas Pendidikan"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-medium focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowSchoolModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 flex items-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4 text-emerald-200" />
                  <span>{editingSchoolId ? "Perbarui Sekolah" : "Daftarkan Sekolah"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL KONFIRMASI HAPUS SEKOLAH TERDAFTAR                 */}
      {/* ======================================================== */}
      {deleteSchoolDialog.show && deleteSchoolDialog.school && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 no-print">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border-2 border-rose-400 space-y-4 animate-scaleIn text-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-rose-100 text-rose-700 rounded-2xl">
                <AlertCircle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900">Konfirmasi Hapus Sekolah</h4>
                <p className="text-xs text-slate-600 mt-0.5">Tindakan ini akan mencabut izin akses.</p>
              </div>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              Apakah Anda yakin ingin menghapus <strong>{deleteSchoolDialog.school.nama}</strong> dari daftar sekolah terdaftar? Guru dari sekolah ini tidak akan dapat login lagi ke portal.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeleteSchoolDialog({ show: false, school: null })}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDeleteSchool}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Sekolah</span>
              </button>
            </div>
          </div>
        </div>
      )}
      {/* MODAL TAMBAH / EDIT PENGGUNA & PASSWORD GENERATOR        */}
      {/* ======================================================== */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border-2 border-emerald-500 space-y-5 animate-scaleIn text-slate-800">
            <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl border border-emerald-300">
                  <KeyRound className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    {editingUserId ? "Ubah Data & Password Pengguna" : "Tambah Pengguna Baru & Atur Password"}
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    Password otomatis diatur secara sistem acak (5 karakter huruf kapital &amp; angka).
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nama Pengguna / Nama Lengkap Guru:
                </label>
                <input
                  type="text"
                  required
                  value={formData.namaLengkap}
                  onChange={(e) => setFormData({ ...formData, namaLengkap: e.target.value })}
                  placeholder="Contoh: Dra. Siti Masitoh, M.Pd.I"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nama Sekolah / Satuan Pendidikan:
                </label>
                <input
                  type="text"
                  required
                  value={formData.namaSekolah}
                  onChange={(e) => setFormData({ ...formData, namaSekolah: e.target.value })}
                  placeholder="Contoh: SD Negeri Ciketing Udik 2"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* GENERATOR PASSWORD 5 KARAKTER */}
              <div className="p-3.5 bg-[#e6f7ef] border-2 border-emerald-300 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-extrabold text-emerald-950 uppercase tracking-wider">
                    Password Sistem (5 Karakter Huruf Kapital &amp; Angka):
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const newP = generateRandomPassword5();
                      setFormData({ ...formData, password: newP });
                      showToast(`Password acak baru dibuat: ${newP}`);
                    }}
                    className="text-[11px] font-bold text-emerald-900 hover:text-white bg-white hover:bg-emerald-700 border border-emerald-400 px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                    title="Generate ulang password acak baru"
                  >
                    <RefreshCw className="w-3 h-3 text-emerald-700 hover:rotate-180" />
                    <span>🎲 Acak Password Baru</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={5}
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value.toUpperCase() })}
                    placeholder="Contoh: 7K9X2"
                    className="flex-1 text-center font-mono text-base font-extrabold tracking-widest px-3 py-2 rounded-xl bg-white border-2 border-emerald-400 text-emerald-950 focus:ring-2 focus:ring-emerald-500 focus:outline-none uppercase"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(formData.password);
                      showToast(`Password ${formData.password} disalin ke clipboard!`);
                    }}
                    className="px-3 py-2 rounded-xl text-xs font-bold bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-100 flex items-center gap-1 cursor-pointer shadow-xs"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Salin</span>
                  </button>
                </div>
                <p className="text-[10.5px] text-slate-600 font-medium">
                  Sistem otomatis men-generate 5 karakter acak. Anda juga dapat mengubah kode ini secara manual (harus tepat 5 huruf kapital &amp; angka).
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Peran Pengguna:
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-bold focus:outline-none"
                  >
                    <option value="guru">Guru PAI &amp; BP</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Status Akses:
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-bold focus:outline-none"
                  >
                    <option value="aktif">Aktif (Bisa Login)</option>
                    <option value="nonaktif">Nonaktif (Akses Dikunci)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Keterangan / Catatan Admin:
                </label>
                <input
                  type="text"
                  value={formData.keterangan}
                  onChange={(e) => setFormData({ ...formData, keterangan: e.target.value })}
                  placeholder="Contoh: Guru PAI Kelas 3 & 4, NIP. 1985..."
                  className="w-full text-xs px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-medium focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-md shadow-emerald-950/20 flex items-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4 text-emerald-200" />
                  <span>{editingUserId ? "Perbarui Pengguna" : "Simpan Pengguna & Password"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL KONFIRMASI HAPUS                                   */}
      {/* ======================================================== */}
      {deleteDialog.show && deleteDialog.user && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 no-print">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border-2 border-rose-400 space-y-4 animate-scaleIn text-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-rose-100 text-rose-700 rounded-2xl">
                <AlertCircle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900">Konfirmasi Hapus Akun</h4>
                <p className="text-xs text-slate-600 mt-0.5">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              Apakah Anda yakin ingin menghapus akun pengguna <strong>{deleteDialog.user.namaLengkap}</strong> ({deleteDialog.user.namaSekolah})? Guru bersangkutan tidak akan dapat masuk ke sistem lagi.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeleteDialog({ show: false, user: null })}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeDelete}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Akun</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* LEMBAR DOKUMEN CETAK RESMI: REKAP HAK AKSES PENGGUNA     */}
      {/* ======================================================== */}
      <div
        id="printable-hak-akses-area"
        style={paperLightMode ? { padding: "2cm 1.8cm 2cm 2.2cm" } : undefined}
        className={`rounded-2xl border p-6 sm:p-8 transition-colors duration-300 overflow-x-auto ${docContainerClass} official-doc-typography hidden`}
      >
        {/* KOP SURAT RESMI */}
        {useKopSurat && kopSuratUrl && (
          <div className="kop-surat-header mb-4 text-center">
            <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
            <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
          </div>
        )}

        {/* Header Dokumen */}
        <div className="doc-header-box text-center border-b-2 pb-4 mb-6 border-black">
          <h2 className="doc-main-title text-xl sm:text-[15pt] font-bold uppercase tracking-wide text-center" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            REKAPITULASI HAK AKSES DAN PASSWORD PENGGUNA APLIKASI
          </h2>
          <h3 className="doc-sub-title text-sm sm:text-[13pt] font-bold uppercase tracking-wider text-center text-black" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            SISTEM ADMINISTRASI PEMBELAJARAN PAI &amp; BUDI PEKERTI SD
          </h3>
          <p className="text-xs sm:text-[11pt] font-semibold text-center mt-1" style={{ margin: "2pt 0 0 0" }}>
            KURIKULUM MERDEKA • PUSAT KONTROL ADMINISTRATOR
          </p>
        </div>

        {/* Identitas Dokumen */}
        <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-2xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Satuan Pendidikan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.sekolah}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Tahun Ajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.tahunAjaran}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Format Password Sistem</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">5 Karakter Acak Kombinasi Huruf Kapital &amp; Angka</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-48 font-bold shrink-0">Total Pengguna Terdaftar</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{users.length} Akun ({stats.aktif} Aktif, {stats.nonaktif} Nonaktif)</span>
          </div>
        </div>

        {/* Tabel Cetak */}
        <div className="overflow-x-auto print:overflow-visible">
          <table className={`w-full border-collapse border ${tableBorderClass}`} style={{ borderCollapse: 'collapse', width: '100%', fontSize: '10pt' }}>
            <thead>
              <tr className={tableHeaderBgClass}>
                <th className={`border px-2 py-2 text-center font-bold w-[5%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>No</th>
                <th className={`border px-3 py-2 text-left font-bold w-[30%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'left' }}>Nama Pengguna / Guru</th>
                <th className={`border px-3 py-2 text-left font-bold w-[25%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'left' }}>Nama Sekolah</th>
                <th className={`border px-2 py-2 text-center font-bold w-[15%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>Password (5 Karakter)</th>
                <th className={`border px-2 py-2 text-center font-bold w-[12%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>Peran</th>
                <th className={`border px-2 py-2 text-center font-bold w-[13%] ${tableBorderClass}`} style={{ border: '1px solid #000000', verticalAlign: 'middle', textAlign: 'center' }}>Status Akses</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u, idx) => (
                <tr key={u.id} className="keep-together">
                  <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>{idx + 1}</td>
                  <td className={`border px-3 py-2 font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'left' }}>
                    {u.namaLengkap}
                    {u.keterangan && <div className="text-[8.5pt] font-normal text-slate-600">{u.keterangan}</div>}
                  </td>
                  <td className={`border px-3 py-2 ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'left' }}>{u.namaSekolah}</td>
                  <td className={`border px-2 py-2 text-center font-mono font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center', letterSpacing: '2px' }}>
                    {u.password}
                  </td>
                  <td className={`border px-2 py-2 text-center ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center' }}>
                    {u.role === "admin" ? "ADMINISTRATOR" : "GURU PAI"}
                  </td>
                  <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`} style={{ border: '1px solid #000000', textAlign: 'center', color: u.status === "aktif" ? '#047857' : '#b91c1c' }}>
                    {u.status === "aktif" ? "AKTIF" : "NONAKTIF"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Tanda Tangan Pengesahan Resmi */}
        <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <tbody>
            <tr style={{ border: 'none', background: 'transparent' }}>
              <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
              </td>
              <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Administrator Sistem Aplikasi</p>
                <div style={{ height: "70px", minHeight: "70px" }}></div>
                <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>
                  {currentUser?.namaLengkap || "Administrator Sistem"}
                </p>
                <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>ID: ADMIN-SYS-PAI</p>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
